echo script type: T
echo ">>>>>>>>running test 1"
../source/print_tokens.c.inst.exe  < ../inputs/newtst148.tst > ../newoutputs/t1
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/0.tr
echo ">>>>>>>>running test 2"
../source/print_tokens.c.inst.exe  < ../inputs/newtst1.tst > ../newoutputs/t2
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1.tr
echo ">>>>>>>>running test 3"
../source/print_tokens.c.inst.exe  < ../inputs/newtst1.tst.tst > ../newoutputs/t3
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2.tr
echo ">>>>>>>>running test 4"
../source/print_tokens.c.inst.exe  < ../inputs/newtst10.tst > ../newoutputs/t4
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3.tr
echo ">>>>>>>>running test 5"
../source/print_tokens.c.inst.exe  < ../inputs/newtst100.tst > ../newoutputs/t5
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4.tr
echo ">>>>>>>>running test 6"
../source/print_tokens.c.inst.exe  < ../inputs/newtst101.tst > ../newoutputs/t6
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/5.tr
echo ">>>>>>>>running test 7"
../source/print_tokens.c.inst.exe  < ../inputs/newtst102.tst > ../newoutputs/t7
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/6.tr
echo ">>>>>>>>running test 8"
../source/print_tokens.c.inst.exe  < ../inputs/newtst103.tst > ../newoutputs/t8
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/7.tr
echo ">>>>>>>>running test 9"
../source/print_tokens.c.inst.exe  < ../inputs/newtst104.tst > ../newoutputs/t9
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/8.tr
echo ">>>>>>>>running test 10"
../source/print_tokens.c.inst.exe  < ../inputs/newtst105.tst > ../newoutputs/t10
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/9.tr
echo ">>>>>>>>running test 11"
../source/print_tokens.c.inst.exe  < ../inputs/newtst106.tst > ../newoutputs/t11
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/10.tr
echo ">>>>>>>>running test 12"
../source/print_tokens.c.inst.exe  < ../inputs/newtst107.tst > ../newoutputs/t12
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/11.tr
echo ">>>>>>>>running test 13"
../source/print_tokens.c.inst.exe  < ../inputs/newtst108.tst > ../newoutputs/t13
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/12.tr
echo ">>>>>>>>running test 14"
../source/print_tokens.c.inst.exe  < ../inputs/newtst109.tst > ../newoutputs/t14
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/13.tr
echo ">>>>>>>>running test 15"
../source/print_tokens.c.inst.exe  < ../inputs/newtst11.tst > ../newoutputs/t15
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/14.tr
echo ">>>>>>>>running test 16"
../source/print_tokens.c.inst.exe  < ../inputs/newtst110.tst > ../newoutputs/t16
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/15.tr
echo ">>>>>>>>running test 17"
../source/print_tokens.c.inst.exe  < ../inputs/newtst111.tst > ../newoutputs/t17
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/16.tr
echo ">>>>>>>>running test 18"
../source/print_tokens.c.inst.exe  < ../inputs/newtst112.tst > ../newoutputs/t18
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/17.tr
echo ">>>>>>>>running test 19"
../source/print_tokens.c.inst.exe  < ../inputs/newtst113.tst > ../newoutputs/t19
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/18.tr
echo ">>>>>>>>running test 20"
../source/print_tokens.c.inst.exe  < ../inputs/newtst114.tst > ../newoutputs/t20
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/19.tr
echo ">>>>>>>>running test 21"
../source/print_tokens.c.inst.exe  < ../inputs/newtst115.tst > ../newoutputs/t21
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/20.tr
echo ">>>>>>>>running test 22"
../source/print_tokens.c.inst.exe  < ../inputs/newtst116.tst > ../newoutputs/t22
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/21.tr
echo ">>>>>>>>running test 23"
../source/print_tokens.c.inst.exe  < ../inputs/newtst117.tst > ../newoutputs/t23
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/22.tr
echo ">>>>>>>>running test 24"
../source/print_tokens.c.inst.exe  < ../inputs/newtst118.tst > ../newoutputs/t24
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/23.tr
echo ">>>>>>>>running test 25"
../source/print_tokens.c.inst.exe  < ../inputs/newtst119.tst > ../newoutputs/t25
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/24.tr
echo ">>>>>>>>running test 26"
../source/print_tokens.c.inst.exe  < ../inputs/newtst12.tst > ../newoutputs/t26
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/25.tr
echo ">>>>>>>>running test 27"
../source/print_tokens.c.inst.exe  < ../inputs/newtst120.tst > ../newoutputs/t27
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/26.tr
echo ">>>>>>>>running test 28"
../source/print_tokens.c.inst.exe  < ../inputs/newtst121.tst > ../newoutputs/t28
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/27.tr
echo ">>>>>>>>running test 29"
../source/print_tokens.c.inst.exe  < ../inputs/newtst122.tst > ../newoutputs/t29
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/28.tr
echo ">>>>>>>>running test 30"
../source/print_tokens.c.inst.exe  < ../inputs/newtst123.tst > ../newoutputs/t30
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/29.tr
echo ">>>>>>>>running test 31"
../source/print_tokens.c.inst.exe  < ../inputs/newtst124.tst > ../newoutputs/t31
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/30.tr
echo ">>>>>>>>running test 32"
../source/print_tokens.c.inst.exe  < ../inputs/newtst125.tst > ../newoutputs/t32
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/31.tr
echo ">>>>>>>>running test 33"
../source/print_tokens.c.inst.exe  < ../inputs/newtst126.tst > ../newoutputs/t33
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/32.tr
echo ">>>>>>>>running test 34"
../source/print_tokens.c.inst.exe  < ../inputs/newtst127.tst > ../newoutputs/t34
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/33.tr
echo ">>>>>>>>running test 35"
../source/print_tokens.c.inst.exe  < ../inputs/newtst128.tst > ../newoutputs/t35
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/34.tr
echo ">>>>>>>>running test 36"
../source/print_tokens.c.inst.exe  < ../inputs/newtst129.tst > ../newoutputs/t36
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/35.tr
echo ">>>>>>>>running test 37"
../source/print_tokens.c.inst.exe  < ../inputs/newtst13.tst > ../newoutputs/t37
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/36.tr
echo ">>>>>>>>running test 38"
../source/print_tokens.c.inst.exe  < ../inputs/newtst130.tst > ../newoutputs/t38
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/37.tr
echo ">>>>>>>>running test 39"
../source/print_tokens.c.inst.exe  < ../inputs/newtst131.tst > ../newoutputs/t39
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/38.tr
echo ">>>>>>>>running test 40"
../source/print_tokens.c.inst.exe  < ../inputs/newtst132.tst > ../newoutputs/t40
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/39.tr
echo ">>>>>>>>running test 41"
../source/print_tokens.c.inst.exe  < ../inputs/newtst133.tst > ../newoutputs/t41
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/40.tr
echo ">>>>>>>>running test 42"
../source/print_tokens.c.inst.exe  < ../inputs/newtst134.tst > ../newoutputs/t42
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/41.tr
echo ">>>>>>>>running test 43"
../source/print_tokens.c.inst.exe  < ../inputs/newtst135.tst > ../newoutputs/t43
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/42.tr
echo ">>>>>>>>running test 44"
../source/print_tokens.c.inst.exe  < ../inputs/newtst136.tst > ../newoutputs/t44
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/43.tr
echo ">>>>>>>>running test 45"
../source/print_tokens.c.inst.exe  < ../inputs/newtst137.tst > ../newoutputs/t45
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/44.tr
echo ">>>>>>>>running test 46"
../source/print_tokens.c.inst.exe  < ../inputs/newtst138.tst > ../newoutputs/t46
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/45.tr
echo ">>>>>>>>running test 47"
../source/print_tokens.c.inst.exe  < ../inputs/newtst139.tst > ../newoutputs/t47
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/46.tr
echo ">>>>>>>>running test 48"
../source/print_tokens.c.inst.exe  < ../inputs/newtst14.tst > ../newoutputs/t48
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/47.tr
echo ">>>>>>>>running test 49"
../source/print_tokens.c.inst.exe  < ../inputs/newtst140.tst > ../newoutputs/t49
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/48.tr
echo ">>>>>>>>running test 50"
../source/print_tokens.c.inst.exe  < ../inputs/newtst141.tst > ../newoutputs/t50
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/49.tr
echo ">>>>>>>>running test 51"
../source/print_tokens.c.inst.exe  < ../inputs/newtst142.tst > ../newoutputs/t51
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/50.tr
echo ">>>>>>>>running test 52"
../source/print_tokens.c.inst.exe  < ../inputs/newtst143.tst > ../newoutputs/t52
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/51.tr
echo ">>>>>>>>running test 53"
../source/print_tokens.c.inst.exe  < ../inputs/newtst144.tst > ../newoutputs/t53
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/52.tr
echo ">>>>>>>>running test 54"
../source/print_tokens.c.inst.exe  < ../inputs/newtst145.tst > ../newoutputs/t54
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/53.tr
echo ">>>>>>>>running test 55"
../source/print_tokens.c.inst.exe  < ../inputs/newtst146.tst > ../newoutputs/t55
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/54.tr
echo ">>>>>>>>running test 56"
../source/print_tokens.c.inst.exe  < ../inputs/newtst147.tst > ../newoutputs/t56
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/55.tr
echo ">>>>>>>>running test 57"
../source/print_tokens.c.inst.exe  < ../inputs/newtst149.tst > ../newoutputs/t57
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/56.tr
echo ">>>>>>>>running test 58"
../source/print_tokens.c.inst.exe  < ../inputs/newtst15.tst > ../newoutputs/t58
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/57.tr
echo ">>>>>>>>running test 59"
../source/print_tokens.c.inst.exe  < ../inputs/newtst150.tst > ../newoutputs/t59
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/58.tr
echo ">>>>>>>>running test 60"
../source/print_tokens.c.inst.exe  < ../inputs/newtst151.tst > ../newoutputs/t60
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/59.tr
echo ">>>>>>>>running test 61"
../source/print_tokens.c.inst.exe  < ../inputs/newtst152.tst > ../newoutputs/t61
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/60.tr
echo ">>>>>>>>running test 62"
../source/print_tokens.c.inst.exe  < ../inputs/newtst153.tst > ../newoutputs/t62
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/61.tr
echo ">>>>>>>>running test 63"
../source/print_tokens.c.inst.exe  < ../inputs/newtst154.tst > ../newoutputs/t63
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/62.tr
echo ">>>>>>>>running test 64"
../source/print_tokens.c.inst.exe  < ../inputs/newtst155.tst > ../newoutputs/t64
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/63.tr
echo ">>>>>>>>running test 65"
../source/print_tokens.c.inst.exe  < ../inputs/newtst156.tst > ../newoutputs/t65
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/64.tr
echo ">>>>>>>>running test 66"
../source/print_tokens.c.inst.exe  < ../inputs/newtst157.tst > ../newoutputs/t66
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/65.tr
echo ">>>>>>>>running test 67"
../source/print_tokens.c.inst.exe  < ../inputs/newtst158.tst > ../newoutputs/t67
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/66.tr
echo ">>>>>>>>running test 68"
../source/print_tokens.c.inst.exe  < ../inputs/newtst159.tst > ../newoutputs/t68
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/67.tr
echo ">>>>>>>>running test 69"
../source/print_tokens.c.inst.exe  < ../inputs/newtst16.tst > ../newoutputs/t69
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/68.tr
echo ">>>>>>>>running test 70"
../source/print_tokens.c.inst.exe  < ../inputs/newtst160.tst > ../newoutputs/t70
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/69.tr
echo ">>>>>>>>running test 71"
../source/print_tokens.c.inst.exe  < ../inputs/newtst161.tst > ../newoutputs/t71
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/70.tr
echo ">>>>>>>>running test 72"
../source/print_tokens.c.inst.exe  < ../inputs/newtst162.tst > ../newoutputs/t72
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/71.tr
echo ">>>>>>>>running test 73"
../source/print_tokens.c.inst.exe  < ../inputs/newtst163.tst > ../newoutputs/t73
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/72.tr
echo ">>>>>>>>running test 74"
../source/print_tokens.c.inst.exe  < ../inputs/newtst164.tst > ../newoutputs/t74
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/73.tr
echo ">>>>>>>>running test 75"
../source/print_tokens.c.inst.exe  < ../inputs/newtst165.tst > ../newoutputs/t75
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/74.tr
echo ">>>>>>>>running test 76"
../source/print_tokens.c.inst.exe  < ../inputs/newtst166.tst > ../newoutputs/t76
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/75.tr
echo ">>>>>>>>running test 77"
../source/print_tokens.c.inst.exe  < ../inputs/newtst167.tst > ../newoutputs/t77
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/76.tr
echo ">>>>>>>>running test 78"
../source/print_tokens.c.inst.exe  < ../inputs/newtst168.tst > ../newoutputs/t78
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/77.tr
echo ">>>>>>>>running test 79"
../source/print_tokens.c.inst.exe  < ../inputs/newtst169.tst > ../newoutputs/t79
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/78.tr
echo ">>>>>>>>running test 80"
../source/print_tokens.c.inst.exe  < ../inputs/newtst17.tst > ../newoutputs/t80
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/79.tr
echo ">>>>>>>>running test 81"
../source/print_tokens.c.inst.exe  < ../inputs/newtst170.tst > ../newoutputs/t81
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/80.tr
echo ">>>>>>>>running test 82"
../source/print_tokens.c.inst.exe  < ../inputs/newtst171.tst > ../newoutputs/t82
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/81.tr
echo ">>>>>>>>running test 83"
../source/print_tokens.c.inst.exe  < ../inputs/newtst172.tst > ../newoutputs/t83
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/82.tr
echo ">>>>>>>>running test 84"
../source/print_tokens.c.inst.exe  < ../inputs/newtst173.tst > ../newoutputs/t84
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/83.tr
echo ">>>>>>>>running test 85"
../source/print_tokens.c.inst.exe  < ../inputs/newtst174.tst > ../newoutputs/t85
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/84.tr
echo ">>>>>>>>running test 86"
../source/print_tokens.c.inst.exe  < ../inputs/newtst175.tst > ../newoutputs/t86
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/85.tr
echo ">>>>>>>>running test 87"
../source/print_tokens.c.inst.exe  < ../inputs/newtst176.tst > ../newoutputs/t87
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/86.tr
echo ">>>>>>>>running test 88"
../source/print_tokens.c.inst.exe  < ../inputs/newtst177.tst > ../newoutputs/t88
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/87.tr
echo ">>>>>>>>running test 89"
../source/print_tokens.c.inst.exe  < ../inputs/newtst178.tst > ../newoutputs/t89
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/88.tr
echo ">>>>>>>>running test 90"
../source/print_tokens.c.inst.exe  < ../inputs/newtst179.tst > ../newoutputs/t90
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/89.tr
echo ">>>>>>>>running test 91"
../source/print_tokens.c.inst.exe  < ../inputs/newtst18.tst > ../newoutputs/t91
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/90.tr
echo ">>>>>>>>running test 92"
../source/print_tokens.c.inst.exe  < ../inputs/newtst180.tst > ../newoutputs/t92
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/91.tr
echo ">>>>>>>>running test 93"
../source/print_tokens.c.inst.exe  < ../inputs/newtst181.tst > ../newoutputs/t93
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/92.tr
echo ">>>>>>>>running test 94"
../source/print_tokens.c.inst.exe  < ../inputs/newtst182.tst > ../newoutputs/t94
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/93.tr
echo ">>>>>>>>running test 95"
../source/print_tokens.c.inst.exe  < ../inputs/newtst183.tst > ../newoutputs/t95
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/94.tr
echo ">>>>>>>>running test 96"
../source/print_tokens.c.inst.exe  < ../inputs/newtst184.tst > ../newoutputs/t96
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/95.tr
echo ">>>>>>>>running test 97"
../source/print_tokens.c.inst.exe  < ../inputs/newtst185.tst > ../newoutputs/t97
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/96.tr
echo ">>>>>>>>running test 98"
../source/print_tokens.c.inst.exe  < ../inputs/newtst186.tst > ../newoutputs/t98
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/97.tr
echo ">>>>>>>>running test 99"
../source/print_tokens.c.inst.exe  < ../inputs/newtst187.tst > ../newoutputs/t99
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/98.tr
echo ">>>>>>>>running test 100"
../source/print_tokens.c.inst.exe  < ../inputs/newtst188.tst > ../newoutputs/t100
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/99.tr
echo ">>>>>>>>running test 101"
../source/print_tokens.c.inst.exe  < ../inputs/newtst189.tst > ../newoutputs/t101
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/100.tr
echo ">>>>>>>>running test 102"
../source/print_tokens.c.inst.exe  < ../inputs/newtst19.tst > ../newoutputs/t102
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/101.tr
echo ">>>>>>>>running test 103"
../source/print_tokens.c.inst.exe  < ../inputs/newtst190.tst > ../newoutputs/t103
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/102.tr
echo ">>>>>>>>running test 104"
../source/print_tokens.c.inst.exe  < ../inputs/newtst191.tst > ../newoutputs/t104
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/103.tr
echo ">>>>>>>>running test 105"
../source/print_tokens.c.inst.exe  < ../inputs/newtst192.tst > ../newoutputs/t105
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/104.tr
echo ">>>>>>>>running test 106"
../source/print_tokens.c.inst.exe  < ../inputs/newtst193.tst > ../newoutputs/t106
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/105.tr
echo ">>>>>>>>running test 107"
../source/print_tokens.c.inst.exe  < ../inputs/newtst194.tst > ../newoutputs/t107
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/106.tr
echo ">>>>>>>>running test 108"
../source/print_tokens.c.inst.exe  < ../inputs/newtst195.tst > ../newoutputs/t108
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/107.tr
echo ">>>>>>>>running test 109"
../source/print_tokens.c.inst.exe  < ../inputs/newtst196.tst > ../newoutputs/t109
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/108.tr
echo ">>>>>>>>running test 110"
../source/print_tokens.c.inst.exe  < ../inputs/newtst197.tst > ../newoutputs/t110
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/109.tr
echo ">>>>>>>>running test 111"
../source/print_tokens.c.inst.exe  < ../inputs/newtst198.tst > ../newoutputs/t111
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/110.tr
echo ">>>>>>>>running test 112"
../source/print_tokens.c.inst.exe  < ../inputs/newtst199.tst > ../newoutputs/t112
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/111.tr
echo ">>>>>>>>running test 113"
../source/print_tokens.c.inst.exe  < ../inputs/newtst2.tst > ../newoutputs/t113
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/112.tr
echo ">>>>>>>>running test 114"
../source/print_tokens.c.inst.exe  < ../inputs/newtst2.tst.tst > ../newoutputs/t114
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/113.tr
echo ">>>>>>>>running test 115"
../source/print_tokens.c.inst.exe  < ../inputs/newtst20.tst > ../newoutputs/t115
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/114.tr
echo ">>>>>>>>running test 116"
../source/print_tokens.c.inst.exe  < ../inputs/newtst200.tst > ../newoutputs/t116
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/115.tr
echo ">>>>>>>>running test 117"
../source/print_tokens.c.inst.exe  < ../inputs/newtst201.tst > ../newoutputs/t117
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/116.tr
echo ">>>>>>>>running test 118"
../source/print_tokens.c.inst.exe  < ../inputs/newtst202.tst > ../newoutputs/t118
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/117.tr
echo ">>>>>>>>running test 119"
../source/print_tokens.c.inst.exe  < ../inputs/newtst203.tst > ../newoutputs/t119
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/118.tr
echo ">>>>>>>>running test 120"
../source/print_tokens.c.inst.exe  < ../inputs/newtst204.tst > ../newoutputs/t120
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/119.tr
echo ">>>>>>>>running test 121"
../source/print_tokens.c.inst.exe  < ../inputs/newtst205.tst > ../newoutputs/t121
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/120.tr
echo ">>>>>>>>running test 122"
../source/print_tokens.c.inst.exe  < ../inputs/newtst206.tst > ../newoutputs/t122
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/121.tr
echo ">>>>>>>>running test 123"
../source/print_tokens.c.inst.exe  < ../inputs/newtst207.tst > ../newoutputs/t123
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/122.tr
echo ">>>>>>>>running test 124"
../source/print_tokens.c.inst.exe  < ../inputs/newtst208.tst > ../newoutputs/t124
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/123.tr
echo ">>>>>>>>running test 125"
../source/print_tokens.c.inst.exe  < ../inputs/newtst209.tst > ../newoutputs/t125
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/124.tr
echo ">>>>>>>>running test 126"
../source/print_tokens.c.inst.exe  < ../inputs/newtst21.tst > ../newoutputs/t126
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/125.tr
echo ">>>>>>>>running test 127"
../source/print_tokens.c.inst.exe  < ../inputs/newtst21.tst.tst > ../newoutputs/t127
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/126.tr
echo ">>>>>>>>running test 128"
../source/print_tokens.c.inst.exe  < ../inputs/newtst210.tst > ../newoutputs/t128
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/127.tr
echo ">>>>>>>>running test 129"
../source/print_tokens.c.inst.exe  < ../inputs/newtst211.tst > ../newoutputs/t129
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/128.tr
echo ">>>>>>>>running test 130"
../source/print_tokens.c.inst.exe  < ../inputs/newtst212.tst > ../newoutputs/t130
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/129.tr
echo ">>>>>>>>running test 131"
../source/print_tokens.c.inst.exe  < ../inputs/newtst213.tst > ../newoutputs/t131
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/130.tr
echo ">>>>>>>>running test 132"
../source/print_tokens.c.inst.exe  < ../inputs/newtst214.tst > ../newoutputs/t132
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/131.tr
echo ">>>>>>>>running test 133"
../source/print_tokens.c.inst.exe  < ../inputs/newtst215.tst > ../newoutputs/t133
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/132.tr
echo ">>>>>>>>running test 134"
../source/print_tokens.c.inst.exe  < ../inputs/newtst216.tst > ../newoutputs/t134
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/133.tr
echo ">>>>>>>>running test 135"
../source/print_tokens.c.inst.exe  < ../inputs/newtst217.tst > ../newoutputs/t135
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/134.tr
echo ">>>>>>>>running test 136"
../source/print_tokens.c.inst.exe  < ../inputs/newtst218.tst > ../newoutputs/t136
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/135.tr
echo ">>>>>>>>running test 137"
../source/print_tokens.c.inst.exe  < ../inputs/newtst219.tst > ../newoutputs/t137
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/136.tr
echo ">>>>>>>>running test 138"
../source/print_tokens.c.inst.exe  < ../inputs/newtst22.tst > ../newoutputs/t138
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/137.tr
echo ">>>>>>>>running test 139"
../source/print_tokens.c.inst.exe  < ../inputs/newtst220.tst > ../newoutputs/t139
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/138.tr
echo ">>>>>>>>running test 140"
../source/print_tokens.c.inst.exe  < ../inputs/newtst221.tst > ../newoutputs/t140
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/139.tr
echo ">>>>>>>>running test 141"
../source/print_tokens.c.inst.exe  < ../inputs/newtst222.tst > ../newoutputs/t141
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/140.tr
echo ">>>>>>>>running test 142"
../source/print_tokens.c.inst.exe  < ../inputs/newtst223.tst > ../newoutputs/t142
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/141.tr
echo ">>>>>>>>running test 143"
../source/print_tokens.c.inst.exe  < ../inputs/newtst224.tst > ../newoutputs/t143
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/142.tr
echo ">>>>>>>>running test 144"
../source/print_tokens.c.inst.exe  < ../inputs/newtst225.tst > ../newoutputs/t144
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/143.tr
echo ">>>>>>>>running test 145"
../source/print_tokens.c.inst.exe  < ../inputs/newtst226.tst > ../newoutputs/t145
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/144.tr
echo ">>>>>>>>running test 146"
../source/print_tokens.c.inst.exe  < ../inputs/newtst227.tst > ../newoutputs/t146
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/145.tr
echo ">>>>>>>>running test 147"
../source/print_tokens.c.inst.exe  < ../inputs/newtst228.tst > ../newoutputs/t147
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/146.tr
echo ">>>>>>>>running test 148"
../source/print_tokens.c.inst.exe  < ../inputs/newtst229.tst > ../newoutputs/t148
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/147.tr
echo ">>>>>>>>running test 149"
../source/print_tokens.c.inst.exe  < ../inputs/newtst23.tst > ../newoutputs/t149
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/148.tr
echo ">>>>>>>>running test 150"
../source/print_tokens.c.inst.exe  < ../inputs/newtst230.tst > ../newoutputs/t150
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/149.tr
echo ">>>>>>>>running test 151"
../source/print_tokens.c.inst.exe  < ../inputs/newtst231.tst > ../newoutputs/t151
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/150.tr
echo ">>>>>>>>running test 152"
../source/print_tokens.c.inst.exe  < ../inputs/newtst232.tst > ../newoutputs/t152
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/151.tr
echo ">>>>>>>>running test 153"
../source/print_tokens.c.inst.exe  < ../inputs/newtst233.tst > ../newoutputs/t153
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/152.tr
echo ">>>>>>>>running test 154"
../source/print_tokens.c.inst.exe  < ../inputs/newtst234.tst > ../newoutputs/t154
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/153.tr
echo ">>>>>>>>running test 155"
../source/print_tokens.c.inst.exe  < ../inputs/newtst234.tst.tst > ../newoutputs/t155
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/154.tr
echo ">>>>>>>>running test 156"
../source/print_tokens.c.inst.exe  < ../inputs/newtst235.tst > ../newoutputs/t156
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/155.tr
echo ">>>>>>>>running test 157"
../source/print_tokens.c.inst.exe  < ../inputs/newtst236.tst > ../newoutputs/t157
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/156.tr
echo ">>>>>>>>running test 158"
../source/print_tokens.c.inst.exe  < ../inputs/newtst237.tst > ../newoutputs/t158
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/157.tr
echo ">>>>>>>>running test 159"
../source/print_tokens.c.inst.exe  < ../inputs/newtst238.tst > ../newoutputs/t159
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/158.tr
echo ">>>>>>>>running test 160"
../source/print_tokens.c.inst.exe  < ../inputs/newtst239.tst > ../newoutputs/t160
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/159.tr
echo ">>>>>>>>running test 161"
../source/print_tokens.c.inst.exe  < ../inputs/newtst24.tst > ../newoutputs/t161
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/160.tr
echo ">>>>>>>>running test 162"
../source/print_tokens.c.inst.exe  < ../inputs/newtst240.tst > ../newoutputs/t162
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/161.tr
echo ">>>>>>>>running test 163"
../source/print_tokens.c.inst.exe  < ../inputs/newtst240.tst.tst > ../newoutputs/t163
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/162.tr
echo ">>>>>>>>running test 164"
../source/print_tokens.c.inst.exe  < ../inputs/newtst241.tst > ../newoutputs/t164
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/163.tr
echo ">>>>>>>>running test 165"
../source/print_tokens.c.inst.exe  < ../inputs/newtst241.tst.tst > ../newoutputs/t165
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/164.tr
echo ">>>>>>>>running test 166"
../source/print_tokens.c.inst.exe  < ../inputs/newtst242.tst > ../newoutputs/t166
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/165.tr
echo ">>>>>>>>running test 167"
../source/print_tokens.c.inst.exe  < ../inputs/newtst242.tst.tst > ../newoutputs/t167
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/166.tr
echo ">>>>>>>>running test 168"
../source/print_tokens.c.inst.exe  < ../inputs/newtst243.tst > ../newoutputs/t168
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/167.tr
echo ">>>>>>>>running test 169"
../source/print_tokens.c.inst.exe  < ../inputs/newtst243.tst.tst > ../newoutputs/t169
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/168.tr
echo ">>>>>>>>running test 170"
../source/print_tokens.c.inst.exe  < ../inputs/newtst244.tst > ../newoutputs/t170
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/169.tr
echo ">>>>>>>>running test 171"
../source/print_tokens.c.inst.exe  < ../inputs/newtst244.tst.tst > ../newoutputs/t171
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/170.tr
echo ">>>>>>>>running test 172"
../source/print_tokens.c.inst.exe  < ../inputs/newtst245.tst > ../newoutputs/t172
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/171.tr
echo ">>>>>>>>running test 173"
../source/print_tokens.c.inst.exe  < ../inputs/newtst245.tst.tst > ../newoutputs/t173
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/172.tr
echo ">>>>>>>>running test 174"
../source/print_tokens.c.inst.exe  < ../inputs/newtst246.tst > ../newoutputs/t174
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/173.tr
echo ">>>>>>>>running test 175"
../source/print_tokens.c.inst.exe  < ../inputs/newtst246.tst.tst > ../newoutputs/t175
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/174.tr
echo ">>>>>>>>running test 176"
../source/print_tokens.c.inst.exe  < ../inputs/newtst247.tst > ../newoutputs/t176
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/175.tr
echo ">>>>>>>>running test 177"
../source/print_tokens.c.inst.exe  < ../inputs/newtst247.tst.tst > ../newoutputs/t177
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/176.tr
echo ">>>>>>>>running test 178"
../source/print_tokens.c.inst.exe  < ../inputs/newtst248.tst > ../newoutputs/t178
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/177.tr
echo ">>>>>>>>running test 179"
../source/print_tokens.c.inst.exe  < ../inputs/newtst248.tst.tst > ../newoutputs/t179
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/178.tr
echo ">>>>>>>>running test 180"
../source/print_tokens.c.inst.exe  < ../inputs/newtst249.tst > ../newoutputs/t180
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/179.tr
echo ">>>>>>>>running test 181"
../source/print_tokens.c.inst.exe  < ../inputs/newtst249.tst.tst > ../newoutputs/t181
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/180.tr
echo ">>>>>>>>running test 182"
../source/print_tokens.c.inst.exe  < ../inputs/newtst25.tst > ../newoutputs/t182
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/181.tr
echo ">>>>>>>>running test 183"
../source/print_tokens.c.inst.exe  < ../inputs/newtst250.tst > ../newoutputs/t183
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/182.tr
echo ">>>>>>>>running test 184"
../source/print_tokens.c.inst.exe  < ../inputs/newtst251.tst > ../newoutputs/t184
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/183.tr
echo ">>>>>>>>running test 185"
../source/print_tokens.c.inst.exe  < ../inputs/newtst252.tst > ../newoutputs/t185
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/184.tr
echo ">>>>>>>>running test 186"
../source/print_tokens.c.inst.exe  < ../inputs/newtst253.tst > ../newoutputs/t186
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/185.tr
echo ">>>>>>>>running test 187"
../source/print_tokens.c.inst.exe  < ../inputs/newtst254.tst > ../newoutputs/t187
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/186.tr
echo ">>>>>>>>running test 188"
../source/print_tokens.c.inst.exe  < ../inputs/newtst254.tst.tst > ../newoutputs/t188
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/187.tr
echo ">>>>>>>>running test 189"
../source/print_tokens.c.inst.exe  < ../inputs/newtst255.tst > ../newoutputs/t189
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/188.tr
echo ">>>>>>>>running test 190"
../source/print_tokens.c.inst.exe  < ../inputs/newtst256.tst > ../newoutputs/t190
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/189.tr
echo ">>>>>>>>running test 191"
../source/print_tokens.c.inst.exe  < ../inputs/newtst257.tst > ../newoutputs/t191
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/190.tr
echo ">>>>>>>>running test 192"
../source/print_tokens.c.inst.exe  < ../inputs/newtst258.tst > ../newoutputs/t192
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/191.tr
echo ">>>>>>>>running test 193"
../source/print_tokens.c.inst.exe  < ../inputs/newtst259.tst > ../newoutputs/t193
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/192.tr
echo ">>>>>>>>running test 194"
../source/print_tokens.c.inst.exe  < ../inputs/newtst26.tst > ../newoutputs/t194
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/193.tr
echo ">>>>>>>>running test 195"
../source/print_tokens.c.inst.exe  < ../inputs/newtst260.tst > ../newoutputs/t195
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/194.tr
echo ">>>>>>>>running test 196"
../source/print_tokens.c.inst.exe  < ../inputs/newtst261.tst > ../newoutputs/t196
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/195.tr
echo ">>>>>>>>running test 197"
../source/print_tokens.c.inst.exe  < ../inputs/newtst262.tst > ../newoutputs/t197
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/196.tr
echo ">>>>>>>>running test 198"
../source/print_tokens.c.inst.exe  < ../inputs/newtst263.tst > ../newoutputs/t198
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/197.tr
echo ">>>>>>>>running test 199"
../source/print_tokens.c.inst.exe  < ../inputs/newtst264.tst > ../newoutputs/t199
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/198.tr
echo ">>>>>>>>running test 200"
../source/print_tokens.c.inst.exe  < ../inputs/newtst265.tst > ../newoutputs/t200
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/199.tr
echo ">>>>>>>>running test 201"
../source/print_tokens.c.inst.exe  < ../inputs/newtst266.tst > ../newoutputs/t201
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/200.tr
echo ">>>>>>>>running test 202"
../source/print_tokens.c.inst.exe  < ../inputs/newtst267.tst > ../newoutputs/t202
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/201.tr
echo ">>>>>>>>running test 203"
../source/print_tokens.c.inst.exe  < ../inputs/newtst268.tst > ../newoutputs/t203
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/202.tr
echo ">>>>>>>>running test 204"
../source/print_tokens.c.inst.exe  < ../inputs/newtst269.tst > ../newoutputs/t204
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/203.tr
echo ">>>>>>>>running test 205"
../source/print_tokens.c.inst.exe  < ../inputs/newtst27.tst > ../newoutputs/t205
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/204.tr
echo ">>>>>>>>running test 206"
../source/print_tokens.c.inst.exe  < ../inputs/newtst270.tst > ../newoutputs/t206
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/205.tr
echo ">>>>>>>>running test 207"
../source/print_tokens.c.inst.exe  < ../inputs/newtst271.tst > ../newoutputs/t207
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/206.tr
echo ">>>>>>>>running test 208"
../source/print_tokens.c.inst.exe  < ../inputs/newtst272.tst > ../newoutputs/t208
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/207.tr
echo ">>>>>>>>running test 209"
../source/print_tokens.c.inst.exe  < ../inputs/newtst273.tst > ../newoutputs/t209
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/208.tr
echo ">>>>>>>>running test 210"
../source/print_tokens.c.inst.exe  < ../inputs/newtst274.tst > ../newoutputs/t210
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/209.tr
echo ">>>>>>>>running test 211"
../source/print_tokens.c.inst.exe  < ../inputs/newtst275.tst > ../newoutputs/t211
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/210.tr
echo ">>>>>>>>running test 212"
../source/print_tokens.c.inst.exe  < ../inputs/newtst276.tst > ../newoutputs/t212
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/211.tr
echo ">>>>>>>>running test 213"
../source/print_tokens.c.inst.exe  < ../inputs/newtst277.tst > ../newoutputs/t213
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/212.tr
echo ">>>>>>>>running test 214"
../source/print_tokens.c.inst.exe  < ../inputs/newtst278.tst > ../newoutputs/t214
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/213.tr
echo ">>>>>>>>running test 215"
../source/print_tokens.c.inst.exe  < ../inputs/newtst279.tst > ../newoutputs/t215
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/214.tr
echo ">>>>>>>>running test 216"
../source/print_tokens.c.inst.exe  < ../inputs/newtst28.tst > ../newoutputs/t216
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/215.tr
echo ">>>>>>>>running test 217"
../source/print_tokens.c.inst.exe  < ../inputs/newtst280.tst > ../newoutputs/t217
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/216.tr
echo ">>>>>>>>running test 218"
../source/print_tokens.c.inst.exe  < ../inputs/newtst281.tst > ../newoutputs/t218
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/217.tr
echo ">>>>>>>>running test 219"
../source/print_tokens.c.inst.exe  < ../inputs/newtst282.tst > ../newoutputs/t219
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/218.tr
echo ">>>>>>>>running test 220"
../source/print_tokens.c.inst.exe  < ../inputs/newtst283.tst > ../newoutputs/t220
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/219.tr
echo ">>>>>>>>running test 221"
../source/print_tokens.c.inst.exe  < ../inputs/newtst284.tst > ../newoutputs/t221
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/220.tr
echo ">>>>>>>>running test 222"
../source/print_tokens.c.inst.exe  < ../inputs/newtst285.tst > ../newoutputs/t222
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/221.tr
echo ">>>>>>>>running test 223"
../source/print_tokens.c.inst.exe  < ../inputs/newtst286.tst > ../newoutputs/t223
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/222.tr
echo ">>>>>>>>running test 224"
../source/print_tokens.c.inst.exe  < ../inputs/newtst287.tst > ../newoutputs/t224
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/223.tr
echo ">>>>>>>>running test 225"
../source/print_tokens.c.inst.exe  < ../inputs/newtst288.tst > ../newoutputs/t225
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/224.tr
echo ">>>>>>>>running test 226"
../source/print_tokens.c.inst.exe  < ../inputs/newtst289.tst > ../newoutputs/t226
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/225.tr
echo ">>>>>>>>running test 227"
../source/print_tokens.c.inst.exe  < ../inputs/newtst29.tst > ../newoutputs/t227
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/226.tr
echo ">>>>>>>>running test 228"
../source/print_tokens.c.inst.exe  < ../inputs/newtst290.tst > ../newoutputs/t228
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/227.tr
echo ">>>>>>>>running test 229"
../source/print_tokens.c.inst.exe  < ../inputs/newtst291.tst > ../newoutputs/t229
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/228.tr
echo ">>>>>>>>running test 230"
../source/print_tokens.c.inst.exe  < ../inputs/newtst292.tst > ../newoutputs/t230
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/229.tr
echo ">>>>>>>>running test 231"
../source/print_tokens.c.inst.exe  < ../inputs/newtst293.tst > ../newoutputs/t231
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/230.tr
echo ">>>>>>>>running test 232"
../source/print_tokens.c.inst.exe  < ../inputs/newtst294.tst > ../newoutputs/t232
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/231.tr
echo ">>>>>>>>running test 233"
../source/print_tokens.c.inst.exe  < ../inputs/newtst295.tst > ../newoutputs/t233
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/232.tr
echo ">>>>>>>>running test 234"
../source/print_tokens.c.inst.exe  < ../inputs/newtst296.tst > ../newoutputs/t234
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/233.tr
echo ">>>>>>>>running test 235"
../source/print_tokens.c.inst.exe  < ../inputs/newtst297.tst > ../newoutputs/t235
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/234.tr
echo ">>>>>>>>running test 236"
../source/print_tokens.c.inst.exe  < ../inputs/newtst298.tst > ../newoutputs/t236
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/235.tr
echo ">>>>>>>>running test 237"
../source/print_tokens.c.inst.exe  < ../inputs/newtst299.tst > ../newoutputs/t237
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/236.tr
echo ">>>>>>>>running test 238"
../source/print_tokens.c.inst.exe  < ../inputs/newtst3.tst > ../newoutputs/t238
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/237.tr
echo ">>>>>>>>running test 239"
../source/print_tokens.c.inst.exe  < ../inputs/newtst3.tst.tst > ../newoutputs/t239
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/238.tr
echo ">>>>>>>>running test 240"
../source/print_tokens.c.inst.exe  < ../inputs/newtst30.tst > ../newoutputs/t240
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/239.tr
echo ">>>>>>>>running test 241"
../source/print_tokens.c.inst.exe  < ../inputs/newtst300.tst > ../newoutputs/t241
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/240.tr
echo ">>>>>>>>running test 242"
../source/print_tokens.c.inst.exe  < ../inputs/newtst301.tst > ../newoutputs/t242
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/241.tr
echo ">>>>>>>>running test 243"
../source/print_tokens.c.inst.exe  < ../inputs/newtst302.tst > ../newoutputs/t243
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/242.tr
echo ">>>>>>>>running test 244"
../source/print_tokens.c.inst.exe  < ../inputs/newtst303.tst > ../newoutputs/t244
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/243.tr
echo ">>>>>>>>running test 245"
../source/print_tokens.c.inst.exe  < ../inputs/newtst304.tst > ../newoutputs/t245
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/244.tr
echo ">>>>>>>>running test 246"
../source/print_tokens.c.inst.exe  < ../inputs/newtst305.tst > ../newoutputs/t246
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/245.tr
echo ">>>>>>>>running test 247"
../source/print_tokens.c.inst.exe  < ../inputs/newtst306.tst > ../newoutputs/t247
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/246.tr
echo ">>>>>>>>running test 248"
../source/print_tokens.c.inst.exe  < ../inputs/newtst307.tst > ../newoutputs/t248
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/247.tr
echo ">>>>>>>>running test 249"
../source/print_tokens.c.inst.exe  < ../inputs/newtst308.tst > ../newoutputs/t249
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/248.tr
echo ">>>>>>>>running test 250"
../source/print_tokens.c.inst.exe  < ../inputs/newtst309.tst > ../newoutputs/t250
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/249.tr
echo ">>>>>>>>running test 251"
../source/print_tokens.c.inst.exe  < ../inputs/newtst31.tst > ../newoutputs/t251
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/250.tr
echo ">>>>>>>>running test 252"
../source/print_tokens.c.inst.exe  < ../inputs/newtst31.tst.tst > ../newoutputs/t252
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/251.tr
echo ">>>>>>>>running test 253"
../source/print_tokens.c.inst.exe  < ../inputs/newtst310.tst > ../newoutputs/t253
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/252.tr
echo ">>>>>>>>running test 254"
../source/print_tokens.c.inst.exe  < ../inputs/newtst311.tst > ../newoutputs/t254
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/253.tr
echo ">>>>>>>>running test 255"
../source/print_tokens.c.inst.exe  < ../inputs/newtst312.tst > ../newoutputs/t255
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/254.tr
echo ">>>>>>>>running test 256"
../source/print_tokens.c.inst.exe  < ../inputs/newtst313.tst > ../newoutputs/t256
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/255.tr
echo ">>>>>>>>running test 257"
../source/print_tokens.c.inst.exe  < ../inputs/newtst314.tst > ../newoutputs/t257
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/256.tr
echo ">>>>>>>>running test 258"
../source/print_tokens.c.inst.exe  < ../inputs/newtst315.tst > ../newoutputs/t258
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/257.tr
echo ">>>>>>>>running test 259"
../source/print_tokens.c.inst.exe  < ../inputs/newtst316.tst > ../newoutputs/t259
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/258.tr
echo ">>>>>>>>running test 260"
../source/print_tokens.c.inst.exe  < ../inputs/newtst317.tst > ../newoutputs/t260
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/259.tr
echo ">>>>>>>>running test 261"
../source/print_tokens.c.inst.exe  < ../inputs/newtst318.tst > ../newoutputs/t261
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/260.tr
echo ">>>>>>>>running test 262"
../source/print_tokens.c.inst.exe  < ../inputs/newtst319.tst > ../newoutputs/t262
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/261.tr
echo ">>>>>>>>running test 263"
../source/print_tokens.c.inst.exe  < ../inputs/newtst32.tst > ../newoutputs/t263
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/262.tr
echo ">>>>>>>>running test 264"
../source/print_tokens.c.inst.exe  < ../inputs/newtst320.tst > ../newoutputs/t264
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/263.tr
echo ">>>>>>>>running test 265"
../source/print_tokens.c.inst.exe  < ../inputs/newtst321.tst > ../newoutputs/t265
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/264.tr
echo ">>>>>>>>running test 266"
../source/print_tokens.c.inst.exe  < ../inputs/newtst322.tst > ../newoutputs/t266
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/265.tr
echo ">>>>>>>>running test 267"
../source/print_tokens.c.inst.exe  < ../inputs/newtst323.tst > ../newoutputs/t267
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/266.tr
echo ">>>>>>>>running test 268"
../source/print_tokens.c.inst.exe  < ../inputs/newtst324.tst > ../newoutputs/t268
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/267.tr
echo ">>>>>>>>running test 269"
../source/print_tokens.c.inst.exe  < ../inputs/newtst325.tst > ../newoutputs/t269
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/268.tr
echo ">>>>>>>>running test 270"
../source/print_tokens.c.inst.exe  < ../inputs/newtst326.tst > ../newoutputs/t270
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/269.tr
echo ">>>>>>>>running test 271"
../source/print_tokens.c.inst.exe  < ../inputs/newtst327.tst > ../newoutputs/t271
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/270.tr
echo ">>>>>>>>running test 272"
../source/print_tokens.c.inst.exe  < ../inputs/newtst328.tst > ../newoutputs/t272
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/271.tr
echo ">>>>>>>>running test 273"
../source/print_tokens.c.inst.exe  < ../inputs/newtst329.tst > ../newoutputs/t273
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/272.tr
echo ">>>>>>>>running test 274"
../source/print_tokens.c.inst.exe  < ../inputs/newtst33.tst > ../newoutputs/t274
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/273.tr
echo ">>>>>>>>running test 275"
../source/print_tokens.c.inst.exe  < ../inputs/newtst330.tst > ../newoutputs/t275
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/274.tr
echo ">>>>>>>>running test 276"
../source/print_tokens.c.inst.exe  < ../inputs/newtst331.tst > ../newoutputs/t276
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/275.tr
echo ">>>>>>>>running test 277"
../source/print_tokens.c.inst.exe  < ../inputs/newtst332.tst > ../newoutputs/t277
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/276.tr
echo ">>>>>>>>running test 278"
../source/print_tokens.c.inst.exe  < ../inputs/newtst333.tst > ../newoutputs/t278
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/277.tr
echo ">>>>>>>>running test 279"
../source/print_tokens.c.inst.exe  < ../inputs/newtst334.tst > ../newoutputs/t279
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/278.tr
echo ">>>>>>>>running test 280"
../source/print_tokens.c.inst.exe  < ../inputs/newtst335.tst > ../newoutputs/t280
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/279.tr
echo ">>>>>>>>running test 281"
../source/print_tokens.c.inst.exe  < ../inputs/newtst336.tst > ../newoutputs/t281
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/280.tr
echo ">>>>>>>>running test 282"
../source/print_tokens.c.inst.exe  < ../inputs/newtst337.tst > ../newoutputs/t282
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/281.tr
echo ">>>>>>>>running test 283"
../source/print_tokens.c.inst.exe  < ../inputs/newtst338.tst > ../newoutputs/t283
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/282.tr
echo ">>>>>>>>running test 284"
../source/print_tokens.c.inst.exe  < ../inputs/newtst339.tst > ../newoutputs/t284
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/283.tr
echo ">>>>>>>>running test 285"
../source/print_tokens.c.inst.exe  < ../inputs/newtst34.tst > ../newoutputs/t285
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/284.tr
echo ">>>>>>>>running test 286"
../source/print_tokens.c.inst.exe  < ../inputs/newtst340.tst > ../newoutputs/t286
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/285.tr
echo ">>>>>>>>running test 287"
../source/print_tokens.c.inst.exe  < ../inputs/newtst341.tst > ../newoutputs/t287
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/286.tr
echo ">>>>>>>>running test 288"
../source/print_tokens.c.inst.exe  < ../inputs/newtst342.tst > ../newoutputs/t288
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/287.tr
echo ">>>>>>>>running test 289"
../source/print_tokens.c.inst.exe  < ../inputs/newtst343.tst > ../newoutputs/t289
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/288.tr
echo ">>>>>>>>running test 290"
../source/print_tokens.c.inst.exe  < ../inputs/newtst344.tst > ../newoutputs/t290
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/289.tr
echo ">>>>>>>>running test 291"
../source/print_tokens.c.inst.exe  < ../inputs/newtst345.tst > ../newoutputs/t291
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/290.tr
echo ">>>>>>>>running test 292"
../source/print_tokens.c.inst.exe  < ../inputs/newtst346.tst > ../newoutputs/t292
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/291.tr
echo ">>>>>>>>running test 293"
../source/print_tokens.c.inst.exe  < ../inputs/newtst347.tst > ../newoutputs/t293
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/292.tr
echo ">>>>>>>>running test 294"
../source/print_tokens.c.inst.exe  < ../inputs/newtst348.tst > ../newoutputs/t294
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/293.tr
echo ">>>>>>>>running test 295"
../source/print_tokens.c.inst.exe  < ../inputs/newtst349.tst > ../newoutputs/t295
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/294.tr
echo ">>>>>>>>running test 296"
../source/print_tokens.c.inst.exe  < ../inputs/newtst35.tst > ../newoutputs/t296
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/295.tr
echo ">>>>>>>>running test 297"
../source/print_tokens.c.inst.exe  < ../inputs/newtst350.tst > ../newoutputs/t297
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/296.tr
echo ">>>>>>>>running test 298"
../source/print_tokens.c.inst.exe  < ../inputs/newtst352.tst > ../newoutputs/t298
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/297.tr
echo ">>>>>>>>running test 299"
../source/print_tokens.c.inst.exe  < ../inputs/newtst353.tst > ../newoutputs/t299
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/298.tr
echo ">>>>>>>>running test 300"
../source/print_tokens.c.inst.exe  < ../inputs/newtst354.tst > ../newoutputs/t300
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/299.tr
echo ">>>>>>>>running test 301"
../source/print_tokens.c.inst.exe  < ../inputs/newtst355.tst > ../newoutputs/t301
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/300.tr
echo ">>>>>>>>running test 302"
../source/print_tokens.c.inst.exe  < ../inputs/newtst356.tst > ../newoutputs/t302
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/301.tr
echo ">>>>>>>>running test 303"
../source/print_tokens.c.inst.exe  < ../inputs/newtst357.tst > ../newoutputs/t303
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/302.tr
echo ">>>>>>>>running test 304"
../source/print_tokens.c.inst.exe  < ../inputs/newtst358.tst > ../newoutputs/t304
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/303.tr
echo ">>>>>>>>running test 305"
../source/print_tokens.c.inst.exe  < ../inputs/newtst359.tst > ../newoutputs/t305
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/304.tr
echo ">>>>>>>>running test 306"
../source/print_tokens.c.inst.exe  < ../inputs/newtst36.tst > ../newoutputs/t306
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/305.tr
echo ">>>>>>>>running test 307"
../source/print_tokens.c.inst.exe  < ../inputs/newtst360.tst > ../newoutputs/t307
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/306.tr
echo ">>>>>>>>running test 308"
../source/print_tokens.c.inst.exe  < ../inputs/newtst361.tst > ../newoutputs/t308
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/307.tr
echo ">>>>>>>>running test 309"
../source/print_tokens.c.inst.exe  < ../inputs/newtst362.tst > ../newoutputs/t309
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/308.tr
echo ">>>>>>>>running test 310"
../source/print_tokens.c.inst.exe  < ../inputs/newtst363.tst > ../newoutputs/t310
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/309.tr
echo ">>>>>>>>running test 311"
../source/print_tokens.c.inst.exe  < ../inputs/newtst364.tst > ../newoutputs/t311
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/310.tr
echo ">>>>>>>>running test 312"
../source/print_tokens.c.inst.exe  < ../inputs/newtst365.tst > ../newoutputs/t312
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/311.tr
echo ">>>>>>>>running test 313"
../source/print_tokens.c.inst.exe  < ../inputs/newtst366.tst > ../newoutputs/t313
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/312.tr
echo ">>>>>>>>running test 314"
../source/print_tokens.c.inst.exe  < ../inputs/newtst367.tst > ../newoutputs/t314
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/313.tr
echo ">>>>>>>>running test 315"
../source/print_tokens.c.inst.exe  < ../inputs/newtst368.tst > ../newoutputs/t315
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/314.tr
echo ">>>>>>>>running test 316"
../source/print_tokens.c.inst.exe  < ../inputs/newtst369.tst > ../newoutputs/t316
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/315.tr
echo ">>>>>>>>running test 317"
../source/print_tokens.c.inst.exe  < ../inputs/newtst37.tst > ../newoutputs/t317
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/316.tr
echo ">>>>>>>>running test 318"
../source/print_tokens.c.inst.exe  < ../inputs/newtst370.tst > ../newoutputs/t318
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/317.tr
echo ">>>>>>>>running test 319"
../source/print_tokens.c.inst.exe  < ../inputs/newtst371.tst > ../newoutputs/t319
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/318.tr
echo ">>>>>>>>running test 320"
../source/print_tokens.c.inst.exe  < ../inputs/newtst372.tst > ../newoutputs/t320
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/319.tr
echo ">>>>>>>>running test 321"
../source/print_tokens.c.inst.exe  < ../inputs/newtst373.tst > ../newoutputs/t321
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/320.tr
echo ">>>>>>>>running test 322"
../source/print_tokens.c.inst.exe  < ../inputs/newtst374.tst > ../newoutputs/t322
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/321.tr
echo ">>>>>>>>running test 323"
../source/print_tokens.c.inst.exe  < ../inputs/newtst375.tst > ../newoutputs/t323
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/322.tr
echo ">>>>>>>>running test 324"
../source/print_tokens.c.inst.exe  < ../inputs/newtst376.tst > ../newoutputs/t324
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/323.tr
echo ">>>>>>>>running test 325"
../source/print_tokens.c.inst.exe  < ../inputs/newtst377.tst > ../newoutputs/t325
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/324.tr
echo ">>>>>>>>running test 326"
../source/print_tokens.c.inst.exe  < ../inputs/newtst378.tst > ../newoutputs/t326
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/325.tr
echo ">>>>>>>>running test 327"
../source/print_tokens.c.inst.exe  < ../inputs/newtst379.tst > ../newoutputs/t327
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/326.tr
echo ">>>>>>>>running test 328"
../source/print_tokens.c.inst.exe  < ../inputs/newtst38.tst > ../newoutputs/t328
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/327.tr
echo ">>>>>>>>running test 329"
../source/print_tokens.c.inst.exe  < ../inputs/newtst380.tst > ../newoutputs/t329
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/328.tr
echo ">>>>>>>>running test 330"
../source/print_tokens.c.inst.exe  < ../inputs/newtst381.tst > ../newoutputs/t330
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/329.tr
echo ">>>>>>>>running test 331"
../source/print_tokens.c.inst.exe  < ../inputs/newtst382.tst > ../newoutputs/t331
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/330.tr
echo ">>>>>>>>running test 332"
../source/print_tokens.c.inst.exe  < ../inputs/newtst383.tst > ../newoutputs/t332
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/331.tr
echo ">>>>>>>>running test 333"
../source/print_tokens.c.inst.exe  < ../inputs/newtst384.tst > ../newoutputs/t333
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/332.tr
echo ">>>>>>>>running test 334"
../source/print_tokens.c.inst.exe  < ../inputs/newtst385.tst > ../newoutputs/t334
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/333.tr
echo ">>>>>>>>running test 335"
../source/print_tokens.c.inst.exe  < ../inputs/newtst386.tst > ../newoutputs/t335
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/334.tr
echo ">>>>>>>>running test 336"
../source/print_tokens.c.inst.exe  < ../inputs/newtst387.tst > ../newoutputs/t336
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/335.tr
echo ">>>>>>>>running test 337"
../source/print_tokens.c.inst.exe  < ../inputs/newtst388.tst > ../newoutputs/t337
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/336.tr
echo ">>>>>>>>running test 338"
../source/print_tokens.c.inst.exe  < ../inputs/newtst389.tst > ../newoutputs/t338
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/337.tr
echo ">>>>>>>>running test 339"
../source/print_tokens.c.inst.exe  < ../inputs/newtst39.tst > ../newoutputs/t339
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/338.tr
echo ">>>>>>>>running test 340"
../source/print_tokens.c.inst.exe  < ../inputs/newtst390.tst > ../newoutputs/t340
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/339.tr
echo ">>>>>>>>running test 341"
../source/print_tokens.c.inst.exe  < ../inputs/newtst391.tst > ../newoutputs/t341
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/340.tr
echo ">>>>>>>>running test 342"
../source/print_tokens.c.inst.exe  < ../inputs/newtst392.tst > ../newoutputs/t342
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/341.tr
echo ">>>>>>>>running test 343"
../source/print_tokens.c.inst.exe  < ../inputs/newtst393.tst > ../newoutputs/t343
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/342.tr
echo ">>>>>>>>running test 344"
../source/print_tokens.c.inst.exe  < ../inputs/newtst394.tst > ../newoutputs/t344
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/343.tr
echo ">>>>>>>>running test 345"
../source/print_tokens.c.inst.exe  < ../inputs/newtst395.tst > ../newoutputs/t345
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/344.tr
echo ">>>>>>>>running test 346"
../source/print_tokens.c.inst.exe  < ../inputs/newtst396.tst > ../newoutputs/t346
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/345.tr
echo ">>>>>>>>running test 347"
../source/print_tokens.c.inst.exe  < ../inputs/newtst397.tst > ../newoutputs/t347
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/346.tr
echo ">>>>>>>>running test 348"
../source/print_tokens.c.inst.exe  < ../inputs/newtst398.tst > ../newoutputs/t348
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/347.tr
echo ">>>>>>>>running test 349"
../source/print_tokens.c.inst.exe  < ../inputs/newtst399.tst > ../newoutputs/t349
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/348.tr
echo ">>>>>>>>running test 350"
../source/print_tokens.c.inst.exe  < ../inputs/newtst4.tst > ../newoutputs/t350
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/349.tr
echo ">>>>>>>>running test 351"
../source/print_tokens.c.inst.exe  < ../inputs/newtst4.tst.tst > ../newoutputs/t351
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/350.tr
echo ">>>>>>>>running test 352"
../source/print_tokens.c.inst.exe  < ../inputs/newtst40.tst > ../newoutputs/t352
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/351.tr
echo ">>>>>>>>running test 353"
../source/print_tokens.c.inst.exe  < ../inputs/newtst400.tst > ../newoutputs/t353
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/352.tr
echo ">>>>>>>>running test 354"
../source/print_tokens.c.inst.exe  < ../inputs/newtst401.tst > ../newoutputs/t354
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/353.tr
echo ">>>>>>>>running test 355"
../source/print_tokens.c.inst.exe  < ../inputs/newtst402.tst > ../newoutputs/t355
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/354.tr
echo ">>>>>>>>running test 356"
../source/print_tokens.c.inst.exe  < ../inputs/newtst403.tst > ../newoutputs/t356
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/355.tr
echo ">>>>>>>>running test 357"
../source/print_tokens.c.inst.exe  < ../inputs/newtst404.tst > ../newoutputs/t357
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/356.tr
echo ">>>>>>>>running test 358"
../source/print_tokens.c.inst.exe  < ../inputs/newtst405.tst > ../newoutputs/t358
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/357.tr
echo ">>>>>>>>running test 359"
../source/print_tokens.c.inst.exe  < ../inputs/newtst406.tst > ../newoutputs/t359
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/358.tr
echo ">>>>>>>>running test 360"
../source/print_tokens.c.inst.exe  < ../inputs/newtst407.tst > ../newoutputs/t360
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/359.tr
echo ">>>>>>>>running test 361"
../source/print_tokens.c.inst.exe  < ../inputs/newtst408.tst > ../newoutputs/t361
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/360.tr
echo ">>>>>>>>running test 362"
../source/print_tokens.c.inst.exe  < ../inputs/newtst409.tst > ../newoutputs/t362
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/361.tr
echo ">>>>>>>>running test 363"
../source/print_tokens.c.inst.exe  < ../inputs/newtst41.tst > ../newoutputs/t363
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/362.tr
echo ">>>>>>>>running test 364"
../source/print_tokens.c.inst.exe  < ../inputs/newtst410.tst > ../newoutputs/t364
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/363.tr
echo ">>>>>>>>running test 365"
../source/print_tokens.c.inst.exe  < ../inputs/newtst411.tst > ../newoutputs/t365
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/364.tr
echo ">>>>>>>>running test 366"
../source/print_tokens.c.inst.exe  < ../inputs/newtst412.tst > ../newoutputs/t366
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/365.tr
echo ">>>>>>>>running test 367"
../source/print_tokens.c.inst.exe  < ../inputs/newtst413.tst > ../newoutputs/t367
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/366.tr
echo ">>>>>>>>running test 368"
../source/print_tokens.c.inst.exe  < ../inputs/newtst414.tst > ../newoutputs/t368
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/367.tr
echo ">>>>>>>>running test 369"
../source/print_tokens.c.inst.exe  < ../inputs/newtst415.tst > ../newoutputs/t369
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/368.tr
echo ">>>>>>>>running test 370"
../source/print_tokens.c.inst.exe  < ../inputs/newtst416.tst > ../newoutputs/t370
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/369.tr
echo ">>>>>>>>running test 371"
../source/print_tokens.c.inst.exe  < ../inputs/newtst417.tst > ../newoutputs/t371
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/370.tr
echo ">>>>>>>>running test 372"
../source/print_tokens.c.inst.exe  < ../inputs/newtst418.tst > ../newoutputs/t372
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/371.tr
echo ">>>>>>>>running test 373"
../source/print_tokens.c.inst.exe  < ../inputs/newtst419.tst > ../newoutputs/t373
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/372.tr
echo ">>>>>>>>running test 374"
../source/print_tokens.c.inst.exe  < ../inputs/newtst42.tst > ../newoutputs/t374
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/373.tr
echo ">>>>>>>>running test 375"
../source/print_tokens.c.inst.exe  < ../inputs/newtst420.tst > ../newoutputs/t375
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/374.tr
echo ">>>>>>>>running test 376"
../source/print_tokens.c.inst.exe  < ../inputs/newtst421.tst > ../newoutputs/t376
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/375.tr
echo ">>>>>>>>running test 377"
../source/print_tokens.c.inst.exe  < ../inputs/newtst422.tst > ../newoutputs/t377
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/376.tr
echo ">>>>>>>>running test 378"
../source/print_tokens.c.inst.exe  < ../inputs/newtst423.tst > ../newoutputs/t378
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/377.tr
echo ">>>>>>>>running test 379"
../source/print_tokens.c.inst.exe  < ../inputs/newtst424.tst > ../newoutputs/t379
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/378.tr
echo ">>>>>>>>running test 380"
../source/print_tokens.c.inst.exe  < ../inputs/newtst425.tst > ../newoutputs/t380
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/379.tr
echo ">>>>>>>>running test 381"
../source/print_tokens.c.inst.exe  < ../inputs/newtst426.tst > ../newoutputs/t381
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/380.tr
echo ">>>>>>>>running test 382"
../source/print_tokens.c.inst.exe  < ../inputs/newtst427.tst > ../newoutputs/t382
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/381.tr
echo ">>>>>>>>running test 383"
../source/print_tokens.c.inst.exe  < ../inputs/newtst428.tst > ../newoutputs/t383
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/382.tr
echo ">>>>>>>>running test 384"
../source/print_tokens.c.inst.exe  < ../inputs/newtst429.tst > ../newoutputs/t384
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/383.tr
echo ">>>>>>>>running test 385"
../source/print_tokens.c.inst.exe  < ../inputs/newtst43.tst > ../newoutputs/t385
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/384.tr
echo ">>>>>>>>running test 386"
../source/print_tokens.c.inst.exe  < ../inputs/newtst430.tst > ../newoutputs/t386
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/385.tr
echo ">>>>>>>>running test 387"
../source/print_tokens.c.inst.exe  < ../inputs/newtst431.tst > ../newoutputs/t387
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/386.tr
echo ">>>>>>>>running test 388"
../source/print_tokens.c.inst.exe  < ../inputs/newtst432.tst > ../newoutputs/t388
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/387.tr
echo ">>>>>>>>running test 389"
../source/print_tokens.c.inst.exe  < ../inputs/newtst433.tst > ../newoutputs/t389
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/388.tr
echo ">>>>>>>>running test 390"
../source/print_tokens.c.inst.exe  < ../inputs/newtst434.tst > ../newoutputs/t390
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/389.tr
echo ">>>>>>>>running test 391"
../source/print_tokens.c.inst.exe  < ../inputs/newtst435.tst > ../newoutputs/t391
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/390.tr
echo ">>>>>>>>running test 392"
../source/print_tokens.c.inst.exe  < ../inputs/newtst436.tst > ../newoutputs/t392
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/391.tr
echo ">>>>>>>>running test 393"
../source/print_tokens.c.inst.exe  < ../inputs/newtst437.tst > ../newoutputs/t393
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/392.tr
echo ">>>>>>>>running test 394"
../source/print_tokens.c.inst.exe  < ../inputs/newtst438.tst > ../newoutputs/t394
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/393.tr
echo ">>>>>>>>running test 395"
../source/print_tokens.c.inst.exe  < ../inputs/newtst439.tst > ../newoutputs/t395
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/394.tr
echo ">>>>>>>>running test 396"
../source/print_tokens.c.inst.exe  < ../inputs/newtst44.tst > ../newoutputs/t396
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/395.tr
echo ">>>>>>>>running test 397"
../source/print_tokens.c.inst.exe  < ../inputs/newtst440.tst > ../newoutputs/t397
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/396.tr
echo ">>>>>>>>running test 398"
../source/print_tokens.c.inst.exe  < ../inputs/newtst441.tst > ../newoutputs/t398
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/397.tr
echo ">>>>>>>>running test 399"
../source/print_tokens.c.inst.exe  < ../inputs/newtst442.tst > ../newoutputs/t399
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/398.tr
echo ">>>>>>>>running test 400"
../source/print_tokens.c.inst.exe  < ../inputs/newtst443.tst > ../newoutputs/t400
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/399.tr
echo ">>>>>>>>running test 401"
../source/print_tokens.c.inst.exe  < ../inputs/newtst444.tst > ../newoutputs/t401
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/400.tr
echo ">>>>>>>>running test 402"
../source/print_tokens.c.inst.exe  < ../inputs/newtst445.tst > ../newoutputs/t402
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/401.tr
echo ">>>>>>>>running test 403"
../source/print_tokens.c.inst.exe  < ../inputs/newtst446.tst > ../newoutputs/t403
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/402.tr
echo ">>>>>>>>running test 404"
../source/print_tokens.c.inst.exe  < ../inputs/newtst447.tst > ../newoutputs/t404
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/403.tr
echo ">>>>>>>>running test 405"
../source/print_tokens.c.inst.exe  < ../inputs/newtst448.tst > ../newoutputs/t405
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/404.tr
echo ">>>>>>>>running test 406"
../source/print_tokens.c.inst.exe  < ../inputs/newtst449.tst > ../newoutputs/t406
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/405.tr
echo ">>>>>>>>running test 407"
../source/print_tokens.c.inst.exe  < ../inputs/newtst45.tst > ../newoutputs/t407
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/406.tr
echo ">>>>>>>>running test 408"
../source/print_tokens.c.inst.exe  < ../inputs/newtst450.tst > ../newoutputs/t408
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/407.tr
echo ">>>>>>>>running test 409"
../source/print_tokens.c.inst.exe  < ../inputs/newtst451.tst > ../newoutputs/t409
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/408.tr
echo ">>>>>>>>running test 410"
../source/print_tokens.c.inst.exe  < ../inputs/newtst452.tst > ../newoutputs/t410
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/409.tr
echo ">>>>>>>>running test 411"
../source/print_tokens.c.inst.exe  < ../inputs/newtst453.tst > ../newoutputs/t411
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/410.tr
echo ">>>>>>>>running test 412"
../source/print_tokens.c.inst.exe  < ../inputs/newtst454.tst > ../newoutputs/t412
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/411.tr
echo ">>>>>>>>running test 413"
../source/print_tokens.c.inst.exe  < ../inputs/newtst455.tst > ../newoutputs/t413
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/412.tr
echo ">>>>>>>>running test 414"
../source/print_tokens.c.inst.exe  < ../inputs/newtst456.tst > ../newoutputs/t414
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/413.tr
echo ">>>>>>>>running test 415"
../source/print_tokens.c.inst.exe  < ../inputs/newtst457.tst > ../newoutputs/t415
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/414.tr
echo ">>>>>>>>running test 416"
../source/print_tokens.c.inst.exe  < ../inputs/newtst458.tst > ../newoutputs/t416
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/415.tr
echo ">>>>>>>>running test 417"
../source/print_tokens.c.inst.exe  < ../inputs/newtst459.tst > ../newoutputs/t417
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/416.tr
echo ">>>>>>>>running test 418"
../source/print_tokens.c.inst.exe  < ../inputs/newtst46.tst > ../newoutputs/t418
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/417.tr
echo ">>>>>>>>running test 419"
../source/print_tokens.c.inst.exe  < ../inputs/newtst460.tst > ../newoutputs/t419
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/418.tr
echo ">>>>>>>>running test 420"
../source/print_tokens.c.inst.exe  < ../inputs/newtst461.tst > ../newoutputs/t420
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/419.tr
echo ">>>>>>>>running test 421"
../source/print_tokens.c.inst.exe  < ../inputs/newtst462.tst > ../newoutputs/t421
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/420.tr
echo ">>>>>>>>running test 422"
../source/print_tokens.c.inst.exe  < ../inputs/newtst463.tst > ../newoutputs/t422
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/421.tr
echo ">>>>>>>>running test 423"
../source/print_tokens.c.inst.exe  < ../inputs/newtst464.tst > ../newoutputs/t423
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/422.tr
echo ">>>>>>>>running test 424"
../source/print_tokens.c.inst.exe  < ../inputs/newtst465.tst > ../newoutputs/t424
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/423.tr
echo ">>>>>>>>running test 425"
../source/print_tokens.c.inst.exe  < ../inputs/newtst466.tst > ../newoutputs/t425
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/424.tr
echo ">>>>>>>>running test 426"
../source/print_tokens.c.inst.exe  < ../inputs/newtst467.tst > ../newoutputs/t426
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/425.tr
echo ">>>>>>>>running test 427"
../source/print_tokens.c.inst.exe  < ../inputs/newtst468.tst > ../newoutputs/t427
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/426.tr
echo ">>>>>>>>running test 428"
../source/print_tokens.c.inst.exe  < ../inputs/newtst469.tst > ../newoutputs/t428
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/427.tr
echo ">>>>>>>>running test 429"
../source/print_tokens.c.inst.exe  < ../inputs/newtst47.tst > ../newoutputs/t429
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/428.tr
echo ">>>>>>>>running test 430"
../source/print_tokens.c.inst.exe  < ../inputs/newtst470.tst > ../newoutputs/t430
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/429.tr
echo ">>>>>>>>running test 431"
../source/print_tokens.c.inst.exe  < ../inputs/newtst471.tst > ../newoutputs/t431
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/430.tr
echo ">>>>>>>>running test 432"
../source/print_tokens.c.inst.exe  < ../inputs/newtst472.tst > ../newoutputs/t432
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/431.tr
echo ">>>>>>>>running test 433"
../source/print_tokens.c.inst.exe  < ../inputs/newtst473.tst > ../newoutputs/t433
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/432.tr
echo ">>>>>>>>running test 434"
../source/print_tokens.c.inst.exe  < ../inputs/newtst474.tst > ../newoutputs/t434
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/433.tr
echo ">>>>>>>>running test 435"
../source/print_tokens.c.inst.exe  < ../inputs/newtst475.tst > ../newoutputs/t435
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/434.tr
echo ">>>>>>>>running test 436"
../source/print_tokens.c.inst.exe  < ../inputs/newtst476.tst > ../newoutputs/t436
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/435.tr
echo ">>>>>>>>running test 437"
../source/print_tokens.c.inst.exe  < ../inputs/newtst477.tst > ../newoutputs/t437
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/436.tr
echo ">>>>>>>>running test 438"
../source/print_tokens.c.inst.exe  < ../inputs/newtst478.tst > ../newoutputs/t438
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/437.tr
echo ">>>>>>>>running test 439"
../source/print_tokens.c.inst.exe  < ../inputs/newtst479.tst > ../newoutputs/t439
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/438.tr
echo ">>>>>>>>running test 440"
../source/print_tokens.c.inst.exe  < ../inputs/newtst48.tst > ../newoutputs/t440
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/439.tr
echo ">>>>>>>>running test 441"
../source/print_tokens.c.inst.exe  < ../inputs/newtst480.tst > ../newoutputs/t441
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/440.tr
echo ">>>>>>>>running test 442"
../source/print_tokens.c.inst.exe  < ../inputs/newtst481.tst > ../newoutputs/t442
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/441.tr
echo ">>>>>>>>running test 443"
../source/print_tokens.c.inst.exe  < ../inputs/newtst482.tst > ../newoutputs/t443
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/442.tr
echo ">>>>>>>>running test 444"
../source/print_tokens.c.inst.exe  < ../inputs/newtst483.tst > ../newoutputs/t444
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/443.tr
echo ">>>>>>>>running test 445"
../source/print_tokens.c.inst.exe  < ../inputs/newtst484.tst > ../newoutputs/t445
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/444.tr
echo ">>>>>>>>running test 446"
../source/print_tokens.c.inst.exe  < ../inputs/newtst485.tst > ../newoutputs/t446
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/445.tr
echo ">>>>>>>>running test 447"
../source/print_tokens.c.inst.exe  < ../inputs/newtst486.tst > ../newoutputs/t447
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/446.tr
echo ">>>>>>>>running test 448"
../source/print_tokens.c.inst.exe  < ../inputs/newtst487.tst > ../newoutputs/t448
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/447.tr
echo ">>>>>>>>running test 449"
../source/print_tokens.c.inst.exe  < ../inputs/newtst488.tst > ../newoutputs/t449
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/448.tr
echo ">>>>>>>>running test 450"
../source/print_tokens.c.inst.exe  < ../inputs/newtst489.tst > ../newoutputs/t450
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/449.tr
echo ">>>>>>>>running test 451"
../source/print_tokens.c.inst.exe  < ../inputs/newtst49.tst > ../newoutputs/t451
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/450.tr
echo ">>>>>>>>running test 452"
../source/print_tokens.c.inst.exe  < ../inputs/newtst490.tst > ../newoutputs/t452
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/451.tr
echo ">>>>>>>>running test 453"
../source/print_tokens.c.inst.exe  < ../inputs/newtst491.tst > ../newoutputs/t453
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/452.tr
echo ">>>>>>>>running test 454"
../source/print_tokens.c.inst.exe  < ../inputs/newtst492.tst > ../newoutputs/t454
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/453.tr
echo ">>>>>>>>running test 455"
../source/print_tokens.c.inst.exe  < ../inputs/newtst493.tst > ../newoutputs/t455
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/454.tr
echo ">>>>>>>>running test 456"
../source/print_tokens.c.inst.exe  < ../inputs/newtst494.tst > ../newoutputs/t456
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/455.tr
echo ">>>>>>>>running test 457"
../source/print_tokens.c.inst.exe  < ../inputs/newtst495.tst > ../newoutputs/t457
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/456.tr
echo ">>>>>>>>running test 458"
../source/print_tokens.c.inst.exe  < ../inputs/newtst496.tst > ../newoutputs/t458
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/457.tr
echo ">>>>>>>>running test 459"
../source/print_tokens.c.inst.exe  < ../inputs/newtst497.tst > ../newoutputs/t459
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/458.tr
echo ">>>>>>>>running test 460"
../source/print_tokens.c.inst.exe  < ../inputs/newtst498.tst > ../newoutputs/t460
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/459.tr
echo ">>>>>>>>running test 461"
../source/print_tokens.c.inst.exe  < ../inputs/newtst499.tst > ../newoutputs/t461
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/460.tr
echo ">>>>>>>>running test 462"
../source/print_tokens.c.inst.exe  < ../inputs/newtst5.tst > ../newoutputs/t462
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/461.tr
echo ">>>>>>>>running test 463"
../source/print_tokens.c.inst.exe  < ../inputs/newtst5.tst.tst > ../newoutputs/t463
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/462.tr
echo ">>>>>>>>running test 464"
../source/print_tokens.c.inst.exe  < ../inputs/newtst50.tst > ../newoutputs/t464
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/463.tr
echo ">>>>>>>>running test 465"
../source/print_tokens.c.inst.exe  < ../inputs/newtst500.tst > ../newoutputs/t465
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/464.tr
echo ">>>>>>>>running test 466"
../source/print_tokens.c.inst.exe  < ../inputs/newtst501.tst > ../newoutputs/t466
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/465.tr
echo ">>>>>>>>running test 467"
../source/print_tokens.c.inst.exe  < ../inputs/newtst502.tst > ../newoutputs/t467
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/466.tr
echo ">>>>>>>>running test 468"
../source/print_tokens.c.inst.exe  < ../inputs/newtst503.tst > ../newoutputs/t468
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/467.tr
echo ">>>>>>>>running test 469"
../source/print_tokens.c.inst.exe  < ../inputs/newtst504.tst > ../newoutputs/t469
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/468.tr
echo ">>>>>>>>running test 470"
../source/print_tokens.c.inst.exe  < ../inputs/newtst505.tst > ../newoutputs/t470
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/469.tr
echo ">>>>>>>>running test 471"
../source/print_tokens.c.inst.exe  < ../inputs/newtst506.tst > ../newoutputs/t471
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/470.tr
echo ">>>>>>>>running test 472"
../source/print_tokens.c.inst.exe  < ../inputs/newtst507.tst > ../newoutputs/t472
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/471.tr
echo ">>>>>>>>running test 473"
../source/print_tokens.c.inst.exe  < ../inputs/newtst508.tst > ../newoutputs/t473
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/472.tr
echo ">>>>>>>>running test 474"
../source/print_tokens.c.inst.exe  < ../inputs/newtst509.tst > ../newoutputs/t474
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/473.tr
echo ">>>>>>>>running test 475"
../source/print_tokens.c.inst.exe  < ../inputs/newtst51.tst > ../newoutputs/t475
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/474.tr
echo ">>>>>>>>running test 476"
../source/print_tokens.c.inst.exe  < ../inputs/newtst510.tst > ../newoutputs/t476
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/475.tr
echo ">>>>>>>>running test 477"
../source/print_tokens.c.inst.exe  < ../inputs/newtst511.tst > ../newoutputs/t477
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/476.tr
echo ">>>>>>>>running test 478"
../source/print_tokens.c.inst.exe  < ../inputs/newtst512.tst > ../newoutputs/t478
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/477.tr
echo ">>>>>>>>running test 479"
../source/print_tokens.c.inst.exe  < ../inputs/newtst513.tst > ../newoutputs/t479
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/478.tr
echo ">>>>>>>>running test 480"
../source/print_tokens.c.inst.exe  < ../inputs/newtst514.tst > ../newoutputs/t480
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/479.tr
echo ">>>>>>>>running test 481"
../source/print_tokens.c.inst.exe  < ../inputs/newtst515.tst > ../newoutputs/t481
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/480.tr
echo ">>>>>>>>running test 482"
../source/print_tokens.c.inst.exe  < ../inputs/newtst516.tst > ../newoutputs/t482
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/481.tr
echo ">>>>>>>>running test 483"
../source/print_tokens.c.inst.exe  < ../inputs/newtst517.tst > ../newoutputs/t483
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/482.tr
echo ">>>>>>>>running test 484"
../source/print_tokens.c.inst.exe  < ../inputs/newtst518.tst > ../newoutputs/t484
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/483.tr
echo ">>>>>>>>running test 485"
../source/print_tokens.c.inst.exe  < ../inputs/newtst519.tst > ../newoutputs/t485
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/484.tr
echo ">>>>>>>>running test 486"
../source/print_tokens.c.inst.exe  < ../inputs/newtst52.tst > ../newoutputs/t486
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/485.tr
echo ">>>>>>>>running test 487"
../source/print_tokens.c.inst.exe  < ../inputs/newtst520.tst > ../newoutputs/t487
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/486.tr
echo ">>>>>>>>running test 488"
../source/print_tokens.c.inst.exe  < ../inputs/newtst521.tst > ../newoutputs/t488
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/487.tr
echo ">>>>>>>>running test 489"
../source/print_tokens.c.inst.exe  < ../inputs/newtst522.tst > ../newoutputs/t489
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/488.tr
echo ">>>>>>>>running test 490"
../source/print_tokens.c.inst.exe  < ../inputs/newtst523.tst > ../newoutputs/t490
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/489.tr
echo ">>>>>>>>running test 491"
../source/print_tokens.c.inst.exe  < ../inputs/newtst524.tst > ../newoutputs/t491
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/490.tr
echo ">>>>>>>>running test 492"
../source/print_tokens.c.inst.exe  < ../inputs/newtst525.tst > ../newoutputs/t492
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/491.tr
echo ">>>>>>>>running test 493"
../source/print_tokens.c.inst.exe  < ../inputs/newtst526.tst > ../newoutputs/t493
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/492.tr
echo ">>>>>>>>running test 494"
../source/print_tokens.c.inst.exe  < ../inputs/newtst527.tst > ../newoutputs/t494
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/493.tr
echo ">>>>>>>>running test 495"
../source/print_tokens.c.inst.exe  < ../inputs/newtst528.tst > ../newoutputs/t495
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/494.tr
echo ">>>>>>>>running test 496"
../source/print_tokens.c.inst.exe  < ../inputs/newtst529.tst > ../newoutputs/t496
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/495.tr
echo ">>>>>>>>running test 497"
../source/print_tokens.c.inst.exe  < ../inputs/newtst53.tst > ../newoutputs/t497
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/496.tr
echo ">>>>>>>>running test 498"
../source/print_tokens.c.inst.exe  < ../inputs/newtst530.tst > ../newoutputs/t498
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/497.tr
echo ">>>>>>>>running test 499"
../source/print_tokens.c.inst.exe  < ../inputs/newtst531.tst > ../newoutputs/t499
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/498.tr
echo ">>>>>>>>running test 500"
../source/print_tokens.c.inst.exe  < ../inputs/newtst532.tst > ../newoutputs/t500
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/499.tr
echo ">>>>>>>>running test 501"
../source/print_tokens.c.inst.exe  < ../inputs/newtst533.tst > ../newoutputs/t501
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/500.tr
echo ">>>>>>>>running test 502"
../source/print_tokens.c.inst.exe  < ../inputs/newtst534.tst > ../newoutputs/t502
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/501.tr
echo ">>>>>>>>running test 503"
../source/print_tokens.c.inst.exe  < ../inputs/newtst535.tst > ../newoutputs/t503
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/502.tr
echo ">>>>>>>>running test 504"
../source/print_tokens.c.inst.exe  < ../inputs/newtst536.tst > ../newoutputs/t504
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/503.tr
echo ">>>>>>>>running test 505"
../source/print_tokens.c.inst.exe  < ../inputs/newtst537.tst > ../newoutputs/t505
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/504.tr
echo ">>>>>>>>running test 506"
../source/print_tokens.c.inst.exe  < ../inputs/newtst538.tst > ../newoutputs/t506
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/505.tr
echo ">>>>>>>>running test 507"
../source/print_tokens.c.inst.exe  < ../inputs/newtst539.tst > ../newoutputs/t507
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/506.tr
echo ">>>>>>>>running test 508"
../source/print_tokens.c.inst.exe  < ../inputs/newtst54.tst > ../newoutputs/t508
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/507.tr
echo ">>>>>>>>running test 509"
../source/print_tokens.c.inst.exe  < ../inputs/newtst540.tst > ../newoutputs/t509
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/508.tr
echo ">>>>>>>>running test 510"
../source/print_tokens.c.inst.exe  < ../inputs/newtst541.tst > ../newoutputs/t510
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/509.tr
echo ">>>>>>>>running test 511"
../source/print_tokens.c.inst.exe  < ../inputs/newtst542.tst > ../newoutputs/t511
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/510.tr
echo ">>>>>>>>running test 512"
../source/print_tokens.c.inst.exe  < ../inputs/newtst543.tst > ../newoutputs/t512
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/511.tr
echo ">>>>>>>>running test 513"
../source/print_tokens.c.inst.exe  < ../inputs/newtst544.tst > ../newoutputs/t513
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/512.tr
echo ">>>>>>>>running test 514"
../source/print_tokens.c.inst.exe  < ../inputs/newtst545.tst > ../newoutputs/t514
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/513.tr
echo ">>>>>>>>running test 515"
../source/print_tokens.c.inst.exe  < ../inputs/newtst546.tst > ../newoutputs/t515
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/514.tr
echo ">>>>>>>>running test 516"
../source/print_tokens.c.inst.exe  < ../inputs/newtst547.tst > ../newoutputs/t516
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/515.tr
echo ">>>>>>>>running test 517"
../source/print_tokens.c.inst.exe  < ../inputs/newtst548.tst > ../newoutputs/t517
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/516.tr
echo ">>>>>>>>running test 518"
../source/print_tokens.c.inst.exe  < ../inputs/newtst549.tst > ../newoutputs/t518
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/517.tr
echo ">>>>>>>>running test 519"
../source/print_tokens.c.inst.exe  < ../inputs/newtst55.tst > ../newoutputs/t519
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/518.tr
echo ">>>>>>>>running test 520"
../source/print_tokens.c.inst.exe  < ../inputs/newtst550.tst > ../newoutputs/t520
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/519.tr
echo ">>>>>>>>running test 521"
../source/print_tokens.c.inst.exe  < ../inputs/newtst551.tst > ../newoutputs/t521
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/520.tr
echo ">>>>>>>>running test 522"
../source/print_tokens.c.inst.exe  < ../inputs/newtst552.tst > ../newoutputs/t522
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/521.tr
echo ">>>>>>>>running test 523"
../source/print_tokens.c.inst.exe  < ../inputs/newtst553.tst > ../newoutputs/t523
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/522.tr
echo ">>>>>>>>running test 524"
../source/print_tokens.c.inst.exe  < ../inputs/newtst554.tst > ../newoutputs/t524
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/523.tr
echo ">>>>>>>>running test 525"
../source/print_tokens.c.inst.exe  < ../inputs/newtst555.tst > ../newoutputs/t525
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/524.tr
echo ">>>>>>>>running test 526"
../source/print_tokens.c.inst.exe  < ../inputs/newtst556.tst > ../newoutputs/t526
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/525.tr
echo ">>>>>>>>running test 527"
../source/print_tokens.c.inst.exe  < ../inputs/newtst557.tst > ../newoutputs/t527
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/526.tr
echo ">>>>>>>>running test 528"
../source/print_tokens.c.inst.exe  < ../inputs/newtst558.tst > ../newoutputs/t528
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/527.tr
echo ">>>>>>>>running test 529"
../source/print_tokens.c.inst.exe  < ../inputs/newtst559.tst > ../newoutputs/t529
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/528.tr
echo ">>>>>>>>running test 530"
../source/print_tokens.c.inst.exe  < ../inputs/newtst56.tst > ../newoutputs/t530
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/529.tr
echo ">>>>>>>>running test 531"
../source/print_tokens.c.inst.exe  < ../inputs/newtst560.tst > ../newoutputs/t531
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/530.tr
echo ">>>>>>>>running test 532"
../source/print_tokens.c.inst.exe  < ../inputs/newtst561.tst > ../newoutputs/t532
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/531.tr
echo ">>>>>>>>running test 533"
../source/print_tokens.c.inst.exe  < ../inputs/newtst562.tst > ../newoutputs/t533
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/532.tr
echo ">>>>>>>>running test 534"
../source/print_tokens.c.inst.exe  < ../inputs/newtst563.tst > ../newoutputs/t534
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/533.tr
echo ">>>>>>>>running test 535"
../source/print_tokens.c.inst.exe  < ../inputs/newtst564.tst > ../newoutputs/t535
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/534.tr
echo ">>>>>>>>running test 536"
../source/print_tokens.c.inst.exe  < ../inputs/newtst565.tst > ../newoutputs/t536
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/535.tr
echo ">>>>>>>>running test 537"
../source/print_tokens.c.inst.exe  < ../inputs/newtst566.tst > ../newoutputs/t537
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/536.tr
echo ">>>>>>>>running test 538"
../source/print_tokens.c.inst.exe  < ../inputs/newtst567.tst > ../newoutputs/t538
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/537.tr
echo ">>>>>>>>running test 539"
../source/print_tokens.c.inst.exe  < ../inputs/newtst568.tst > ../newoutputs/t539
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/538.tr
echo ">>>>>>>>running test 540"
../source/print_tokens.c.inst.exe  < ../inputs/newtst569.tst > ../newoutputs/t540
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/539.tr
echo ">>>>>>>>running test 541"
../source/print_tokens.c.inst.exe  < ../inputs/newtst57.tst > ../newoutputs/t541
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/540.tr
echo ">>>>>>>>running test 542"
../source/print_tokens.c.inst.exe  < ../inputs/newtst570.tst > ../newoutputs/t542
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/541.tr
echo ">>>>>>>>running test 543"
../source/print_tokens.c.inst.exe  < ../inputs/newtst571.tst > ../newoutputs/t543
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/542.tr
echo ">>>>>>>>running test 544"
../source/print_tokens.c.inst.exe  < ../inputs/newtst572.tst > ../newoutputs/t544
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/543.tr
echo ">>>>>>>>running test 545"
../source/print_tokens.c.inst.exe  < ../inputs/newtst573.tst > ../newoutputs/t545
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/544.tr
echo ">>>>>>>>running test 546"
../source/print_tokens.c.inst.exe  < ../inputs/newtst574.tst > ../newoutputs/t546
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/545.tr
echo ">>>>>>>>running test 547"
../source/print_tokens.c.inst.exe  < ../inputs/newtst575.tst > ../newoutputs/t547
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/546.tr
echo ">>>>>>>>running test 548"
../source/print_tokens.c.inst.exe  < ../inputs/newtst576.tst > ../newoutputs/t548
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/547.tr
echo ">>>>>>>>running test 549"
../source/print_tokens.c.inst.exe  < ../inputs/newtst577.tst > ../newoutputs/t549
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/548.tr
echo ">>>>>>>>running test 550"
../source/print_tokens.c.inst.exe  < ../inputs/newtst578.tst > ../newoutputs/t550
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/549.tr
echo ">>>>>>>>running test 551"
../source/print_tokens.c.inst.exe  < ../inputs/newtst579.tst > ../newoutputs/t551
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/550.tr
echo ">>>>>>>>running test 552"
../source/print_tokens.c.inst.exe  < ../inputs/newtst58.tst > ../newoutputs/t552
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/551.tr
echo ">>>>>>>>running test 553"
../source/print_tokens.c.inst.exe  < ../inputs/newtst580.tst > ../newoutputs/t553
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/552.tr
echo ">>>>>>>>running test 554"
../source/print_tokens.c.inst.exe  < ../inputs/newtst581.tst > ../newoutputs/t554
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/553.tr
echo ">>>>>>>>running test 555"
../source/print_tokens.c.inst.exe  < ../inputs/newtst582.tst > ../newoutputs/t555
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/554.tr
echo ">>>>>>>>running test 556"
../source/print_tokens.c.inst.exe  < ../inputs/newtst583.tst > ../newoutputs/t556
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/555.tr
echo ">>>>>>>>running test 557"
../source/print_tokens.c.inst.exe  < ../inputs/newtst584.tst > ../newoutputs/t557
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/556.tr
echo ">>>>>>>>running test 558"
../source/print_tokens.c.inst.exe  < ../inputs/newtst585.tst > ../newoutputs/t558
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/557.tr
echo ">>>>>>>>running test 559"
../source/print_tokens.c.inst.exe  < ../inputs/newtst586.tst > ../newoutputs/t559
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/558.tr
echo ">>>>>>>>running test 560"
../source/print_tokens.c.inst.exe  < ../inputs/newtst587.tst > ../newoutputs/t560
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/559.tr
echo ">>>>>>>>running test 561"
../source/print_tokens.c.inst.exe  < ../inputs/newtst588.tst > ../newoutputs/t561
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/560.tr
echo ">>>>>>>>running test 562"
../source/print_tokens.c.inst.exe  < ../inputs/newtst589.tst > ../newoutputs/t562
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/561.tr
echo ">>>>>>>>running test 563"
../source/print_tokens.c.inst.exe  < ../inputs/newtst59.tst > ../newoutputs/t563
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/562.tr
echo ">>>>>>>>running test 564"
../source/print_tokens.c.inst.exe  < ../inputs/newtst590.tst > ../newoutputs/t564
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/563.tr
echo ">>>>>>>>running test 565"
../source/print_tokens.c.inst.exe  < ../inputs/newtst591.tst > ../newoutputs/t565
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/564.tr
echo ">>>>>>>>running test 566"
../source/print_tokens.c.inst.exe  < ../inputs/newtst592.tst > ../newoutputs/t566
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/565.tr
echo ">>>>>>>>running test 567"
../source/print_tokens.c.inst.exe  < ../inputs/newtst593.tst > ../newoutputs/t567
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/566.tr
echo ">>>>>>>>running test 568"
../source/print_tokens.c.inst.exe  < ../inputs/newtst594.tst > ../newoutputs/t568
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/567.tr
echo ">>>>>>>>running test 569"
../source/print_tokens.c.inst.exe  < ../inputs/newtst595.tst > ../newoutputs/t569
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/568.tr
echo ">>>>>>>>running test 570"
../source/print_tokens.c.inst.exe  < ../inputs/newtst596.tst > ../newoutputs/t570
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/569.tr
echo ">>>>>>>>running test 571"
../source/print_tokens.c.inst.exe  < ../inputs/newtst597.tst > ../newoutputs/t571
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/570.tr
echo ">>>>>>>>running test 572"
../source/print_tokens.c.inst.exe  < ../inputs/newtst598.tst > ../newoutputs/t572
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/571.tr
echo ">>>>>>>>running test 573"
../source/print_tokens.c.inst.exe  < ../inputs/newtst599.tst > ../newoutputs/t573
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/572.tr
echo ">>>>>>>>running test 574"
../source/print_tokens.c.inst.exe  < ../inputs/newtst6.tst > ../newoutputs/t574
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/573.tr
echo ">>>>>>>>running test 575"
../source/print_tokens.c.inst.exe  < ../inputs/newtst6.tst.tst > ../newoutputs/t575
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/574.tr
echo ">>>>>>>>running test 576"
../source/print_tokens.c.inst.exe  < ../inputs/newtst60.tst > ../newoutputs/t576
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/575.tr
echo ">>>>>>>>running test 577"
../source/print_tokens.c.inst.exe  < ../inputs/newtst600.tst > ../newoutputs/t577
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/576.tr
echo ">>>>>>>>running test 578"
../source/print_tokens.c.inst.exe  < ../inputs/newtst61.tst > ../newoutputs/t578
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/577.tr
echo ">>>>>>>>running test 579"
../source/print_tokens.c.inst.exe  < ../inputs/newtst62.tst > ../newoutputs/t579
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/578.tr
echo ">>>>>>>>running test 580"
../source/print_tokens.c.inst.exe  < ../inputs/newtst63.tst > ../newoutputs/t580
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/579.tr
echo ">>>>>>>>running test 581"
../source/print_tokens.c.inst.exe  < ../inputs/newtst64.tst > ../newoutputs/t581
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/580.tr
echo ">>>>>>>>running test 582"
../source/print_tokens.c.inst.exe  < ../inputs/newtst65.tst > ../newoutputs/t582
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/581.tr
echo ">>>>>>>>running test 583"
../source/print_tokens.c.inst.exe  < ../inputs/newtst66.tst > ../newoutputs/t583
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/582.tr
echo ">>>>>>>>running test 584"
../source/print_tokens.c.inst.exe  < ../inputs/newtst67.tst > ../newoutputs/t584
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/583.tr
echo ">>>>>>>>running test 585"
../source/print_tokens.c.inst.exe  < ../inputs/newtst68.tst > ../newoutputs/t585
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/584.tr
echo ">>>>>>>>running test 586"
../source/print_tokens.c.inst.exe  < ../inputs/newtst69.tst > ../newoutputs/t586
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/585.tr
echo ">>>>>>>>running test 587"
../source/print_tokens.c.inst.exe  < ../inputs/newtst7.tst > ../newoutputs/t587
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/586.tr
echo ">>>>>>>>running test 588"
../source/print_tokens.c.inst.exe  < ../inputs/newtst7.tst.tst > ../newoutputs/t588
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/587.tr
echo ">>>>>>>>running test 589"
../source/print_tokens.c.inst.exe  < ../inputs/newtst70.tst > ../newoutputs/t589
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/588.tr
echo ">>>>>>>>running test 590"
../source/print_tokens.c.inst.exe  < ../inputs/newtst71.tst > ../newoutputs/t590
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/589.tr
echo ">>>>>>>>running test 591"
../source/print_tokens.c.inst.exe  < ../inputs/newtst72.tst > ../newoutputs/t591
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/590.tr
echo ">>>>>>>>running test 592"
../source/print_tokens.c.inst.exe  < ../inputs/newtst73.tst > ../newoutputs/t592
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/591.tr
echo ">>>>>>>>running test 593"
../source/print_tokens.c.inst.exe  < ../inputs/newtst74.tst > ../newoutputs/t593
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/592.tr
echo ">>>>>>>>running test 594"
../source/print_tokens.c.inst.exe  < ../inputs/newtst75.tst > ../newoutputs/t594
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/593.tr
echo ">>>>>>>>running test 595"
../source/print_tokens.c.inst.exe  < ../inputs/newtst76.tst > ../newoutputs/t595
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/594.tr
echo ">>>>>>>>running test 596"
../source/print_tokens.c.inst.exe  < ../inputs/newtst77.tst > ../newoutputs/t596
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/595.tr
echo ">>>>>>>>running test 597"
../source/print_tokens.c.inst.exe  < ../inputs/newtst78.tst > ../newoutputs/t597
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/596.tr
echo ">>>>>>>>running test 598"
../source/print_tokens.c.inst.exe  < ../inputs/newtst79.tst > ../newoutputs/t598
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/597.tr
echo ">>>>>>>>running test 599"
../source/print_tokens.c.inst.exe  < ../inputs/newtst8.tst > ../newoutputs/t599
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/598.tr
echo ">>>>>>>>running test 600"
../source/print_tokens.c.inst.exe  < ../inputs/newtst8.tst.tst > ../newoutputs/t600
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/599.tr
echo ">>>>>>>>running test 601"
../source/print_tokens.c.inst.exe  < ../inputs/newtst80.tst > ../newoutputs/t601
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/600.tr
echo ">>>>>>>>running test 602"
../source/print_tokens.c.inst.exe  < ../inputs/newtst81.tst > ../newoutputs/t602
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/601.tr
echo ">>>>>>>>running test 603"
../source/print_tokens.c.inst.exe  < ../inputs/newtst82.tst > ../newoutputs/t603
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/602.tr
echo ">>>>>>>>running test 604"
../source/print_tokens.c.inst.exe  < ../inputs/newtst83.tst > ../newoutputs/t604
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/603.tr
echo ">>>>>>>>running test 605"
../source/print_tokens.c.inst.exe  < ../inputs/newtst84.tst > ../newoutputs/t605
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/604.tr
echo ">>>>>>>>running test 606"
../source/print_tokens.c.inst.exe  < ../inputs/newtst85.tst > ../newoutputs/t606
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/605.tr
echo ">>>>>>>>running test 607"
../source/print_tokens.c.inst.exe  < ../inputs/newtst86.tst > ../newoutputs/t607
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/606.tr
echo ">>>>>>>>running test 608"
../source/print_tokens.c.inst.exe  < ../inputs/newtst87.tst > ../newoutputs/t608
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/607.tr
echo ">>>>>>>>running test 609"
../source/print_tokens.c.inst.exe  < ../inputs/newtst88.tst > ../newoutputs/t609
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/608.tr
echo ">>>>>>>>running test 610"
../source/print_tokens.c.inst.exe  < ../inputs/newtst89.tst > ../newoutputs/t610
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/609.tr
echo ">>>>>>>>running test 611"
../source/print_tokens.c.inst.exe  < ../inputs/newtst9.tst > ../newoutputs/t611
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/610.tr
echo ">>>>>>>>running test 612"
../source/print_tokens.c.inst.exe  < ../inputs/newtst9.tst.tst > ../newoutputs/t612
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/611.tr
echo ">>>>>>>>running test 613"
../source/print_tokens.c.inst.exe  < ../inputs/newtst90.tst > ../newoutputs/t613
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/612.tr
echo ">>>>>>>>running test 614"
../source/print_tokens.c.inst.exe  < ../inputs/newtst91.tst > ../newoutputs/t614
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/613.tr
echo ">>>>>>>>running test 615"
../source/print_tokens.c.inst.exe  < ../inputs/newtst92.tst > ../newoutputs/t615
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/614.tr
echo ">>>>>>>>running test 616"
../source/print_tokens.c.inst.exe  < ../inputs/newtst93.tst > ../newoutputs/t616
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/615.tr
echo ">>>>>>>>running test 617"
../source/print_tokens.c.inst.exe  < ../inputs/newtst94.tst > ../newoutputs/t617
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/616.tr
echo ">>>>>>>>running test 618"
../source/print_tokens.c.inst.exe  < ../inputs/newtst95.tst > ../newoutputs/t618
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/617.tr
echo ">>>>>>>>running test 619"
../source/print_tokens.c.inst.exe  < ../inputs/newtst96.tst > ../newoutputs/t619
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/618.tr
echo ">>>>>>>>running test 620"
../source/print_tokens.c.inst.exe  < ../inputs/newtst97.tst > ../newoutputs/t620
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/619.tr
echo ">>>>>>>>running test 621"
../source/print_tokens.c.inst.exe  < ../inputs/newtst98.tst > ../newoutputs/t621
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/620.tr
echo ">>>>>>>>running test 622"
../source/print_tokens.c.inst.exe  < ../inputs/newtst99.tst > ../newoutputs/t622
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/621.tr
echo ">>>>>>>>running test 623"
../source/print_tokens.c.inst.exe  < ../inputs/tc1 > ../newoutputs/t623
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/622.tr
echo ">>>>>>>>running test 624"
../source/print_tokens.c.inst.exe  < ../inputs/tc10 > ../newoutputs/t624
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/623.tr
echo ">>>>>>>>running test 625"
../source/print_tokens.c.inst.exe  < ../inputs/tc100 > ../newoutputs/t625
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/624.tr
echo ">>>>>>>>running test 626"
../source/print_tokens.c.inst.exe  < ../inputs/tc101 > ../newoutputs/t626
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/625.tr
echo ">>>>>>>>running test 627"
../source/print_tokens.c.inst.exe  < ../inputs/tc102 > ../newoutputs/t627
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/626.tr
echo ">>>>>>>>running test 628"
../source/print_tokens.c.inst.exe  < ../inputs/tc103 > ../newoutputs/t628
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/627.tr
echo ">>>>>>>>running test 629"
../source/print_tokens.c.inst.exe  < ../inputs/tc104 > ../newoutputs/t629
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/628.tr
echo ">>>>>>>>running test 630"
../source/print_tokens.c.inst.exe  < ../inputs/tc105 > ../newoutputs/t630
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/629.tr
echo ">>>>>>>>running test 631"
../source/print_tokens.c.inst.exe  < ../inputs/tc106 > ../newoutputs/t631
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/630.tr
echo ">>>>>>>>running test 632"
../source/print_tokens.c.inst.exe  < ../inputs/tc107 > ../newoutputs/t632
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/631.tr
echo ">>>>>>>>running test 633"
../source/print_tokens.c.inst.exe  < ../inputs/tc108 > ../newoutputs/t633
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/632.tr
echo ">>>>>>>>running test 634"
../source/print_tokens.c.inst.exe  < ../inputs/tc109 > ../newoutputs/t634
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/633.tr
echo ">>>>>>>>running test 635"
../source/print_tokens.c.inst.exe  < ../inputs/tc11 > ../newoutputs/t635
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/634.tr
echo ">>>>>>>>running test 636"
../source/print_tokens.c.inst.exe  < ../inputs/tc110 > ../newoutputs/t636
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/635.tr
echo ">>>>>>>>running test 637"
../source/print_tokens.c.inst.exe  < ../inputs/tc111 > ../newoutputs/t637
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/636.tr
echo ">>>>>>>>running test 638"
../source/print_tokens.c.inst.exe  < ../inputs/tc112 > ../newoutputs/t638
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/637.tr
echo ">>>>>>>>running test 639"
../source/print_tokens.c.inst.exe  < ../inputs/tc113 > ../newoutputs/t639
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/638.tr
echo ">>>>>>>>running test 640"
../source/print_tokens.c.inst.exe  < ../inputs/tc114 > ../newoutputs/t640
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/639.tr
echo ">>>>>>>>running test 641"
../source/print_tokens.c.inst.exe  < ../inputs/tc115 > ../newoutputs/t641
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/640.tr
echo ">>>>>>>>running test 642"
../source/print_tokens.c.inst.exe  < ../inputs/tc116 > ../newoutputs/t642
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/641.tr
echo ">>>>>>>>running test 643"
../source/print_tokens.c.inst.exe  < ../inputs/tc117 > ../newoutputs/t643
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/642.tr
echo ">>>>>>>>running test 644"
../source/print_tokens.c.inst.exe  < ../inputs/tc118 > ../newoutputs/t644
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/643.tr
echo ">>>>>>>>running test 645"
../source/print_tokens.c.inst.exe  < ../inputs/tc119 > ../newoutputs/t645
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/644.tr
echo ">>>>>>>>running test 646"
../source/print_tokens.c.inst.exe  < ../inputs/tc12 > ../newoutputs/t646
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/645.tr
echo ">>>>>>>>running test 647"
../source/print_tokens.c.inst.exe  < ../inputs/tc120 > ../newoutputs/t647
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/646.tr
echo ">>>>>>>>running test 648"
../source/print_tokens.c.inst.exe  < ../inputs/tc121 > ../newoutputs/t648
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/647.tr
echo ">>>>>>>>running test 649"
../source/print_tokens.c.inst.exe  < ../inputs/tc122 > ../newoutputs/t649
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/648.tr
echo ">>>>>>>>running test 650"
../source/print_tokens.c.inst.exe  < ../inputs/tc123 > ../newoutputs/t650
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/649.tr
echo ">>>>>>>>running test 651"
../source/print_tokens.c.inst.exe  < ../inputs/tc124 > ../newoutputs/t651
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/650.tr
echo ">>>>>>>>running test 652"
../source/print_tokens.c.inst.exe  < ../inputs/tc125 > ../newoutputs/t652
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/651.tr
echo ">>>>>>>>running test 653"
../source/print_tokens.c.inst.exe  < ../inputs/tc126 > ../newoutputs/t653
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/652.tr
echo ">>>>>>>>running test 654"
../source/print_tokens.c.inst.exe  < ../inputs/tc127 > ../newoutputs/t654
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/653.tr
echo ">>>>>>>>running test 655"
../source/print_tokens.c.inst.exe  < ../inputs/tc128 > ../newoutputs/t655
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/654.tr
echo ">>>>>>>>running test 656"
../source/print_tokens.c.inst.exe  < ../inputs/tc129 > ../newoutputs/t656
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/655.tr
echo ">>>>>>>>running test 657"
../source/print_tokens.c.inst.exe  < ../inputs/tc13 > ../newoutputs/t657
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/656.tr
echo ">>>>>>>>running test 658"
../source/print_tokens.c.inst.exe  < ../inputs/tc130 > ../newoutputs/t658
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/657.tr
echo ">>>>>>>>running test 659"
../source/print_tokens.c.inst.exe  < ../inputs/tc131 > ../newoutputs/t659
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/658.tr
echo ">>>>>>>>running test 660"
../source/print_tokens.c.inst.exe  < ../inputs/tc132 > ../newoutputs/t660
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/659.tr
echo ">>>>>>>>running test 661"
../source/print_tokens.c.inst.exe  < ../inputs/tc133 > ../newoutputs/t661
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/660.tr
echo ">>>>>>>>running test 662"
../source/print_tokens.c.inst.exe  < ../inputs/tc134 > ../newoutputs/t662
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/661.tr
echo ">>>>>>>>running test 663"
../source/print_tokens.c.inst.exe  < ../inputs/tc135 > ../newoutputs/t663
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/662.tr
echo ">>>>>>>>running test 664"
../source/print_tokens.c.inst.exe  < ../inputs/tc136 > ../newoutputs/t664
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/663.tr
echo ">>>>>>>>running test 665"
../source/print_tokens.c.inst.exe  < ../inputs/tc137 > ../newoutputs/t665
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/664.tr
echo ">>>>>>>>running test 666"
../source/print_tokens.c.inst.exe  < ../inputs/tc138 > ../newoutputs/t666
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/665.tr
echo ">>>>>>>>running test 667"
../source/print_tokens.c.inst.exe  < ../inputs/tc139 > ../newoutputs/t667
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/666.tr
echo ">>>>>>>>running test 668"
../source/print_tokens.c.inst.exe  < ../inputs/tc14 > ../newoutputs/t668
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/667.tr
echo ">>>>>>>>running test 669"
../source/print_tokens.c.inst.exe  < ../inputs/tc140 > ../newoutputs/t669
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/668.tr
echo ">>>>>>>>running test 670"
../source/print_tokens.c.inst.exe  < ../inputs/tc141 > ../newoutputs/t670
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/669.tr
echo ">>>>>>>>running test 671"
../source/print_tokens.c.inst.exe  < ../inputs/tc142 > ../newoutputs/t671
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/670.tr
echo ">>>>>>>>running test 672"
../source/print_tokens.c.inst.exe  < ../inputs/tc143 > ../newoutputs/t672
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/671.tr
echo ">>>>>>>>running test 673"
../source/print_tokens.c.inst.exe  < ../inputs/tc144 > ../newoutputs/t673
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/672.tr
echo ">>>>>>>>running test 674"
../source/print_tokens.c.inst.exe  < ../inputs/tc145 > ../newoutputs/t674
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/673.tr
echo ">>>>>>>>running test 675"
../source/print_tokens.c.inst.exe  < ../inputs/tc146 > ../newoutputs/t675
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/674.tr
echo ">>>>>>>>running test 676"
../source/print_tokens.c.inst.exe  < ../inputs/tc147 > ../newoutputs/t676
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/675.tr
echo ">>>>>>>>running test 677"
../source/print_tokens.c.inst.exe  < ../inputs/tc148 > ../newoutputs/t677
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/676.tr
echo ">>>>>>>>running test 678"
../source/print_tokens.c.inst.exe  < ../inputs/tc149 > ../newoutputs/t678
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/677.tr
echo ">>>>>>>>running test 679"
../source/print_tokens.c.inst.exe  < ../inputs/tc15 > ../newoutputs/t679
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/678.tr
echo ">>>>>>>>running test 680"
../source/print_tokens.c.inst.exe  < ../inputs/tc150 > ../newoutputs/t680
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/679.tr
echo ">>>>>>>>running test 681"
../source/print_tokens.c.inst.exe  < ../inputs/tc151 > ../newoutputs/t681
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/680.tr
echo ">>>>>>>>running test 682"
../source/print_tokens.c.inst.exe  < ../inputs/tc152 > ../newoutputs/t682
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/681.tr
echo ">>>>>>>>running test 683"
../source/print_tokens.c.inst.exe  < ../inputs/tc153 > ../newoutputs/t683
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/682.tr
echo ">>>>>>>>running test 684"
../source/print_tokens.c.inst.exe  < ../inputs/tc154 > ../newoutputs/t684
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/683.tr
echo ">>>>>>>>running test 685"
../source/print_tokens.c.inst.exe  < ../inputs/tc155 > ../newoutputs/t685
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/684.tr
echo ">>>>>>>>running test 686"
../source/print_tokens.c.inst.exe  < ../inputs/tc156 > ../newoutputs/t686
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/685.tr
echo ">>>>>>>>running test 687"
../source/print_tokens.c.inst.exe  < ../inputs/tc157 > ../newoutputs/t687
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/686.tr
echo ">>>>>>>>running test 688"
../source/print_tokens.c.inst.exe  < ../inputs/tc158 > ../newoutputs/t688
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/687.tr
echo ">>>>>>>>running test 689"
../source/print_tokens.c.inst.exe  < ../inputs/tc159 > ../newoutputs/t689
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/688.tr
echo ">>>>>>>>running test 690"
../source/print_tokens.c.inst.exe  < ../inputs/tc16 > ../newoutputs/t690
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/689.tr
echo ">>>>>>>>running test 691"
../source/print_tokens.c.inst.exe  < ../inputs/tc160 > ../newoutputs/t691
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/690.tr
echo ">>>>>>>>running test 692"
../source/print_tokens.c.inst.exe  < ../inputs/tc161 > ../newoutputs/t692
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/691.tr
echo ">>>>>>>>running test 693"
../source/print_tokens.c.inst.exe  < ../inputs/tc162 > ../newoutputs/t693
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/692.tr
echo ">>>>>>>>running test 694"
../source/print_tokens.c.inst.exe  < ../inputs/tc163 > ../newoutputs/t694
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/693.tr
echo ">>>>>>>>running test 695"
../source/print_tokens.c.inst.exe  < ../inputs/tc164 > ../newoutputs/t695
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/694.tr
echo ">>>>>>>>running test 696"
../source/print_tokens.c.inst.exe  < ../inputs/tc165 > ../newoutputs/t696
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/695.tr
echo ">>>>>>>>running test 697"
../source/print_tokens.c.inst.exe  < ../inputs/tc166 > ../newoutputs/t697
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/696.tr
echo ">>>>>>>>running test 698"
../source/print_tokens.c.inst.exe  < ../inputs/tc167 > ../newoutputs/t698
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/697.tr
echo ">>>>>>>>running test 699"
../source/print_tokens.c.inst.exe  < ../inputs/tc168 > ../newoutputs/t699
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/698.tr
echo ">>>>>>>>running test 700"
../source/print_tokens.c.inst.exe  < ../inputs/tc169 > ../newoutputs/t700
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/699.tr
echo ">>>>>>>>running test 701"
../source/print_tokens.c.inst.exe  < ../inputs/tc17 > ../newoutputs/t701
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/700.tr
echo ">>>>>>>>running test 702"
../source/print_tokens.c.inst.exe  < ../inputs/tc170 > ../newoutputs/t702
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/701.tr
echo ">>>>>>>>running test 703"
../source/print_tokens.c.inst.exe  < ../inputs/tc171 > ../newoutputs/t703
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/702.tr
echo ">>>>>>>>running test 704"
../source/print_tokens.c.inst.exe  < ../inputs/tc172 > ../newoutputs/t704
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/703.tr
echo ">>>>>>>>running test 705"
../source/print_tokens.c.inst.exe  < ../inputs/tc173 > ../newoutputs/t705
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/704.tr
echo ">>>>>>>>running test 706"
../source/print_tokens.c.inst.exe  < ../inputs/tc174 > ../newoutputs/t706
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/705.tr
echo ">>>>>>>>running test 707"
../source/print_tokens.c.inst.exe  < ../inputs/tc175 > ../newoutputs/t707
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/706.tr
echo ">>>>>>>>running test 708"
../source/print_tokens.c.inst.exe  < ../inputs/tc176 > ../newoutputs/t708
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/707.tr
echo ">>>>>>>>running test 709"
../source/print_tokens.c.inst.exe  < ../inputs/tc177 > ../newoutputs/t709
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/708.tr
echo ">>>>>>>>running test 710"
../source/print_tokens.c.inst.exe  < ../inputs/tc178 > ../newoutputs/t710
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/709.tr
echo ">>>>>>>>running test 711"
../source/print_tokens.c.inst.exe  < ../inputs/tc179 > ../newoutputs/t711
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/710.tr
echo ">>>>>>>>running test 712"
../source/print_tokens.c.inst.exe  < ../inputs/tc18 > ../newoutputs/t712
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/711.tr
echo ">>>>>>>>running test 713"
../source/print_tokens.c.inst.exe  < ../inputs/tc180 > ../newoutputs/t713
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/712.tr
echo ">>>>>>>>running test 714"
../source/print_tokens.c.inst.exe  < ../inputs/tc181 > ../newoutputs/t714
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/713.tr
echo ">>>>>>>>running test 715"
../source/print_tokens.c.inst.exe  < ../inputs/tc182 > ../newoutputs/t715
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/714.tr
echo ">>>>>>>>running test 716"
../source/print_tokens.c.inst.exe  < ../inputs/tc183 > ../newoutputs/t716
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/715.tr
echo ">>>>>>>>running test 717"
../source/print_tokens.c.inst.exe  < ../inputs/tc184 > ../newoutputs/t717
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/716.tr
echo ">>>>>>>>running test 718"
../source/print_tokens.c.inst.exe  < ../inputs/tc185 > ../newoutputs/t718
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/717.tr
echo ">>>>>>>>running test 719"
../source/print_tokens.c.inst.exe  < ../inputs/tc186 > ../newoutputs/t719
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/718.tr
echo ">>>>>>>>running test 720"
../source/print_tokens.c.inst.exe  < ../inputs/tc187 > ../newoutputs/t720
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/719.tr
echo ">>>>>>>>running test 721"
../source/print_tokens.c.inst.exe  < ../inputs/tc188 > ../newoutputs/t721
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/720.tr
echo ">>>>>>>>running test 722"
../source/print_tokens.c.inst.exe  < ../inputs/tc189 > ../newoutputs/t722
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/721.tr
echo ">>>>>>>>running test 723"
../source/print_tokens.c.inst.exe  < ../inputs/tc19 > ../newoutputs/t723
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/722.tr
echo ">>>>>>>>running test 724"
../source/print_tokens.c.inst.exe  < ../inputs/tc190 > ../newoutputs/t724
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/723.tr
echo ">>>>>>>>running test 725"
../source/print_tokens.c.inst.exe  < ../inputs/tc191 > ../newoutputs/t725
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/724.tr
echo ">>>>>>>>running test 726"
../source/print_tokens.c.inst.exe  < ../inputs/tc192 > ../newoutputs/t726
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/725.tr
echo ">>>>>>>>running test 727"
../source/print_tokens.c.inst.exe  < ../inputs/tc193 > ../newoutputs/t727
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/726.tr
echo ">>>>>>>>running test 728"
../source/print_tokens.c.inst.exe  < ../inputs/tc194 > ../newoutputs/t728
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/727.tr
echo ">>>>>>>>running test 729"
../source/print_tokens.c.inst.exe  < ../inputs/tc195 > ../newoutputs/t729
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/728.tr
echo ">>>>>>>>running test 730"
../source/print_tokens.c.inst.exe  < ../inputs/tc196 > ../newoutputs/t730
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/729.tr
echo ">>>>>>>>running test 731"
../source/print_tokens.c.inst.exe  < ../inputs/tc197 > ../newoutputs/t731
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/730.tr
echo ">>>>>>>>running test 732"
../source/print_tokens.c.inst.exe  < ../inputs/tc198 > ../newoutputs/t732
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/731.tr
echo ">>>>>>>>running test 733"
../source/print_tokens.c.inst.exe  < ../inputs/tc199 > ../newoutputs/t733
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/732.tr
echo ">>>>>>>>running test 734"
../source/print_tokens.c.inst.exe  < ../inputs/tc2 > ../newoutputs/t734
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/733.tr
echo ">>>>>>>>running test 735"
../source/print_tokens.c.inst.exe  < ../inputs/tc20 > ../newoutputs/t735
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/734.tr
echo ">>>>>>>>running test 736"
../source/print_tokens.c.inst.exe  < ../inputs/tc200 > ../newoutputs/t736
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/735.tr
echo ">>>>>>>>running test 737"
../source/print_tokens.c.inst.exe  < ../inputs/tc201 > ../newoutputs/t737
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/736.tr
echo ">>>>>>>>running test 738"
../source/print_tokens.c.inst.exe  < ../inputs/tc202 > ../newoutputs/t738
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/737.tr
echo ">>>>>>>>running test 739"
../source/print_tokens.c.inst.exe  < ../inputs/tc203 > ../newoutputs/t739
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/738.tr
echo ">>>>>>>>running test 740"
../source/print_tokens.c.inst.exe  < ../inputs/tc204 > ../newoutputs/t740
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/739.tr
echo ">>>>>>>>running test 741"
../source/print_tokens.c.inst.exe  < ../inputs/tc205 > ../newoutputs/t741
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/740.tr
echo ">>>>>>>>running test 742"
../source/print_tokens.c.inst.exe  < ../inputs/tc206 > ../newoutputs/t742
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/741.tr
echo ">>>>>>>>running test 743"
../source/print_tokens.c.inst.exe  < ../inputs/tc207 > ../newoutputs/t743
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/742.tr
echo ">>>>>>>>running test 744"
../source/print_tokens.c.inst.exe  < ../inputs/tc208 > ../newoutputs/t744
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/743.tr
echo ">>>>>>>>running test 745"
../source/print_tokens.c.inst.exe  < ../inputs/tc209 > ../newoutputs/t745
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/744.tr
echo ">>>>>>>>running test 746"
../source/print_tokens.c.inst.exe  < ../inputs/tc21 > ../newoutputs/t746
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/745.tr
echo ">>>>>>>>running test 747"
../source/print_tokens.c.inst.exe  < ../inputs/tc210 > ../newoutputs/t747
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/746.tr
echo ">>>>>>>>running test 748"
../source/print_tokens.c.inst.exe  < ../inputs/tc211 > ../newoutputs/t748
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/747.tr
echo ">>>>>>>>running test 749"
../source/print_tokens.c.inst.exe  < ../inputs/tc212 > ../newoutputs/t749
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/748.tr
echo ">>>>>>>>running test 750"
../source/print_tokens.c.inst.exe  < ../inputs/tc213 > ../newoutputs/t750
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/749.tr
echo ">>>>>>>>running test 751"
../source/print_tokens.c.inst.exe  < ../inputs/tc214 > ../newoutputs/t751
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/750.tr
echo ">>>>>>>>running test 752"
../source/print_tokens.c.inst.exe  < ../inputs/tc215 > ../newoutputs/t752
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/751.tr
echo ">>>>>>>>running test 753"
../source/print_tokens.c.inst.exe  < ../inputs/tc216 > ../newoutputs/t753
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/752.tr
echo ">>>>>>>>running test 754"
../source/print_tokens.c.inst.exe  < ../inputs/tc217 > ../newoutputs/t754
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/753.tr
echo ">>>>>>>>running test 755"
../source/print_tokens.c.inst.exe  < ../inputs/tc218 > ../newoutputs/t755
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/754.tr
echo ">>>>>>>>running test 756"
../source/print_tokens.c.inst.exe  < ../inputs/tc219 > ../newoutputs/t756
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/755.tr
echo ">>>>>>>>running test 757"
../source/print_tokens.c.inst.exe  < ../inputs/tc22 > ../newoutputs/t757
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/756.tr
echo ">>>>>>>>running test 758"
../source/print_tokens.c.inst.exe  < ../inputs/tc220 > ../newoutputs/t758
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/757.tr
echo ">>>>>>>>running test 759"
../source/print_tokens.c.inst.exe  < ../inputs/tc221 > ../newoutputs/t759
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/758.tr
echo ">>>>>>>>running test 760"
../source/print_tokens.c.inst.exe  < ../inputs/tc222 > ../newoutputs/t760
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/759.tr
echo ">>>>>>>>running test 761"
../source/print_tokens.c.inst.exe  < ../inputs/tc223 > ../newoutputs/t761
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/760.tr
echo ">>>>>>>>running test 762"
../source/print_tokens.c.inst.exe  < ../inputs/tc224 > ../newoutputs/t762
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/761.tr
echo ">>>>>>>>running test 763"
../source/print_tokens.c.inst.exe  < ../inputs/tc225 > ../newoutputs/t763
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/762.tr
echo ">>>>>>>>running test 764"
../source/print_tokens.c.inst.exe  < ../inputs/tc226 > ../newoutputs/t764
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/763.tr
echo ">>>>>>>>running test 765"
../source/print_tokens.c.inst.exe  < ../inputs/tc227 > ../newoutputs/t765
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/764.tr
echo ">>>>>>>>running test 766"
../source/print_tokens.c.inst.exe  < ../inputs/tc228 > ../newoutputs/t766
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/765.tr
echo ">>>>>>>>running test 767"
../source/print_tokens.c.inst.exe  < ../inputs/tc229 > ../newoutputs/t767
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/766.tr
echo ">>>>>>>>running test 768"
../source/print_tokens.c.inst.exe  < ../inputs/tc23 > ../newoutputs/t768
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/767.tr
echo ">>>>>>>>running test 769"
../source/print_tokens.c.inst.exe  < ../inputs/tc230 > ../newoutputs/t769
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/768.tr
echo ">>>>>>>>running test 770"
../source/print_tokens.c.inst.exe  < ../inputs/tc231 > ../newoutputs/t770
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/769.tr
echo ">>>>>>>>running test 771"
../source/print_tokens.c.inst.exe  < ../inputs/tc232 > ../newoutputs/t771
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/770.tr
echo ">>>>>>>>running test 772"
../source/print_tokens.c.inst.exe  < ../inputs/tc233 > ../newoutputs/t772
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/771.tr
echo ">>>>>>>>running test 773"
../source/print_tokens.c.inst.exe  < ../inputs/tc234 > ../newoutputs/t773
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/772.tr
echo ">>>>>>>>running test 774"
../source/print_tokens.c.inst.exe  < ../inputs/tc235 > ../newoutputs/t774
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/773.tr
echo ">>>>>>>>running test 775"
../source/print_tokens.c.inst.exe  < ../inputs/tc236 > ../newoutputs/t775
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/774.tr
echo ">>>>>>>>running test 776"
../source/print_tokens.c.inst.exe  < ../inputs/tc237 > ../newoutputs/t776
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/775.tr
echo ">>>>>>>>running test 777"
../source/print_tokens.c.inst.exe  < ../inputs/tc238 > ../newoutputs/t777
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/776.tr
echo ">>>>>>>>running test 778"
../source/print_tokens.c.inst.exe  < ../inputs/tc239 > ../newoutputs/t778
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/777.tr
echo ">>>>>>>>running test 779"
../source/print_tokens.c.inst.exe  < ../inputs/tc24 > ../newoutputs/t779
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/778.tr
echo ">>>>>>>>running test 780"
../source/print_tokens.c.inst.exe  < ../inputs/tc240 > ../newoutputs/t780
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/779.tr
echo ">>>>>>>>running test 781"
../source/print_tokens.c.inst.exe  < ../inputs/tc241 > ../newoutputs/t781
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/780.tr
echo ">>>>>>>>running test 782"
../source/print_tokens.c.inst.exe  < ../inputs/tc242 > ../newoutputs/t782
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/781.tr
echo ">>>>>>>>running test 783"
../source/print_tokens.c.inst.exe  < ../inputs/tc243 > ../newoutputs/t783
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/782.tr
echo ">>>>>>>>running test 784"
../source/print_tokens.c.inst.exe  < ../inputs/tc244 > ../newoutputs/t784
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/783.tr
echo ">>>>>>>>running test 785"
../source/print_tokens.c.inst.exe  < ../inputs/tc245 > ../newoutputs/t785
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/784.tr
echo ">>>>>>>>running test 786"
../source/print_tokens.c.inst.exe  < ../inputs/tc246 > ../newoutputs/t786
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/785.tr
echo ">>>>>>>>running test 787"
../source/print_tokens.c.inst.exe  < ../inputs/tc247 > ../newoutputs/t787
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/786.tr
echo ">>>>>>>>running test 788"
../source/print_tokens.c.inst.exe  < ../inputs/tc248 > ../newoutputs/t788
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/787.tr
echo ">>>>>>>>running test 789"
../source/print_tokens.c.inst.exe  < ../inputs/tc249 > ../newoutputs/t789
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/788.tr
echo ">>>>>>>>running test 790"
../source/print_tokens.c.inst.exe  < ../inputs/tc25 > ../newoutputs/t790
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/789.tr
echo ">>>>>>>>running test 791"
../source/print_tokens.c.inst.exe  < ../inputs/tc250 > ../newoutputs/t791
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/790.tr
echo ">>>>>>>>running test 792"
../source/print_tokens.c.inst.exe  < ../inputs/tc251 > ../newoutputs/t792
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/791.tr
echo ">>>>>>>>running test 793"
../source/print_tokens.c.inst.exe  < ../inputs/tc252 > ../newoutputs/t793
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/792.tr
echo ">>>>>>>>running test 794"
../source/print_tokens.c.inst.exe  < ../inputs/tc253 > ../newoutputs/t794
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/793.tr
echo ">>>>>>>>running test 795"
../source/print_tokens.c.inst.exe  < ../inputs/tc254 > ../newoutputs/t795
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/794.tr
echo ">>>>>>>>running test 796"
../source/print_tokens.c.inst.exe  < ../inputs/tc255 > ../newoutputs/t796
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/795.tr
echo ">>>>>>>>running test 797"
../source/print_tokens.c.inst.exe  < ../inputs/tc256 > ../newoutputs/t797
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/796.tr
echo ">>>>>>>>running test 798"
../source/print_tokens.c.inst.exe  < ../inputs/tc257 > ../newoutputs/t798
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/797.tr
echo ">>>>>>>>running test 799"
../source/print_tokens.c.inst.exe  < ../inputs/tc258 > ../newoutputs/t799
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/798.tr
echo ">>>>>>>>running test 800"
../source/print_tokens.c.inst.exe  < ../inputs/tc259 > ../newoutputs/t800
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/799.tr
echo ">>>>>>>>running test 801"
../source/print_tokens.c.inst.exe  < ../inputs/tc26 > ../newoutputs/t801
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/800.tr
echo ">>>>>>>>running test 802"
../source/print_tokens.c.inst.exe  < ../inputs/tc260 > ../newoutputs/t802
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/801.tr
echo ">>>>>>>>running test 803"
../source/print_tokens.c.inst.exe  < ../inputs/tc261 > ../newoutputs/t803
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/802.tr
echo ">>>>>>>>running test 804"
../source/print_tokens.c.inst.exe  < ../inputs/tc262 > ../newoutputs/t804
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/803.tr
echo ">>>>>>>>running test 805"
../source/print_tokens.c.inst.exe  < ../inputs/tc263 > ../newoutputs/t805
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/804.tr
echo ">>>>>>>>running test 806"
../source/print_tokens.c.inst.exe  < ../inputs/tc264 > ../newoutputs/t806
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/805.tr
echo ">>>>>>>>running test 807"
../source/print_tokens.c.inst.exe  < ../inputs/tc265 > ../newoutputs/t807
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/806.tr
echo ">>>>>>>>running test 808"
../source/print_tokens.c.inst.exe  < ../inputs/tc266 > ../newoutputs/t808
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/807.tr
echo ">>>>>>>>running test 809"
../source/print_tokens.c.inst.exe  < ../inputs/tc267 > ../newoutputs/t809
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/808.tr
echo ">>>>>>>>running test 810"
../source/print_tokens.c.inst.exe  < ../inputs/tc268 > ../newoutputs/t810
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/809.tr
echo ">>>>>>>>running test 811"
../source/print_tokens.c.inst.exe  < ../inputs/tc269 > ../newoutputs/t811
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/810.tr
echo ">>>>>>>>running test 812"
../source/print_tokens.c.inst.exe  < ../inputs/tc27 > ../newoutputs/t812
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/811.tr
echo ">>>>>>>>running test 813"
../source/print_tokens.c.inst.exe  < ../inputs/tc270 > ../newoutputs/t813
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/812.tr
echo ">>>>>>>>running test 814"
../source/print_tokens.c.inst.exe  < ../inputs/tc271 > ../newoutputs/t814
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/813.tr
echo ">>>>>>>>running test 815"
../source/print_tokens.c.inst.exe  < ../inputs/tc272 > ../newoutputs/t815
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/814.tr
echo ">>>>>>>>running test 816"
../source/print_tokens.c.inst.exe  < ../inputs/tc273 > ../newoutputs/t816
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/815.tr
echo ">>>>>>>>running test 817"
../source/print_tokens.c.inst.exe  < ../inputs/tc274 > ../newoutputs/t817
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/816.tr
echo ">>>>>>>>running test 818"
../source/print_tokens.c.inst.exe  < ../inputs/tc275 > ../newoutputs/t818
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/817.tr
echo ">>>>>>>>running test 819"
../source/print_tokens.c.inst.exe  < ../inputs/tc276 > ../newoutputs/t819
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/818.tr
echo ">>>>>>>>running test 820"
../source/print_tokens.c.inst.exe  < ../inputs/tc277 > ../newoutputs/t820
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/819.tr
echo ">>>>>>>>running test 821"
../source/print_tokens.c.inst.exe  < ../inputs/tc278 > ../newoutputs/t821
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/820.tr
echo ">>>>>>>>running test 822"
../source/print_tokens.c.inst.exe  < ../inputs/tc279 > ../newoutputs/t822
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/821.tr
echo ">>>>>>>>running test 823"
../source/print_tokens.c.inst.exe  < ../inputs/tc28 > ../newoutputs/t823
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/822.tr
echo ">>>>>>>>running test 824"
../source/print_tokens.c.inst.exe  < ../inputs/tc280 > ../newoutputs/t824
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/823.tr
echo ">>>>>>>>running test 825"
../source/print_tokens.c.inst.exe  < ../inputs/tc281 > ../newoutputs/t825
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/824.tr
echo ">>>>>>>>running test 826"
../source/print_tokens.c.inst.exe  < ../inputs/tc282 > ../newoutputs/t826
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/825.tr
echo ">>>>>>>>running test 827"
../source/print_tokens.c.inst.exe  < ../inputs/tc283 > ../newoutputs/t827
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/826.tr
echo ">>>>>>>>running test 828"
../source/print_tokens.c.inst.exe  < ../inputs/tc284 > ../newoutputs/t828
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/827.tr
echo ">>>>>>>>running test 829"
../source/print_tokens.c.inst.exe  < ../inputs/tc285 > ../newoutputs/t829
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/828.tr
echo ">>>>>>>>running test 830"
../source/print_tokens.c.inst.exe  < ../inputs/tc286 > ../newoutputs/t830
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/829.tr
echo ">>>>>>>>running test 831"
../source/print_tokens.c.inst.exe  < ../inputs/tc287 > ../newoutputs/t831
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/830.tr
echo ">>>>>>>>running test 832"
../source/print_tokens.c.inst.exe  < ../inputs/tc288 > ../newoutputs/t832
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/831.tr
echo ">>>>>>>>running test 833"
../source/print_tokens.c.inst.exe  < ../inputs/tc289 > ../newoutputs/t833
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/832.tr
echo ">>>>>>>>running test 834"
../source/print_tokens.c.inst.exe  < ../inputs/tc29 > ../newoutputs/t834
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/833.tr
echo ">>>>>>>>running test 835"
../source/print_tokens.c.inst.exe  < ../inputs/tc290 > ../newoutputs/t835
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/834.tr
echo ">>>>>>>>running test 836"
../source/print_tokens.c.inst.exe  < ../inputs/tc291 > ../newoutputs/t836
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/835.tr
echo ">>>>>>>>running test 837"
../source/print_tokens.c.inst.exe  < ../inputs/tc292 > ../newoutputs/t837
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/836.tr
echo ">>>>>>>>running test 838"
../source/print_tokens.c.inst.exe  < ../inputs/tc293 > ../newoutputs/t838
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/837.tr
echo ">>>>>>>>running test 839"
../source/print_tokens.c.inst.exe  < ../inputs/tc294 > ../newoutputs/t839
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/838.tr
echo ">>>>>>>>running test 840"
../source/print_tokens.c.inst.exe  < ../inputs/tc295 > ../newoutputs/t840
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/839.tr
echo ">>>>>>>>running test 841"
../source/print_tokens.c.inst.exe  < ../inputs/tc296 > ../newoutputs/t841
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/840.tr
echo ">>>>>>>>running test 842"
../source/print_tokens.c.inst.exe  < ../inputs/tc297 > ../newoutputs/t842
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/841.tr
echo ">>>>>>>>running test 843"
../source/print_tokens.c.inst.exe  < ../inputs/tc298 > ../newoutputs/t843
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/842.tr
echo ">>>>>>>>running test 844"
../source/print_tokens.c.inst.exe  < ../inputs/tc299 > ../newoutputs/t844
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/843.tr
echo ">>>>>>>>running test 845"
../source/print_tokens.c.inst.exe  < ../inputs/tc3 > ../newoutputs/t845
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/844.tr
echo ">>>>>>>>running test 846"
../source/print_tokens.c.inst.exe  < ../inputs/tc30 > ../newoutputs/t846
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/845.tr
echo ">>>>>>>>running test 847"
../source/print_tokens.c.inst.exe  < ../inputs/tc300 > ../newoutputs/t847
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/846.tr
echo ">>>>>>>>running test 848"
../source/print_tokens.c.inst.exe  < ../inputs/tc301 > ../newoutputs/t848
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/847.tr
echo ">>>>>>>>running test 849"
../source/print_tokens.c.inst.exe  < ../inputs/tc302 > ../newoutputs/t849
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/848.tr
echo ">>>>>>>>running test 850"
../source/print_tokens.c.inst.exe  < ../inputs/tc303 > ../newoutputs/t850
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/849.tr
echo ">>>>>>>>running test 851"
../source/print_tokens.c.inst.exe  < ../inputs/tc304 > ../newoutputs/t851
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/850.tr
echo ">>>>>>>>running test 852"
../source/print_tokens.c.inst.exe  < ../inputs/tc305 > ../newoutputs/t852
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/851.tr
echo ">>>>>>>>running test 853"
../source/print_tokens.c.inst.exe  < ../inputs/tc306 > ../newoutputs/t853
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/852.tr
echo ">>>>>>>>running test 854"
../source/print_tokens.c.inst.exe  < ../inputs/tc307 > ../newoutputs/t854
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/853.tr
echo ">>>>>>>>running test 855"
../source/print_tokens.c.inst.exe  < ../inputs/tc308 > ../newoutputs/t855
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/854.tr
echo ">>>>>>>>running test 856"
../source/print_tokens.c.inst.exe  < ../inputs/tc309 > ../newoutputs/t856
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/855.tr
echo ">>>>>>>>running test 857"
../source/print_tokens.c.inst.exe  < ../inputs/tc31 > ../newoutputs/t857
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/856.tr
echo ">>>>>>>>running test 858"
../source/print_tokens.c.inst.exe  < ../inputs/tc310 > ../newoutputs/t858
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/857.tr
echo ">>>>>>>>running test 859"
../source/print_tokens.c.inst.exe  < ../inputs/tc311 > ../newoutputs/t859
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/858.tr
echo ">>>>>>>>running test 860"
../source/print_tokens.c.inst.exe  < ../inputs/tc312 > ../newoutputs/t860
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/859.tr
echo ">>>>>>>>running test 861"
../source/print_tokens.c.inst.exe  < ../inputs/tc313 > ../newoutputs/t861
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/860.tr
echo ">>>>>>>>running test 862"
../source/print_tokens.c.inst.exe  < ../inputs/tc314 > ../newoutputs/t862
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/861.tr
echo ">>>>>>>>running test 863"
../source/print_tokens.c.inst.exe  < ../inputs/tc315 > ../newoutputs/t863
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/862.tr
echo ">>>>>>>>running test 864"
../source/print_tokens.c.inst.exe  < ../inputs/tc316 > ../newoutputs/t864
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/863.tr
echo ">>>>>>>>running test 865"
../source/print_tokens.c.inst.exe  < ../inputs/tc317 > ../newoutputs/t865
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/864.tr
echo ">>>>>>>>running test 866"
../source/print_tokens.c.inst.exe  < ../inputs/tc318 > ../newoutputs/t866
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/865.tr
echo ">>>>>>>>running test 867"
../source/print_tokens.c.inst.exe  < ../inputs/tc319 > ../newoutputs/t867
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/866.tr
echo ">>>>>>>>running test 868"
../source/print_tokens.c.inst.exe  < ../inputs/tc32 > ../newoutputs/t868
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/867.tr
echo ">>>>>>>>running test 869"
../source/print_tokens.c.inst.exe  < ../inputs/tc320 > ../newoutputs/t869
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/868.tr
echo ">>>>>>>>running test 870"
../source/print_tokens.c.inst.exe  < ../inputs/tc321 > ../newoutputs/t870
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/869.tr
echo ">>>>>>>>running test 871"
../source/print_tokens.c.inst.exe  < ../inputs/tc322 > ../newoutputs/t871
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/870.tr
echo ">>>>>>>>running test 872"
../source/print_tokens.c.inst.exe  < ../inputs/tc323 > ../newoutputs/t872
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/871.tr
echo ">>>>>>>>running test 873"
../source/print_tokens.c.inst.exe  < ../inputs/tc324 > ../newoutputs/t873
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/872.tr
echo ">>>>>>>>running test 874"
../source/print_tokens.c.inst.exe  < ../inputs/tc325 > ../newoutputs/t874
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/873.tr
echo ">>>>>>>>running test 875"
../source/print_tokens.c.inst.exe  < ../inputs/tc326 > ../newoutputs/t875
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/874.tr
echo ">>>>>>>>running test 876"
../source/print_tokens.c.inst.exe  < ../inputs/tc327 > ../newoutputs/t876
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/875.tr
echo ">>>>>>>>running test 877"
../source/print_tokens.c.inst.exe  < ../inputs/tc328 > ../newoutputs/t877
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/876.tr
echo ">>>>>>>>running test 878"
../source/print_tokens.c.inst.exe  < ../inputs/tc329 > ../newoutputs/t878
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/877.tr
echo ">>>>>>>>running test 879"
../source/print_tokens.c.inst.exe  < ../inputs/tc33 > ../newoutputs/t879
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/878.tr
echo ">>>>>>>>running test 880"
../source/print_tokens.c.inst.exe  < ../inputs/tc330 > ../newoutputs/t880
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/879.tr
echo ">>>>>>>>running test 881"
../source/print_tokens.c.inst.exe  < ../inputs/tc331 > ../newoutputs/t881
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/880.tr
echo ">>>>>>>>running test 882"
../source/print_tokens.c.inst.exe  < ../inputs/tc332 > ../newoutputs/t882
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/881.tr
echo ">>>>>>>>running test 883"
../source/print_tokens.c.inst.exe  < ../inputs/tc333 > ../newoutputs/t883
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/882.tr
echo ">>>>>>>>running test 884"
../source/print_tokens.c.inst.exe  < ../inputs/tc334 > ../newoutputs/t884
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/883.tr
echo ">>>>>>>>running test 885"
../source/print_tokens.c.inst.exe  < ../inputs/tc335 > ../newoutputs/t885
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/884.tr
echo ">>>>>>>>running test 886"
../source/print_tokens.c.inst.exe  < ../inputs/tc336 > ../newoutputs/t886
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/885.tr
echo ">>>>>>>>running test 887"
../source/print_tokens.c.inst.exe  < ../inputs/tc337 > ../newoutputs/t887
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/886.tr
echo ">>>>>>>>running test 888"
../source/print_tokens.c.inst.exe  < ../inputs/tc338 > ../newoutputs/t888
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/887.tr
echo ">>>>>>>>running test 889"
../source/print_tokens.c.inst.exe  < ../inputs/tc339 > ../newoutputs/t889
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/888.tr
echo ">>>>>>>>running test 890"
../source/print_tokens.c.inst.exe  < ../inputs/tc34 > ../newoutputs/t890
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/889.tr
echo ">>>>>>>>running test 891"
../source/print_tokens.c.inst.exe  < ../inputs/tc340 > ../newoutputs/t891
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/890.tr
echo ">>>>>>>>running test 892"
../source/print_tokens.c.inst.exe  < ../inputs/tc341 > ../newoutputs/t892
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/891.tr
echo ">>>>>>>>running test 893"
../source/print_tokens.c.inst.exe  < ../inputs/tc342 > ../newoutputs/t893
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/892.tr
echo ">>>>>>>>running test 894"
../source/print_tokens.c.inst.exe  < ../inputs/tc343 > ../newoutputs/t894
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/893.tr
echo ">>>>>>>>running test 895"
../source/print_tokens.c.inst.exe  < ../inputs/tc344 > ../newoutputs/t895
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/894.tr
echo ">>>>>>>>running test 896"
../source/print_tokens.c.inst.exe  < ../inputs/tc345 > ../newoutputs/t896
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/895.tr
echo ">>>>>>>>running test 897"
../source/print_tokens.c.inst.exe  < ../inputs/tc346 > ../newoutputs/t897
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/896.tr
echo ">>>>>>>>running test 898"
../source/print_tokens.c.inst.exe  < ../inputs/tc347 > ../newoutputs/t898
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/897.tr
echo ">>>>>>>>running test 899"
../source/print_tokens.c.inst.exe  < ../inputs/tc348 > ../newoutputs/t899
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/898.tr
echo ">>>>>>>>running test 900"
../source/print_tokens.c.inst.exe  < ../inputs/tc349 > ../newoutputs/t900
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/899.tr
echo ">>>>>>>>running test 901"
../source/print_tokens.c.inst.exe  < ../inputs/tc35 > ../newoutputs/t901
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/900.tr
echo ">>>>>>>>running test 902"
../source/print_tokens.c.inst.exe  < ../inputs/tc350 > ../newoutputs/t902
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/901.tr
echo ">>>>>>>>running test 903"
../source/print_tokens.c.inst.exe  < ../inputs/tc351 > ../newoutputs/t903
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/902.tr
echo ">>>>>>>>running test 904"
../source/print_tokens.c.inst.exe  < ../inputs/tc352 > ../newoutputs/t904
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/903.tr
echo ">>>>>>>>running test 905"
../source/print_tokens.c.inst.exe  < ../inputs/tc353 > ../newoutputs/t905
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/904.tr
echo ">>>>>>>>running test 906"
../source/print_tokens.c.inst.exe  < ../inputs/tc354 > ../newoutputs/t906
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/905.tr
echo ">>>>>>>>running test 907"
../source/print_tokens.c.inst.exe  < ../inputs/tc355 > ../newoutputs/t907
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/906.tr
echo ">>>>>>>>running test 908"
../source/print_tokens.c.inst.exe  < ../inputs/tc356 > ../newoutputs/t908
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/907.tr
echo ">>>>>>>>running test 909"
../source/print_tokens.c.inst.exe  < ../inputs/tc357 > ../newoutputs/t909
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/908.tr
echo ">>>>>>>>running test 910"
../source/print_tokens.c.inst.exe  < ../inputs/tc358 > ../newoutputs/t910
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/909.tr
echo ">>>>>>>>running test 911"
../source/print_tokens.c.inst.exe  < ../inputs/tc359 > ../newoutputs/t911
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/910.tr
echo ">>>>>>>>running test 912"
../source/print_tokens.c.inst.exe  < ../inputs/tc36 > ../newoutputs/t912
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/911.tr
echo ">>>>>>>>running test 913"
../source/print_tokens.c.inst.exe  < ../inputs/tc360 > ../newoutputs/t913
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/912.tr
echo ">>>>>>>>running test 914"
../source/print_tokens.c.inst.exe  < ../inputs/tc361 > ../newoutputs/t914
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/913.tr
echo ">>>>>>>>running test 915"
../source/print_tokens.c.inst.exe  < ../inputs/tc362 > ../newoutputs/t915
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/914.tr
echo ">>>>>>>>running test 916"
../source/print_tokens.c.inst.exe  < ../inputs/tc363 > ../newoutputs/t916
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/915.tr
echo ">>>>>>>>running test 917"
../source/print_tokens.c.inst.exe  < ../inputs/tc364 > ../newoutputs/t917
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/916.tr
echo ">>>>>>>>running test 918"
../source/print_tokens.c.inst.exe  < ../inputs/tc365 > ../newoutputs/t918
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/917.tr
echo ">>>>>>>>running test 919"
../source/print_tokens.c.inst.exe  < ../inputs/tc366 > ../newoutputs/t919
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/918.tr
echo ">>>>>>>>running test 920"
../source/print_tokens.c.inst.exe  < ../inputs/tc367 > ../newoutputs/t920
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/919.tr
echo ">>>>>>>>running test 921"
../source/print_tokens.c.inst.exe  < ../inputs/tc368 > ../newoutputs/t921
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/920.tr
echo ">>>>>>>>running test 922"
../source/print_tokens.c.inst.exe  < ../inputs/tc369 > ../newoutputs/t922
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/921.tr
echo ">>>>>>>>running test 923"
../source/print_tokens.c.inst.exe  < ../inputs/tc37 > ../newoutputs/t923
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/922.tr
echo ">>>>>>>>running test 924"
../source/print_tokens.c.inst.exe  < ../inputs/tc370 > ../newoutputs/t924
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/923.tr
echo ">>>>>>>>running test 925"
../source/print_tokens.c.inst.exe  < ../inputs/tc371 > ../newoutputs/t925
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/924.tr
echo ">>>>>>>>running test 926"
../source/print_tokens.c.inst.exe  < ../inputs/tc372 > ../newoutputs/t926
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/925.tr
echo ">>>>>>>>running test 927"
../source/print_tokens.c.inst.exe  < ../inputs/tc373 > ../newoutputs/t927
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/926.tr
echo ">>>>>>>>running test 928"
../source/print_tokens.c.inst.exe  < ../inputs/tc374 > ../newoutputs/t928
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/927.tr
echo ">>>>>>>>running test 929"
../source/print_tokens.c.inst.exe  < ../inputs/tc375 > ../newoutputs/t929
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/928.tr
echo ">>>>>>>>running test 930"
../source/print_tokens.c.inst.exe  < ../inputs/tc376 > ../newoutputs/t930
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/929.tr
echo ">>>>>>>>running test 931"
../source/print_tokens.c.inst.exe  < ../inputs/tc377 > ../newoutputs/t931
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/930.tr
echo ">>>>>>>>running test 932"
../source/print_tokens.c.inst.exe  < ../inputs/tc378 > ../newoutputs/t932
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/931.tr
echo ">>>>>>>>running test 933"
../source/print_tokens.c.inst.exe  < ../inputs/tc379 > ../newoutputs/t933
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/932.tr
echo ">>>>>>>>running test 934"
../source/print_tokens.c.inst.exe  < ../inputs/tc38 > ../newoutputs/t934
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/933.tr
echo ">>>>>>>>running test 935"
../source/print_tokens.c.inst.exe  < ../inputs/tc380 > ../newoutputs/t935
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/934.tr
echo ">>>>>>>>running test 936"
../source/print_tokens.c.inst.exe  < ../inputs/tc381 > ../newoutputs/t936
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/935.tr
echo ">>>>>>>>running test 937"
../source/print_tokens.c.inst.exe  < ../inputs/tc382 > ../newoutputs/t937
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/936.tr
echo ">>>>>>>>running test 938"
../source/print_tokens.c.inst.exe  < ../inputs/tc383 > ../newoutputs/t938
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/937.tr
echo ">>>>>>>>running test 939"
../source/print_tokens.c.inst.exe  < ../inputs/tc384 > ../newoutputs/t939
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/938.tr
echo ">>>>>>>>running test 940"
../source/print_tokens.c.inst.exe  < ../inputs/tc385 > ../newoutputs/t940
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/939.tr
echo ">>>>>>>>running test 941"
../source/print_tokens.c.inst.exe  < ../inputs/tc386 > ../newoutputs/t941
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/940.tr
echo ">>>>>>>>running test 942"
../source/print_tokens.c.inst.exe  < ../inputs/tc387 > ../newoutputs/t942
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/941.tr
echo ">>>>>>>>running test 943"
../source/print_tokens.c.inst.exe  < ../inputs/tc388 > ../newoutputs/t943
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/942.tr
echo ">>>>>>>>running test 944"
../source/print_tokens.c.inst.exe  < ../inputs/tc389 > ../newoutputs/t944
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/943.tr
echo ">>>>>>>>running test 945"
../source/print_tokens.c.inst.exe  < ../inputs/tc39 > ../newoutputs/t945
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/944.tr
echo ">>>>>>>>running test 946"
../source/print_tokens.c.inst.exe  < ../inputs/tc390 > ../newoutputs/t946
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/945.tr
echo ">>>>>>>>running test 947"
../source/print_tokens.c.inst.exe  < ../inputs/tc391 > ../newoutputs/t947
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/946.tr
echo ">>>>>>>>running test 948"
../source/print_tokens.c.inst.exe  < ../inputs/tc392 > ../newoutputs/t948
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/947.tr
echo ">>>>>>>>running test 949"
../source/print_tokens.c.inst.exe  < ../inputs/tc393 > ../newoutputs/t949
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/948.tr
echo ">>>>>>>>running test 950"
../source/print_tokens.c.inst.exe  < ../inputs/tc394 > ../newoutputs/t950
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/949.tr
echo ">>>>>>>>running test 951"
../source/print_tokens.c.inst.exe  < ../inputs/tc395 > ../newoutputs/t951
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/950.tr
echo ">>>>>>>>running test 952"
../source/print_tokens.c.inst.exe  < ../inputs/tc396 > ../newoutputs/t952
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/951.tr
echo ">>>>>>>>running test 953"
../source/print_tokens.c.inst.exe  < ../inputs/tc397 > ../newoutputs/t953
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/952.tr
echo ">>>>>>>>running test 954"
../source/print_tokens.c.inst.exe  < ../inputs/tc398 > ../newoutputs/t954
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/953.tr
echo ">>>>>>>>running test 955"
../source/print_tokens.c.inst.exe  < ../inputs/tc399 > ../newoutputs/t955
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/954.tr
echo ">>>>>>>>running test 956"
../source/print_tokens.c.inst.exe  < ../inputs/tc4 > ../newoutputs/t956
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/955.tr
echo ">>>>>>>>running test 957"
../source/print_tokens.c.inst.exe  < ../inputs/tc40 > ../newoutputs/t957
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/956.tr
echo ">>>>>>>>running test 958"
../source/print_tokens.c.inst.exe  < ../inputs/tc400 > ../newoutputs/t958
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/957.tr
echo ">>>>>>>>running test 959"
../source/print_tokens.c.inst.exe  < ../inputs/tc41 > ../newoutputs/t959
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/958.tr
echo ">>>>>>>>running test 960"
../source/print_tokens.c.inst.exe  < ../inputs/tc42 > ../newoutputs/t960
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/959.tr
echo ">>>>>>>>running test 961"
../source/print_tokens.c.inst.exe  < ../inputs/tc43 > ../newoutputs/t961
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/960.tr
echo ">>>>>>>>running test 962"
../source/print_tokens.c.inst.exe  < ../inputs/tc44 > ../newoutputs/t962
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/961.tr
echo ">>>>>>>>running test 963"
../source/print_tokens.c.inst.exe  < ../inputs/tc45 > ../newoutputs/t963
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/962.tr
echo ">>>>>>>>running test 964"
../source/print_tokens.c.inst.exe  < ../inputs/tc46 > ../newoutputs/t964
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/963.tr
echo ">>>>>>>>running test 965"
../source/print_tokens.c.inst.exe  < ../inputs/tc47 > ../newoutputs/t965
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/964.tr
echo ">>>>>>>>running test 966"
../source/print_tokens.c.inst.exe  < ../inputs/tc48 > ../newoutputs/t966
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/965.tr
echo ">>>>>>>>running test 967"
../source/print_tokens.c.inst.exe  < ../inputs/tc49 > ../newoutputs/t967
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/966.tr
echo ">>>>>>>>running test 968"
../source/print_tokens.c.inst.exe  < ../inputs/tc5 > ../newoutputs/t968
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/967.tr
echo ">>>>>>>>running test 969"
../source/print_tokens.c.inst.exe  < ../inputs/tc50 > ../newoutputs/t969
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/968.tr
echo ">>>>>>>>running test 970"
../source/print_tokens.c.inst.exe  < ../inputs/tc51 > ../newoutputs/t970
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/969.tr
echo ">>>>>>>>running test 971"
../source/print_tokens.c.inst.exe  < ../inputs/tc52 > ../newoutputs/t971
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/970.tr
echo ">>>>>>>>running test 972"
../source/print_tokens.c.inst.exe  < ../inputs/tc53 > ../newoutputs/t972
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/971.tr
echo ">>>>>>>>running test 973"
../source/print_tokens.c.inst.exe  < ../inputs/tc54 > ../newoutputs/t973
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/972.tr
echo ">>>>>>>>running test 974"
../source/print_tokens.c.inst.exe  < ../inputs/tc55 > ../newoutputs/t974
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/973.tr
echo ">>>>>>>>running test 975"
../source/print_tokens.c.inst.exe  < ../inputs/tc56 > ../newoutputs/t975
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/974.tr
echo ">>>>>>>>running test 976"
../source/print_tokens.c.inst.exe  < ../inputs/tc57 > ../newoutputs/t976
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/975.tr
echo ">>>>>>>>running test 977"
../source/print_tokens.c.inst.exe  < ../inputs/tc58 > ../newoutputs/t977
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/976.tr
echo ">>>>>>>>running test 978"
../source/print_tokens.c.inst.exe  < ../inputs/tc59 > ../newoutputs/t978
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/977.tr
echo ">>>>>>>>running test 979"
../source/print_tokens.c.inst.exe  < ../inputs/tc6 > ../newoutputs/t979
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/978.tr
echo ">>>>>>>>running test 980"
../source/print_tokens.c.inst.exe  < ../inputs/tc60 > ../newoutputs/t980
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/979.tr
echo ">>>>>>>>running test 981"
../source/print_tokens.c.inst.exe  < ../inputs/tc61 > ../newoutputs/t981
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/980.tr
echo ">>>>>>>>running test 982"
../source/print_tokens.c.inst.exe  < ../inputs/tc62 > ../newoutputs/t982
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/981.tr
echo ">>>>>>>>running test 983"
../source/print_tokens.c.inst.exe  < ../inputs/tc63 > ../newoutputs/t983
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/982.tr
echo ">>>>>>>>running test 984"
../source/print_tokens.c.inst.exe  < ../inputs/tc64 > ../newoutputs/t984
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/983.tr
echo ">>>>>>>>running test 985"
../source/print_tokens.c.inst.exe  < ../inputs/tc65 > ../newoutputs/t985
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/984.tr
echo ">>>>>>>>running test 986"
../source/print_tokens.c.inst.exe  < ../inputs/tc66 > ../newoutputs/t986
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/985.tr
echo ">>>>>>>>running test 987"
../source/print_tokens.c.inst.exe  < ../inputs/tc67 > ../newoutputs/t987
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/986.tr
echo ">>>>>>>>running test 988"
../source/print_tokens.c.inst.exe  < ../inputs/tc68 > ../newoutputs/t988
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/987.tr
echo ">>>>>>>>running test 989"
../source/print_tokens.c.inst.exe  < ../inputs/tc69 > ../newoutputs/t989
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/988.tr
echo ">>>>>>>>running test 990"
../source/print_tokens.c.inst.exe  < ../inputs/tc7 > ../newoutputs/t990
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/989.tr
echo ">>>>>>>>running test 991"
../source/print_tokens.c.inst.exe  < ../inputs/tc70 > ../newoutputs/t991
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/990.tr
echo ">>>>>>>>running test 992"
../source/print_tokens.c.inst.exe  < ../inputs/tc71 > ../newoutputs/t992
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/991.tr
echo ">>>>>>>>running test 993"
../source/print_tokens.c.inst.exe  < ../inputs/tc72 > ../newoutputs/t993
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/992.tr
echo ">>>>>>>>running test 994"
../source/print_tokens.c.inst.exe  < ../inputs/tc73 > ../newoutputs/t994
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/993.tr
echo ">>>>>>>>running test 995"
../source/print_tokens.c.inst.exe  < ../inputs/tc74 > ../newoutputs/t995
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/994.tr
echo ">>>>>>>>running test 996"
../source/print_tokens.c.inst.exe  < ../inputs/tc75 > ../newoutputs/t996
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/995.tr
echo ">>>>>>>>running test 997"
../source/print_tokens.c.inst.exe  < ../inputs/tc76 > ../newoutputs/t997
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/996.tr
echo ">>>>>>>>running test 998"
../source/print_tokens.c.inst.exe  < ../inputs/tc77 > ../newoutputs/t998
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/997.tr
echo ">>>>>>>>running test 999"
../source/print_tokens.c.inst.exe  < ../inputs/tc78 > ../newoutputs/t999
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/998.tr
echo ">>>>>>>>running test 1000"
../source/print_tokens.c.inst.exe  < ../inputs/tc79 > ../newoutputs/t1000
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/999.tr
echo ">>>>>>>>running test 1001"
../source/print_tokens.c.inst.exe  < ../inputs/tc8 > ../newoutputs/t1001
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1000.tr
echo ">>>>>>>>running test 1002"
../source/print_tokens.c.inst.exe  < ../inputs/tc80 > ../newoutputs/t1002
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1001.tr
echo ">>>>>>>>running test 1003"
../source/print_tokens.c.inst.exe  < ../inputs/tc81 > ../newoutputs/t1003
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1002.tr
echo ">>>>>>>>running test 1004"
../source/print_tokens.c.inst.exe  < ../inputs/tc82 > ../newoutputs/t1004
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1003.tr
echo ">>>>>>>>running test 1005"
../source/print_tokens.c.inst.exe  < ../inputs/tc83 > ../newoutputs/t1005
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1004.tr
echo ">>>>>>>>running test 1006"
../source/print_tokens.c.inst.exe  < ../inputs/tc84 > ../newoutputs/t1006
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1005.tr
echo ">>>>>>>>running test 1007"
../source/print_tokens.c.inst.exe  < ../inputs/tc85 > ../newoutputs/t1007
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1006.tr
echo ">>>>>>>>running test 1008"
../source/print_tokens.c.inst.exe  < ../inputs/tc86 > ../newoutputs/t1008
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1007.tr
echo ">>>>>>>>running test 1009"
../source/print_tokens.c.inst.exe  < ../inputs/tc87 > ../newoutputs/t1009
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1008.tr
echo ">>>>>>>>running test 1010"
../source/print_tokens.c.inst.exe  < ../inputs/tc88 > ../newoutputs/t1010
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1009.tr
echo ">>>>>>>>running test 1011"
../source/print_tokens.c.inst.exe  < ../inputs/tc89 > ../newoutputs/t1011
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1010.tr
echo ">>>>>>>>running test 1012"
../source/print_tokens.c.inst.exe  < ../inputs/tc9 > ../newoutputs/t1012
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1011.tr
echo ">>>>>>>>running test 1013"
../source/print_tokens.c.inst.exe  < ../inputs/tc90 > ../newoutputs/t1013
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1012.tr
echo ">>>>>>>>running test 1014"
../source/print_tokens.c.inst.exe  < ../inputs/tc91 > ../newoutputs/t1014
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1013.tr
echo ">>>>>>>>running test 1015"
../source/print_tokens.c.inst.exe  < ../inputs/tc92 > ../newoutputs/t1015
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1014.tr
echo ">>>>>>>>running test 1016"
../source/print_tokens.c.inst.exe  < ../inputs/tc93 > ../newoutputs/t1016
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1015.tr
echo ">>>>>>>>running test 1017"
../source/print_tokens.c.inst.exe  < ../inputs/tc94 > ../newoutputs/t1017
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1016.tr
echo ">>>>>>>>running test 1018"
../source/print_tokens.c.inst.exe  < ../inputs/tc95 > ../newoutputs/t1018
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1017.tr
echo ">>>>>>>>running test 1019"
../source/print_tokens.c.inst.exe  < ../inputs/tc96 > ../newoutputs/t1019
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1018.tr
echo ">>>>>>>>running test 1020"
../source/print_tokens.c.inst.exe  < ../inputs/tc97 > ../newoutputs/t1020
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1019.tr
echo ">>>>>>>>running test 1021"
../source/print_tokens.c.inst.exe  < ../inputs/tc98 > ../newoutputs/t1021
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1020.tr
echo ">>>>>>>>running test 1022"
../source/print_tokens.c.inst.exe  < ../inputs/tc99 > ../newoutputs/t1022
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1021.tr
echo ">>>>>>>>running test 1023"
../source/print_tokens.c.inst.exe  < ../inputs/test1 > ../newoutputs/t1023
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1022.tr
echo ">>>>>>>>running test 1024"
../source/print_tokens.c.inst.exe  < ../inputs/test10 > ../newoutputs/t1024
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1023.tr
echo ">>>>>>>>running test 1025"
../source/print_tokens.c.inst.exe  < ../inputs/test100 > ../newoutputs/t1025
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1024.tr
echo ">>>>>>>>running test 1026"
../source/print_tokens.c.inst.exe  < ../inputs/test101 > ../newoutputs/t1026
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1025.tr
echo ">>>>>>>>running test 1027"
../source/print_tokens.c.inst.exe  < ../inputs/test102 > ../newoutputs/t1027
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1026.tr
echo ">>>>>>>>running test 1028"
../source/print_tokens.c.inst.exe  < ../inputs/test103 > ../newoutputs/t1028
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1027.tr
echo ">>>>>>>>running test 1029"
../source/print_tokens.c.inst.exe  < ../inputs/test104 > ../newoutputs/t1029
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1028.tr
echo ">>>>>>>>running test 1030"
../source/print_tokens.c.inst.exe  < ../inputs/test105 > ../newoutputs/t1030
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1029.tr
echo ">>>>>>>>running test 1031"
../source/print_tokens.c.inst.exe  < ../inputs/test106 > ../newoutputs/t1031
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1030.tr
echo ">>>>>>>>running test 1032"
../source/print_tokens.c.inst.exe  < ../inputs/test107 > ../newoutputs/t1032
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1031.tr
echo ">>>>>>>>running test 1033"
../source/print_tokens.c.inst.exe  < ../inputs/test108 > ../newoutputs/t1033
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1032.tr
echo ">>>>>>>>running test 1034"
../source/print_tokens.c.inst.exe  < ../inputs/test109 > ../newoutputs/t1034
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1033.tr
echo ">>>>>>>>running test 1035"
../source/print_tokens.c.inst.exe  < ../inputs/test11 > ../newoutputs/t1035
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1034.tr
echo ">>>>>>>>running test 1036"
../source/print_tokens.c.inst.exe  < ../inputs/test110 > ../newoutputs/t1036
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1035.tr
echo ">>>>>>>>running test 1037"
../source/print_tokens.c.inst.exe  < ../inputs/test111 > ../newoutputs/t1037
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1036.tr
echo ">>>>>>>>running test 1038"
../source/print_tokens.c.inst.exe  < ../inputs/test112 > ../newoutputs/t1038
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1037.tr
echo ">>>>>>>>running test 1039"
../source/print_tokens.c.inst.exe  < ../inputs/test113 > ../newoutputs/t1039
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1038.tr
echo ">>>>>>>>running test 1040"
../source/print_tokens.c.inst.exe  < ../inputs/test114 > ../newoutputs/t1040
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1039.tr
echo ">>>>>>>>running test 1041"
../source/print_tokens.c.inst.exe  < ../inputs/test115 > ../newoutputs/t1041
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1040.tr
echo ">>>>>>>>running test 1042"
../source/print_tokens.c.inst.exe  < ../inputs/test116 > ../newoutputs/t1042
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1041.tr
echo ">>>>>>>>running test 1043"
../source/print_tokens.c.inst.exe  < ../inputs/test117 > ../newoutputs/t1043
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1042.tr
echo ">>>>>>>>running test 1044"
../source/print_tokens.c.inst.exe  < ../inputs/test118 > ../newoutputs/t1044
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1043.tr
echo ">>>>>>>>running test 1045"
../source/print_tokens.c.inst.exe  < ../inputs/test119 > ../newoutputs/t1045
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1044.tr
echo ">>>>>>>>running test 1046"
../source/print_tokens.c.inst.exe  < ../inputs/test12 > ../newoutputs/t1046
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1045.tr
echo ">>>>>>>>running test 1047"
../source/print_tokens.c.inst.exe  < ../inputs/test120 > ../newoutputs/t1047
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1046.tr
echo ">>>>>>>>running test 1048"
../source/print_tokens.c.inst.exe  < ../inputs/test121 > ../newoutputs/t1048
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1047.tr
echo ">>>>>>>>running test 1049"
../source/print_tokens.c.inst.exe  < ../inputs/test122 > ../newoutputs/t1049
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1048.tr
echo ">>>>>>>>running test 1050"
../source/print_tokens.c.inst.exe  < ../inputs/test123 > ../newoutputs/t1050
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1049.tr
echo ">>>>>>>>running test 1051"
../source/print_tokens.c.inst.exe  < ../inputs/test124 > ../newoutputs/t1051
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1050.tr
echo ">>>>>>>>running test 1052"
../source/print_tokens.c.inst.exe  < ../inputs/test125 > ../newoutputs/t1052
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1051.tr
echo ">>>>>>>>running test 1053"
../source/print_tokens.c.inst.exe  < ../inputs/test126 > ../newoutputs/t1053
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1052.tr
echo ">>>>>>>>running test 1054"
../source/print_tokens.c.inst.exe  < ../inputs/test127 > ../newoutputs/t1054
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1053.tr
echo ">>>>>>>>running test 1055"
../source/print_tokens.c.inst.exe  < ../inputs/test128 > ../newoutputs/t1055
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1054.tr
echo ">>>>>>>>running test 1056"
../source/print_tokens.c.inst.exe  < ../inputs/test129 > ../newoutputs/t1056
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1055.tr
echo ">>>>>>>>running test 1057"
../source/print_tokens.c.inst.exe  < ../inputs/test13 > ../newoutputs/t1057
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1056.tr
echo ">>>>>>>>running test 1058"
../source/print_tokens.c.inst.exe  < ../inputs/test130 > ../newoutputs/t1058
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1057.tr
echo ">>>>>>>>running test 1059"
../source/print_tokens.c.inst.exe  < ../inputs/test131 > ../newoutputs/t1059
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1058.tr
echo ">>>>>>>>running test 1060"
../source/print_tokens.c.inst.exe  < ../inputs/test132 > ../newoutputs/t1060
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1059.tr
echo ">>>>>>>>running test 1061"
../source/print_tokens.c.inst.exe  < ../inputs/test133 > ../newoutputs/t1061
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1060.tr
echo ">>>>>>>>running test 1062"
../source/print_tokens.c.inst.exe  < ../inputs/test134 > ../newoutputs/t1062
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1061.tr
echo ">>>>>>>>running test 1063"
../source/print_tokens.c.inst.exe  < ../inputs/test135 > ../newoutputs/t1063
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1062.tr
echo ">>>>>>>>running test 1064"
../source/print_tokens.c.inst.exe  < ../inputs/test136 > ../newoutputs/t1064
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1063.tr
echo ">>>>>>>>running test 1065"
../source/print_tokens.c.inst.exe  < ../inputs/test137 > ../newoutputs/t1065
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1064.tr
echo ">>>>>>>>running test 1066"
../source/print_tokens.c.inst.exe  < ../inputs/test138 > ../newoutputs/t1066
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1065.tr
echo ">>>>>>>>running test 1067"
../source/print_tokens.c.inst.exe  < ../inputs/test139 > ../newoutputs/t1067
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1066.tr
echo ">>>>>>>>running test 1068"
../source/print_tokens.c.inst.exe  < ../inputs/test14 > ../newoutputs/t1068
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1067.tr
echo ">>>>>>>>running test 1069"
../source/print_tokens.c.inst.exe  < ../inputs/test140 > ../newoutputs/t1069
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1068.tr
echo ">>>>>>>>running test 1070"
../source/print_tokens.c.inst.exe  < ../inputs/test141 > ../newoutputs/t1070
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1069.tr
echo ">>>>>>>>running test 1071"
../source/print_tokens.c.inst.exe  < ../inputs/test142 > ../newoutputs/t1071
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1070.tr
echo ">>>>>>>>running test 1072"
../source/print_tokens.c.inst.exe  < ../inputs/test143 > ../newoutputs/t1072
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1071.tr
echo ">>>>>>>>running test 1073"
../source/print_tokens.c.inst.exe  < ../inputs/test144 > ../newoutputs/t1073
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1072.tr
echo ">>>>>>>>running test 1074"
../source/print_tokens.c.inst.exe  < ../inputs/test145 > ../newoutputs/t1074
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1073.tr
echo ">>>>>>>>running test 1075"
../source/print_tokens.c.inst.exe  < ../inputs/test146 > ../newoutputs/t1075
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1074.tr
echo ">>>>>>>>running test 1076"
../source/print_tokens.c.inst.exe  < ../inputs/test147 > ../newoutputs/t1076
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1075.tr
echo ">>>>>>>>running test 1077"
../source/print_tokens.c.inst.exe  < ../inputs/test148 > ../newoutputs/t1077
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1076.tr
echo ">>>>>>>>running test 1078"
../source/print_tokens.c.inst.exe  < ../inputs/test149 > ../newoutputs/t1078
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1077.tr
echo ">>>>>>>>running test 1079"
../source/print_tokens.c.inst.exe  < ../inputs/test15 > ../newoutputs/t1079
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1078.tr
echo ">>>>>>>>running test 1080"
../source/print_tokens.c.inst.exe  < ../inputs/test150 > ../newoutputs/t1080
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1079.tr
echo ">>>>>>>>running test 1081"
../source/print_tokens.c.inst.exe  < ../inputs/test151 > ../newoutputs/t1081
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1080.tr
echo ">>>>>>>>running test 1082"
../source/print_tokens.c.inst.exe  < ../inputs/test152 > ../newoutputs/t1082
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1081.tr
echo ">>>>>>>>running test 1083"
../source/print_tokens.c.inst.exe  < ../inputs/test153 > ../newoutputs/t1083
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1082.tr
echo ">>>>>>>>running test 1084"
../source/print_tokens.c.inst.exe  < ../inputs/test154 > ../newoutputs/t1084
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1083.tr
echo ">>>>>>>>running test 1085"
../source/print_tokens.c.inst.exe  < ../inputs/test155 > ../newoutputs/t1085
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1084.tr
echo ">>>>>>>>running test 1086"
../source/print_tokens.c.inst.exe  < ../inputs/test156 > ../newoutputs/t1086
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1085.tr
echo ">>>>>>>>running test 1087"
../source/print_tokens.c.inst.exe  < ../inputs/test157 > ../newoutputs/t1087
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1086.tr
echo ">>>>>>>>running test 1088"
../source/print_tokens.c.inst.exe  < ../inputs/test158 > ../newoutputs/t1088
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1087.tr
echo ">>>>>>>>running test 1089"
../source/print_tokens.c.inst.exe  < ../inputs/test159 > ../newoutputs/t1089
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1088.tr
echo ">>>>>>>>running test 1090"
../source/print_tokens.c.inst.exe  < ../inputs/test16 > ../newoutputs/t1090
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1089.tr
echo ">>>>>>>>running test 1091"
../source/print_tokens.c.inst.exe  < ../inputs/test160 > ../newoutputs/t1091
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1090.tr
echo ">>>>>>>>running test 1092"
../source/print_tokens.c.inst.exe  < ../inputs/test161 > ../newoutputs/t1092
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1091.tr
echo ">>>>>>>>running test 1093"
../source/print_tokens.c.inst.exe  < ../inputs/test162 > ../newoutputs/t1093
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1092.tr
echo ">>>>>>>>running test 1094"
../source/print_tokens.c.inst.exe  < ../inputs/test163 > ../newoutputs/t1094
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1093.tr
echo ">>>>>>>>running test 1095"
../source/print_tokens.c.inst.exe  < ../inputs/test164 > ../newoutputs/t1095
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1094.tr
echo ">>>>>>>>running test 1096"
../source/print_tokens.c.inst.exe  < ../inputs/test165 > ../newoutputs/t1096
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1095.tr
echo ">>>>>>>>running test 1097"
../source/print_tokens.c.inst.exe  < ../inputs/test166 > ../newoutputs/t1097
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1096.tr
echo ">>>>>>>>running test 1098"
../source/print_tokens.c.inst.exe  < ../inputs/test167 > ../newoutputs/t1098
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1097.tr
echo ">>>>>>>>running test 1099"
../source/print_tokens.c.inst.exe  < ../inputs/test168 > ../newoutputs/t1099
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1098.tr
echo ">>>>>>>>running test 1100"
../source/print_tokens.c.inst.exe  < ../inputs/test169 > ../newoutputs/t1100
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1099.tr
echo ">>>>>>>>running test 1101"
../source/print_tokens.c.inst.exe  < ../inputs/test17 > ../newoutputs/t1101
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1100.tr
echo ">>>>>>>>running test 1102"
../source/print_tokens.c.inst.exe  < ../inputs/test170 > ../newoutputs/t1102
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1101.tr
echo ">>>>>>>>running test 1103"
../source/print_tokens.c.inst.exe  < ../inputs/test171 > ../newoutputs/t1103
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1102.tr
echo ">>>>>>>>running test 1104"
../source/print_tokens.c.inst.exe  < ../inputs/test172 > ../newoutputs/t1104
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1103.tr
echo ">>>>>>>>running test 1105"
../source/print_tokens.c.inst.exe  < ../inputs/test173 > ../newoutputs/t1105
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1104.tr
echo ">>>>>>>>running test 1106"
../source/print_tokens.c.inst.exe  < ../inputs/test174 > ../newoutputs/t1106
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1105.tr
echo ">>>>>>>>running test 1107"
../source/print_tokens.c.inst.exe  < ../inputs/test175 > ../newoutputs/t1107
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1106.tr
echo ">>>>>>>>running test 1108"
../source/print_tokens.c.inst.exe  < ../inputs/test176 > ../newoutputs/t1108
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1107.tr
echo ">>>>>>>>running test 1109"
../source/print_tokens.c.inst.exe  < ../inputs/test177 > ../newoutputs/t1109
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1108.tr
echo ">>>>>>>>running test 1110"
../source/print_tokens.c.inst.exe  < ../inputs/test178 > ../newoutputs/t1110
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1109.tr
echo ">>>>>>>>running test 1111"
../source/print_tokens.c.inst.exe  < ../inputs/test179 > ../newoutputs/t1111
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1110.tr
echo ">>>>>>>>running test 1112"
../source/print_tokens.c.inst.exe  < ../inputs/test18 > ../newoutputs/t1112
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1111.tr
echo ">>>>>>>>running test 1113"
../source/print_tokens.c.inst.exe  < ../inputs/test180 > ../newoutputs/t1113
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1112.tr
echo ">>>>>>>>running test 1114"
../source/print_tokens.c.inst.exe  < ../inputs/test181 > ../newoutputs/t1114
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1113.tr
echo ">>>>>>>>running test 1115"
../source/print_tokens.c.inst.exe  < ../inputs/test182 > ../newoutputs/t1115
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1114.tr
echo ">>>>>>>>running test 1116"
../source/print_tokens.c.inst.exe  < ../inputs/test183 > ../newoutputs/t1116
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1115.tr
echo ">>>>>>>>running test 1117"
../source/print_tokens.c.inst.exe  < ../inputs/test184 > ../newoutputs/t1117
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1116.tr
echo ">>>>>>>>running test 1118"
../source/print_tokens.c.inst.exe  < ../inputs/test185 > ../newoutputs/t1118
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1117.tr
echo ">>>>>>>>running test 1119"
../source/print_tokens.c.inst.exe  < ../inputs/test186 > ../newoutputs/t1119
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1118.tr
echo ">>>>>>>>running test 1120"
../source/print_tokens.c.inst.exe  < ../inputs/test187 > ../newoutputs/t1120
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1119.tr
echo ">>>>>>>>running test 1121"
../source/print_tokens.c.inst.exe  < ../inputs/test188 > ../newoutputs/t1121
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1120.tr
echo ">>>>>>>>running test 1122"
../source/print_tokens.c.inst.exe  < ../inputs/test189 > ../newoutputs/t1122
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1121.tr
echo ">>>>>>>>running test 1123"
../source/print_tokens.c.inst.exe  < ../inputs/test19 > ../newoutputs/t1123
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1122.tr
echo ">>>>>>>>running test 1124"
../source/print_tokens.c.inst.exe  < ../inputs/test190 > ../newoutputs/t1124
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1123.tr
echo ">>>>>>>>running test 1125"
../source/print_tokens.c.inst.exe  < ../inputs/test191 > ../newoutputs/t1125
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1124.tr
echo ">>>>>>>>running test 1126"
../source/print_tokens.c.inst.exe  < ../inputs/test192 > ../newoutputs/t1126
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1125.tr
echo ">>>>>>>>running test 1127"
../source/print_tokens.c.inst.exe  < ../inputs/test193 > ../newoutputs/t1127
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1126.tr
echo ">>>>>>>>running test 1128"
../source/print_tokens.c.inst.exe  < ../inputs/test194 > ../newoutputs/t1128
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1127.tr
echo ">>>>>>>>running test 1129"
../source/print_tokens.c.inst.exe  < ../inputs/test195 > ../newoutputs/t1129
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1128.tr
echo ">>>>>>>>running test 1130"
../source/print_tokens.c.inst.exe  < ../inputs/test196 > ../newoutputs/t1130
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1129.tr
echo ">>>>>>>>running test 1131"
../source/print_tokens.c.inst.exe  < ../inputs/test197 > ../newoutputs/t1131
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1130.tr
echo ">>>>>>>>running test 1132"
../source/print_tokens.c.inst.exe  < ../inputs/test198 > ../newoutputs/t1132
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1131.tr
echo ">>>>>>>>running test 1133"
../source/print_tokens.c.inst.exe  < ../inputs/test199 > ../newoutputs/t1133
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1132.tr
echo ">>>>>>>>running test 1134"
../source/print_tokens.c.inst.exe  < ../inputs/test2 > ../newoutputs/t1134
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1133.tr
echo ">>>>>>>>running test 1135"
../source/print_tokens.c.inst.exe  < ../inputs/test20 > ../newoutputs/t1135
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1134.tr
echo ">>>>>>>>running test 1136"
../source/print_tokens.c.inst.exe  < ../inputs/test200 > ../newoutputs/t1136
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1135.tr
echo ">>>>>>>>running test 1137"
../source/print_tokens.c.inst.exe  < ../inputs/test201 > ../newoutputs/t1137
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1136.tr
echo ">>>>>>>>running test 1138"
../source/print_tokens.c.inst.exe  < ../inputs/test202 > ../newoutputs/t1138
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1137.tr
echo ">>>>>>>>running test 1139"
../source/print_tokens.c.inst.exe  < ../inputs/test203 > ../newoutputs/t1139
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1138.tr
echo ">>>>>>>>running test 1140"
../source/print_tokens.c.inst.exe  < ../inputs/test204 > ../newoutputs/t1140
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1139.tr
echo ">>>>>>>>running test 1141"
../source/print_tokens.c.inst.exe  < ../inputs/test205 > ../newoutputs/t1141
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1140.tr
echo ">>>>>>>>running test 1142"
../source/print_tokens.c.inst.exe  < ../inputs/test206 > ../newoutputs/t1142
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1141.tr
echo ">>>>>>>>running test 1143"
../source/print_tokens.c.inst.exe  < ../inputs/test207 > ../newoutputs/t1143
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1142.tr
echo ">>>>>>>>running test 1144"
../source/print_tokens.c.inst.exe  < ../inputs/test208 > ../newoutputs/t1144
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1143.tr
echo ">>>>>>>>running test 1145"
../source/print_tokens.c.inst.exe  < ../inputs/test209 > ../newoutputs/t1145
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1144.tr
echo ">>>>>>>>running test 1146"
../source/print_tokens.c.inst.exe  < ../inputs/test21 > ../newoutputs/t1146
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1145.tr
echo ">>>>>>>>running test 1147"
../source/print_tokens.c.inst.exe  < ../inputs/test210 > ../newoutputs/t1147
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1146.tr
echo ">>>>>>>>running test 1148"
../source/print_tokens.c.inst.exe  < ../inputs/test211 > ../newoutputs/t1148
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1147.tr
echo ">>>>>>>>running test 1149"
../source/print_tokens.c.inst.exe  < ../inputs/test212 > ../newoutputs/t1149
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1148.tr
echo ">>>>>>>>running test 1150"
../source/print_tokens.c.inst.exe  < ../inputs/test213 > ../newoutputs/t1150
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1149.tr
echo ">>>>>>>>running test 1151"
../source/print_tokens.c.inst.exe  < ../inputs/test214 > ../newoutputs/t1151
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1150.tr
echo ">>>>>>>>running test 1152"
../source/print_tokens.c.inst.exe  < ../inputs/test215 > ../newoutputs/t1152
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1151.tr
echo ">>>>>>>>running test 1153"
../source/print_tokens.c.inst.exe  < ../inputs/test216 > ../newoutputs/t1153
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1152.tr
echo ">>>>>>>>running test 1154"
../source/print_tokens.c.inst.exe  < ../inputs/test217 > ../newoutputs/t1154
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1153.tr
echo ">>>>>>>>running test 1155"
../source/print_tokens.c.inst.exe  < ../inputs/test218 > ../newoutputs/t1155
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1154.tr
echo ">>>>>>>>running test 1156"
../source/print_tokens.c.inst.exe  < ../inputs/test219 > ../newoutputs/t1156
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1155.tr
echo ">>>>>>>>running test 1157"
../source/print_tokens.c.inst.exe  < ../inputs/test22 > ../newoutputs/t1157
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1156.tr
echo ">>>>>>>>running test 1158"
../source/print_tokens.c.inst.exe  < ../inputs/test220 > ../newoutputs/t1158
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1157.tr
echo ">>>>>>>>running test 1159"
../source/print_tokens.c.inst.exe  < ../inputs/test221 > ../newoutputs/t1159
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1158.tr
echo ">>>>>>>>running test 1160"
../source/print_tokens.c.inst.exe  < ../inputs/test222 > ../newoutputs/t1160
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1159.tr
echo ">>>>>>>>running test 1161"
../source/print_tokens.c.inst.exe  < ../inputs/test223 > ../newoutputs/t1161
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1160.tr
echo ">>>>>>>>running test 1162"
../source/print_tokens.c.inst.exe  < ../inputs/test224 > ../newoutputs/t1162
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1161.tr
echo ">>>>>>>>running test 1163"
../source/print_tokens.c.inst.exe  < ../inputs/test225 > ../newoutputs/t1163
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1162.tr
echo ">>>>>>>>running test 1164"
../source/print_tokens.c.inst.exe  < ../inputs/test226 > ../newoutputs/t1164
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1163.tr
echo ">>>>>>>>running test 1165"
../source/print_tokens.c.inst.exe  < ../inputs/test227 > ../newoutputs/t1165
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1164.tr
echo ">>>>>>>>running test 1166"
../source/print_tokens.c.inst.exe  < ../inputs/test228 > ../newoutputs/t1166
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1165.tr
echo ">>>>>>>>running test 1167"
../source/print_tokens.c.inst.exe  < ../inputs/test229 > ../newoutputs/t1167
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1166.tr
echo ">>>>>>>>running test 1168"
../source/print_tokens.c.inst.exe  < ../inputs/test23 > ../newoutputs/t1168
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1167.tr
echo ">>>>>>>>running test 1169"
../source/print_tokens.c.inst.exe  < ../inputs/test230 > ../newoutputs/t1169
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1168.tr
echo ">>>>>>>>running test 1170"
../source/print_tokens.c.inst.exe  < ../inputs/test231 > ../newoutputs/t1170
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1169.tr
echo ">>>>>>>>running test 1171"
../source/print_tokens.c.inst.exe  < ../inputs/test232 > ../newoutputs/t1171
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1170.tr
echo ">>>>>>>>running test 1172"
../source/print_tokens.c.inst.exe  < ../inputs/test233 > ../newoutputs/t1172
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1171.tr
echo ">>>>>>>>running test 1173"
../source/print_tokens.c.inst.exe  < ../inputs/test234 > ../newoutputs/t1173
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1172.tr
echo ">>>>>>>>running test 1174"
../source/print_tokens.c.inst.exe  < ../inputs/test235 > ../newoutputs/t1174
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1173.tr
echo ">>>>>>>>running test 1175"
../source/print_tokens.c.inst.exe  < ../inputs/test236 > ../newoutputs/t1175
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1174.tr
echo ">>>>>>>>running test 1176"
../source/print_tokens.c.inst.exe  < ../inputs/test237 > ../newoutputs/t1176
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1175.tr
echo ">>>>>>>>running test 1177"
../source/print_tokens.c.inst.exe  < ../inputs/test238 > ../newoutputs/t1177
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1176.tr
echo ">>>>>>>>running test 1178"
../source/print_tokens.c.inst.exe  < ../inputs/test239 > ../newoutputs/t1178
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1177.tr
echo ">>>>>>>>running test 1179"
../source/print_tokens.c.inst.exe  < ../inputs/test24 > ../newoutputs/t1179
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1178.tr
echo ">>>>>>>>running test 1180"
../source/print_tokens.c.inst.exe  < ../inputs/test240 > ../newoutputs/t1180
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1179.tr
echo ">>>>>>>>running test 1181"
../source/print_tokens.c.inst.exe  < ../inputs/test241 > ../newoutputs/t1181
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1180.tr
echo ">>>>>>>>running test 1182"
../source/print_tokens.c.inst.exe  < ../inputs/test242 > ../newoutputs/t1182
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1181.tr
echo ">>>>>>>>running test 1183"
../source/print_tokens.c.inst.exe  < ../inputs/test243 > ../newoutputs/t1183
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1182.tr
echo ">>>>>>>>running test 1184"
../source/print_tokens.c.inst.exe  < ../inputs/test244 > ../newoutputs/t1184
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1183.tr
echo ">>>>>>>>running test 1185"
../source/print_tokens.c.inst.exe  < ../inputs/test245 > ../newoutputs/t1185
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1184.tr
echo ">>>>>>>>running test 1186"
../source/print_tokens.c.inst.exe  < ../inputs/test246 > ../newoutputs/t1186
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1185.tr
echo ">>>>>>>>running test 1187"
../source/print_tokens.c.inst.exe  < ../inputs/test247 > ../newoutputs/t1187
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1186.tr
echo ">>>>>>>>running test 1188"
../source/print_tokens.c.inst.exe  < ../inputs/test248 > ../newoutputs/t1188
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1187.tr
echo ">>>>>>>>running test 1189"
../source/print_tokens.c.inst.exe  < ../inputs/test249 > ../newoutputs/t1189
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1188.tr
echo ">>>>>>>>running test 1190"
../source/print_tokens.c.inst.exe  < ../inputs/test25 > ../newoutputs/t1190
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1189.tr
echo ">>>>>>>>running test 1191"
../source/print_tokens.c.inst.exe  < ../inputs/test250 > ../newoutputs/t1191
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1190.tr
echo ">>>>>>>>running test 1192"
../source/print_tokens.c.inst.exe  < ../inputs/test251 > ../newoutputs/t1192
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1191.tr
echo ">>>>>>>>running test 1193"
../source/print_tokens.c.inst.exe  < ../inputs/test252 > ../newoutputs/t1193
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1192.tr
echo ">>>>>>>>running test 1194"
../source/print_tokens.c.inst.exe  < ../inputs/test253 > ../newoutputs/t1194
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1193.tr
echo ">>>>>>>>running test 1195"
../source/print_tokens.c.inst.exe  < ../inputs/test254 > ../newoutputs/t1195
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1194.tr
echo ">>>>>>>>running test 1196"
../source/print_tokens.c.inst.exe  < ../inputs/test255 > ../newoutputs/t1196
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1195.tr
echo ">>>>>>>>running test 1197"
../source/print_tokens.c.inst.exe  < ../inputs/test256 > ../newoutputs/t1197
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1196.tr
echo ">>>>>>>>running test 1198"
../source/print_tokens.c.inst.exe  < ../inputs/test257 > ../newoutputs/t1198
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1197.tr
echo ">>>>>>>>running test 1199"
../source/print_tokens.c.inst.exe  < ../inputs/test258 > ../newoutputs/t1199
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1198.tr
echo ">>>>>>>>running test 1200"
../source/print_tokens.c.inst.exe  < ../inputs/test259 > ../newoutputs/t1200
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1199.tr
echo ">>>>>>>>running test 1201"
../source/print_tokens.c.inst.exe  < ../inputs/test26 > ../newoutputs/t1201
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1200.tr
echo ">>>>>>>>running test 1202"
../source/print_tokens.c.inst.exe  < ../inputs/test260 > ../newoutputs/t1202
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1201.tr
echo ">>>>>>>>running test 1203"
../source/print_tokens.c.inst.exe  < ../inputs/test261 > ../newoutputs/t1203
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1202.tr
echo ">>>>>>>>running test 1204"
../source/print_tokens.c.inst.exe  < ../inputs/test262 > ../newoutputs/t1204
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1203.tr
echo ">>>>>>>>running test 1205"
../source/print_tokens.c.inst.exe  < ../inputs/test263 > ../newoutputs/t1205
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1204.tr
echo ">>>>>>>>running test 1206"
../source/print_tokens.c.inst.exe  < ../inputs/test264 > ../newoutputs/t1206
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1205.tr
echo ">>>>>>>>running test 1207"
../source/print_tokens.c.inst.exe  < ../inputs/test265 > ../newoutputs/t1207
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1206.tr
echo ">>>>>>>>running test 1208"
../source/print_tokens.c.inst.exe  < ../inputs/test266 > ../newoutputs/t1208
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1207.tr
echo ">>>>>>>>running test 1209"
../source/print_tokens.c.inst.exe  < ../inputs/test267 > ../newoutputs/t1209
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1208.tr
echo ">>>>>>>>running test 1210"
../source/print_tokens.c.inst.exe  < ../inputs/test268 > ../newoutputs/t1210
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1209.tr
echo ">>>>>>>>running test 1211"
../source/print_tokens.c.inst.exe  < ../inputs/test269 > ../newoutputs/t1211
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1210.tr
echo ">>>>>>>>running test 1212"
../source/print_tokens.c.inst.exe  < ../inputs/test27 > ../newoutputs/t1212
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1211.tr
echo ">>>>>>>>running test 1213"
../source/print_tokens.c.inst.exe  < ../inputs/test270 > ../newoutputs/t1213
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1212.tr
echo ">>>>>>>>running test 1214"
../source/print_tokens.c.inst.exe  < ../inputs/test271 > ../newoutputs/t1214
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1213.tr
echo ">>>>>>>>running test 1215"
../source/print_tokens.c.inst.exe  < ../inputs/test272 > ../newoutputs/t1215
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1214.tr
echo ">>>>>>>>running test 1216"
../source/print_tokens.c.inst.exe  < ../inputs/test273 > ../newoutputs/t1216
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1215.tr
echo ">>>>>>>>running test 1217"
../source/print_tokens.c.inst.exe  < ../inputs/test274 > ../newoutputs/t1217
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1216.tr
echo ">>>>>>>>running test 1218"
../source/print_tokens.c.inst.exe  < ../inputs/test275 > ../newoutputs/t1218
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1217.tr
echo ">>>>>>>>running test 1219"
../source/print_tokens.c.inst.exe  < ../inputs/test276 > ../newoutputs/t1219
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1218.tr
echo ">>>>>>>>running test 1220"
../source/print_tokens.c.inst.exe  < ../inputs/test277 > ../newoutputs/t1220
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1219.tr
echo ">>>>>>>>running test 1221"
../source/print_tokens.c.inst.exe  < ../inputs/test278 > ../newoutputs/t1221
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1220.tr
echo ">>>>>>>>running test 1222"
../source/print_tokens.c.inst.exe  < ../inputs/test279 > ../newoutputs/t1222
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1221.tr
echo ">>>>>>>>running test 1223"
../source/print_tokens.c.inst.exe  < ../inputs/test28 > ../newoutputs/t1223
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1222.tr
echo ">>>>>>>>running test 1224"
../source/print_tokens.c.inst.exe  < ../inputs/test280 > ../newoutputs/t1224
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1223.tr
echo ">>>>>>>>running test 1225"
../source/print_tokens.c.inst.exe  < ../inputs/test281 > ../newoutputs/t1225
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1224.tr
echo ">>>>>>>>running test 1226"
../source/print_tokens.c.inst.exe  < ../inputs/test282 > ../newoutputs/t1226
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1225.tr
echo ">>>>>>>>running test 1227"
../source/print_tokens.c.inst.exe  < ../inputs/test283 > ../newoutputs/t1227
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1226.tr
echo ">>>>>>>>running test 1228"
../source/print_tokens.c.inst.exe  < ../inputs/test284 > ../newoutputs/t1228
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1227.tr
echo ">>>>>>>>running test 1229"
../source/print_tokens.c.inst.exe  < ../inputs/test285 > ../newoutputs/t1229
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1228.tr
echo ">>>>>>>>running test 1230"
../source/print_tokens.c.inst.exe  < ../inputs/test286 > ../newoutputs/t1230
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1229.tr
echo ">>>>>>>>running test 1231"
../source/print_tokens.c.inst.exe  < ../inputs/test287 > ../newoutputs/t1231
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1230.tr
echo ">>>>>>>>running test 1232"
../source/print_tokens.c.inst.exe  < ../inputs/test288 > ../newoutputs/t1232
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1231.tr
echo ">>>>>>>>running test 1233"
../source/print_tokens.c.inst.exe  < ../inputs/test289 > ../newoutputs/t1233
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1232.tr
echo ">>>>>>>>running test 1234"
../source/print_tokens.c.inst.exe  < ../inputs/test29 > ../newoutputs/t1234
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1233.tr
echo ">>>>>>>>running test 1235"
../source/print_tokens.c.inst.exe  < ../inputs/test290 > ../newoutputs/t1235
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1234.tr
echo ">>>>>>>>running test 1236"
../source/print_tokens.c.inst.exe  < ../inputs/test291 > ../newoutputs/t1236
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1235.tr
echo ">>>>>>>>running test 1237"
../source/print_tokens.c.inst.exe  < ../inputs/test292 > ../newoutputs/t1237
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1236.tr
echo ">>>>>>>>running test 1238"
../source/print_tokens.c.inst.exe  < ../inputs/test293 > ../newoutputs/t1238
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1237.tr
echo ">>>>>>>>running test 1239"
../source/print_tokens.c.inst.exe  < ../inputs/test294 > ../newoutputs/t1239
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1238.tr
echo ">>>>>>>>running test 1240"
../source/print_tokens.c.inst.exe  < ../inputs/test295 > ../newoutputs/t1240
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1239.tr
echo ">>>>>>>>running test 1241"
../source/print_tokens.c.inst.exe  < ../inputs/test296 > ../newoutputs/t1241
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1240.tr
echo ">>>>>>>>running test 1242"
../source/print_tokens.c.inst.exe  < ../inputs/test297 > ../newoutputs/t1242
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1241.tr
echo ">>>>>>>>running test 1243"
../source/print_tokens.c.inst.exe  < ../inputs/test298 > ../newoutputs/t1243
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1242.tr
echo ">>>>>>>>running test 1244"
../source/print_tokens.c.inst.exe  < ../inputs/test299 > ../newoutputs/t1244
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1243.tr
echo ">>>>>>>>running test 1245"
../source/print_tokens.c.inst.exe  < ../inputs/test3 > ../newoutputs/t1245
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1244.tr
echo ">>>>>>>>running test 1246"
../source/print_tokens.c.inst.exe  < ../inputs/test30 > ../newoutputs/t1246
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1245.tr
echo ">>>>>>>>running test 1247"
../source/print_tokens.c.inst.exe  < ../inputs/test300 > ../newoutputs/t1247
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1246.tr
echo ">>>>>>>>running test 1248"
../source/print_tokens.c.inst.exe  < ../inputs/test301 > ../newoutputs/t1248
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1247.tr
echo ">>>>>>>>running test 1249"
../source/print_tokens.c.inst.exe  < ../inputs/test302 > ../newoutputs/t1249
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1248.tr
echo ">>>>>>>>running test 1250"
../source/print_tokens.c.inst.exe  < ../inputs/test303 > ../newoutputs/t1250
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1249.tr
echo ">>>>>>>>running test 1251"
../source/print_tokens.c.inst.exe  < ../inputs/test304 > ../newoutputs/t1251
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1250.tr
echo ">>>>>>>>running test 1252"
../source/print_tokens.c.inst.exe  < ../inputs/test305 > ../newoutputs/t1252
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1251.tr
echo ">>>>>>>>running test 1253"
../source/print_tokens.c.inst.exe  < ../inputs/test306 > ../newoutputs/t1253
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1252.tr
echo ">>>>>>>>running test 1254"
../source/print_tokens.c.inst.exe  < ../inputs/test307 > ../newoutputs/t1254
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1253.tr
echo ">>>>>>>>running test 1255"
../source/print_tokens.c.inst.exe  < ../inputs/test308 > ../newoutputs/t1255
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1254.tr
echo ">>>>>>>>running test 1256"
../source/print_tokens.c.inst.exe  < ../inputs/test309 > ../newoutputs/t1256
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1255.tr
echo ">>>>>>>>running test 1257"
../source/print_tokens.c.inst.exe  < ../inputs/test31 > ../newoutputs/t1257
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1256.tr
echo ">>>>>>>>running test 1258"
../source/print_tokens.c.inst.exe  < ../inputs/test310 > ../newoutputs/t1258
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1257.tr
echo ">>>>>>>>running test 1259"
../source/print_tokens.c.inst.exe  < ../inputs/test311 > ../newoutputs/t1259
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1258.tr
echo ">>>>>>>>running test 1260"
../source/print_tokens.c.inst.exe  < ../inputs/test312 > ../newoutputs/t1260
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1259.tr
echo ">>>>>>>>running test 1261"
../source/print_tokens.c.inst.exe  < ../inputs/test313 > ../newoutputs/t1261
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1260.tr
echo ">>>>>>>>running test 1262"
../source/print_tokens.c.inst.exe  < ../inputs/test314 > ../newoutputs/t1262
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1261.tr
echo ">>>>>>>>running test 1263"
../source/print_tokens.c.inst.exe  < ../inputs/test315 > ../newoutputs/t1263
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1262.tr
echo ">>>>>>>>running test 1264"
../source/print_tokens.c.inst.exe  < ../inputs/test316 > ../newoutputs/t1264
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1263.tr
echo ">>>>>>>>running test 1265"
../source/print_tokens.c.inst.exe  < ../inputs/test317 > ../newoutputs/t1265
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1264.tr
echo ">>>>>>>>running test 1266"
../source/print_tokens.c.inst.exe  < ../inputs/test318 > ../newoutputs/t1266
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1265.tr
echo ">>>>>>>>running test 1267"
../source/print_tokens.c.inst.exe  < ../inputs/test319 > ../newoutputs/t1267
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1266.tr
echo ">>>>>>>>running test 1268"
../source/print_tokens.c.inst.exe  < ../inputs/test32 > ../newoutputs/t1268
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1267.tr
echo ">>>>>>>>running test 1269"
../source/print_tokens.c.inst.exe  < ../inputs/test320 > ../newoutputs/t1269
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1268.tr
echo ">>>>>>>>running test 1270"
../source/print_tokens.c.inst.exe  < ../inputs/test321 > ../newoutputs/t1270
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1269.tr
echo ">>>>>>>>running test 1271"
../source/print_tokens.c.inst.exe  < ../inputs/test322 > ../newoutputs/t1271
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1270.tr
echo ">>>>>>>>running test 1272"
../source/print_tokens.c.inst.exe  < ../inputs/test323 > ../newoutputs/t1272
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1271.tr
echo ">>>>>>>>running test 1273"
../source/print_tokens.c.inst.exe  < ../inputs/test324 > ../newoutputs/t1273
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1272.tr
echo ">>>>>>>>running test 1274"
../source/print_tokens.c.inst.exe  < ../inputs/test325 > ../newoutputs/t1274
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1273.tr
echo ">>>>>>>>running test 1275"
../source/print_tokens.c.inst.exe  < ../inputs/test326 > ../newoutputs/t1275
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1274.tr
echo ">>>>>>>>running test 1276"
../source/print_tokens.c.inst.exe  < ../inputs/test327 > ../newoutputs/t1276
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1275.tr
echo ">>>>>>>>running test 1277"
../source/print_tokens.c.inst.exe  < ../inputs/test328 > ../newoutputs/t1277
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1276.tr
echo ">>>>>>>>running test 1278"
../source/print_tokens.c.inst.exe  < ../inputs/test329 > ../newoutputs/t1278
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1277.tr
echo ">>>>>>>>running test 1279"
../source/print_tokens.c.inst.exe  < ../inputs/test33 > ../newoutputs/t1279
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1278.tr
echo ">>>>>>>>running test 1280"
../source/print_tokens.c.inst.exe  < ../inputs/test330 > ../newoutputs/t1280
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1279.tr
echo ">>>>>>>>running test 1281"
../source/print_tokens.c.inst.exe  < ../inputs/test331 > ../newoutputs/t1281
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1280.tr
echo ">>>>>>>>running test 1282"
../source/print_tokens.c.inst.exe  < ../inputs/test332 > ../newoutputs/t1282
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1281.tr
echo ">>>>>>>>running test 1283"
../source/print_tokens.c.inst.exe  < ../inputs/test333 > ../newoutputs/t1283
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1282.tr
echo ">>>>>>>>running test 1284"
../source/print_tokens.c.inst.exe  < ../inputs/test334 > ../newoutputs/t1284
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1283.tr
echo ">>>>>>>>running test 1285"
../source/print_tokens.c.inst.exe  < ../inputs/test335 > ../newoutputs/t1285
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1284.tr
echo ">>>>>>>>running test 1286"
../source/print_tokens.c.inst.exe  < ../inputs/test336 > ../newoutputs/t1286
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1285.tr
echo ">>>>>>>>running test 1287"
../source/print_tokens.c.inst.exe  < ../inputs/test337 > ../newoutputs/t1287
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1286.tr
echo ">>>>>>>>running test 1288"
../source/print_tokens.c.inst.exe  < ../inputs/test338 > ../newoutputs/t1288
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1287.tr
echo ">>>>>>>>running test 1289"
../source/print_tokens.c.inst.exe  < ../inputs/test339 > ../newoutputs/t1289
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1288.tr
echo ">>>>>>>>running test 1290"
../source/print_tokens.c.inst.exe  < ../inputs/test34 > ../newoutputs/t1290
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1289.tr
echo ">>>>>>>>running test 1291"
../source/print_tokens.c.inst.exe  < ../inputs/test340 > ../newoutputs/t1291
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1290.tr
echo ">>>>>>>>running test 1292"
../source/print_tokens.c.inst.exe  < ../inputs/test341 > ../newoutputs/t1292
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1291.tr
echo ">>>>>>>>running test 1293"
../source/print_tokens.c.inst.exe  < ../inputs/test342 > ../newoutputs/t1293
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1292.tr
echo ">>>>>>>>running test 1294"
../source/print_tokens.c.inst.exe  < ../inputs/test343 > ../newoutputs/t1294
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1293.tr
echo ">>>>>>>>running test 1295"
../source/print_tokens.c.inst.exe  < ../inputs/test344 > ../newoutputs/t1295
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1294.tr
echo ">>>>>>>>running test 1296"
../source/print_tokens.c.inst.exe  < ../inputs/test345 > ../newoutputs/t1296
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1295.tr
echo ">>>>>>>>running test 1297"
../source/print_tokens.c.inst.exe  < ../inputs/test346 > ../newoutputs/t1297
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1296.tr
echo ">>>>>>>>running test 1298"
../source/print_tokens.c.inst.exe  < ../inputs/test347 > ../newoutputs/t1298
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1297.tr
echo ">>>>>>>>running test 1299"
../source/print_tokens.c.inst.exe  < ../inputs/test348 > ../newoutputs/t1299
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1298.tr
echo ">>>>>>>>running test 1300"
../source/print_tokens.c.inst.exe  < ../inputs/test349 > ../newoutputs/t1300
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1299.tr
echo ">>>>>>>>running test 1301"
../source/print_tokens.c.inst.exe  < ../inputs/test35 > ../newoutputs/t1301
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1300.tr
echo ">>>>>>>>running test 1302"
../source/print_tokens.c.inst.exe  < ../inputs/test350 > ../newoutputs/t1302
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1301.tr
echo ">>>>>>>>running test 1303"
../source/print_tokens.c.inst.exe  < ../inputs/test351 > ../newoutputs/t1303
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1302.tr
echo ">>>>>>>>running test 1304"
../source/print_tokens.c.inst.exe  < ../inputs/test352 > ../newoutputs/t1304
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1303.tr
echo ">>>>>>>>running test 1305"
../source/print_tokens.c.inst.exe  < ../inputs/test353 > ../newoutputs/t1305
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1304.tr
echo ">>>>>>>>running test 1306"
../source/print_tokens.c.inst.exe  < ../inputs/test354 > ../newoutputs/t1306
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1305.tr
echo ">>>>>>>>running test 1307"
../source/print_tokens.c.inst.exe  < ../inputs/test355 > ../newoutputs/t1307
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1306.tr
echo ">>>>>>>>running test 1308"
../source/print_tokens.c.inst.exe  < ../inputs/test356 > ../newoutputs/t1308
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1307.tr
echo ">>>>>>>>running test 1309"
../source/print_tokens.c.inst.exe  < ../inputs/test357 > ../newoutputs/t1309
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1308.tr
echo ">>>>>>>>running test 1310"
../source/print_tokens.c.inst.exe  < ../inputs/test358 > ../newoutputs/t1310
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1309.tr
echo ">>>>>>>>running test 1311"
../source/print_tokens.c.inst.exe  < ../inputs/test359 > ../newoutputs/t1311
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1310.tr
echo ">>>>>>>>running test 1312"
../source/print_tokens.c.inst.exe  < ../inputs/test36 > ../newoutputs/t1312
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1311.tr
echo ">>>>>>>>running test 1313"
../source/print_tokens.c.inst.exe  < ../inputs/test360 > ../newoutputs/t1313
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1312.tr
echo ">>>>>>>>running test 1314"
../source/print_tokens.c.inst.exe  < ../inputs/test361 > ../newoutputs/t1314
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1313.tr
echo ">>>>>>>>running test 1315"
../source/print_tokens.c.inst.exe  < ../inputs/test362 > ../newoutputs/t1315
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1314.tr
echo ">>>>>>>>running test 1316"
../source/print_tokens.c.inst.exe  < ../inputs/test363 > ../newoutputs/t1316
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1315.tr
echo ">>>>>>>>running test 1317"
../source/print_tokens.c.inst.exe  < ../inputs/test364 > ../newoutputs/t1317
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1316.tr
echo ">>>>>>>>running test 1318"
../source/print_tokens.c.inst.exe  < ../inputs/test365 > ../newoutputs/t1318
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1317.tr
echo ">>>>>>>>running test 1319"
../source/print_tokens.c.inst.exe  < ../inputs/test366 > ../newoutputs/t1319
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1318.tr
echo ">>>>>>>>running test 1320"
../source/print_tokens.c.inst.exe  < ../inputs/test367 > ../newoutputs/t1320
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1319.tr
echo ">>>>>>>>running test 1321"
../source/print_tokens.c.inst.exe  < ../inputs/test368 > ../newoutputs/t1321
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1320.tr
echo ">>>>>>>>running test 1322"
../source/print_tokens.c.inst.exe  < ../inputs/test369 > ../newoutputs/t1322
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1321.tr
echo ">>>>>>>>running test 1323"
../source/print_tokens.c.inst.exe  < ../inputs/test37 > ../newoutputs/t1323
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1322.tr
echo ">>>>>>>>running test 1324"
../source/print_tokens.c.inst.exe  < ../inputs/test370 > ../newoutputs/t1324
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1323.tr
echo ">>>>>>>>running test 1325"
../source/print_tokens.c.inst.exe  < ../inputs/test371 > ../newoutputs/t1325
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1324.tr
echo ">>>>>>>>running test 1326"
../source/print_tokens.c.inst.exe  < ../inputs/test372 > ../newoutputs/t1326
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1325.tr
echo ">>>>>>>>running test 1327"
../source/print_tokens.c.inst.exe  < ../inputs/test373 > ../newoutputs/t1327
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1326.tr
echo ">>>>>>>>running test 1328"
../source/print_tokens.c.inst.exe  < ../inputs/test374 > ../newoutputs/t1328
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1327.tr
echo ">>>>>>>>running test 1329"
../source/print_tokens.c.inst.exe  < ../inputs/test375 > ../newoutputs/t1329
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1328.tr
echo ">>>>>>>>running test 1330"
../source/print_tokens.c.inst.exe  < ../inputs/test376 > ../newoutputs/t1330
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1329.tr
echo ">>>>>>>>running test 1331"
../source/print_tokens.c.inst.exe  < ../inputs/test377 > ../newoutputs/t1331
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1330.tr
echo ">>>>>>>>running test 1332"
../source/print_tokens.c.inst.exe  < ../inputs/test378 > ../newoutputs/t1332
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1331.tr
echo ">>>>>>>>running test 1333"
../source/print_tokens.c.inst.exe  < ../inputs/test379 > ../newoutputs/t1333
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1332.tr
echo ">>>>>>>>running test 1334"
../source/print_tokens.c.inst.exe  < ../inputs/test38 > ../newoutputs/t1334
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1333.tr
echo ">>>>>>>>running test 1335"
../source/print_tokens.c.inst.exe  < ../inputs/test380 > ../newoutputs/t1335
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1334.tr
echo ">>>>>>>>running test 1336"
../source/print_tokens.c.inst.exe  < ../inputs/test381 > ../newoutputs/t1336
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1335.tr
echo ">>>>>>>>running test 1337"
../source/print_tokens.c.inst.exe  < ../inputs/test382 > ../newoutputs/t1337
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1336.tr
echo ">>>>>>>>running test 1338"
../source/print_tokens.c.inst.exe  < ../inputs/test383 > ../newoutputs/t1338
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1337.tr
echo ">>>>>>>>running test 1339"
../source/print_tokens.c.inst.exe  < ../inputs/test384 > ../newoutputs/t1339
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1338.tr
echo ">>>>>>>>running test 1340"
../source/print_tokens.c.inst.exe  < ../inputs/test385 > ../newoutputs/t1340
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1339.tr
echo ">>>>>>>>running test 1341"
../source/print_tokens.c.inst.exe  < ../inputs/test386 > ../newoutputs/t1341
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1340.tr
echo ">>>>>>>>running test 1342"
../source/print_tokens.c.inst.exe  < ../inputs/test387 > ../newoutputs/t1342
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1341.tr
echo ">>>>>>>>running test 1343"
../source/print_tokens.c.inst.exe  < ../inputs/test388 > ../newoutputs/t1343
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1342.tr
echo ">>>>>>>>running test 1344"
../source/print_tokens.c.inst.exe  < ../inputs/test389 > ../newoutputs/t1344
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1343.tr
echo ">>>>>>>>running test 1345"
../source/print_tokens.c.inst.exe  < ../inputs/test39 > ../newoutputs/t1345
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1344.tr
echo ">>>>>>>>running test 1346"
../source/print_tokens.c.inst.exe  < ../inputs/test390 > ../newoutputs/t1346
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1345.tr
echo ">>>>>>>>running test 1347"
../source/print_tokens.c.inst.exe  < ../inputs/test391 > ../newoutputs/t1347
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1346.tr
echo ">>>>>>>>running test 1348"
../source/print_tokens.c.inst.exe  < ../inputs/test392 > ../newoutputs/t1348
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1347.tr
echo ">>>>>>>>running test 1349"
../source/print_tokens.c.inst.exe  < ../inputs/test393 > ../newoutputs/t1349
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1348.tr
echo ">>>>>>>>running test 1350"
../source/print_tokens.c.inst.exe  < ../inputs/test394 > ../newoutputs/t1350
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1349.tr
echo ">>>>>>>>running test 1351"
../source/print_tokens.c.inst.exe  < ../inputs/test395 > ../newoutputs/t1351
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1350.tr
echo ">>>>>>>>running test 1352"
../source/print_tokens.c.inst.exe  < ../inputs/test396 > ../newoutputs/t1352
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1351.tr
echo ">>>>>>>>running test 1353"
../source/print_tokens.c.inst.exe  < ../inputs/test397 > ../newoutputs/t1353
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1352.tr
echo ">>>>>>>>running test 1354"
../source/print_tokens.c.inst.exe  < ../inputs/test398 > ../newoutputs/t1354
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1353.tr
echo ">>>>>>>>running test 1355"
../source/print_tokens.c.inst.exe  < ../inputs/test399 > ../newoutputs/t1355
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1354.tr
echo ">>>>>>>>running test 1356"
../source/print_tokens.c.inst.exe  < ../inputs/test4 > ../newoutputs/t1356
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1355.tr
echo ">>>>>>>>running test 1357"
../source/print_tokens.c.inst.exe  < ../inputs/test40 > ../newoutputs/t1357
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1356.tr
echo ">>>>>>>>running test 1358"
../source/print_tokens.c.inst.exe  < ../inputs/test400 > ../newoutputs/t1358
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1357.tr
echo ">>>>>>>>running test 1359"
../source/print_tokens.c.inst.exe  < ../inputs/test41 > ../newoutputs/t1359
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1358.tr
echo ">>>>>>>>running test 1360"
../source/print_tokens.c.inst.exe  < ../inputs/test42 > ../newoutputs/t1360
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1359.tr
echo ">>>>>>>>running test 1361"
../source/print_tokens.c.inst.exe  < ../inputs/test43 > ../newoutputs/t1361
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1360.tr
echo ">>>>>>>>running test 1362"
../source/print_tokens.c.inst.exe  < ../inputs/test44 > ../newoutputs/t1362
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1361.tr
echo ">>>>>>>>running test 1363"
../source/print_tokens.c.inst.exe  < ../inputs/test45 > ../newoutputs/t1363
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1362.tr
echo ">>>>>>>>running test 1364"
../source/print_tokens.c.inst.exe  < ../inputs/test46 > ../newoutputs/t1364
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1363.tr
echo ">>>>>>>>running test 1365"
../source/print_tokens.c.inst.exe  < ../inputs/test47 > ../newoutputs/t1365
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1364.tr
echo ">>>>>>>>running test 1366"
../source/print_tokens.c.inst.exe  < ../inputs/test48 > ../newoutputs/t1366
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1365.tr
echo ">>>>>>>>running test 1367"
../source/print_tokens.c.inst.exe  < ../inputs/test49 > ../newoutputs/t1367
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1366.tr
echo ">>>>>>>>running test 1368"
../source/print_tokens.c.inst.exe  < ../inputs/test5 > ../newoutputs/t1368
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1367.tr
echo ">>>>>>>>running test 1369"
../source/print_tokens.c.inst.exe  < ../inputs/test50 > ../newoutputs/t1369
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1368.tr
echo ">>>>>>>>running test 1370"
../source/print_tokens.c.inst.exe  < ../inputs/test51 > ../newoutputs/t1370
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1369.tr
echo ">>>>>>>>running test 1371"
../source/print_tokens.c.inst.exe  < ../inputs/test52 > ../newoutputs/t1371
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1370.tr
echo ">>>>>>>>running test 1372"
../source/print_tokens.c.inst.exe  < ../inputs/test53 > ../newoutputs/t1372
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1371.tr
echo ">>>>>>>>running test 1373"
../source/print_tokens.c.inst.exe  < ../inputs/test54 > ../newoutputs/t1373
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1372.tr
echo ">>>>>>>>running test 1374"
../source/print_tokens.c.inst.exe  < ../inputs/test55 > ../newoutputs/t1374
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1373.tr
echo ">>>>>>>>running test 1375"
../source/print_tokens.c.inst.exe  < ../inputs/test56 > ../newoutputs/t1375
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1374.tr
echo ">>>>>>>>running test 1376"
../source/print_tokens.c.inst.exe  < ../inputs/test57 > ../newoutputs/t1376
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1375.tr
echo ">>>>>>>>running test 1377"
../source/print_tokens.c.inst.exe  < ../inputs/test58 > ../newoutputs/t1377
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1376.tr
echo ">>>>>>>>running test 1378"
../source/print_tokens.c.inst.exe  < ../inputs/test59 > ../newoutputs/t1378
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1377.tr
echo ">>>>>>>>running test 1379"
../source/print_tokens.c.inst.exe  < ../inputs/test6 > ../newoutputs/t1379
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1378.tr
echo ">>>>>>>>running test 1380"
../source/print_tokens.c.inst.exe  < ../inputs/test60 > ../newoutputs/t1380
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1379.tr
echo ">>>>>>>>running test 1381"
../source/print_tokens.c.inst.exe  < ../inputs/test61 > ../newoutputs/t1381
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1380.tr
echo ">>>>>>>>running test 1382"
../source/print_tokens.c.inst.exe  < ../inputs/test62 > ../newoutputs/t1382
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1381.tr
echo ">>>>>>>>running test 1383"
../source/print_tokens.c.inst.exe  < ../inputs/test63 > ../newoutputs/t1383
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1382.tr
echo ">>>>>>>>running test 1384"
../source/print_tokens.c.inst.exe  < ../inputs/test64 > ../newoutputs/t1384
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1383.tr
echo ">>>>>>>>running test 1385"
../source/print_tokens.c.inst.exe  < ../inputs/test65 > ../newoutputs/t1385
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1384.tr
echo ">>>>>>>>running test 1386"
../source/print_tokens.c.inst.exe  < ../inputs/test66 > ../newoutputs/t1386
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1385.tr
echo ">>>>>>>>running test 1387"
../source/print_tokens.c.inst.exe  < ../inputs/test67 > ../newoutputs/t1387
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1386.tr
echo ">>>>>>>>running test 1388"
../source/print_tokens.c.inst.exe  < ../inputs/test68 > ../newoutputs/t1388
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1387.tr
echo ">>>>>>>>running test 1389"
../source/print_tokens.c.inst.exe  < ../inputs/test69 > ../newoutputs/t1389
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1388.tr
echo ">>>>>>>>running test 1390"
../source/print_tokens.c.inst.exe  < ../inputs/test7 > ../newoutputs/t1390
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1389.tr
echo ">>>>>>>>running test 1391"
../source/print_tokens.c.inst.exe  < ../inputs/test70 > ../newoutputs/t1391
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1390.tr
echo ">>>>>>>>running test 1392"
../source/print_tokens.c.inst.exe  < ../inputs/test71 > ../newoutputs/t1392
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1391.tr
echo ">>>>>>>>running test 1393"
../source/print_tokens.c.inst.exe  < ../inputs/test72 > ../newoutputs/t1393
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1392.tr
echo ">>>>>>>>running test 1394"
../source/print_tokens.c.inst.exe  < ../inputs/test73 > ../newoutputs/t1394
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1393.tr
echo ">>>>>>>>running test 1395"
../source/print_tokens.c.inst.exe  < ../inputs/test74 > ../newoutputs/t1395
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1394.tr
echo ">>>>>>>>running test 1396"
../source/print_tokens.c.inst.exe  < ../inputs/test75 > ../newoutputs/t1396
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1395.tr
echo ">>>>>>>>running test 1397"
../source/print_tokens.c.inst.exe  < ../inputs/test76 > ../newoutputs/t1397
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1396.tr
echo ">>>>>>>>running test 1398"
../source/print_tokens.c.inst.exe  < ../inputs/test77 > ../newoutputs/t1398
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1397.tr
echo ">>>>>>>>running test 1399"
../source/print_tokens.c.inst.exe  < ../inputs/test78 > ../newoutputs/t1399
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1398.tr
echo ">>>>>>>>running test 1400"
../source/print_tokens.c.inst.exe  < ../inputs/test79 > ../newoutputs/t1400
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1399.tr
echo ">>>>>>>>running test 1401"
../source/print_tokens.c.inst.exe  < ../inputs/test8 > ../newoutputs/t1401
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1400.tr
echo ">>>>>>>>running test 1402"
../source/print_tokens.c.inst.exe  < ../inputs/test80 > ../newoutputs/t1402
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1401.tr
echo ">>>>>>>>running test 1403"
../source/print_tokens.c.inst.exe  < ../inputs/test81 > ../newoutputs/t1403
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1402.tr
echo ">>>>>>>>running test 1404"
../source/print_tokens.c.inst.exe  < ../inputs/test82 > ../newoutputs/t1404
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1403.tr
echo ">>>>>>>>running test 1405"
../source/print_tokens.c.inst.exe  < ../inputs/test83 > ../newoutputs/t1405
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1404.tr
echo ">>>>>>>>running test 1406"
../source/print_tokens.c.inst.exe  < ../inputs/test84 > ../newoutputs/t1406
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1405.tr
echo ">>>>>>>>running test 1407"
../source/print_tokens.c.inst.exe  < ../inputs/test85 > ../newoutputs/t1407
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1406.tr
echo ">>>>>>>>running test 1408"
../source/print_tokens.c.inst.exe  < ../inputs/test86 > ../newoutputs/t1408
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1407.tr
echo ">>>>>>>>running test 1409"
../source/print_tokens.c.inst.exe  < ../inputs/test87 > ../newoutputs/t1409
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1408.tr
echo ">>>>>>>>running test 1410"
../source/print_tokens.c.inst.exe  < ../inputs/test88 > ../newoutputs/t1410
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1409.tr
echo ">>>>>>>>running test 1411"
../source/print_tokens.c.inst.exe  < ../inputs/test89 > ../newoutputs/t1411
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1410.tr
echo ">>>>>>>>running test 1412"
../source/print_tokens.c.inst.exe  < ../inputs/test9 > ../newoutputs/t1412
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1411.tr
echo ">>>>>>>>running test 1413"
../source/print_tokens.c.inst.exe  < ../inputs/test90 > ../newoutputs/t1413
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1412.tr
echo ">>>>>>>>running test 1414"
../source/print_tokens.c.inst.exe  < ../inputs/test91 > ../newoutputs/t1414
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1413.tr
echo ">>>>>>>>running test 1415"
../source/print_tokens.c.inst.exe  < ../inputs/test92 > ../newoutputs/t1415
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1414.tr
echo ">>>>>>>>running test 1416"
../source/print_tokens.c.inst.exe  < ../inputs/test93 > ../newoutputs/t1416
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1415.tr
echo ">>>>>>>>running test 1417"
../source/print_tokens.c.inst.exe  < ../inputs/test94 > ../newoutputs/t1417
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1416.tr
echo ">>>>>>>>running test 1418"
../source/print_tokens.c.inst.exe  < ../inputs/test95 > ../newoutputs/t1418
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1417.tr
echo ">>>>>>>>running test 1419"
../source/print_tokens.c.inst.exe  < ../inputs/test96 > ../newoutputs/t1419
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1418.tr
echo ">>>>>>>>running test 1420"
../source/print_tokens.c.inst.exe  < ../inputs/test97 > ../newoutputs/t1420
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1419.tr
echo ">>>>>>>>running test 1421"
../source/print_tokens.c.inst.exe  < ../inputs/test98 > ../newoutputs/t1421
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1420.tr
echo ">>>>>>>>running test 1422"
../source/print_tokens.c.inst.exe  < ../inputs/test99 > ../newoutputs/t1422
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1421.tr
echo ">>>>>>>>running test 1423"
../source/print_tokens.c.inst.exe  < ../inputs/ts500 > ../newoutputs/t1423
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1422.tr
echo ">>>>>>>>running test 1424"
../source/print_tokens.c.inst.exe  < ../inputs/ts501 > ../newoutputs/t1424
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1423.tr
echo ">>>>>>>>running test 1425"
../source/print_tokens.c.inst.exe  < ../inputs/ts502 > ../newoutputs/t1425
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1424.tr
echo ">>>>>>>>running test 1426"
../source/print_tokens.c.inst.exe  < ../inputs/ts503 > ../newoutputs/t1426
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1425.tr
echo ">>>>>>>>running test 1427"
../source/print_tokens.c.inst.exe  < ../inputs/ts504 > ../newoutputs/t1427
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1426.tr
echo ">>>>>>>>running test 1428"
../source/print_tokens.c.inst.exe  < ../inputs/ts505 > ../newoutputs/t1428
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1427.tr
echo ">>>>>>>>running test 1429"
../source/print_tokens.c.inst.exe  < ../inputs/ts506 > ../newoutputs/t1429
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1428.tr
echo ">>>>>>>>running test 1430"
../source/print_tokens.c.inst.exe  < ../inputs/ts507 > ../newoutputs/t1430
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1429.tr
echo ">>>>>>>>running test 1431"
../source/print_tokens.c.inst.exe  < ../inputs/ts508 > ../newoutputs/t1431
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1430.tr
echo ">>>>>>>>running test 1432"
../source/print_tokens.c.inst.exe  < ../inputs/ts509 > ../newoutputs/t1432
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1431.tr
echo ">>>>>>>>running test 1433"
../source/print_tokens.c.inst.exe  < ../inputs/ts510 > ../newoutputs/t1433
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1432.tr
echo ">>>>>>>>running test 1434"
../source/print_tokens.c.inst.exe  < ../inputs/ts511 > ../newoutputs/t1434
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1433.tr
echo ">>>>>>>>running test 1435"
../source/print_tokens.c.inst.exe  < ../inputs/ts512 > ../newoutputs/t1435
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1434.tr
echo ">>>>>>>>running test 1436"
../source/print_tokens.c.inst.exe  < ../inputs/ts513 > ../newoutputs/t1436
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1435.tr
echo ">>>>>>>>running test 1437"
../source/print_tokens.c.inst.exe  < ../inputs/ts514 > ../newoutputs/t1437
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1436.tr
echo ">>>>>>>>running test 1438"
../source/print_tokens.c.inst.exe  < ../inputs/ts515 > ../newoutputs/t1438
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1437.tr
echo ">>>>>>>>running test 1439"
../source/print_tokens.c.inst.exe  < ../inputs/ts516 > ../newoutputs/t1439
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1438.tr
echo ">>>>>>>>running test 1440"
../source/print_tokens.c.inst.exe  < ../inputs/ts517 > ../newoutputs/t1440
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1439.tr
echo ">>>>>>>>running test 1441"
../source/print_tokens.c.inst.exe  < ../inputs/ts518 > ../newoutputs/t1441
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1440.tr
echo ">>>>>>>>running test 1442"
../source/print_tokens.c.inst.exe  < ../inputs/ts519 > ../newoutputs/t1442
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1441.tr
echo ">>>>>>>>running test 1443"
../source/print_tokens.c.inst.exe  < ../inputs/ts520 > ../newoutputs/t1443
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1442.tr
echo ">>>>>>>>running test 1444"
../source/print_tokens.c.inst.exe  < ../inputs/ts521 > ../newoutputs/t1444
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1443.tr
echo ">>>>>>>>running test 1445"
../source/print_tokens.c.inst.exe  < ../inputs/ts522 > ../newoutputs/t1445
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1444.tr
echo ">>>>>>>>running test 1446"
../source/print_tokens.c.inst.exe  < ../inputs/ts523 > ../newoutputs/t1446
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1445.tr
echo ">>>>>>>>running test 1447"
../source/print_tokens.c.inst.exe  < ../inputs/ts524 > ../newoutputs/t1447
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1446.tr
echo ">>>>>>>>running test 1448"
../source/print_tokens.c.inst.exe  < ../inputs/ts525 > ../newoutputs/t1448
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1447.tr
echo ">>>>>>>>running test 1449"
../source/print_tokens.c.inst.exe  < ../inputs/ts526 > ../newoutputs/t1449
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1448.tr
echo ">>>>>>>>running test 1450"
../source/print_tokens.c.inst.exe  < ../inputs/ts527 > ../newoutputs/t1450
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1449.tr
echo ">>>>>>>>running test 1451"
../source/print_tokens.c.inst.exe  < ../inputs/ts528 > ../newoutputs/t1451
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1450.tr
echo ">>>>>>>>running test 1452"
../source/print_tokens.c.inst.exe  < ../inputs/ts529 > ../newoutputs/t1452
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1451.tr
echo ">>>>>>>>running test 1453"
../source/print_tokens.c.inst.exe  < ../inputs/ts530 > ../newoutputs/t1453
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1452.tr
echo ">>>>>>>>running test 1454"
../source/print_tokens.c.inst.exe  < ../inputs/ts531 > ../newoutputs/t1454
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1453.tr
echo ">>>>>>>>running test 1455"
../source/print_tokens.c.inst.exe  < ../inputs/ts532 > ../newoutputs/t1455
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1454.tr
echo ">>>>>>>>running test 1456"
../source/print_tokens.c.inst.exe  < ../inputs/ts533 > ../newoutputs/t1456
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1455.tr
echo ">>>>>>>>running test 1457"
../source/print_tokens.c.inst.exe  < ../inputs/ts534 > ../newoutputs/t1457
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1456.tr
echo ">>>>>>>>running test 1458"
../source/print_tokens.c.inst.exe  < ../inputs/ts535 > ../newoutputs/t1458
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1457.tr
echo ">>>>>>>>running test 1459"
../source/print_tokens.c.inst.exe  < ../inputs/ts536 > ../newoutputs/t1459
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1458.tr
echo ">>>>>>>>running test 1460"
../source/print_tokens.c.inst.exe  < ../inputs/ts537 > ../newoutputs/t1460
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1459.tr
echo ">>>>>>>>running test 1461"
../source/print_tokens.c.inst.exe  < ../inputs/ts538 > ../newoutputs/t1461
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1460.tr
echo ">>>>>>>>running test 1462"
../source/print_tokens.c.inst.exe  < ../inputs/ts539 > ../newoutputs/t1462
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1461.tr
echo ">>>>>>>>running test 1463"
../source/print_tokens.c.inst.exe  < ../inputs/ts540 > ../newoutputs/t1463
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1462.tr
echo ">>>>>>>>running test 1464"
../source/print_tokens.c.inst.exe  < ../inputs/ts541 > ../newoutputs/t1464
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1463.tr
echo ">>>>>>>>running test 1465"
../source/print_tokens.c.inst.exe  < ../inputs/ts542 > ../newoutputs/t1465
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1464.tr
echo ">>>>>>>>running test 1466"
../source/print_tokens.c.inst.exe  < ../inputs/ts543 > ../newoutputs/t1466
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1465.tr
echo ">>>>>>>>running test 1467"
../source/print_tokens.c.inst.exe  < ../inputs/ts544 > ../newoutputs/t1467
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1466.tr
echo ">>>>>>>>running test 1468"
../source/print_tokens.c.inst.exe  < ../inputs/ts545 > ../newoutputs/t1468
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1467.tr
echo ">>>>>>>>running test 1469"
../source/print_tokens.c.inst.exe  < ../inputs/ts546 > ../newoutputs/t1469
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1468.tr
echo ">>>>>>>>running test 1470"
../source/print_tokens.c.inst.exe  < ../inputs/ts547 > ../newoutputs/t1470
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1469.tr
echo ">>>>>>>>running test 1471"
../source/print_tokens.c.inst.exe  < ../inputs/ts548 > ../newoutputs/t1471
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1470.tr
echo ">>>>>>>>running test 1472"
../source/print_tokens.c.inst.exe  < ../inputs/ts549 > ../newoutputs/t1472
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1471.tr
echo ">>>>>>>>running test 1473"
../source/print_tokens.c.inst.exe  < ../inputs/ts550 > ../newoutputs/t1473
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1472.tr
echo ">>>>>>>>running test 1474"
../source/print_tokens.c.inst.exe  < ../inputs/ts551 > ../newoutputs/t1474
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1473.tr
echo ">>>>>>>>running test 1475"
../source/print_tokens.c.inst.exe  < ../inputs/ts552 > ../newoutputs/t1475
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1474.tr
echo ">>>>>>>>running test 1476"
../source/print_tokens.c.inst.exe  < ../inputs/ts553 > ../newoutputs/t1476
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1475.tr
echo ">>>>>>>>running test 1477"
../source/print_tokens.c.inst.exe  < ../inputs/ts554 > ../newoutputs/t1477
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1476.tr
echo ">>>>>>>>running test 1478"
../source/print_tokens.c.inst.exe  < ../inputs/ts555 > ../newoutputs/t1478
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1477.tr
echo ">>>>>>>>running test 1479"
../source/print_tokens.c.inst.exe  < ../inputs/ts556 > ../newoutputs/t1479
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1478.tr
echo ">>>>>>>>running test 1480"
../source/print_tokens.c.inst.exe  < ../inputs/ts557 > ../newoutputs/t1480
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1479.tr
echo ">>>>>>>>running test 1481"
../source/print_tokens.c.inst.exe  < ../inputs/ts558 > ../newoutputs/t1481
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1480.tr
echo ">>>>>>>>running test 1482"
../source/print_tokens.c.inst.exe  < ../inputs/ts559 > ../newoutputs/t1482
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1481.tr
echo ">>>>>>>>running test 1483"
../source/print_tokens.c.inst.exe  < ../inputs/ts560 > ../newoutputs/t1483
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1482.tr
echo ">>>>>>>>running test 1484"
../source/print_tokens.c.inst.exe  < ../inputs/ts561 > ../newoutputs/t1484
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1483.tr
echo ">>>>>>>>running test 1485"
../source/print_tokens.c.inst.exe  < ../inputs/ts562 > ../newoutputs/t1485
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1484.tr
echo ">>>>>>>>running test 1486"
../source/print_tokens.c.inst.exe  < ../inputs/ts563 > ../newoutputs/t1486
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1485.tr
echo ">>>>>>>>running test 1487"
../source/print_tokens.c.inst.exe  < ../inputs/ts564 > ../newoutputs/t1487
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1486.tr
echo ">>>>>>>>running test 1488"
../source/print_tokens.c.inst.exe  < ../inputs/ts565 > ../newoutputs/t1488
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1487.tr
echo ">>>>>>>>running test 1489"
../source/print_tokens.c.inst.exe  < ../inputs/ts566 > ../newoutputs/t1489
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1488.tr
echo ">>>>>>>>running test 1490"
../source/print_tokens.c.inst.exe  < ../inputs/ts567 > ../newoutputs/t1490
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1489.tr
echo ">>>>>>>>running test 1491"
../source/print_tokens.c.inst.exe  < ../inputs/ts568 > ../newoutputs/t1491
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1490.tr
echo ">>>>>>>>running test 1492"
../source/print_tokens.c.inst.exe  < ../inputs/ts569 > ../newoutputs/t1492
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1491.tr
echo ">>>>>>>>running test 1493"
../source/print_tokens.c.inst.exe  < ../inputs/ts570 > ../newoutputs/t1493
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1492.tr
echo ">>>>>>>>running test 1494"
../source/print_tokens.c.inst.exe  < ../inputs/ts571 > ../newoutputs/t1494
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1493.tr
echo ">>>>>>>>running test 1495"
../source/print_tokens.c.inst.exe  < ../inputs/ts572 > ../newoutputs/t1495
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1494.tr
echo ">>>>>>>>running test 1496"
../source/print_tokens.c.inst.exe  < ../inputs/ts573 > ../newoutputs/t1496
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1495.tr
echo ">>>>>>>>running test 1497"
../source/print_tokens.c.inst.exe  < ../inputs/ts574 > ../newoutputs/t1497
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1496.tr
echo ">>>>>>>>running test 1498"
../source/print_tokens.c.inst.exe  < ../inputs/ts575 > ../newoutputs/t1498
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1497.tr
echo ">>>>>>>>running test 1499"
../source/print_tokens.c.inst.exe  < ../inputs/ts576 > ../newoutputs/t1499
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1498.tr
echo ">>>>>>>>running test 1500"
../source/print_tokens.c.inst.exe  < ../inputs/ts577 > ../newoutputs/t1500
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1499.tr
echo ">>>>>>>>running test 1501"
../source/print_tokens.c.inst.exe  < ../inputs/ts578 > ../newoutputs/t1501
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1500.tr
echo ">>>>>>>>running test 1502"
../source/print_tokens.c.inst.exe  < ../inputs/ts579 > ../newoutputs/t1502
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1501.tr
echo ">>>>>>>>running test 1503"
../source/print_tokens.c.inst.exe  < ../inputs/ts580 > ../newoutputs/t1503
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1502.tr
echo ">>>>>>>>running test 1504"
../source/print_tokens.c.inst.exe  < ../inputs/ts581 > ../newoutputs/t1504
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1503.tr
echo ">>>>>>>>running test 1505"
../source/print_tokens.c.inst.exe  < ../inputs/ts582 > ../newoutputs/t1505
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1504.tr
echo ">>>>>>>>running test 1506"
../source/print_tokens.c.inst.exe  < ../inputs/ts583 > ../newoutputs/t1506
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1505.tr
echo ">>>>>>>>running test 1507"
../source/print_tokens.c.inst.exe  < ../inputs/ts584 > ../newoutputs/t1507
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1506.tr
echo ">>>>>>>>running test 1508"
../source/print_tokens.c.inst.exe  < ../inputs/ts585 > ../newoutputs/t1508
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1507.tr
echo ">>>>>>>>running test 1509"
../source/print_tokens.c.inst.exe  < ../inputs/ts586 > ../newoutputs/t1509
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1508.tr
echo ">>>>>>>>running test 1510"
../source/print_tokens.c.inst.exe  < ../inputs/ts587 > ../newoutputs/t1510
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1509.tr
echo ">>>>>>>>running test 1511"
../source/print_tokens.c.inst.exe  < ../inputs/ts588 > ../newoutputs/t1511
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1510.tr
echo ">>>>>>>>running test 1512"
../source/print_tokens.c.inst.exe  < ../inputs/ts589 > ../newoutputs/t1512
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1511.tr
echo ">>>>>>>>running test 1513"
../source/print_tokens.c.inst.exe  < ../inputs/ts590 > ../newoutputs/t1513
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1512.tr
echo ">>>>>>>>running test 1514"
../source/print_tokens.c.inst.exe  < ../inputs/ts591 > ../newoutputs/t1514
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1513.tr
echo ">>>>>>>>running test 1515"
../source/print_tokens.c.inst.exe  < ../inputs/ts592 > ../newoutputs/t1515
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1514.tr
echo ">>>>>>>>running test 1516"
../source/print_tokens.c.inst.exe  < ../inputs/ts593 > ../newoutputs/t1516
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1515.tr
echo ">>>>>>>>running test 1517"
../source/print_tokens.c.inst.exe  < ../inputs/ts594 > ../newoutputs/t1517
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1516.tr
echo ">>>>>>>>running test 1518"
../source/print_tokens.c.inst.exe  < ../inputs/ts595 > ../newoutputs/t1518
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1517.tr
echo ">>>>>>>>running test 1519"
../source/print_tokens.c.inst.exe  < ../inputs/ts596 > ../newoutputs/t1519
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1518.tr
echo ">>>>>>>>running test 1520"
../source/print_tokens.c.inst.exe  < ../inputs/ts597 > ../newoutputs/t1520
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1519.tr
echo ">>>>>>>>running test 1521"
../source/print_tokens.c.inst.exe  < ../inputs/ts598 > ../newoutputs/t1521
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1520.tr
echo ">>>>>>>>running test 1522"
../source/print_tokens.c.inst.exe  < ../inputs/ts599 > ../newoutputs/t1522
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1521.tr
echo ">>>>>>>>running test 1523"
../source/print_tokens.c.inst.exe  < ../inputs/ts600 > ../newoutputs/t1523
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1522.tr
echo ">>>>>>>>running test 1524"
../source/print_tokens.c.inst.exe  < ../inputs/ts601 > ../newoutputs/t1524
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1523.tr
echo ">>>>>>>>running test 1525"
../source/print_tokens.c.inst.exe  < ../inputs/ts603 > ../newoutputs/t1525
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1524.tr
echo ">>>>>>>>running test 1526"
../source/print_tokens.c.inst.exe  < ../inputs/ts604 > ../newoutputs/t1526
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1525.tr
echo ">>>>>>>>running test 1527"
../source/print_tokens.c.inst.exe  < ../inputs/ts605 > ../newoutputs/t1527
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1526.tr
echo ">>>>>>>>running test 1528"
../source/print_tokens.c.inst.exe  < ../inputs/ts606 > ../newoutputs/t1528
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1527.tr
echo ">>>>>>>>running test 1529"
../source/print_tokens.c.inst.exe  < ../inputs/ts607 > ../newoutputs/t1529
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1528.tr
echo ">>>>>>>>running test 1530"
../source/print_tokens.c.inst.exe  < ../inputs/ts608 > ../newoutputs/t1530
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1529.tr
echo ">>>>>>>>running test 1531"
../source/print_tokens.c.inst.exe  < ../inputs/ts609 > ../newoutputs/t1531
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1530.tr
echo ">>>>>>>>running test 1532"
../source/print_tokens.c.inst.exe  < ../inputs/ts610 > ../newoutputs/t1532
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1531.tr
echo ">>>>>>>>running test 1533"
../source/print_tokens.c.inst.exe  < ../inputs/ts611 > ../newoutputs/t1533
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1532.tr
echo ">>>>>>>>running test 1534"
../source/print_tokens.c.inst.exe  < ../inputs/ts612 > ../newoutputs/t1534
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1533.tr
echo ">>>>>>>>running test 1535"
../source/print_tokens.c.inst.exe  < ../inputs/ts613 > ../newoutputs/t1535
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1534.tr
echo ">>>>>>>>running test 1536"
../source/print_tokens.c.inst.exe  < ../inputs/ts614 > ../newoutputs/t1536
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1535.tr
echo ">>>>>>>>running test 1537"
../source/print_tokens.c.inst.exe  < ../inputs/ts615 > ../newoutputs/t1537
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1536.tr
echo ">>>>>>>>running test 1538"
../source/print_tokens.c.inst.exe  < ../inputs/ts616 > ../newoutputs/t1538
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1537.tr
echo ">>>>>>>>running test 1539"
../source/print_tokens.c.inst.exe  < ../inputs/ts617 > ../newoutputs/t1539
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1538.tr
echo ">>>>>>>>running test 1540"
../source/print_tokens.c.inst.exe  < ../inputs/ts618 > ../newoutputs/t1540
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1539.tr
echo ">>>>>>>>running test 1541"
../source/print_tokens.c.inst.exe  < ../inputs/ts619 > ../newoutputs/t1541
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1540.tr
echo ">>>>>>>>running test 1542"
../source/print_tokens.c.inst.exe  < ../inputs/ts620 > ../newoutputs/t1542
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1541.tr
echo ">>>>>>>>running test 1543"
../source/print_tokens.c.inst.exe  < ../inputs/ts621 > ../newoutputs/t1543
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1542.tr
echo ">>>>>>>>running test 1544"
../source/print_tokens.c.inst.exe  < ../inputs/ts622 > ../newoutputs/t1544
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1543.tr
echo ">>>>>>>>running test 1545"
../source/print_tokens.c.inst.exe  < ../inputs/ts623 > ../newoutputs/t1545
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1544.tr
echo ">>>>>>>>running test 1546"
../source/print_tokens.c.inst.exe  < ../inputs/ts624 > ../newoutputs/t1546
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1545.tr
echo ">>>>>>>>running test 1547"
../source/print_tokens.c.inst.exe  < ../inputs/ts625 > ../newoutputs/t1547
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1546.tr
echo ">>>>>>>>running test 1548"
../source/print_tokens.c.inst.exe  < ../inputs/ts626 > ../newoutputs/t1548
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1547.tr
echo ">>>>>>>>running test 1549"
../source/print_tokens.c.inst.exe  < ../inputs/ts627 > ../newoutputs/t1549
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1548.tr
echo ">>>>>>>>running test 1550"
../source/print_tokens.c.inst.exe  < ../inputs/ts628 > ../newoutputs/t1550
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1549.tr
echo ">>>>>>>>running test 1551"
../source/print_tokens.c.inst.exe  < ../inputs/ts629 > ../newoutputs/t1551
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1550.tr
echo ">>>>>>>>running test 1552"
../source/print_tokens.c.inst.exe  < ../inputs/ts630 > ../newoutputs/t1552
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1551.tr
echo ">>>>>>>>running test 1553"
../source/print_tokens.c.inst.exe  < ../inputs/ts631 > ../newoutputs/t1553
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1552.tr
echo ">>>>>>>>running test 1554"
../source/print_tokens.c.inst.exe  < ../inputs/ts632 > ../newoutputs/t1554
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1553.tr
echo ">>>>>>>>running test 1555"
../source/print_tokens.c.inst.exe  < ../inputs/ts633 > ../newoutputs/t1555
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1554.tr
echo ">>>>>>>>running test 1556"
../source/print_tokens.c.inst.exe  < ../inputs/ts634 > ../newoutputs/t1556
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1555.tr
echo ">>>>>>>>running test 1557"
../source/print_tokens.c.inst.exe  < ../inputs/ts635 > ../newoutputs/t1557
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1556.tr
echo ">>>>>>>>running test 1558"
../source/print_tokens.c.inst.exe  < ../inputs/ts636 > ../newoutputs/t1558
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1557.tr
echo ">>>>>>>>running test 1559"
../source/print_tokens.c.inst.exe  < ../inputs/ts637 > ../newoutputs/t1559
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1558.tr
echo ">>>>>>>>running test 1560"
../source/print_tokens.c.inst.exe  < ../inputs/ts638 > ../newoutputs/t1560
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1559.tr
echo ">>>>>>>>running test 1561"
../source/print_tokens.c.inst.exe  < ../inputs/ts639 > ../newoutputs/t1561
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1560.tr
echo ">>>>>>>>running test 1562"
../source/print_tokens.c.inst.exe  < ../inputs/ts640 > ../newoutputs/t1562
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1561.tr
echo ">>>>>>>>running test 1563"
../source/print_tokens.c.inst.exe  < ../inputs/ts641 > ../newoutputs/t1563
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1562.tr
echo ">>>>>>>>running test 1564"
../source/print_tokens.c.inst.exe  < ../inputs/ts642 > ../newoutputs/t1564
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1563.tr
echo ">>>>>>>>running test 1565"
../source/print_tokens.c.inst.exe  < ../inputs/ts643 > ../newoutputs/t1565
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1564.tr
echo ">>>>>>>>running test 1566"
../source/print_tokens.c.inst.exe  < ../inputs/ts644 > ../newoutputs/t1566
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1565.tr
echo ">>>>>>>>running test 1567"
../source/print_tokens.c.inst.exe  < ../inputs/ts645 > ../newoutputs/t1567
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1566.tr
echo ">>>>>>>>running test 1568"
../source/print_tokens.c.inst.exe  < ../inputs/ts646 > ../newoutputs/t1568
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1567.tr
echo ">>>>>>>>running test 1569"
../source/print_tokens.c.inst.exe  < ../inputs/ts647 > ../newoutputs/t1569
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1568.tr
echo ">>>>>>>>running test 1570"
../source/print_tokens.c.inst.exe  < ../inputs/ts648 > ../newoutputs/t1570
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1569.tr
echo ">>>>>>>>running test 1571"
../source/print_tokens.c.inst.exe  < ../inputs/ts649 > ../newoutputs/t1571
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1570.tr
echo ">>>>>>>>running test 1572"
../source/print_tokens.c.inst.exe  < ../inputs/ts650 > ../newoutputs/t1572
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1571.tr
echo ">>>>>>>>running test 1573"
../source/print_tokens.c.inst.exe  < ../inputs/ts651 > ../newoutputs/t1573
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1572.tr
echo ">>>>>>>>running test 1574"
../source/print_tokens.c.inst.exe  < ../inputs/ts652 > ../newoutputs/t1574
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1573.tr
echo ">>>>>>>>running test 1575"
../source/print_tokens.c.inst.exe  < ../inputs/ts653 > ../newoutputs/t1575
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1574.tr
echo ">>>>>>>>running test 1576"
../source/print_tokens.c.inst.exe  < ../inputs/ts654 > ../newoutputs/t1576
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1575.tr
echo ">>>>>>>>running test 1577"
../source/print_tokens.c.inst.exe  < ../inputs/ts655 > ../newoutputs/t1577
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1576.tr
echo ">>>>>>>>running test 1578"
../source/print_tokens.c.inst.exe  < ../inputs/ts656 > ../newoutputs/t1578
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1577.tr
echo ">>>>>>>>running test 1579"
../source/print_tokens.c.inst.exe  < ../inputs/ts657 > ../newoutputs/t1579
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1578.tr
echo ">>>>>>>>running test 1580"
../source/print_tokens.c.inst.exe  < ../inputs/ts658 > ../newoutputs/t1580
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1579.tr
echo ">>>>>>>>running test 1581"
../source/print_tokens.c.inst.exe  < ../inputs/ts659 > ../newoutputs/t1581
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1580.tr
echo ">>>>>>>>running test 1582"
../source/print_tokens.c.inst.exe  < ../inputs/ts660 > ../newoutputs/t1582
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1581.tr
echo ">>>>>>>>running test 1583"
../source/print_tokens.c.inst.exe  < ../inputs/ts661 > ../newoutputs/t1583
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1582.tr
echo ">>>>>>>>running test 1584"
../source/print_tokens.c.inst.exe  < ../inputs/ts662 > ../newoutputs/t1584
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1583.tr
echo ">>>>>>>>running test 1585"
../source/print_tokens.c.inst.exe  < ../inputs/ts663 > ../newoutputs/t1585
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1584.tr
echo ">>>>>>>>running test 1586"
../source/print_tokens.c.inst.exe  < ../inputs/ts664 > ../newoutputs/t1586
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1585.tr
echo ">>>>>>>>running test 1587"
../source/print_tokens.c.inst.exe  < ../inputs/ts665 > ../newoutputs/t1587
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1586.tr
echo ">>>>>>>>running test 1588"
../source/print_tokens.c.inst.exe  < ../inputs/ts666 > ../newoutputs/t1588
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1587.tr
echo ">>>>>>>>running test 1589"
../source/print_tokens.c.inst.exe  < ../inputs/ts667 > ../newoutputs/t1589
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1588.tr
echo ">>>>>>>>running test 1590"
../source/print_tokens.c.inst.exe  < ../inputs/ts668 > ../newoutputs/t1590
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1589.tr
echo ">>>>>>>>running test 1591"
../source/print_tokens.c.inst.exe  < ../inputs/ts669 > ../newoutputs/t1591
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1590.tr
echo ">>>>>>>>running test 1592"
../source/print_tokens.c.inst.exe  < ../inputs/ts670 > ../newoutputs/t1592
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1591.tr
echo ">>>>>>>>running test 1593"
../source/print_tokens.c.inst.exe  < ../inputs/ts671 > ../newoutputs/t1593
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1592.tr
echo ">>>>>>>>running test 1594"
../source/print_tokens.c.inst.exe  < ../inputs/ts672 > ../newoutputs/t1594
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1593.tr
echo ">>>>>>>>running test 1595"
../source/print_tokens.c.inst.exe  < ../inputs/ts673 > ../newoutputs/t1595
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1594.tr
echo ">>>>>>>>running test 1596"
../source/print_tokens.c.inst.exe  < ../inputs/ts674 > ../newoutputs/t1596
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1595.tr
echo ">>>>>>>>running test 1597"
../source/print_tokens.c.inst.exe  < ../inputs/ts675 > ../newoutputs/t1597
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1596.tr
echo ">>>>>>>>running test 1598"
../source/print_tokens.c.inst.exe  < ../inputs/ts676 > ../newoutputs/t1598
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1597.tr
echo ">>>>>>>>running test 1599"
../source/print_tokens.c.inst.exe  < ../inputs/ts677 > ../newoutputs/t1599
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1598.tr
echo ">>>>>>>>running test 1600"
../source/print_tokens.c.inst.exe  < ../inputs/ts678 > ../newoutputs/t1600
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1599.tr
echo ">>>>>>>>running test 1601"
../source/print_tokens.c.inst.exe  < ../inputs/ts679 > ../newoutputs/t1601
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1600.tr
echo ">>>>>>>>running test 1602"
../source/print_tokens.c.inst.exe  < ../inputs/ts680 > ../newoutputs/t1602
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1601.tr
echo ">>>>>>>>running test 1603"
../source/print_tokens.c.inst.exe  < ../inputs/ts681 > ../newoutputs/t1603
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1602.tr
echo ">>>>>>>>running test 1604"
../source/print_tokens.c.inst.exe  < ../inputs/ts682 > ../newoutputs/t1604
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1603.tr
echo ">>>>>>>>running test 1605"
../source/print_tokens.c.inst.exe  < ../inputs/ts683 > ../newoutputs/t1605
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1604.tr
echo ">>>>>>>>running test 1606"
../source/print_tokens.c.inst.exe  < ../inputs/ts684 > ../newoutputs/t1606
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1605.tr
echo ">>>>>>>>running test 1607"
../source/print_tokens.c.inst.exe  < ../inputs/ts685 > ../newoutputs/t1607
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1606.tr
echo ">>>>>>>>running test 1608"
../source/print_tokens.c.inst.exe  < ../inputs/ts686 > ../newoutputs/t1608
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1607.tr
echo ">>>>>>>>running test 1609"
../source/print_tokens.c.inst.exe  < ../inputs/ts687 > ../newoutputs/t1609
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1608.tr
echo ">>>>>>>>running test 1610"
../source/print_tokens.c.inst.exe  < ../inputs/ts688 > ../newoutputs/t1610
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1609.tr
echo ">>>>>>>>running test 1611"
../source/print_tokens.c.inst.exe  < ../inputs/ts689 > ../newoutputs/t1611
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1610.tr
echo ">>>>>>>>running test 1612"
../source/print_tokens.c.inst.exe  < ../inputs/ts690 > ../newoutputs/t1612
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1611.tr
echo ">>>>>>>>running test 1613"
../source/print_tokens.c.inst.exe  < ../inputs/ts691 > ../newoutputs/t1613
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1612.tr
echo ">>>>>>>>running test 1614"
../source/print_tokens.c.inst.exe  < ../inputs/ts692 > ../newoutputs/t1614
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1613.tr
echo ">>>>>>>>running test 1615"
../source/print_tokens.c.inst.exe  < ../inputs/ts693 > ../newoutputs/t1615
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1614.tr
echo ">>>>>>>>running test 1616"
../source/print_tokens.c.inst.exe  < ../inputs/ts694 > ../newoutputs/t1616
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1615.tr
echo ">>>>>>>>running test 1617"
../source/print_tokens.c.inst.exe  < ../inputs/ts695 > ../newoutputs/t1617
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1616.tr
echo ">>>>>>>>running test 1618"
../source/print_tokens.c.inst.exe  < ../inputs/ts696 > ../newoutputs/t1618
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1617.tr
echo ">>>>>>>>running test 1619"
../source/print_tokens.c.inst.exe  < ../inputs/ts697 > ../newoutputs/t1619
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1618.tr
echo ">>>>>>>>running test 1620"
../source/print_tokens.c.inst.exe  < ../inputs/ts698 > ../newoutputs/t1620
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1619.tr
echo ">>>>>>>>running test 1621"
../source/print_tokens.c.inst.exe  < ../inputs/ts699 > ../newoutputs/t1621
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1620.tr
echo ">>>>>>>>running test 1622"
../source/print_tokens.c.inst.exe  < ../inputs/ts701 > ../newoutputs/t1622
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1621.tr
echo ">>>>>>>>running test 1623"
../source/print_tokens.c.inst.exe  < ../inputs/ts702 > ../newoutputs/t1623
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1622.tr
echo ">>>>>>>>running test 1624"
../source/print_tokens.c.inst.exe  < ../inputs/ts703 > ../newoutputs/t1624
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1623.tr
echo ">>>>>>>>running test 1625"
../source/print_tokens.c.inst.exe  < ../inputs/ts704 > ../newoutputs/t1625
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1624.tr
echo ">>>>>>>>running test 1626"
../source/print_tokens.c.inst.exe  < ../inputs/ts705 > ../newoutputs/t1626
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1625.tr
echo ">>>>>>>>running test 1627"
../source/print_tokens.c.inst.exe  < ../inputs/ts706 > ../newoutputs/t1627
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1626.tr
echo ">>>>>>>>running test 1628"
../source/print_tokens.c.inst.exe  < ../inputs/ts707 > ../newoutputs/t1628
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1627.tr
echo ">>>>>>>>running test 1629"
../source/print_tokens.c.inst.exe  < ../inputs/ts708 > ../newoutputs/t1629
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1628.tr
echo ">>>>>>>>running test 1630"
../source/print_tokens.c.inst.exe  < ../inputs/ts709 > ../newoutputs/t1630
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1629.tr
echo ">>>>>>>>running test 1631"
../source/print_tokens.c.inst.exe  < ../inputs/ts710 > ../newoutputs/t1631
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1630.tr
echo ">>>>>>>>running test 1632"
../source/print_tokens.c.inst.exe  < ../inputs/ts711 > ../newoutputs/t1632
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1631.tr
echo ">>>>>>>>running test 1633"
../source/print_tokens.c.inst.exe  < ../inputs/ts712 > ../newoutputs/t1633
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1632.tr
echo ">>>>>>>>running test 1634"
../source/print_tokens.c.inst.exe  < ../inputs/ts713 > ../newoutputs/t1634
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1633.tr
echo ">>>>>>>>running test 1635"
../source/print_tokens.c.inst.exe  < ../inputs/ts714 > ../newoutputs/t1635
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1634.tr
echo ">>>>>>>>running test 1636"
../source/print_tokens.c.inst.exe  < ../inputs/ts715 > ../newoutputs/t1636
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1635.tr
echo ">>>>>>>>running test 1637"
../source/print_tokens.c.inst.exe  < ../inputs/ts716 > ../newoutputs/t1637
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1636.tr
echo ">>>>>>>>running test 1638"
../source/print_tokens.c.inst.exe  < ../inputs/ts717 > ../newoutputs/t1638
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1637.tr
echo ">>>>>>>>running test 1639"
../source/print_tokens.c.inst.exe  < ../inputs/ts718 > ../newoutputs/t1639
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1638.tr
echo ">>>>>>>>running test 1640"
../source/print_tokens.c.inst.exe  < ../inputs/ts719 > ../newoutputs/t1640
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1639.tr
echo ">>>>>>>>running test 1641"
../source/print_tokens.c.inst.exe  < ../inputs/ts720 > ../newoutputs/t1641
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1640.tr
echo ">>>>>>>>running test 1642"
../source/print_tokens.c.inst.exe  < ../inputs/ts721 > ../newoutputs/t1642
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1641.tr
echo ">>>>>>>>running test 1643"
../source/print_tokens.c.inst.exe  < ../inputs/ts722 > ../newoutputs/t1643
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1642.tr
echo ">>>>>>>>running test 1644"
../source/print_tokens.c.inst.exe  < ../inputs/ts723 > ../newoutputs/t1644
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1643.tr
echo ">>>>>>>>running test 1645"
../source/print_tokens.c.inst.exe  < ../inputs/ts724 > ../newoutputs/t1645
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1644.tr
echo ">>>>>>>>running test 1646"
../source/print_tokens.c.inst.exe  < ../inputs/ts725 > ../newoutputs/t1646
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1645.tr
echo ">>>>>>>>running test 1647"
../source/print_tokens.c.inst.exe  < ../inputs/ts726 > ../newoutputs/t1647
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1646.tr
echo ">>>>>>>>running test 1648"
../source/print_tokens.c.inst.exe  < ../inputs/ts727 > ../newoutputs/t1648
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1647.tr
echo ">>>>>>>>running test 1649"
../source/print_tokens.c.inst.exe  < ../inputs/ts728 > ../newoutputs/t1649
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1648.tr
echo ">>>>>>>>running test 1650"
../source/print_tokens.c.inst.exe  < ../inputs/ts729 > ../newoutputs/t1650
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1649.tr
echo ">>>>>>>>running test 1651"
../source/print_tokens.c.inst.exe  < ../inputs/ts730 > ../newoutputs/t1651
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1650.tr
echo ">>>>>>>>running test 1652"
../source/print_tokens.c.inst.exe  < ../inputs/ts731 > ../newoutputs/t1652
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1651.tr
echo ">>>>>>>>running test 1653"
../source/print_tokens.c.inst.exe  < ../inputs/ts732 > ../newoutputs/t1653
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1652.tr
echo ">>>>>>>>running test 1654"
../source/print_tokens.c.inst.exe  < ../inputs/ts733 > ../newoutputs/t1654
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1653.tr
echo ">>>>>>>>running test 1655"
../source/print_tokens.c.inst.exe  < ../inputs/ts734 > ../newoutputs/t1655
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1654.tr
echo ">>>>>>>>running test 1656"
../source/print_tokens.c.inst.exe  < ../inputs/ts735 > ../newoutputs/t1656
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1655.tr
echo ">>>>>>>>running test 1657"
../source/print_tokens.c.inst.exe  < ../inputs/ts736 > ../newoutputs/t1657
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1656.tr
echo ">>>>>>>>running test 1658"
../source/print_tokens.c.inst.exe  < ../inputs/ts737 > ../newoutputs/t1658
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1657.tr
echo ">>>>>>>>running test 1659"
../source/print_tokens.c.inst.exe  < ../inputs/ts738 > ../newoutputs/t1659
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1658.tr
echo ">>>>>>>>running test 1660"
../source/print_tokens.c.inst.exe  < ../inputs/ts739 > ../newoutputs/t1660
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1659.tr
echo ">>>>>>>>running test 1661"
../source/print_tokens.c.inst.exe  < ../inputs/ts740 > ../newoutputs/t1661
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1660.tr
echo ">>>>>>>>running test 1662"
../source/print_tokens.c.inst.exe  < ../inputs/ts741 > ../newoutputs/t1662
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1661.tr
echo ">>>>>>>>running test 1663"
../source/print_tokens.c.inst.exe  < ../inputs/ts742 > ../newoutputs/t1663
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1662.tr
echo ">>>>>>>>running test 1664"
../source/print_tokens.c.inst.exe  < ../inputs/ts743 > ../newoutputs/t1664
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1663.tr
echo ">>>>>>>>running test 1665"
../source/print_tokens.c.inst.exe  < ../inputs/ts744 > ../newoutputs/t1665
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1664.tr
echo ">>>>>>>>running test 1666"
../source/print_tokens.c.inst.exe  < ../inputs/ts745 > ../newoutputs/t1666
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1665.tr
echo ">>>>>>>>running test 1667"
../source/print_tokens.c.inst.exe  < ../inputs/ts746 > ../newoutputs/t1667
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1666.tr
echo ">>>>>>>>running test 1668"
../source/print_tokens.c.inst.exe  < ../inputs/ts747 > ../newoutputs/t1668
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1667.tr
echo ">>>>>>>>running test 1669"
../source/print_tokens.c.inst.exe  < ../inputs/ts748 > ../newoutputs/t1669
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1668.tr
echo ">>>>>>>>running test 1670"
../source/print_tokens.c.inst.exe  < ../inputs/ts749 > ../newoutputs/t1670
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1669.tr
echo ">>>>>>>>running test 1671"
../source/print_tokens.c.inst.exe  < ../inputs/ts750 > ../newoutputs/t1671
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1670.tr
echo ">>>>>>>>running test 1672"
../source/print_tokens.c.inst.exe  < ../inputs/ts751 > ../newoutputs/t1672
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1671.tr
echo ">>>>>>>>running test 1673"
../source/print_tokens.c.inst.exe  < ../inputs/ts752 > ../newoutputs/t1673
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1672.tr
echo ">>>>>>>>running test 1674"
../source/print_tokens.c.inst.exe  < ../inputs/ts753 > ../newoutputs/t1674
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1673.tr
echo ">>>>>>>>running test 1675"
../source/print_tokens.c.inst.exe  < ../inputs/ts754 > ../newoutputs/t1675
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1674.tr
echo ">>>>>>>>running test 1676"
../source/print_tokens.c.inst.exe  < ../inputs/ts755 > ../newoutputs/t1676
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1675.tr
echo ">>>>>>>>running test 1677"
../source/print_tokens.c.inst.exe  < ../inputs/ts756 > ../newoutputs/t1677
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1676.tr
echo ">>>>>>>>running test 1678"
../source/print_tokens.c.inst.exe  < ../inputs/ts757 > ../newoutputs/t1678
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1677.tr
echo ">>>>>>>>running test 1679"
../source/print_tokens.c.inst.exe  < ../inputs/ts758 > ../newoutputs/t1679
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1678.tr
echo ">>>>>>>>running test 1680"
../source/print_tokens.c.inst.exe  < ../inputs/ts759 > ../newoutputs/t1680
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1679.tr
echo ">>>>>>>>running test 1681"
../source/print_tokens.c.inst.exe  < ../inputs/ts760 > ../newoutputs/t1681
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1680.tr
echo ">>>>>>>>running test 1682"
../source/print_tokens.c.inst.exe  < ../inputs/ts761 > ../newoutputs/t1682
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1681.tr
echo ">>>>>>>>running test 1683"
../source/print_tokens.c.inst.exe  < ../inputs/ts762 > ../newoutputs/t1683
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1682.tr
echo ">>>>>>>>running test 1684"
../source/print_tokens.c.inst.exe  < ../inputs/ts763 > ../newoutputs/t1684
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1683.tr
echo ">>>>>>>>running test 1685"
../source/print_tokens.c.inst.exe  < ../inputs/ts764 > ../newoutputs/t1685
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1684.tr
echo ">>>>>>>>running test 1686"
../source/print_tokens.c.inst.exe  < ../inputs/ts765 > ../newoutputs/t1686
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1685.tr
echo ">>>>>>>>running test 1687"
../source/print_tokens.c.inst.exe  < ../inputs/ts766 > ../newoutputs/t1687
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1686.tr
echo ">>>>>>>>running test 1688"
../source/print_tokens.c.inst.exe  < ../inputs/ts767 > ../newoutputs/t1688
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1687.tr
echo ">>>>>>>>running test 1689"
../source/print_tokens.c.inst.exe  < ../inputs/ts768 > ../newoutputs/t1689
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1688.tr
echo ">>>>>>>>running test 1690"
../source/print_tokens.c.inst.exe  < ../inputs/ts769 > ../newoutputs/t1690
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1689.tr
echo ">>>>>>>>running test 1691"
../source/print_tokens.c.inst.exe  < ../inputs/ts770 > ../newoutputs/t1691
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1690.tr
echo ">>>>>>>>running test 1692"
../source/print_tokens.c.inst.exe  < ../inputs/ts771 > ../newoutputs/t1692
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1691.tr
echo ">>>>>>>>running test 1693"
../source/print_tokens.c.inst.exe  < ../inputs/ts772 > ../newoutputs/t1693
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1692.tr
echo ">>>>>>>>running test 1694"
../source/print_tokens.c.inst.exe  < ../inputs/ts773 > ../newoutputs/t1694
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1693.tr
echo ">>>>>>>>running test 1695"
../source/print_tokens.c.inst.exe  < ../inputs/ts774 > ../newoutputs/t1695
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1694.tr
echo ">>>>>>>>running test 1696"
../source/print_tokens.c.inst.exe  < ../inputs/ts775 > ../newoutputs/t1696
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1695.tr
echo ">>>>>>>>running test 1697"
../source/print_tokens.c.inst.exe  < ../inputs/ts776 > ../newoutputs/t1697
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1696.tr
echo ">>>>>>>>running test 1698"
../source/print_tokens.c.inst.exe  < ../inputs/ts777 > ../newoutputs/t1698
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1697.tr
echo ">>>>>>>>running test 1699"
../source/print_tokens.c.inst.exe  < ../inputs/ts778 > ../newoutputs/t1699
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1698.tr
echo ">>>>>>>>running test 1700"
../source/print_tokens.c.inst.exe  < ../inputs/ts779 > ../newoutputs/t1700
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1699.tr
echo ">>>>>>>>running test 1701"
../source/print_tokens.c.inst.exe  < ../inputs/ts780 > ../newoutputs/t1701
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1700.tr
echo ">>>>>>>>running test 1702"
../source/print_tokens.c.inst.exe  < ../inputs/ts781 > ../newoutputs/t1702
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1701.tr
echo ">>>>>>>>running test 1703"
../source/print_tokens.c.inst.exe  < ../inputs/ts782 > ../newoutputs/t1703
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1702.tr
echo ">>>>>>>>running test 1704"
../source/print_tokens.c.inst.exe  < ../inputs/ts783 > ../newoutputs/t1704
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1703.tr
echo ">>>>>>>>running test 1705"
../source/print_tokens.c.inst.exe  < ../inputs/ts784 > ../newoutputs/t1705
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1704.tr
echo ">>>>>>>>running test 1706"
../source/print_tokens.c.inst.exe  < ../inputs/ts785 > ../newoutputs/t1706
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1705.tr
echo ">>>>>>>>running test 1707"
../source/print_tokens.c.inst.exe  < ../inputs/ts786 > ../newoutputs/t1707
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1706.tr
echo ">>>>>>>>running test 1708"
../source/print_tokens.c.inst.exe  < ../inputs/ts787 > ../newoutputs/t1708
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1707.tr
echo ">>>>>>>>running test 1709"
../source/print_tokens.c.inst.exe  < ../inputs/ts788 > ../newoutputs/t1709
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1708.tr
echo ">>>>>>>>running test 1710"
../source/print_tokens.c.inst.exe  < ../inputs/ts789 > ../newoutputs/t1710
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1709.tr
echo ">>>>>>>>running test 1711"
../source/print_tokens.c.inst.exe  < ../inputs/ts790 > ../newoutputs/t1711
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1710.tr
echo ">>>>>>>>running test 1712"
../source/print_tokens.c.inst.exe  < ../inputs/ts791 > ../newoutputs/t1712
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1711.tr
echo ">>>>>>>>running test 1713"
../source/print_tokens.c.inst.exe  < ../inputs/ts792 > ../newoutputs/t1713
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1712.tr
echo ">>>>>>>>running test 1714"
../source/print_tokens.c.inst.exe  < ../inputs/ts793 > ../newoutputs/t1714
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1713.tr
echo ">>>>>>>>running test 1715"
../source/print_tokens.c.inst.exe  < ../inputs/ts794 > ../newoutputs/t1715
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1714.tr
echo ">>>>>>>>running test 1716"
../source/print_tokens.c.inst.exe  < ../inputs/ts795 > ../newoutputs/t1716
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1715.tr
echo ">>>>>>>>running test 1717"
../source/print_tokens.c.inst.exe  < ../inputs/ts796 > ../newoutputs/t1717
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1716.tr
echo ">>>>>>>>running test 1718"
../source/print_tokens.c.inst.exe  < ../inputs/ts797 > ../newoutputs/t1718
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1717.tr
echo ">>>>>>>>running test 1719"
../source/print_tokens.c.inst.exe  < ../inputs/ts798 > ../newoutputs/t1719
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1718.tr
echo ">>>>>>>>running test 1720"
../source/print_tokens.c.inst.exe  < ../inputs/ts799 > ../newoutputs/t1720
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1719.tr
echo ">>>>>>>>running test 1721"
../source/print_tokens.c.inst.exe  < ../inputs/ts800 > ../newoutputs/t1721
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1720.tr
echo ">>>>>>>>running test 1722"
../source/print_tokens.c.inst.exe  < ../inputs/tst1 > ../newoutputs/t1722
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1721.tr
echo ">>>>>>>>running test 1723"
../source/print_tokens.c.inst.exe  < ../inputs/tst10 > ../newoutputs/t1723
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1722.tr
echo ">>>>>>>>running test 1724"
../source/print_tokens.c.inst.exe  < ../inputs/tst100 > ../newoutputs/t1724
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1723.tr
echo ">>>>>>>>running test 1725"
../source/print_tokens.c.inst.exe  < ../inputs/tst101 > ../newoutputs/t1725
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1724.tr
echo ">>>>>>>>running test 1726"
../source/print_tokens.c.inst.exe  < ../inputs/tst102 > ../newoutputs/t1726
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1725.tr
echo ">>>>>>>>running test 1727"
../source/print_tokens.c.inst.exe  < ../inputs/tst103 > ../newoutputs/t1727
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1726.tr
echo ">>>>>>>>running test 1728"
../source/print_tokens.c.inst.exe  < ../inputs/tst104 > ../newoutputs/t1728
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1727.tr
echo ">>>>>>>>running test 1729"
../source/print_tokens.c.inst.exe  < ../inputs/tst105 > ../newoutputs/t1729
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1728.tr
echo ">>>>>>>>running test 1730"
../source/print_tokens.c.inst.exe  < ../inputs/tst106 > ../newoutputs/t1730
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1729.tr
echo ">>>>>>>>running test 1731"
../source/print_tokens.c.inst.exe  < ../inputs/tst107 > ../newoutputs/t1731
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1730.tr
echo ">>>>>>>>running test 1732"
../source/print_tokens.c.inst.exe  < ../inputs/tst108 > ../newoutputs/t1732
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1731.tr
echo ">>>>>>>>running test 1733"
../source/print_tokens.c.inst.exe  < ../inputs/tst109 > ../newoutputs/t1733
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1732.tr
echo ">>>>>>>>running test 1734"
../source/print_tokens.c.inst.exe  < ../inputs/tst11 > ../newoutputs/t1734
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1733.tr
echo ">>>>>>>>running test 1735"
../source/print_tokens.c.inst.exe  < ../inputs/tst110 > ../newoutputs/t1735
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1734.tr
echo ">>>>>>>>running test 1736"
../source/print_tokens.c.inst.exe  < ../inputs/tst111 > ../newoutputs/t1736
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1735.tr
echo ">>>>>>>>running test 1737"
../source/print_tokens.c.inst.exe  < ../inputs/tst112 > ../newoutputs/t1737
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1736.tr
echo ">>>>>>>>running test 1738"
../source/print_tokens.c.inst.exe  < ../inputs/tst113 > ../newoutputs/t1738
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1737.tr
echo ">>>>>>>>running test 1739"
../source/print_tokens.c.inst.exe  < ../inputs/tst114 > ../newoutputs/t1739
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1738.tr
echo ">>>>>>>>running test 1740"
../source/print_tokens.c.inst.exe  < ../inputs/tst115 > ../newoutputs/t1740
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1739.tr
echo ">>>>>>>>running test 1741"
../source/print_tokens.c.inst.exe  < ../inputs/tst116 > ../newoutputs/t1741
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1740.tr
echo ">>>>>>>>running test 1742"
../source/print_tokens.c.inst.exe  < ../inputs/tst117 > ../newoutputs/t1742
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1741.tr
echo ">>>>>>>>running test 1743"
../source/print_tokens.c.inst.exe  < ../inputs/tst118 > ../newoutputs/t1743
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1742.tr
echo ">>>>>>>>running test 1744"
../source/print_tokens.c.inst.exe  < ../inputs/tst119 > ../newoutputs/t1744
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1743.tr
echo ">>>>>>>>running test 1745"
../source/print_tokens.c.inst.exe  < ../inputs/tst12 > ../newoutputs/t1745
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1744.tr
echo ">>>>>>>>running test 1746"
../source/print_tokens.c.inst.exe  < ../inputs/tst120 > ../newoutputs/t1746
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1745.tr
echo ">>>>>>>>running test 1747"
../source/print_tokens.c.inst.exe  < ../inputs/tst121 > ../newoutputs/t1747
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1746.tr
echo ">>>>>>>>running test 1748"
../source/print_tokens.c.inst.exe  < ../inputs/tst122 > ../newoutputs/t1748
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1747.tr
echo ">>>>>>>>running test 1749"
../source/print_tokens.c.inst.exe  < ../inputs/tst123 > ../newoutputs/t1749
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1748.tr
echo ">>>>>>>>running test 1750"
../source/print_tokens.c.inst.exe  < ../inputs/tst124 > ../newoutputs/t1750
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1749.tr
echo ">>>>>>>>running test 1751"
../source/print_tokens.c.inst.exe  < ../inputs/tst125 > ../newoutputs/t1751
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1750.tr
echo ">>>>>>>>running test 1752"
../source/print_tokens.c.inst.exe  < ../inputs/tst126 > ../newoutputs/t1752
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1751.tr
echo ">>>>>>>>running test 1753"
../source/print_tokens.c.inst.exe  < ../inputs/tst127 > ../newoutputs/t1753
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1752.tr
echo ">>>>>>>>running test 1754"
../source/print_tokens.c.inst.exe  < ../inputs/tst128 > ../newoutputs/t1754
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1753.tr
echo ">>>>>>>>running test 1755"
../source/print_tokens.c.inst.exe  < ../inputs/tst129 > ../newoutputs/t1755
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1754.tr
echo ">>>>>>>>running test 1756"
../source/print_tokens.c.inst.exe  < ../inputs/tst13 > ../newoutputs/t1756
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1755.tr
echo ">>>>>>>>running test 1757"
../source/print_tokens.c.inst.exe  < ../inputs/tst130 > ../newoutputs/t1757
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1756.tr
echo ">>>>>>>>running test 1758"
../source/print_tokens.c.inst.exe  < ../inputs/tst131 > ../newoutputs/t1758
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1757.tr
echo ">>>>>>>>running test 1759"
../source/print_tokens.c.inst.exe  < ../inputs/tst132 > ../newoutputs/t1759
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1758.tr
echo ">>>>>>>>running test 1760"
../source/print_tokens.c.inst.exe  < ../inputs/tst133 > ../newoutputs/t1760
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1759.tr
echo ">>>>>>>>running test 1761"
../source/print_tokens.c.inst.exe  < ../inputs/tst134 > ../newoutputs/t1761
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1760.tr
echo ">>>>>>>>running test 1762"
../source/print_tokens.c.inst.exe  < ../inputs/tst135 > ../newoutputs/t1762
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1761.tr
echo ">>>>>>>>running test 1763"
../source/print_tokens.c.inst.exe  < ../inputs/tst136 > ../newoutputs/t1763
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1762.tr
echo ">>>>>>>>running test 1764"
../source/print_tokens.c.inst.exe  < ../inputs/tst137 > ../newoutputs/t1764
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1763.tr
echo ">>>>>>>>running test 1765"
../source/print_tokens.c.inst.exe  < ../inputs/tst138 > ../newoutputs/t1765
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1764.tr
echo ">>>>>>>>running test 1766"
../source/print_tokens.c.inst.exe  < ../inputs/tst139 > ../newoutputs/t1766
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1765.tr
echo ">>>>>>>>running test 1767"
../source/print_tokens.c.inst.exe  < ../inputs/tst14 > ../newoutputs/t1767
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1766.tr
echo ">>>>>>>>running test 1768"
../source/print_tokens.c.inst.exe  < ../inputs/tst140 > ../newoutputs/t1768
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1767.tr
echo ">>>>>>>>running test 1769"
../source/print_tokens.c.inst.exe  < ../inputs/tst141 > ../newoutputs/t1769
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1768.tr
echo ">>>>>>>>running test 1770"
../source/print_tokens.c.inst.exe  < ../inputs/tst142 > ../newoutputs/t1770
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1769.tr
echo ">>>>>>>>running test 1771"
../source/print_tokens.c.inst.exe  < ../inputs/tst143 > ../newoutputs/t1771
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1770.tr
echo ">>>>>>>>running test 1772"
../source/print_tokens.c.inst.exe  < ../inputs/tst144 > ../newoutputs/t1772
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1771.tr
echo ">>>>>>>>running test 1773"
../source/print_tokens.c.inst.exe  < ../inputs/tst145 > ../newoutputs/t1773
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1772.tr
echo ">>>>>>>>running test 1774"
../source/print_tokens.c.inst.exe  < ../inputs/tst146 > ../newoutputs/t1774
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1773.tr
echo ">>>>>>>>running test 1775"
../source/print_tokens.c.inst.exe  < ../inputs/tst147 > ../newoutputs/t1775
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1774.tr
echo ">>>>>>>>running test 1776"
../source/print_tokens.c.inst.exe  < ../inputs/tst148 > ../newoutputs/t1776
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1775.tr
echo ">>>>>>>>running test 1777"
../source/print_tokens.c.inst.exe  < ../inputs/tst149 > ../newoutputs/t1777
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1776.tr
echo ">>>>>>>>running test 1778"
../source/print_tokens.c.inst.exe  < ../inputs/tst15 > ../newoutputs/t1778
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1777.tr
echo ">>>>>>>>running test 1779"
../source/print_tokens.c.inst.exe  < ../inputs/tst150 > ../newoutputs/t1779
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1778.tr
echo ">>>>>>>>running test 1780"
../source/print_tokens.c.inst.exe  < ../inputs/tst151 > ../newoutputs/t1780
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1779.tr
echo ">>>>>>>>running test 1781"
../source/print_tokens.c.inst.exe  < ../inputs/tst152 > ../newoutputs/t1781
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1780.tr
echo ">>>>>>>>running test 1782"
../source/print_tokens.c.inst.exe  < ../inputs/tst153 > ../newoutputs/t1782
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1781.tr
echo ">>>>>>>>running test 1783"
../source/print_tokens.c.inst.exe  < ../inputs/tst154 > ../newoutputs/t1783
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1782.tr
echo ">>>>>>>>running test 1784"
../source/print_tokens.c.inst.exe  < ../inputs/tst155 > ../newoutputs/t1784
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1783.tr
echo ">>>>>>>>running test 1785"
../source/print_tokens.c.inst.exe  < ../inputs/tst156 > ../newoutputs/t1785
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1784.tr
echo ">>>>>>>>running test 1786"
../source/print_tokens.c.inst.exe  < ../inputs/tst157 > ../newoutputs/t1786
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1785.tr
echo ">>>>>>>>running test 1787"
../source/print_tokens.c.inst.exe  < ../inputs/tst158 > ../newoutputs/t1787
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1786.tr
echo ">>>>>>>>running test 1788"
../source/print_tokens.c.inst.exe  < ../inputs/tst159 > ../newoutputs/t1788
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1787.tr
echo ">>>>>>>>running test 1789"
../source/print_tokens.c.inst.exe  < ../inputs/tst16 > ../newoutputs/t1789
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1788.tr
echo ">>>>>>>>running test 1790"
../source/print_tokens.c.inst.exe  < ../inputs/tst160 > ../newoutputs/t1790
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1789.tr
echo ">>>>>>>>running test 1791"
../source/print_tokens.c.inst.exe  < ../inputs/tst161 > ../newoutputs/t1791
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1790.tr
echo ">>>>>>>>running test 1792"
../source/print_tokens.c.inst.exe  < ../inputs/tst162 > ../newoutputs/t1792
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1791.tr
echo ">>>>>>>>running test 1793"
../source/print_tokens.c.inst.exe  < ../inputs/tst163 > ../newoutputs/t1793
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1792.tr
echo ">>>>>>>>running test 1794"
../source/print_tokens.c.inst.exe  < ../inputs/tst164 > ../newoutputs/t1794
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1793.tr
echo ">>>>>>>>running test 1795"
../source/print_tokens.c.inst.exe  < ../inputs/tst165 > ../newoutputs/t1795
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1794.tr
echo ">>>>>>>>running test 1796"
../source/print_tokens.c.inst.exe  < ../inputs/tst166 > ../newoutputs/t1796
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1795.tr
echo ">>>>>>>>running test 1797"
../source/print_tokens.c.inst.exe  < ../inputs/tst167 > ../newoutputs/t1797
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1796.tr
echo ">>>>>>>>running test 1798"
../source/print_tokens.c.inst.exe  < ../inputs/tst168 > ../newoutputs/t1798
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1797.tr
echo ">>>>>>>>running test 1799"
../source/print_tokens.c.inst.exe  < ../inputs/tst169 > ../newoutputs/t1799
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1798.tr
echo ">>>>>>>>running test 1800"
../source/print_tokens.c.inst.exe  < ../inputs/tst17 > ../newoutputs/t1800
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1799.tr
echo ">>>>>>>>running test 1801"
../source/print_tokens.c.inst.exe  < ../inputs/tst170 > ../newoutputs/t1801
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1800.tr
echo ">>>>>>>>running test 1802"
../source/print_tokens.c.inst.exe  < ../inputs/tst171 > ../newoutputs/t1802
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1801.tr
echo ">>>>>>>>running test 1803"
../source/print_tokens.c.inst.exe  < ../inputs/tst172 > ../newoutputs/t1803
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1802.tr
echo ">>>>>>>>running test 1804"
../source/print_tokens.c.inst.exe  < ../inputs/tst173 > ../newoutputs/t1804
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1803.tr
echo ">>>>>>>>running test 1805"
../source/print_tokens.c.inst.exe  < ../inputs/tst174 > ../newoutputs/t1805
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1804.tr
echo ">>>>>>>>running test 1806"
../source/print_tokens.c.inst.exe  < ../inputs/tst175 > ../newoutputs/t1806
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1805.tr
echo ">>>>>>>>running test 1807"
../source/print_tokens.c.inst.exe  < ../inputs/tst176 > ../newoutputs/t1807
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1806.tr
echo ">>>>>>>>running test 1808"
../source/print_tokens.c.inst.exe  < ../inputs/tst177 > ../newoutputs/t1808
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1807.tr
echo ">>>>>>>>running test 1809"
../source/print_tokens.c.inst.exe  < ../inputs/tst178 > ../newoutputs/t1809
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1808.tr
echo ">>>>>>>>running test 1810"
../source/print_tokens.c.inst.exe  < ../inputs/tst179 > ../newoutputs/t1810
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1809.tr
echo ">>>>>>>>running test 1811"
../source/print_tokens.c.inst.exe  < ../inputs/tst18 > ../newoutputs/t1811
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1810.tr
echo ">>>>>>>>running test 1812"
../source/print_tokens.c.inst.exe  < ../inputs/tst180 > ../newoutputs/t1812
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1811.tr
echo ">>>>>>>>running test 1813"
../source/print_tokens.c.inst.exe  < ../inputs/tst181 > ../newoutputs/t1813
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1812.tr
echo ">>>>>>>>running test 1814"
../source/print_tokens.c.inst.exe  < ../inputs/tst182 > ../newoutputs/t1814
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1813.tr
echo ">>>>>>>>running test 1815"
../source/print_tokens.c.inst.exe  < ../inputs/tst183 > ../newoutputs/t1815
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1814.tr
echo ">>>>>>>>running test 1816"
../source/print_tokens.c.inst.exe  < ../inputs/tst184 > ../newoutputs/t1816
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1815.tr
echo ">>>>>>>>running test 1817"
../source/print_tokens.c.inst.exe  < ../inputs/tst185 > ../newoutputs/t1817
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1816.tr
echo ">>>>>>>>running test 1818"
../source/print_tokens.c.inst.exe  < ../inputs/tst186 > ../newoutputs/t1818
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1817.tr
echo ">>>>>>>>running test 1819"
../source/print_tokens.c.inst.exe  < ../inputs/tst187 > ../newoutputs/t1819
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1818.tr
echo ">>>>>>>>running test 1820"
../source/print_tokens.c.inst.exe  < ../inputs/tst188 > ../newoutputs/t1820
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1819.tr
echo ">>>>>>>>running test 1821"
../source/print_tokens.c.inst.exe  < ../inputs/tst189 > ../newoutputs/t1821
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1820.tr
echo ">>>>>>>>running test 1822"
../source/print_tokens.c.inst.exe  < ../inputs/tst19 > ../newoutputs/t1822
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1821.tr
echo ">>>>>>>>running test 1823"
../source/print_tokens.c.inst.exe  < ../inputs/tst190 > ../newoutputs/t1823
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1822.tr
echo ">>>>>>>>running test 1824"
../source/print_tokens.c.inst.exe  < ../inputs/tst191 > ../newoutputs/t1824
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1823.tr
echo ">>>>>>>>running test 1825"
../source/print_tokens.c.inst.exe  < ../inputs/tst192 > ../newoutputs/t1825
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1824.tr
echo ">>>>>>>>running test 1826"
../source/print_tokens.c.inst.exe  < ../inputs/tst193 > ../newoutputs/t1826
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1825.tr
echo ">>>>>>>>running test 1827"
../source/print_tokens.c.inst.exe  < ../inputs/tst194 > ../newoutputs/t1827
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1826.tr
echo ">>>>>>>>running test 1828"
../source/print_tokens.c.inst.exe  < ../inputs/tst195 > ../newoutputs/t1828
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1827.tr
echo ">>>>>>>>running test 1829"
../source/print_tokens.c.inst.exe  < ../inputs/tst196 > ../newoutputs/t1829
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1828.tr
echo ">>>>>>>>running test 1830"
../source/print_tokens.c.inst.exe  < ../inputs/tst197 > ../newoutputs/t1830
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1829.tr
echo ">>>>>>>>running test 1831"
../source/print_tokens.c.inst.exe  < ../inputs/tst198 > ../newoutputs/t1831
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1830.tr
echo ">>>>>>>>running test 1832"
../source/print_tokens.c.inst.exe  < ../inputs/tst199 > ../newoutputs/t1832
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1831.tr
echo ">>>>>>>>running test 1833"
../source/print_tokens.c.inst.exe  < ../inputs/tst2 > ../newoutputs/t1833
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1832.tr
echo ">>>>>>>>running test 1834"
../source/print_tokens.c.inst.exe  < ../inputs/tst20 > ../newoutputs/t1834
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1833.tr
echo ">>>>>>>>running test 1835"
../source/print_tokens.c.inst.exe  < ../inputs/tst200 > ../newoutputs/t1835
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1834.tr
echo ">>>>>>>>running test 1836"
../source/print_tokens.c.inst.exe  < ../inputs/tst201 > ../newoutputs/t1836
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1835.tr
echo ">>>>>>>>running test 1837"
../source/print_tokens.c.inst.exe  < ../inputs/tst202 > ../newoutputs/t1837
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1836.tr
echo ">>>>>>>>running test 1838"
../source/print_tokens.c.inst.exe  < ../inputs/tst203 > ../newoutputs/t1838
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1837.tr
echo ">>>>>>>>running test 1839"
../source/print_tokens.c.inst.exe  < ../inputs/tst204 > ../newoutputs/t1839
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1838.tr
echo ">>>>>>>>running test 1840"
../source/print_tokens.c.inst.exe  < ../inputs/tst205 > ../newoutputs/t1840
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1839.tr
echo ">>>>>>>>running test 1841"
../source/print_tokens.c.inst.exe  < ../inputs/tst206 > ../newoutputs/t1841
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1840.tr
echo ">>>>>>>>running test 1842"
../source/print_tokens.c.inst.exe  < ../inputs/tst207 > ../newoutputs/t1842
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1841.tr
echo ">>>>>>>>running test 1843"
../source/print_tokens.c.inst.exe  < ../inputs/tst208 > ../newoutputs/t1843
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1842.tr
echo ">>>>>>>>running test 1844"
../source/print_tokens.c.inst.exe  < ../inputs/tst209 > ../newoutputs/t1844
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1843.tr
echo ">>>>>>>>running test 1845"
../source/print_tokens.c.inst.exe  < ../inputs/tst21 > ../newoutputs/t1845
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1844.tr
echo ">>>>>>>>running test 1846"
../source/print_tokens.c.inst.exe  < ../inputs/tst210 > ../newoutputs/t1846
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1845.tr
echo ">>>>>>>>running test 1847"
../source/print_tokens.c.inst.exe  < ../inputs/tst211 > ../newoutputs/t1847
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1846.tr
echo ">>>>>>>>running test 1848"
../source/print_tokens.c.inst.exe  < ../inputs/tst212 > ../newoutputs/t1848
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1847.tr
echo ">>>>>>>>running test 1849"
../source/print_tokens.c.inst.exe  < ../inputs/tst213 > ../newoutputs/t1849
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1848.tr
echo ">>>>>>>>running test 1850"
../source/print_tokens.c.inst.exe  < ../inputs/tst214 > ../newoutputs/t1850
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1849.tr
echo ">>>>>>>>running test 1851"
../source/print_tokens.c.inst.exe  < ../inputs/tst215 > ../newoutputs/t1851
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1850.tr
echo ">>>>>>>>running test 1852"
../source/print_tokens.c.inst.exe  < ../inputs/tst216 > ../newoutputs/t1852
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1851.tr
echo ">>>>>>>>running test 1853"
../source/print_tokens.c.inst.exe  < ../inputs/tst217 > ../newoutputs/t1853
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1852.tr
echo ">>>>>>>>running test 1854"
../source/print_tokens.c.inst.exe  < ../inputs/tst218 > ../newoutputs/t1854
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1853.tr
echo ">>>>>>>>running test 1855"
../source/print_tokens.c.inst.exe  < ../inputs/tst219 > ../newoutputs/t1855
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1854.tr
echo ">>>>>>>>running test 1856"
../source/print_tokens.c.inst.exe  < ../inputs/tst22 > ../newoutputs/t1856
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1855.tr
echo ">>>>>>>>running test 1857"
../source/print_tokens.c.inst.exe  < ../inputs/tst220 > ../newoutputs/t1857
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1856.tr
echo ">>>>>>>>running test 1858"
../source/print_tokens.c.inst.exe  < ../inputs/tst221 > ../newoutputs/t1858
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1857.tr
echo ">>>>>>>>running test 1859"
../source/print_tokens.c.inst.exe  < ../inputs/tst222 > ../newoutputs/t1859
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1858.tr
echo ">>>>>>>>running test 1860"
../source/print_tokens.c.inst.exe  < ../inputs/tst223 > ../newoutputs/t1860
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1859.tr
echo ">>>>>>>>running test 1861"
../source/print_tokens.c.inst.exe  < ../inputs/tst224 > ../newoutputs/t1861
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1860.tr
echo ">>>>>>>>running test 1862"
../source/print_tokens.c.inst.exe  < ../inputs/tst225 > ../newoutputs/t1862
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1861.tr
echo ">>>>>>>>running test 1863"
../source/print_tokens.c.inst.exe  < ../inputs/tst226 > ../newoutputs/t1863
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1862.tr
echo ">>>>>>>>running test 1864"
../source/print_tokens.c.inst.exe  < ../inputs/tst227 > ../newoutputs/t1864
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1863.tr
echo ">>>>>>>>running test 1865"
../source/print_tokens.c.inst.exe  < ../inputs/tst228 > ../newoutputs/t1865
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1864.tr
echo ">>>>>>>>running test 1866"
../source/print_tokens.c.inst.exe  < ../inputs/tst229 > ../newoutputs/t1866
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1865.tr
echo ">>>>>>>>running test 1867"
../source/print_tokens.c.inst.exe  < ../inputs/tst23 > ../newoutputs/t1867
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1866.tr
echo ">>>>>>>>running test 1868"
../source/print_tokens.c.inst.exe  < ../inputs/tst230 > ../newoutputs/t1868
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1867.tr
echo ">>>>>>>>running test 1869"
../source/print_tokens.c.inst.exe  < ../inputs/tst231 > ../newoutputs/t1869
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1868.tr
echo ">>>>>>>>running test 1870"
../source/print_tokens.c.inst.exe  < ../inputs/tst232 > ../newoutputs/t1870
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1869.tr
echo ">>>>>>>>running test 1871"
../source/print_tokens.c.inst.exe  < ../inputs/tst233 > ../newoutputs/t1871
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1870.tr
echo ">>>>>>>>running test 1872"
../source/print_tokens.c.inst.exe  < ../inputs/tst234 > ../newoutputs/t1872
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1871.tr
echo ">>>>>>>>running test 1873"
../source/print_tokens.c.inst.exe  < ../inputs/tst235 > ../newoutputs/t1873
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1872.tr
echo ">>>>>>>>running test 1874"
../source/print_tokens.c.inst.exe  < ../inputs/tst236 > ../newoutputs/t1874
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1873.tr
echo ">>>>>>>>running test 1875"
../source/print_tokens.c.inst.exe  < ../inputs/tst237 > ../newoutputs/t1875
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1874.tr
echo ">>>>>>>>running test 1876"
../source/print_tokens.c.inst.exe  < ../inputs/tst238 > ../newoutputs/t1876
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1875.tr
echo ">>>>>>>>running test 1877"
../source/print_tokens.c.inst.exe  < ../inputs/tst239 > ../newoutputs/t1877
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1876.tr
echo ">>>>>>>>running test 1878"
../source/print_tokens.c.inst.exe  < ../inputs/tst24 > ../newoutputs/t1878
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1877.tr
echo ">>>>>>>>running test 1879"
../source/print_tokens.c.inst.exe  < ../inputs/tst240 > ../newoutputs/t1879
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1878.tr
echo ">>>>>>>>running test 1880"
../source/print_tokens.c.inst.exe  < ../inputs/tst241 > ../newoutputs/t1880
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1879.tr
echo ">>>>>>>>running test 1881"
../source/print_tokens.c.inst.exe  < ../inputs/tst242 > ../newoutputs/t1881
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1880.tr
echo ">>>>>>>>running test 1882"
../source/print_tokens.c.inst.exe  < ../inputs/tst243 > ../newoutputs/t1882
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1881.tr
echo ">>>>>>>>running test 1883"
../source/print_tokens.c.inst.exe  < ../inputs/tst244 > ../newoutputs/t1883
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1882.tr
echo ">>>>>>>>running test 1884"
../source/print_tokens.c.inst.exe  < ../inputs/tst245 > ../newoutputs/t1884
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1883.tr
echo ">>>>>>>>running test 1885"
../source/print_tokens.c.inst.exe  < ../inputs/tst246 > ../newoutputs/t1885
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1884.tr
echo ">>>>>>>>running test 1886"
../source/print_tokens.c.inst.exe  < ../inputs/tst247 > ../newoutputs/t1886
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1885.tr
echo ">>>>>>>>running test 1887"
../source/print_tokens.c.inst.exe  < ../inputs/tst248 > ../newoutputs/t1887
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1886.tr
echo ">>>>>>>>running test 1888"
../source/print_tokens.c.inst.exe  < ../inputs/tst249 > ../newoutputs/t1888
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1887.tr
echo ">>>>>>>>running test 1889"
../source/print_tokens.c.inst.exe  < ../inputs/tst25 > ../newoutputs/t1889
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1888.tr
echo ">>>>>>>>running test 1890"
../source/print_tokens.c.inst.exe  < ../inputs/tst250 > ../newoutputs/t1890
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1889.tr
echo ">>>>>>>>running test 1891"
../source/print_tokens.c.inst.exe  < ../inputs/tst251 > ../newoutputs/t1891
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1890.tr
echo ">>>>>>>>running test 1892"
../source/print_tokens.c.inst.exe  < ../inputs/tst252 > ../newoutputs/t1892
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1891.tr
echo ">>>>>>>>running test 1893"
../source/print_tokens.c.inst.exe  < ../inputs/tst253 > ../newoutputs/t1893
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1892.tr
echo ">>>>>>>>running test 1894"
../source/print_tokens.c.inst.exe  < ../inputs/tst254 > ../newoutputs/t1894
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1893.tr
echo ">>>>>>>>running test 1895"
../source/print_tokens.c.inst.exe  < ../inputs/tst255 > ../newoutputs/t1895
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1894.tr
echo ">>>>>>>>running test 1896"
../source/print_tokens.c.inst.exe  < ../inputs/tst256 > ../newoutputs/t1896
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1895.tr
echo ">>>>>>>>running test 1897"
../source/print_tokens.c.inst.exe  < ../inputs/tst257 > ../newoutputs/t1897
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1896.tr
echo ">>>>>>>>running test 1898"
../source/print_tokens.c.inst.exe  < ../inputs/tst258 > ../newoutputs/t1898
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1897.tr
echo ">>>>>>>>running test 1899"
../source/print_tokens.c.inst.exe  < ../inputs/tst259 > ../newoutputs/t1899
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1898.tr
echo ">>>>>>>>running test 1900"
../source/print_tokens.c.inst.exe  < ../inputs/tst26 > ../newoutputs/t1900
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1899.tr
echo ">>>>>>>>running test 1901"
../source/print_tokens.c.inst.exe  < ../inputs/tst260 > ../newoutputs/t1901
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1900.tr
echo ">>>>>>>>running test 1902"
../source/print_tokens.c.inst.exe  < ../inputs/tst261 > ../newoutputs/t1902
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1901.tr
echo ">>>>>>>>running test 1903"
../source/print_tokens.c.inst.exe  < ../inputs/tst262 > ../newoutputs/t1903
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1902.tr
echo ">>>>>>>>running test 1904"
../source/print_tokens.c.inst.exe  < ../inputs/tst263 > ../newoutputs/t1904
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1903.tr
echo ">>>>>>>>running test 1905"
../source/print_tokens.c.inst.exe  < ../inputs/tst264 > ../newoutputs/t1905
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1904.tr
echo ">>>>>>>>running test 1906"
../source/print_tokens.c.inst.exe  < ../inputs/tst265 > ../newoutputs/t1906
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1905.tr
echo ">>>>>>>>running test 1907"
../source/print_tokens.c.inst.exe  < ../inputs/tst266 > ../newoutputs/t1907
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1906.tr
echo ">>>>>>>>running test 1908"
../source/print_tokens.c.inst.exe  < ../inputs/tst267 > ../newoutputs/t1908
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1907.tr
echo ">>>>>>>>running test 1909"
../source/print_tokens.c.inst.exe  < ../inputs/tst268 > ../newoutputs/t1909
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1908.tr
echo ">>>>>>>>running test 1910"
../source/print_tokens.c.inst.exe  < ../inputs/tst269 > ../newoutputs/t1910
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1909.tr
echo ">>>>>>>>running test 1911"
../source/print_tokens.c.inst.exe  < ../inputs/tst27 > ../newoutputs/t1911
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1910.tr
echo ">>>>>>>>running test 1912"
../source/print_tokens.c.inst.exe  < ../inputs/tst270 > ../newoutputs/t1912
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1911.tr
echo ">>>>>>>>running test 1913"
../source/print_tokens.c.inst.exe  < ../inputs/tst271 > ../newoutputs/t1913
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1912.tr
echo ">>>>>>>>running test 1914"
../source/print_tokens.c.inst.exe  < ../inputs/tst272 > ../newoutputs/t1914
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1913.tr
echo ">>>>>>>>running test 1915"
../source/print_tokens.c.inst.exe  < ../inputs/tst273 > ../newoutputs/t1915
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1914.tr
echo ">>>>>>>>running test 1916"
../source/print_tokens.c.inst.exe  < ../inputs/tst274 > ../newoutputs/t1916
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1915.tr
echo ">>>>>>>>running test 1917"
../source/print_tokens.c.inst.exe  < ../inputs/tst275 > ../newoutputs/t1917
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1916.tr
echo ">>>>>>>>running test 1918"
../source/print_tokens.c.inst.exe  < ../inputs/tst276 > ../newoutputs/t1918
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1917.tr
echo ">>>>>>>>running test 1919"
../source/print_tokens.c.inst.exe  < ../inputs/tst277 > ../newoutputs/t1919
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1918.tr
echo ">>>>>>>>running test 1920"
../source/print_tokens.c.inst.exe  < ../inputs/tst278 > ../newoutputs/t1920
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1919.tr
echo ">>>>>>>>running test 1921"
../source/print_tokens.c.inst.exe  < ../inputs/tst279 > ../newoutputs/t1921
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1920.tr
echo ">>>>>>>>running test 1922"
../source/print_tokens.c.inst.exe  < ../inputs/tst28 > ../newoutputs/t1922
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1921.tr
echo ">>>>>>>>running test 1923"
../source/print_tokens.c.inst.exe  < ../inputs/tst280 > ../newoutputs/t1923
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1922.tr
echo ">>>>>>>>running test 1924"
../source/print_tokens.c.inst.exe  < ../inputs/tst281 > ../newoutputs/t1924
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1923.tr
echo ">>>>>>>>running test 1925"
../source/print_tokens.c.inst.exe  < ../inputs/tst282 > ../newoutputs/t1925
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1924.tr
echo ">>>>>>>>running test 1926"
../source/print_tokens.c.inst.exe  < ../inputs/tst283 > ../newoutputs/t1926
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1925.tr
echo ">>>>>>>>running test 1927"
../source/print_tokens.c.inst.exe  < ../inputs/tst284 > ../newoutputs/t1927
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1926.tr
echo ">>>>>>>>running test 1928"
../source/print_tokens.c.inst.exe  < ../inputs/tst285 > ../newoutputs/t1928
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1927.tr
echo ">>>>>>>>running test 1929"
../source/print_tokens.c.inst.exe  < ../inputs/tst286 > ../newoutputs/t1929
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1928.tr
echo ">>>>>>>>running test 1930"
../source/print_tokens.c.inst.exe  < ../inputs/tst287 > ../newoutputs/t1930
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1929.tr
echo ">>>>>>>>running test 1931"
../source/print_tokens.c.inst.exe  < ../inputs/tst288 > ../newoutputs/t1931
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1930.tr
echo ">>>>>>>>running test 1932"
../source/print_tokens.c.inst.exe  < ../inputs/tst289 > ../newoutputs/t1932
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1931.tr
echo ">>>>>>>>running test 1933"
../source/print_tokens.c.inst.exe  < ../inputs/tst29 > ../newoutputs/t1933
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1932.tr
echo ">>>>>>>>running test 1934"
../source/print_tokens.c.inst.exe  < ../inputs/tst290 > ../newoutputs/t1934
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1933.tr
echo ">>>>>>>>running test 1935"
../source/print_tokens.c.inst.exe  < ../inputs/tst291 > ../newoutputs/t1935
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1934.tr
echo ">>>>>>>>running test 1936"
../source/print_tokens.c.inst.exe  < ../inputs/tst292 > ../newoutputs/t1936
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1935.tr
echo ">>>>>>>>running test 1937"
../source/print_tokens.c.inst.exe  < ../inputs/tst293 > ../newoutputs/t1937
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1936.tr
echo ">>>>>>>>running test 1938"
../source/print_tokens.c.inst.exe  < ../inputs/tst294 > ../newoutputs/t1938
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1937.tr
echo ">>>>>>>>running test 1939"
../source/print_tokens.c.inst.exe  < ../inputs/tst295 > ../newoutputs/t1939
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1938.tr
echo ">>>>>>>>running test 1940"
../source/print_tokens.c.inst.exe  < ../inputs/tst296 > ../newoutputs/t1940
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1939.tr
echo ">>>>>>>>running test 1941"
../source/print_tokens.c.inst.exe  < ../inputs/tst297 > ../newoutputs/t1941
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1940.tr
echo ">>>>>>>>running test 1942"
../source/print_tokens.c.inst.exe  < ../inputs/tst298 > ../newoutputs/t1942
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1941.tr
echo ">>>>>>>>running test 1943"
../source/print_tokens.c.inst.exe  < ../inputs/tst299 > ../newoutputs/t1943
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1942.tr
echo ">>>>>>>>running test 1944"
../source/print_tokens.c.inst.exe  < ../inputs/tst3 > ../newoutputs/t1944
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1943.tr
echo ">>>>>>>>running test 1945"
../source/print_tokens.c.inst.exe  < ../inputs/tst30 > ../newoutputs/t1945
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1944.tr
echo ">>>>>>>>running test 1946"
../source/print_tokens.c.inst.exe  < ../inputs/tst300 > ../newoutputs/t1946
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1945.tr
echo ">>>>>>>>running test 1947"
../source/print_tokens.c.inst.exe  < ../inputs/tst31 > ../newoutputs/t1947
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1946.tr
echo ">>>>>>>>running test 1948"
../source/print_tokens.c.inst.exe  < ../inputs/tst32 > ../newoutputs/t1948
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1947.tr
echo ">>>>>>>>running test 1949"
../source/print_tokens.c.inst.exe  < ../inputs/tst33 > ../newoutputs/t1949
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1948.tr
echo ">>>>>>>>running test 1950"
../source/print_tokens.c.inst.exe  < ../inputs/tst34 > ../newoutputs/t1950
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1949.tr
echo ">>>>>>>>running test 1951"
../source/print_tokens.c.inst.exe  < ../inputs/tst35 > ../newoutputs/t1951
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1950.tr
echo ">>>>>>>>running test 1952"
../source/print_tokens.c.inst.exe  < ../inputs/tst36 > ../newoutputs/t1952
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1951.tr
echo ">>>>>>>>running test 1953"
../source/print_tokens.c.inst.exe  < ../inputs/tst37 > ../newoutputs/t1953
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1952.tr
echo ">>>>>>>>running test 1954"
../source/print_tokens.c.inst.exe  < ../inputs/tst38 > ../newoutputs/t1954
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1953.tr
echo ">>>>>>>>running test 1955"
../source/print_tokens.c.inst.exe  < ../inputs/tst39 > ../newoutputs/t1955
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1954.tr
echo ">>>>>>>>running test 1956"
../source/print_tokens.c.inst.exe  < ../inputs/tst4 > ../newoutputs/t1956
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1955.tr
echo ">>>>>>>>running test 1957"
../source/print_tokens.c.inst.exe  < ../inputs/tst40 > ../newoutputs/t1957
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1956.tr
echo ">>>>>>>>running test 1958"
../source/print_tokens.c.inst.exe  < ../inputs/tst41 > ../newoutputs/t1958
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1957.tr
echo ">>>>>>>>running test 1959"
../source/print_tokens.c.inst.exe  < ../inputs/tst42 > ../newoutputs/t1959
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1958.tr
echo ">>>>>>>>running test 1960"
../source/print_tokens.c.inst.exe  < ../inputs/tst43 > ../newoutputs/t1960
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1959.tr
echo ">>>>>>>>running test 1961"
../source/print_tokens.c.inst.exe  < ../inputs/tst44 > ../newoutputs/t1961
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1960.tr
echo ">>>>>>>>running test 1962"
../source/print_tokens.c.inst.exe  < ../inputs/tst45 > ../newoutputs/t1962
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1961.tr
echo ">>>>>>>>running test 1963"
../source/print_tokens.c.inst.exe  < ../inputs/tst46 > ../newoutputs/t1963
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1962.tr
echo ">>>>>>>>running test 1964"
../source/print_tokens.c.inst.exe  < ../inputs/tst47 > ../newoutputs/t1964
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1963.tr
echo ">>>>>>>>running test 1965"
../source/print_tokens.c.inst.exe  < ../inputs/tst48 > ../newoutputs/t1965
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1964.tr
echo ">>>>>>>>running test 1966"
../source/print_tokens.c.inst.exe  < ../inputs/tst49 > ../newoutputs/t1966
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1965.tr
echo ">>>>>>>>running test 1967"
../source/print_tokens.c.inst.exe  < ../inputs/tst5 > ../newoutputs/t1967
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1966.tr
echo ">>>>>>>>running test 1968"
../source/print_tokens.c.inst.exe  < ../inputs/tst50 > ../newoutputs/t1968
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1967.tr
echo ">>>>>>>>running test 1969"
../source/print_tokens.c.inst.exe  < ../inputs/tst51 > ../newoutputs/t1969
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1968.tr
echo ">>>>>>>>running test 1970"
../source/print_tokens.c.inst.exe  < ../inputs/tst52 > ../newoutputs/t1970
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1969.tr
echo ">>>>>>>>running test 1971"
../source/print_tokens.c.inst.exe  < ../inputs/tst53 > ../newoutputs/t1971
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1970.tr
echo ">>>>>>>>running test 1972"
../source/print_tokens.c.inst.exe  < ../inputs/tst54 > ../newoutputs/t1972
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1971.tr
echo ">>>>>>>>running test 1973"
../source/print_tokens.c.inst.exe  < ../inputs/tst55 > ../newoutputs/t1973
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1972.tr
echo ">>>>>>>>running test 1974"
../source/print_tokens.c.inst.exe  < ../inputs/tst56 > ../newoutputs/t1974
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1973.tr
echo ">>>>>>>>running test 1975"
../source/print_tokens.c.inst.exe  < ../inputs/tst57 > ../newoutputs/t1975
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1974.tr
echo ">>>>>>>>running test 1976"
../source/print_tokens.c.inst.exe  < ../inputs/tst58 > ../newoutputs/t1976
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1975.tr
echo ">>>>>>>>running test 1977"
../source/print_tokens.c.inst.exe  < ../inputs/tst59 > ../newoutputs/t1977
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1976.tr
echo ">>>>>>>>running test 1978"
../source/print_tokens.c.inst.exe  < ../inputs/tst6 > ../newoutputs/t1978
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1977.tr
echo ">>>>>>>>running test 1979"
../source/print_tokens.c.inst.exe  < ../inputs/tst60 > ../newoutputs/t1979
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1978.tr
echo ">>>>>>>>running test 1980"
../source/print_tokens.c.inst.exe  < ../inputs/tst61 > ../newoutputs/t1980
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1979.tr
echo ">>>>>>>>running test 1981"
../source/print_tokens.c.inst.exe  < ../inputs/tst62 > ../newoutputs/t1981
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1980.tr
echo ">>>>>>>>running test 1982"
../source/print_tokens.c.inst.exe  < ../inputs/tst63 > ../newoutputs/t1982
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1981.tr
echo ">>>>>>>>running test 1983"
../source/print_tokens.c.inst.exe  < ../inputs/tst64 > ../newoutputs/t1983
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1982.tr
echo ">>>>>>>>running test 1984"
../source/print_tokens.c.inst.exe  < ../inputs/tst65 > ../newoutputs/t1984
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1983.tr
echo ">>>>>>>>running test 1985"
../source/print_tokens.c.inst.exe  < ../inputs/tst66 > ../newoutputs/t1985
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1984.tr
echo ">>>>>>>>running test 1986"
../source/print_tokens.c.inst.exe  < ../inputs/tst67 > ../newoutputs/t1986
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1985.tr
echo ">>>>>>>>running test 1987"
../source/print_tokens.c.inst.exe  < ../inputs/tst68 > ../newoutputs/t1987
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1986.tr
echo ">>>>>>>>running test 1988"
../source/print_tokens.c.inst.exe  < ../inputs/tst69 > ../newoutputs/t1988
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1987.tr
echo ">>>>>>>>running test 1989"
../source/print_tokens.c.inst.exe  < ../inputs/tst7 > ../newoutputs/t1989
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1988.tr
echo ">>>>>>>>running test 1990"
../source/print_tokens.c.inst.exe  < ../inputs/tst70 > ../newoutputs/t1990
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1989.tr
echo ">>>>>>>>running test 1991"
../source/print_tokens.c.inst.exe  < ../inputs/tst71 > ../newoutputs/t1991
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1990.tr
echo ">>>>>>>>running test 1992"
../source/print_tokens.c.inst.exe  < ../inputs/tst72 > ../newoutputs/t1992
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1991.tr
echo ">>>>>>>>running test 1993"
../source/print_tokens.c.inst.exe  < ../inputs/tst73 > ../newoutputs/t1993
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1992.tr
echo ">>>>>>>>running test 1994"
../source/print_tokens.c.inst.exe  < ../inputs/tst74 > ../newoutputs/t1994
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1993.tr
echo ">>>>>>>>running test 1995"
../source/print_tokens.c.inst.exe  < ../inputs/tst75 > ../newoutputs/t1995
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1994.tr
echo ">>>>>>>>running test 1996"
../source/print_tokens.c.inst.exe  < ../inputs/tst76 > ../newoutputs/t1996
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1995.tr
echo ">>>>>>>>running test 1997"
../source/print_tokens.c.inst.exe  < ../inputs/tst77 > ../newoutputs/t1997
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1996.tr
echo ">>>>>>>>running test 1998"
../source/print_tokens.c.inst.exe  < ../inputs/tst78 > ../newoutputs/t1998
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1997.tr
echo ">>>>>>>>running test 1999"
../source/print_tokens.c.inst.exe  < ../inputs/tst79 > ../newoutputs/t1999
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1998.tr
echo ">>>>>>>>running test 2000"
../source/print_tokens.c.inst.exe  < ../inputs/tst8 > ../newoutputs/t2000
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/1999.tr
echo ">>>>>>>>running test 2001"
../source/print_tokens.c.inst.exe  < ../inputs/tst80 > ../newoutputs/t2001
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2000.tr
echo ">>>>>>>>running test 2002"
../source/print_tokens.c.inst.exe  < ../inputs/tst81 > ../newoutputs/t2002
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2001.tr
echo ">>>>>>>>running test 2003"
../source/print_tokens.c.inst.exe  < ../inputs/tst82 > ../newoutputs/t2003
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2002.tr
echo ">>>>>>>>running test 2004"
../source/print_tokens.c.inst.exe  < ../inputs/tst83 > ../newoutputs/t2004
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2003.tr
echo ">>>>>>>>running test 2005"
../source/print_tokens.c.inst.exe  < ../inputs/tst84 > ../newoutputs/t2005
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2004.tr
echo ">>>>>>>>running test 2006"
../source/print_tokens.c.inst.exe  < ../inputs/tst85 > ../newoutputs/t2006
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2005.tr
echo ">>>>>>>>running test 2007"
../source/print_tokens.c.inst.exe  < ../inputs/tst86 > ../newoutputs/t2007
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2006.tr
echo ">>>>>>>>running test 2008"
../source/print_tokens.c.inst.exe  < ../inputs/tst87 > ../newoutputs/t2008
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2007.tr
echo ">>>>>>>>running test 2009"
../source/print_tokens.c.inst.exe  < ../inputs/tst88 > ../newoutputs/t2009
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2008.tr
echo ">>>>>>>>running test 2010"
../source/print_tokens.c.inst.exe  < ../inputs/tst89 > ../newoutputs/t2010
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2009.tr
echo ">>>>>>>>running test 2011"
../source/print_tokens.c.inst.exe  < ../inputs/tst9 > ../newoutputs/t2011
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2010.tr
echo ">>>>>>>>running test 2012"
../source/print_tokens.c.inst.exe  < ../inputs/tst90 > ../newoutputs/t2012
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2011.tr
echo ">>>>>>>>running test 2013"
../source/print_tokens.c.inst.exe  < ../inputs/tst91 > ../newoutputs/t2013
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2012.tr
echo ">>>>>>>>running test 2014"
../source/print_tokens.c.inst.exe  < ../inputs/tst92 > ../newoutputs/t2014
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2013.tr
echo ">>>>>>>>running test 2015"
../source/print_tokens.c.inst.exe  < ../inputs/tst93 > ../newoutputs/t2015
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2014.tr
echo ">>>>>>>>running test 2016"
../source/print_tokens.c.inst.exe  < ../inputs/tst94 > ../newoutputs/t2016
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2015.tr
echo ">>>>>>>>running test 2017"
../source/print_tokens.c.inst.exe  < ../inputs/tst95 > ../newoutputs/t2017
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2016.tr
echo ">>>>>>>>running test 2018"
../source/print_tokens.c.inst.exe  < ../inputs/tst96 > ../newoutputs/t2018
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2017.tr
echo ">>>>>>>>running test 2019"
../source/print_tokens.c.inst.exe  < ../inputs/tst97 > ../newoutputs/t2019
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2018.tr
echo ">>>>>>>>running test 2020"
../source/print_tokens.c.inst.exe  < ../inputs/tst98 > ../newoutputs/t2020
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2019.tr
echo ">>>>>>>>running test 2021"
../source/print_tokens.c.inst.exe  < ../inputs/tst99 > ../newoutputs/t2021
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2020.tr
echo ">>>>>>>>running test 2022"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.100 > ../newoutputs/t2022
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2021.tr
echo ">>>>>>>>running test 2023"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1002 > ../newoutputs/t2023
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2022.tr
echo ">>>>>>>>running test 2024"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1006 > ../newoutputs/t2024
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2023.tr
echo ">>>>>>>>running test 2025"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1007 > ../newoutputs/t2025
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2024.tr
echo ">>>>>>>>running test 2026"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.101 > ../newoutputs/t2026
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2025.tr
echo ">>>>>>>>running test 2027"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1011 > ../newoutputs/t2027
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2026.tr
echo ">>>>>>>>running test 2028"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1012 > ../newoutputs/t2028
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2027.tr
echo ">>>>>>>>running test 2029"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1013 > ../newoutputs/t2029
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2028.tr
echo ">>>>>>>>running test 2030"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1016 > ../newoutputs/t2030
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2029.tr
echo ">>>>>>>>running test 2031"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1017 > ../newoutputs/t2031
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2030.tr
echo ">>>>>>>>running test 2032"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1019 > ../newoutputs/t2032
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2031.tr
echo ">>>>>>>>running test 2033"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.102 > ../newoutputs/t2033
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2032.tr
echo ">>>>>>>>running test 2034"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1021 > ../newoutputs/t2034
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2033.tr
echo ">>>>>>>>running test 2035"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1022 > ../newoutputs/t2035
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2034.tr
echo ">>>>>>>>running test 2036"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1023 > ../newoutputs/t2036
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2035.tr
echo ">>>>>>>>running test 2037"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1026 > ../newoutputs/t2037
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2036.tr
echo ">>>>>>>>running test 2038"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1027 > ../newoutputs/t2038
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2037.tr
echo ">>>>>>>>running test 2039"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1028 > ../newoutputs/t2039
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2038.tr
echo ">>>>>>>>running test 2040"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1029 > ../newoutputs/t2040
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2039.tr
echo ">>>>>>>>running test 2041"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.103 > ../newoutputs/t2041
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2040.tr
echo ">>>>>>>>running test 2042"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1033 > ../newoutputs/t2042
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2041.tr
echo ">>>>>>>>running test 2043"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1037 > ../newoutputs/t2043
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2042.tr
echo ">>>>>>>>running test 2044"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.104 > ../newoutputs/t2044
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2043.tr
echo ">>>>>>>>running test 2045"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1041 > ../newoutputs/t2045
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2044.tr
echo ">>>>>>>>running test 2046"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1044 > ../newoutputs/t2046
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2045.tr
echo ">>>>>>>>running test 2047"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1051 > ../newoutputs/t2047
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2046.tr
echo ">>>>>>>>running test 2048"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1052 > ../newoutputs/t2048
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2047.tr
echo ">>>>>>>>running test 2049"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1053 > ../newoutputs/t2049
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2048.tr
echo ">>>>>>>>running test 2050"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1056 > ../newoutputs/t2050
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2049.tr
echo ">>>>>>>>running test 2051"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1058 > ../newoutputs/t2051
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2050.tr
echo ">>>>>>>>running test 2052"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1062 > ../newoutputs/t2052
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2051.tr
echo ">>>>>>>>running test 2053"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1063 > ../newoutputs/t2053
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2052.tr
echo ">>>>>>>>running test 2054"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1064 > ../newoutputs/t2054
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2053.tr
echo ">>>>>>>>running test 2055"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1066 > ../newoutputs/t2055
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2054.tr
echo ">>>>>>>>running test 2056"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1070 > ../newoutputs/t2056
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2055.tr
echo ">>>>>>>>running test 2057"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1072 > ../newoutputs/t2057
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2056.tr
echo ">>>>>>>>running test 2058"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1073 > ../newoutputs/t2058
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2057.tr
echo ">>>>>>>>running test 2059"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1079 > ../newoutputs/t2059
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2058.tr
echo ">>>>>>>>running test 2060"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.108 > ../newoutputs/t2060
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2059.tr
echo ">>>>>>>>running test 2061"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1081 > ../newoutputs/t2061
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2060.tr
echo ">>>>>>>>running test 2062"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1083 > ../newoutputs/t2062
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2061.tr
echo ">>>>>>>>running test 2063"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1086 > ../newoutputs/t2063
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2062.tr
echo ">>>>>>>>running test 2064"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1087 > ../newoutputs/t2064
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2063.tr
echo ">>>>>>>>running test 2065"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1088 > ../newoutputs/t2065
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2064.tr
echo ">>>>>>>>running test 2066"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1089 > ../newoutputs/t2066
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2065.tr
echo ">>>>>>>>running test 2067"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1090 > ../newoutputs/t2067
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2066.tr
echo ">>>>>>>>running test 2068"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1097 > ../newoutputs/t2068
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2067.tr
echo ">>>>>>>>running test 2069"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1098 > ../newoutputs/t2069
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2068.tr
echo ">>>>>>>>running test 2070"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1099 > ../newoutputs/t2070
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2069.tr
echo ">>>>>>>>running test 2071"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.11 > ../newoutputs/t2071
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2070.tr
echo ">>>>>>>>running test 2072"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.110 > ../newoutputs/t2072
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2071.tr
echo ">>>>>>>>running test 2073"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1100 > ../newoutputs/t2073
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2072.tr
echo ">>>>>>>>running test 2074"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1102 > ../newoutputs/t2074
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2073.tr
echo ">>>>>>>>running test 2075"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1104 > ../newoutputs/t2075
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2074.tr
echo ">>>>>>>>running test 2076"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1106 > ../newoutputs/t2076
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2075.tr
echo ">>>>>>>>running test 2077"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1107 > ../newoutputs/t2077
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2076.tr
echo ">>>>>>>>running test 2078"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1108 > ../newoutputs/t2078
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2077.tr
echo ">>>>>>>>running test 2079"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1111 > ../newoutputs/t2079
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2078.tr
echo ">>>>>>>>running test 2080"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1116 > ../newoutputs/t2080
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2079.tr
echo ">>>>>>>>running test 2081"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1117 > ../newoutputs/t2081
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2080.tr
echo ">>>>>>>>running test 2082"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1118 > ../newoutputs/t2082
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2081.tr
echo ">>>>>>>>running test 2083"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.112 > ../newoutputs/t2083
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2082.tr
echo ">>>>>>>>running test 2084"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1122 > ../newoutputs/t2084
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2083.tr
echo ">>>>>>>>running test 2085"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1123 > ../newoutputs/t2085
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2084.tr
echo ">>>>>>>>running test 2086"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1128 > ../newoutputs/t2086
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2085.tr
echo ">>>>>>>>running test 2087"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1129 > ../newoutputs/t2087
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2086.tr
echo ">>>>>>>>running test 2088"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.113 > ../newoutputs/t2088
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2087.tr
echo ">>>>>>>>running test 2089"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1131 > ../newoutputs/t2089
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2088.tr
echo ">>>>>>>>running test 2090"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1132 > ../newoutputs/t2090
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2089.tr
echo ">>>>>>>>running test 2091"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1133 > ../newoutputs/t2091
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2090.tr
echo ">>>>>>>>running test 2092"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1134 > ../newoutputs/t2092
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2091.tr
echo ">>>>>>>>running test 2093"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1135 > ../newoutputs/t2093
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2092.tr
echo ">>>>>>>>running test 2094"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1136 > ../newoutputs/t2094
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2093.tr
echo ">>>>>>>>running test 2095"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1137 > ../newoutputs/t2095
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2094.tr
echo ">>>>>>>>running test 2096"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1138 > ../newoutputs/t2096
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2095.tr
echo ">>>>>>>>running test 2097"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1143 > ../newoutputs/t2097
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2096.tr
echo ">>>>>>>>running test 2098"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1145 > ../newoutputs/t2098
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2097.tr
echo ">>>>>>>>running test 2099"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1146 > ../newoutputs/t2099
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2098.tr
echo ">>>>>>>>running test 2100"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1147 > ../newoutputs/t2100
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2099.tr
echo ">>>>>>>>running test 2101"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1148 > ../newoutputs/t2101
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2100.tr
echo ">>>>>>>>running test 2102"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1149 > ../newoutputs/t2102
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2101.tr
echo ">>>>>>>>running test 2103"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1150 > ../newoutputs/t2103
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2102.tr
echo ">>>>>>>>running test 2104"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1151 > ../newoutputs/t2104
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2103.tr
echo ">>>>>>>>running test 2105"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1152 > ../newoutputs/t2105
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2104.tr
echo ">>>>>>>>running test 2106"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1153 > ../newoutputs/t2106
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2105.tr
echo ">>>>>>>>running test 2107"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1154 > ../newoutputs/t2107
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2106.tr
echo ">>>>>>>>running test 2108"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1157 > ../newoutputs/t2108
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2107.tr
echo ">>>>>>>>running test 2109"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1158 > ../newoutputs/t2109
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2108.tr
echo ">>>>>>>>running test 2110"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.116 > ../newoutputs/t2110
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2109.tr
echo ">>>>>>>>running test 2111"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1161 > ../newoutputs/t2111
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2110.tr
echo ">>>>>>>>running test 2112"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1164 > ../newoutputs/t2112
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2111.tr
echo ">>>>>>>>running test 2113"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1168 > ../newoutputs/t2113
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2112.tr
echo ">>>>>>>>running test 2114"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1169 > ../newoutputs/t2114
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2113.tr
echo ">>>>>>>>running test 2115"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1170 > ../newoutputs/t2115
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2114.tr
echo ">>>>>>>>running test 2116"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1171 > ../newoutputs/t2116
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2115.tr
echo ">>>>>>>>running test 2117"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1172 > ../newoutputs/t2117
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2116.tr
echo ">>>>>>>>running test 2118"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1175 > ../newoutputs/t2118
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2117.tr
echo ">>>>>>>>running test 2119"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1176 > ../newoutputs/t2119
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2118.tr
echo ">>>>>>>>running test 2120"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1177 > ../newoutputs/t2120
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2119.tr
echo ">>>>>>>>running test 2121"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1178 > ../newoutputs/t2121
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2120.tr
echo ">>>>>>>>running test 2122"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.118 > ../newoutputs/t2122
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2121.tr
echo ">>>>>>>>running test 2123"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1181 > ../newoutputs/t2123
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2122.tr
echo ">>>>>>>>running test 2124"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1183 > ../newoutputs/t2124
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2123.tr
echo ">>>>>>>>running test 2125"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1188 > ../newoutputs/t2125
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2124.tr
echo ">>>>>>>>running test 2126"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1190 > ../newoutputs/t2126
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2125.tr
echo ">>>>>>>>running test 2127"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1194 > ../newoutputs/t2127
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2126.tr
echo ">>>>>>>>running test 2128"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1195 > ../newoutputs/t2128
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2127.tr
echo ">>>>>>>>running test 2129"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1197 > ../newoutputs/t2129
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2128.tr
echo ">>>>>>>>running test 2130"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1199 > ../newoutputs/t2130
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2129.tr
echo ">>>>>>>>running test 2131"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.12 > ../newoutputs/t2131
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2130.tr
echo ">>>>>>>>running test 2132"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.120 > ../newoutputs/t2132
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2131.tr
echo ">>>>>>>>running test 2133"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1201 > ../newoutputs/t2133
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2132.tr
echo ">>>>>>>>running test 2134"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1203 > ../newoutputs/t2134
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2133.tr
echo ">>>>>>>>running test 2135"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1204 > ../newoutputs/t2135
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2134.tr
echo ">>>>>>>>running test 2136"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1205 > ../newoutputs/t2136
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2135.tr
echo ">>>>>>>>running test 2137"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1208 > ../newoutputs/t2137
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2136.tr
echo ">>>>>>>>running test 2138"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1210 > ../newoutputs/t2138
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2137.tr
echo ">>>>>>>>running test 2139"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1211 > ../newoutputs/t2139
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2138.tr
echo ">>>>>>>>running test 2140"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1213 > ../newoutputs/t2140
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2139.tr
echo ">>>>>>>>running test 2141"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1214 > ../newoutputs/t2141
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2140.tr
echo ">>>>>>>>running test 2142"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1215 > ../newoutputs/t2142
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2141.tr
echo ">>>>>>>>running test 2143"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1216 > ../newoutputs/t2143
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2142.tr
echo ">>>>>>>>running test 2144"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1218 > ../newoutputs/t2144
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2143.tr
echo ">>>>>>>>running test 2145"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.122 > ../newoutputs/t2145
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2144.tr
echo ">>>>>>>>running test 2146"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1220 > ../newoutputs/t2146
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2145.tr
echo ">>>>>>>>running test 2147"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1221 > ../newoutputs/t2147
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2146.tr
echo ">>>>>>>>running test 2148"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1222 > ../newoutputs/t2148
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2147.tr
echo ">>>>>>>>running test 2149"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1225 > ../newoutputs/t2149
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2148.tr
echo ">>>>>>>>running test 2150"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1227 > ../newoutputs/t2150
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2149.tr
echo ">>>>>>>>running test 2151"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1229 > ../newoutputs/t2151
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2150.tr
echo ">>>>>>>>running test 2152"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.123 > ../newoutputs/t2152
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2151.tr
echo ">>>>>>>>running test 2153"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1230 > ../newoutputs/t2153
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2152.tr
echo ">>>>>>>>running test 2154"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1231 > ../newoutputs/t2154
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2153.tr
echo ">>>>>>>>running test 2155"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1232 > ../newoutputs/t2155
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2154.tr
echo ">>>>>>>>running test 2156"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1236 > ../newoutputs/t2156
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2155.tr
echo ">>>>>>>>running test 2157"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1238 > ../newoutputs/t2157
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2156.tr
echo ">>>>>>>>running test 2158"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.124 > ../newoutputs/t2158
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2157.tr
echo ">>>>>>>>running test 2159"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1240 > ../newoutputs/t2159
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2158.tr
echo ">>>>>>>>running test 2160"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1242 > ../newoutputs/t2160
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2159.tr
echo ">>>>>>>>running test 2161"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1244 > ../newoutputs/t2161
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2160.tr
echo ">>>>>>>>running test 2162"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1247 > ../newoutputs/t2162
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2161.tr
echo ">>>>>>>>running test 2163"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1248 > ../newoutputs/t2163
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2162.tr
echo ">>>>>>>>running test 2164"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1251 > ../newoutputs/t2164
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2163.tr
echo ">>>>>>>>running test 2165"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1254 > ../newoutputs/t2165
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2164.tr
echo ">>>>>>>>running test 2166"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1257 > ../newoutputs/t2166
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2165.tr
echo ">>>>>>>>running test 2167"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1259 > ../newoutputs/t2167
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2166.tr
echo ">>>>>>>>running test 2168"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1261 > ../newoutputs/t2168
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2167.tr
echo ">>>>>>>>running test 2169"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1262 > ../newoutputs/t2169
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2168.tr
echo ">>>>>>>>running test 2170"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1263 > ../newoutputs/t2170
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2169.tr
echo ">>>>>>>>running test 2171"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1269 > ../newoutputs/t2171
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2170.tr
echo ">>>>>>>>running test 2172"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1271 > ../newoutputs/t2172
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2171.tr
echo ">>>>>>>>running test 2173"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1273 > ../newoutputs/t2173
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2172.tr
echo ">>>>>>>>running test 2174"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1274 > ../newoutputs/t2174
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2173.tr
echo ">>>>>>>>running test 2175"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1275 > ../newoutputs/t2175
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2174.tr
echo ">>>>>>>>running test 2176"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1277 > ../newoutputs/t2176
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2175.tr
echo ">>>>>>>>running test 2177"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1279 > ../newoutputs/t2177
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2176.tr
echo ">>>>>>>>running test 2178"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1280 > ../newoutputs/t2178
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2177.tr
echo ">>>>>>>>running test 2179"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1282 > ../newoutputs/t2179
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2178.tr
echo ">>>>>>>>running test 2180"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1284 > ../newoutputs/t2180
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2179.tr
echo ">>>>>>>>running test 2181"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1285 > ../newoutputs/t2181
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2180.tr
echo ">>>>>>>>running test 2182"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1286 > ../newoutputs/t2182
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2181.tr
echo ">>>>>>>>running test 2183"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1288 > ../newoutputs/t2183
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2182.tr
echo ">>>>>>>>running test 2184"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1293 > ../newoutputs/t2184
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2183.tr
echo ">>>>>>>>running test 2185"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1295 > ../newoutputs/t2185
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2184.tr
echo ">>>>>>>>running test 2186"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1296 > ../newoutputs/t2186
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2185.tr
echo ">>>>>>>>running test 2187"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1297 > ../newoutputs/t2187
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2186.tr
echo ">>>>>>>>running test 2188"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1299 > ../newoutputs/t2188
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2187.tr
echo ">>>>>>>>running test 2189"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.13 > ../newoutputs/t2189
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2188.tr
echo ">>>>>>>>running test 2190"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.130 > ../newoutputs/t2190
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2189.tr
echo ">>>>>>>>running test 2191"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1300 > ../newoutputs/t2191
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2190.tr
echo ">>>>>>>>running test 2192"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1301 > ../newoutputs/t2192
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2191.tr
echo ">>>>>>>>running test 2193"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1304 > ../newoutputs/t2193
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2192.tr
echo ">>>>>>>>running test 2194"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1307 > ../newoutputs/t2194
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2193.tr
echo ">>>>>>>>running test 2195"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1308 > ../newoutputs/t2195
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2194.tr
echo ">>>>>>>>running test 2196"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1309 > ../newoutputs/t2196
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2195.tr
echo ">>>>>>>>running test 2197"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1310 > ../newoutputs/t2197
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2196.tr
echo ">>>>>>>>running test 2198"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1311 > ../newoutputs/t2198
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2197.tr
echo ">>>>>>>>running test 2199"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1312 > ../newoutputs/t2199
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2198.tr
echo ">>>>>>>>running test 2200"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1313 > ../newoutputs/t2200
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2199.tr
echo ">>>>>>>>running test 2201"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1314 > ../newoutputs/t2201
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2200.tr
echo ">>>>>>>>running test 2202"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1315 > ../newoutputs/t2202
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2201.tr
echo ">>>>>>>>running test 2203"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1318 > ../newoutputs/t2203
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2202.tr
echo ">>>>>>>>running test 2204"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1319 > ../newoutputs/t2204
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2203.tr
echo ">>>>>>>>running test 2205"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1320 > ../newoutputs/t2205
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2204.tr
echo ">>>>>>>>running test 2206"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1323 > ../newoutputs/t2206
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2205.tr
echo ">>>>>>>>running test 2207"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1326 > ../newoutputs/t2207
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2206.tr
echo ">>>>>>>>running test 2208"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1329 > ../newoutputs/t2208
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2207.tr
echo ">>>>>>>>running test 2209"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.133 > ../newoutputs/t2209
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2208.tr
echo ">>>>>>>>running test 2210"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1331 > ../newoutputs/t2210
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2209.tr
echo ">>>>>>>>running test 2211"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1332 > ../newoutputs/t2211
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2210.tr
echo ">>>>>>>>running test 2212"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1336 > ../newoutputs/t2212
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2211.tr
echo ">>>>>>>>running test 2213"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1338 > ../newoutputs/t2213
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2212.tr
echo ">>>>>>>>running test 2214"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1343 > ../newoutputs/t2214
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2213.tr
echo ">>>>>>>>running test 2215"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1344 > ../newoutputs/t2215
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2214.tr
echo ">>>>>>>>running test 2216"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1345 > ../newoutputs/t2216
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2215.tr
echo ">>>>>>>>running test 2217"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1347 > ../newoutputs/t2217
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2216.tr
echo ">>>>>>>>running test 2218"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1349 > ../newoutputs/t2218
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2217.tr
echo ">>>>>>>>running test 2219"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.135 > ../newoutputs/t2219
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2218.tr
echo ">>>>>>>>running test 2220"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1350 > ../newoutputs/t2220
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2219.tr
echo ">>>>>>>>running test 2221"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1351 > ../newoutputs/t2221
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2220.tr
echo ">>>>>>>>running test 2222"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1355 > ../newoutputs/t2222
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2221.tr
echo ">>>>>>>>running test 2223"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1356 > ../newoutputs/t2223
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2222.tr
echo ">>>>>>>>running test 2224"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1357 > ../newoutputs/t2224
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2223.tr
echo ">>>>>>>>running test 2225"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.136 > ../newoutputs/t2225
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2224.tr
echo ">>>>>>>>running test 2226"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1360 > ../newoutputs/t2226
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2225.tr
echo ">>>>>>>>running test 2227"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1361 > ../newoutputs/t2227
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2226.tr
echo ">>>>>>>>running test 2228"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1362 > ../newoutputs/t2228
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2227.tr
echo ">>>>>>>>running test 2229"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1363 > ../newoutputs/t2229
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2228.tr
echo ">>>>>>>>running test 2230"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1366 > ../newoutputs/t2230
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2229.tr
echo ">>>>>>>>running test 2231"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1367 > ../newoutputs/t2231
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2230.tr
echo ">>>>>>>>running test 2232"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1369 > ../newoutputs/t2232
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2231.tr
echo ">>>>>>>>running test 2233"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1372 > ../newoutputs/t2233
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2232.tr
echo ">>>>>>>>running test 2234"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1377 > ../newoutputs/t2234
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2233.tr
echo ">>>>>>>>running test 2235"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1381 > ../newoutputs/t2235
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2234.tr
echo ">>>>>>>>running test 2236"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1382 > ../newoutputs/t2236
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2235.tr
echo ">>>>>>>>running test 2237"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1383 > ../newoutputs/t2237
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2236.tr
echo ">>>>>>>>running test 2238"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1387 > ../newoutputs/t2238
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2237.tr
echo ">>>>>>>>running test 2239"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1388 > ../newoutputs/t2239
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2238.tr
echo ">>>>>>>>running test 2240"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1392 > ../newoutputs/t2240
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2239.tr
echo ">>>>>>>>running test 2241"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1393 > ../newoutputs/t2241
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2240.tr
echo ">>>>>>>>running test 2242"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1396 > ../newoutputs/t2242
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2241.tr
echo ">>>>>>>>running test 2243"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1397 > ../newoutputs/t2243
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2242.tr
echo ">>>>>>>>running test 2244"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.140 > ../newoutputs/t2244
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2243.tr
echo ">>>>>>>>running test 2245"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1404 > ../newoutputs/t2245
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2244.tr
echo ">>>>>>>>running test 2246"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1405 > ../newoutputs/t2246
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2245.tr
echo ">>>>>>>>running test 2247"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1408 > ../newoutputs/t2247
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2246.tr
echo ">>>>>>>>running test 2248"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1409 > ../newoutputs/t2248
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2247.tr
echo ">>>>>>>>running test 2249"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1410 > ../newoutputs/t2249
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2248.tr
echo ">>>>>>>>running test 2250"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1413 > ../newoutputs/t2250
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2249.tr
echo ">>>>>>>>running test 2251"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1415 > ../newoutputs/t2251
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2250.tr
echo ">>>>>>>>running test 2252"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.142 > ../newoutputs/t2252
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2251.tr
echo ">>>>>>>>running test 2253"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1420 > ../newoutputs/t2253
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2252.tr
echo ">>>>>>>>running test 2254"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1421 > ../newoutputs/t2254
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2253.tr
echo ">>>>>>>>running test 2255"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1424 > ../newoutputs/t2255
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2254.tr
echo ">>>>>>>>running test 2256"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1425 > ../newoutputs/t2256
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2255.tr
echo ">>>>>>>>running test 2257"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1429 > ../newoutputs/t2257
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2256.tr
echo ">>>>>>>>running test 2258"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.143 > ../newoutputs/t2258
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2257.tr
echo ">>>>>>>>running test 2259"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1430 > ../newoutputs/t2259
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2258.tr
echo ">>>>>>>>running test 2260"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1437 > ../newoutputs/t2260
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2259.tr
echo ">>>>>>>>running test 2261"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1438 > ../newoutputs/t2261
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2260.tr
echo ">>>>>>>>running test 2262"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1439 > ../newoutputs/t2262
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2261.tr
echo ">>>>>>>>running test 2263"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1441 > ../newoutputs/t2263
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2262.tr
echo ">>>>>>>>running test 2264"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1443 > ../newoutputs/t2264
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2263.tr
echo ">>>>>>>>running test 2265"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.145 > ../newoutputs/t2265
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2264.tr
echo ">>>>>>>>running test 2266"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1455 > ../newoutputs/t2266
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2265.tr
echo ">>>>>>>>running test 2267"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1457 > ../newoutputs/t2267
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2266.tr
echo ">>>>>>>>running test 2268"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1459 > ../newoutputs/t2268
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2267.tr
echo ">>>>>>>>running test 2269"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1461 > ../newoutputs/t2269
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2268.tr
echo ">>>>>>>>running test 2270"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1468 > ../newoutputs/t2270
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2269.tr
echo ">>>>>>>>running test 2271"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1469 > ../newoutputs/t2271
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2270.tr
echo ">>>>>>>>running test 2272"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.147 > ../newoutputs/t2272
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2271.tr
echo ">>>>>>>>running test 2273"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1470 > ../newoutputs/t2273
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2272.tr
echo ">>>>>>>>running test 2274"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1475 > ../newoutputs/t2274
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2273.tr
echo ">>>>>>>>running test 2275"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1476 > ../newoutputs/t2275
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2274.tr
echo ">>>>>>>>running test 2276"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1480 > ../newoutputs/t2276
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2275.tr
echo ">>>>>>>>running test 2277"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1483 > ../newoutputs/t2277
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2276.tr
echo ">>>>>>>>running test 2278"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1486 > ../newoutputs/t2278
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2277.tr
echo ">>>>>>>>running test 2279"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1491 > ../newoutputs/t2279
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2278.tr
echo ">>>>>>>>running test 2280"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1492 > ../newoutputs/t2280
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2279.tr
echo ">>>>>>>>running test 2281"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1493 > ../newoutputs/t2281
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2280.tr
echo ">>>>>>>>running test 2282"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1494 > ../newoutputs/t2282
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2281.tr
echo ">>>>>>>>running test 2283"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1496 > ../newoutputs/t2283
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2282.tr
echo ">>>>>>>>running test 2284"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1497 > ../newoutputs/t2284
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2283.tr
echo ">>>>>>>>running test 2285"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.15 > ../newoutputs/t2285
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2284.tr
echo ">>>>>>>>running test 2286"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1501 > ../newoutputs/t2286
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2285.tr
echo ">>>>>>>>running test 2287"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1502 > ../newoutputs/t2287
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2286.tr
echo ">>>>>>>>running test 2288"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1504 > ../newoutputs/t2288
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2287.tr
echo ">>>>>>>>running test 2289"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1509 > ../newoutputs/t2289
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2288.tr
echo ">>>>>>>>running test 2290"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.151 > ../newoutputs/t2290
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2289.tr
echo ">>>>>>>>running test 2291"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1510 > ../newoutputs/t2291
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2290.tr
echo ">>>>>>>>running test 2292"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1516 > ../newoutputs/t2292
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2291.tr
echo ">>>>>>>>running test 2293"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1517 > ../newoutputs/t2293
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2292.tr
echo ">>>>>>>>running test 2294"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1518 > ../newoutputs/t2294
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2293.tr
echo ">>>>>>>>running test 2295"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1519 > ../newoutputs/t2295
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2294.tr
echo ">>>>>>>>running test 2296"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1524 > ../newoutputs/t2296
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2295.tr
echo ">>>>>>>>running test 2297"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1525 > ../newoutputs/t2297
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2296.tr
echo ">>>>>>>>running test 2298"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1526 > ../newoutputs/t2298
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2297.tr
echo ">>>>>>>>running test 2299"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1527 > ../newoutputs/t2299
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2298.tr
echo ">>>>>>>>running test 2300"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1529 > ../newoutputs/t2300
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2299.tr
echo ">>>>>>>>running test 2301"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.153 > ../newoutputs/t2301
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2300.tr
echo ">>>>>>>>running test 2302"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1530 > ../newoutputs/t2302
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2301.tr
echo ">>>>>>>>running test 2303"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1532 > ../newoutputs/t2303
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2302.tr
echo ">>>>>>>>running test 2304"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1534 > ../newoutputs/t2304
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2303.tr
echo ">>>>>>>>running test 2305"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1538 > ../newoutputs/t2305
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2304.tr
echo ">>>>>>>>running test 2306"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1539 > ../newoutputs/t2306
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2305.tr
echo ">>>>>>>>running test 2307"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.154 > ../newoutputs/t2307
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2306.tr
echo ">>>>>>>>running test 2308"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1541 > ../newoutputs/t2308
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2307.tr
echo ">>>>>>>>running test 2309"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1542 > ../newoutputs/t2309
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2308.tr
echo ">>>>>>>>running test 2310"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1546 > ../newoutputs/t2310
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2309.tr
echo ">>>>>>>>running test 2311"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1549 > ../newoutputs/t2311
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2310.tr
echo ">>>>>>>>running test 2312"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.155 > ../newoutputs/t2312
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2311.tr
echo ">>>>>>>>running test 2313"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1551 > ../newoutputs/t2313
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2312.tr
echo ">>>>>>>>running test 2314"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1554 > ../newoutputs/t2314
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2313.tr
echo ">>>>>>>>running test 2315"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1556 > ../newoutputs/t2315
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2314.tr
echo ">>>>>>>>running test 2316"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1557 > ../newoutputs/t2316
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2315.tr
echo ">>>>>>>>running test 2317"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1559 > ../newoutputs/t2317
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2316.tr
echo ">>>>>>>>running test 2318"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1562 > ../newoutputs/t2318
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2317.tr
echo ">>>>>>>>running test 2319"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1563 > ../newoutputs/t2319
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2318.tr
echo ">>>>>>>>running test 2320"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1565 > ../newoutputs/t2320
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2319.tr
echo ">>>>>>>>running test 2321"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1566 > ../newoutputs/t2321
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2320.tr
echo ">>>>>>>>running test 2322"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1567 > ../newoutputs/t2322
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2321.tr
echo ">>>>>>>>running test 2323"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1569 > ../newoutputs/t2323
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2322.tr
echo ">>>>>>>>running test 2324"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.157 > ../newoutputs/t2324
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2323.tr
echo ">>>>>>>>running test 2325"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1570 > ../newoutputs/t2325
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2324.tr
echo ">>>>>>>>running test 2326"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1572 > ../newoutputs/t2326
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2325.tr
echo ">>>>>>>>running test 2327"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1576 > ../newoutputs/t2327
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2326.tr
echo ">>>>>>>>running test 2328"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1578 > ../newoutputs/t2328
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2327.tr
echo ">>>>>>>>running test 2329"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1579 > ../newoutputs/t2329
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2328.tr
echo ">>>>>>>>running test 2330"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1584 > ../newoutputs/t2330
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2329.tr
echo ">>>>>>>>running test 2331"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1587 > ../newoutputs/t2331
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2330.tr
echo ">>>>>>>>running test 2332"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1588 > ../newoutputs/t2332
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2331.tr
echo ">>>>>>>>running test 2333"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1589 > ../newoutputs/t2333
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2332.tr
echo ">>>>>>>>running test 2334"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1593 > ../newoutputs/t2334
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2333.tr
echo ">>>>>>>>running test 2335"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1596 > ../newoutputs/t2335
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2334.tr
echo ">>>>>>>>running test 2336"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1598 > ../newoutputs/t2336
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2335.tr
echo ">>>>>>>>running test 2337"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1599 > ../newoutputs/t2337
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2336.tr
echo ">>>>>>>>running test 2338"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.16 > ../newoutputs/t2338
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2337.tr
echo ">>>>>>>>running test 2339"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.160 > ../newoutputs/t2339
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2338.tr
echo ">>>>>>>>running test 2340"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1600 > ../newoutputs/t2340
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2339.tr
echo ">>>>>>>>running test 2341"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1604 > ../newoutputs/t2341
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2340.tr
echo ">>>>>>>>running test 2342"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1605 > ../newoutputs/t2342
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2341.tr
echo ">>>>>>>>running test 2343"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1609 > ../newoutputs/t2343
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2342.tr
echo ">>>>>>>>running test 2344"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.161 > ../newoutputs/t2344
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2343.tr
echo ">>>>>>>>running test 2345"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1611 > ../newoutputs/t2345
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2344.tr
echo ">>>>>>>>running test 2346"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1612 > ../newoutputs/t2346
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2345.tr
echo ">>>>>>>>running test 2347"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1613 > ../newoutputs/t2347
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2346.tr
echo ">>>>>>>>running test 2348"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1615 > ../newoutputs/t2348
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2347.tr
echo ">>>>>>>>running test 2349"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1616 > ../newoutputs/t2349
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2348.tr
echo ">>>>>>>>running test 2350"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.162 > ../newoutputs/t2350
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2349.tr
echo ">>>>>>>>running test 2351"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1621 > ../newoutputs/t2351
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2350.tr
echo ">>>>>>>>running test 2352"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1622 > ../newoutputs/t2352
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2351.tr
echo ">>>>>>>>running test 2353"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1627 > ../newoutputs/t2353
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2352.tr
echo ">>>>>>>>running test 2354"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1628 > ../newoutputs/t2354
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2353.tr
echo ">>>>>>>>running test 2355"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.163 > ../newoutputs/t2355
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2354.tr
echo ">>>>>>>>running test 2356"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1633 > ../newoutputs/t2356
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2355.tr
echo ">>>>>>>>running test 2357"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1636 > ../newoutputs/t2357
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2356.tr
echo ">>>>>>>>running test 2358"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1639 > ../newoutputs/t2358
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2357.tr
echo ">>>>>>>>running test 2359"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.164 > ../newoutputs/t2359
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2358.tr
echo ">>>>>>>>running test 2360"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1640 > ../newoutputs/t2360
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2359.tr
echo ">>>>>>>>running test 2361"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1642 > ../newoutputs/t2361
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2360.tr
echo ">>>>>>>>running test 2362"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1643 > ../newoutputs/t2362
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2361.tr
echo ">>>>>>>>running test 2363"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1647 > ../newoutputs/t2363
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2362.tr
echo ">>>>>>>>running test 2364"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1648 > ../newoutputs/t2364
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2363.tr
echo ">>>>>>>>running test 2365"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1649 > ../newoutputs/t2365
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2364.tr
echo ">>>>>>>>running test 2366"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1650 > ../newoutputs/t2366
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2365.tr
echo ">>>>>>>>running test 2367"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1658 > ../newoutputs/t2367
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2366.tr
echo ">>>>>>>>running test 2368"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1659 > ../newoutputs/t2368
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2367.tr
echo ">>>>>>>>running test 2369"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1660 > ../newoutputs/t2369
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2368.tr
echo ">>>>>>>>running test 2370"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1666 > ../newoutputs/t2370
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2369.tr
echo ">>>>>>>>running test 2371"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1667 > ../newoutputs/t2371
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2370.tr
echo ">>>>>>>>running test 2372"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1668 > ../newoutputs/t2372
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2371.tr
echo ">>>>>>>>running test 2373"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1669 > ../newoutputs/t2373
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2372.tr
echo ">>>>>>>>running test 2374"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1670 > ../newoutputs/t2374
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2373.tr
echo ">>>>>>>>running test 2375"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1671 > ../newoutputs/t2375
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2374.tr
echo ">>>>>>>>running test 2376"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1672 > ../newoutputs/t2376
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2375.tr
echo ">>>>>>>>running test 2377"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1675 > ../newoutputs/t2377
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2376.tr
echo ">>>>>>>>running test 2378"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1676 > ../newoutputs/t2378
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2377.tr
echo ">>>>>>>>running test 2379"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1679 > ../newoutputs/t2379
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2378.tr
echo ">>>>>>>>running test 2380"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1681 > ../newoutputs/t2380
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2379.tr
echo ">>>>>>>>running test 2381"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1686 > ../newoutputs/t2381
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2380.tr
echo ">>>>>>>>running test 2382"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.169 > ../newoutputs/t2382
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2381.tr
echo ">>>>>>>>running test 2383"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1691 > ../newoutputs/t2383
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2382.tr
echo ">>>>>>>>running test 2384"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1694 > ../newoutputs/t2384
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2383.tr
echo ">>>>>>>>running test 2385"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1695 > ../newoutputs/t2385
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2384.tr
echo ">>>>>>>>running test 2386"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1698 > ../newoutputs/t2386
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2385.tr
echo ">>>>>>>>running test 2387"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.17 > ../newoutputs/t2387
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2386.tr
echo ">>>>>>>>running test 2388"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.170 > ../newoutputs/t2388
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2387.tr
echo ">>>>>>>>running test 2389"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1702 > ../newoutputs/t2389
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2388.tr
echo ">>>>>>>>running test 2390"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1707 > ../newoutputs/t2390
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2389.tr
echo ">>>>>>>>running test 2391"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.171 > ../newoutputs/t2391
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2390.tr
echo ">>>>>>>>running test 2392"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1710 > ../newoutputs/t2392
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2391.tr
echo ">>>>>>>>running test 2393"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1711 > ../newoutputs/t2393
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2392.tr
echo ">>>>>>>>running test 2394"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1712 > ../newoutputs/t2394
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2393.tr
echo ">>>>>>>>running test 2395"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1716 > ../newoutputs/t2395
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2394.tr
echo ">>>>>>>>running test 2396"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1724 > ../newoutputs/t2396
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2395.tr
echo ">>>>>>>>running test 2397"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1730 > ../newoutputs/t2397
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2396.tr
echo ">>>>>>>>running test 2398"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1735 > ../newoutputs/t2398
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2397.tr
echo ">>>>>>>>running test 2399"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1737 > ../newoutputs/t2399
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2398.tr
echo ">>>>>>>>running test 2400"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1738 > ../newoutputs/t2400
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2399.tr
echo ">>>>>>>>running test 2401"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1740 > ../newoutputs/t2401
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2400.tr
echo ">>>>>>>>running test 2402"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1742 > ../newoutputs/t2402
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2401.tr
echo ">>>>>>>>running test 2403"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1744 > ../newoutputs/t2403
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2402.tr
echo ">>>>>>>>running test 2404"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.175 > ../newoutputs/t2404
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2403.tr
echo ">>>>>>>>running test 2405"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1753 > ../newoutputs/t2405
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2404.tr
echo ">>>>>>>>running test 2406"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1754 > ../newoutputs/t2406
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2405.tr
echo ">>>>>>>>running test 2407"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1755 > ../newoutputs/t2407
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2406.tr
echo ">>>>>>>>running test 2408"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1756 > ../newoutputs/t2408
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2407.tr
echo ">>>>>>>>running test 2409"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.176 > ../newoutputs/t2409
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2408.tr
echo ">>>>>>>>running test 2410"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1760 > ../newoutputs/t2410
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2409.tr
echo ">>>>>>>>running test 2411"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1762 > ../newoutputs/t2411
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2410.tr
echo ">>>>>>>>running test 2412"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1764 > ../newoutputs/t2412
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2411.tr
echo ">>>>>>>>running test 2413"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.177 > ../newoutputs/t2413
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2412.tr
echo ">>>>>>>>running test 2414"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1771 > ../newoutputs/t2414
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2413.tr
echo ">>>>>>>>running test 2415"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1773 > ../newoutputs/t2415
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2414.tr
echo ">>>>>>>>running test 2416"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1774 > ../newoutputs/t2416
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2415.tr
echo ">>>>>>>>running test 2417"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1776 > ../newoutputs/t2417
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2416.tr
echo ">>>>>>>>running test 2418"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1778 > ../newoutputs/t2418
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2417.tr
echo ">>>>>>>>running test 2419"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1782 > ../newoutputs/t2419
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2418.tr
echo ">>>>>>>>running test 2420"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1783 > ../newoutputs/t2420
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2419.tr
echo ">>>>>>>>running test 2421"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1785 > ../newoutputs/t2421
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2420.tr
echo ">>>>>>>>running test 2422"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1787 > ../newoutputs/t2422
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2421.tr
echo ">>>>>>>>running test 2423"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1789 > ../newoutputs/t2423
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2422.tr
echo ">>>>>>>>running test 2424"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1792 > ../newoutputs/t2424
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2423.tr
echo ">>>>>>>>running test 2425"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1793 > ../newoutputs/t2425
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2424.tr
echo ">>>>>>>>running test 2426"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1794 > ../newoutputs/t2426
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2425.tr
echo ">>>>>>>>running test 2427"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1798 > ../newoutputs/t2427
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2426.tr
echo ">>>>>>>>running test 2428"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1800 > ../newoutputs/t2428
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2427.tr
echo ">>>>>>>>running test 2429"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1802 > ../newoutputs/t2429
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2428.tr
echo ">>>>>>>>running test 2430"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1806 > ../newoutputs/t2430
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2429.tr
echo ">>>>>>>>running test 2431"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1809 > ../newoutputs/t2431
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2430.tr
echo ">>>>>>>>running test 2432"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1812 > ../newoutputs/t2432
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2431.tr
echo ">>>>>>>>running test 2433"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1814 > ../newoutputs/t2433
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2432.tr
echo ">>>>>>>>running test 2434"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1816 > ../newoutputs/t2434
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2433.tr
echo ">>>>>>>>running test 2435"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1818 > ../newoutputs/t2435
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2434.tr
echo ">>>>>>>>running test 2436"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1819 > ../newoutputs/t2436
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2435.tr
echo ">>>>>>>>running test 2437"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.182 > ../newoutputs/t2437
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2436.tr
echo ">>>>>>>>running test 2438"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1821 > ../newoutputs/t2438
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2437.tr
echo ">>>>>>>>running test 2439"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1823 > ../newoutputs/t2439
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2438.tr
echo ">>>>>>>>running test 2440"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1827 > ../newoutputs/t2440
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2439.tr
echo ">>>>>>>>running test 2441"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1829 > ../newoutputs/t2441
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2440.tr
echo ">>>>>>>>running test 2442"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1830 > ../newoutputs/t2442
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2441.tr
echo ">>>>>>>>running test 2443"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1832 > ../newoutputs/t2443
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2442.tr
echo ">>>>>>>>running test 2444"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1835 > ../newoutputs/t2444
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2443.tr
echo ">>>>>>>>running test 2445"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1836 > ../newoutputs/t2445
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2444.tr
echo ">>>>>>>>running test 2446"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1837 > ../newoutputs/t2446
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2445.tr
echo ">>>>>>>>running test 2447"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1838 > ../newoutputs/t2447
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2446.tr
echo ">>>>>>>>running test 2448"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1839 > ../newoutputs/t2448
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2447.tr
echo ">>>>>>>>running test 2449"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.184 > ../newoutputs/t2449
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2448.tr
echo ">>>>>>>>running test 2450"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1845 > ../newoutputs/t2450
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2449.tr
echo ">>>>>>>>running test 2451"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1847 > ../newoutputs/t2451
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2450.tr
echo ">>>>>>>>running test 2452"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1848 > ../newoutputs/t2452
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2451.tr
echo ">>>>>>>>running test 2453"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.185 > ../newoutputs/t2453
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2452.tr
echo ">>>>>>>>running test 2454"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1850 > ../newoutputs/t2454
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2453.tr
echo ">>>>>>>>running test 2455"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1855 > ../newoutputs/t2455
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2454.tr
echo ">>>>>>>>running test 2456"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1856 > ../newoutputs/t2456
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2455.tr
echo ">>>>>>>>running test 2457"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1858 > ../newoutputs/t2457
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2456.tr
echo ">>>>>>>>running test 2458"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1862 > ../newoutputs/t2458
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2457.tr
echo ">>>>>>>>running test 2459"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1863 > ../newoutputs/t2459
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2458.tr
echo ">>>>>>>>running test 2460"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1865 > ../newoutputs/t2460
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2459.tr
echo ">>>>>>>>running test 2461"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1871 > ../newoutputs/t2461
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2460.tr
echo ">>>>>>>>running test 2462"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1872 > ../newoutputs/t2462
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2461.tr
echo ">>>>>>>>running test 2463"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1873 > ../newoutputs/t2463
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2462.tr
echo ">>>>>>>>running test 2464"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1874 > ../newoutputs/t2464
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2463.tr
echo ">>>>>>>>running test 2465"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1876 > ../newoutputs/t2465
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2464.tr
echo ">>>>>>>>running test 2466"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1877 > ../newoutputs/t2466
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2465.tr
echo ">>>>>>>>running test 2467"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1878 > ../newoutputs/t2467
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2466.tr
echo ">>>>>>>>running test 2468"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.188 > ../newoutputs/t2468
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2467.tr
echo ">>>>>>>>running test 2469"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1880 > ../newoutputs/t2469
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2468.tr
echo ">>>>>>>>running test 2470"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1881 > ../newoutputs/t2470
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2469.tr
echo ">>>>>>>>running test 2471"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1882 > ../newoutputs/t2471
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2470.tr
echo ">>>>>>>>running test 2472"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1885 > ../newoutputs/t2472
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2471.tr
echo ">>>>>>>>running test 2473"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1886 > ../newoutputs/t2473
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2472.tr
echo ">>>>>>>>running test 2474"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1887 > ../newoutputs/t2474
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2473.tr
echo ">>>>>>>>running test 2475"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.189 > ../newoutputs/t2475
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2474.tr
echo ">>>>>>>>running test 2476"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1891 > ../newoutputs/t2476
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2475.tr
echo ">>>>>>>>running test 2477"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1892 > ../newoutputs/t2477
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2476.tr
echo ">>>>>>>>running test 2478"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1893 > ../newoutputs/t2478
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2477.tr
echo ">>>>>>>>running test 2479"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1895 > ../newoutputs/t2479
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2478.tr
echo ">>>>>>>>running test 2480"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1896 > ../newoutputs/t2480
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2479.tr
echo ">>>>>>>>running test 2481"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1897 > ../newoutputs/t2481
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2480.tr
echo ">>>>>>>>running test 2482"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1898 > ../newoutputs/t2482
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2481.tr
echo ">>>>>>>>running test 2483"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.190 > ../newoutputs/t2483
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2482.tr
echo ">>>>>>>>running test 2484"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1903 > ../newoutputs/t2484
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2483.tr
echo ">>>>>>>>running test 2485"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1905 > ../newoutputs/t2485
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2484.tr
echo ">>>>>>>>running test 2486"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1907 > ../newoutputs/t2486
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2485.tr
echo ">>>>>>>>running test 2487"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1908 > ../newoutputs/t2487
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2486.tr
echo ">>>>>>>>running test 2488"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.191 > ../newoutputs/t2488
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2487.tr
echo ">>>>>>>>running test 2489"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1912 > ../newoutputs/t2489
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2488.tr
echo ">>>>>>>>running test 2490"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1913 > ../newoutputs/t2490
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2489.tr
echo ">>>>>>>>running test 2491"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1914 > ../newoutputs/t2491
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2490.tr
echo ">>>>>>>>running test 2492"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1916 > ../newoutputs/t2492
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2491.tr
echo ">>>>>>>>running test 2493"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1917 > ../newoutputs/t2493
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2492.tr
echo ">>>>>>>>running test 2494"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1918 > ../newoutputs/t2494
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2493.tr
echo ">>>>>>>>running test 2495"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1920 > ../newoutputs/t2495
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2494.tr
echo ">>>>>>>>running test 2496"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1922 > ../newoutputs/t2496
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2495.tr
echo ">>>>>>>>running test 2497"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1924 > ../newoutputs/t2497
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2496.tr
echo ">>>>>>>>running test 2498"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1925 > ../newoutputs/t2498
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2497.tr
echo ">>>>>>>>running test 2499"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1926 > ../newoutputs/t2499
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2498.tr
echo ">>>>>>>>running test 2500"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1929 > ../newoutputs/t2500
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2499.tr
echo ">>>>>>>>running test 2501"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.193 > ../newoutputs/t2501
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2500.tr
echo ">>>>>>>>running test 2502"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1931 > ../newoutputs/t2502
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2501.tr
echo ">>>>>>>>running test 2503"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1932 > ../newoutputs/t2503
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2502.tr
echo ">>>>>>>>running test 2504"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1934 > ../newoutputs/t2504
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2503.tr
echo ">>>>>>>>running test 2505"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1935 > ../newoutputs/t2505
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2504.tr
echo ">>>>>>>>running test 2506"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1936 > ../newoutputs/t2506
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2505.tr
echo ">>>>>>>>running test 2507"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1937 > ../newoutputs/t2507
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2506.tr
echo ">>>>>>>>running test 2508"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1938 > ../newoutputs/t2508
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2507.tr
echo ">>>>>>>>running test 2509"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1944 > ../newoutputs/t2509
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2508.tr
echo ">>>>>>>>running test 2510"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1945 > ../newoutputs/t2510
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2509.tr
echo ">>>>>>>>running test 2511"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1946 > ../newoutputs/t2511
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2510.tr
echo ">>>>>>>>running test 2512"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1947 > ../newoutputs/t2512
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2511.tr
echo ">>>>>>>>running test 2513"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1948 > ../newoutputs/t2513
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2512.tr
echo ">>>>>>>>running test 2514"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.195 > ../newoutputs/t2514
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2513.tr
echo ">>>>>>>>running test 2515"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1950 > ../newoutputs/t2515
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2514.tr
echo ">>>>>>>>running test 2516"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1955 > ../newoutputs/t2516
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2515.tr
echo ">>>>>>>>running test 2517"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1958 > ../newoutputs/t2517
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2516.tr
echo ">>>>>>>>running test 2518"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1959 > ../newoutputs/t2518
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2517.tr
echo ">>>>>>>>running test 2519"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1961 > ../newoutputs/t2519
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2518.tr
echo ">>>>>>>>running test 2520"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1964 > ../newoutputs/t2520
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2519.tr
echo ">>>>>>>>running test 2521"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1970 > ../newoutputs/t2521
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2520.tr
echo ">>>>>>>>running test 2522"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1972 > ../newoutputs/t2522
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2521.tr
echo ">>>>>>>>running test 2523"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1974 > ../newoutputs/t2523
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2522.tr
echo ">>>>>>>>running test 2524"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1975 > ../newoutputs/t2524
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2523.tr
echo ">>>>>>>>running test 2525"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1979 > ../newoutputs/t2525
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2524.tr
echo ">>>>>>>>running test 2526"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1984 > ../newoutputs/t2526
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2525.tr
echo ">>>>>>>>running test 2527"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1985 > ../newoutputs/t2527
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2526.tr
echo ">>>>>>>>running test 2528"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1988 > ../newoutputs/t2528
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2527.tr
echo ">>>>>>>>running test 2529"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1989 > ../newoutputs/t2529
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2528.tr
echo ">>>>>>>>running test 2530"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1990 > ../newoutputs/t2530
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2529.tr
echo ">>>>>>>>running test 2531"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1995 > ../newoutputs/t2531
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2530.tr
echo ">>>>>>>>running test 2532"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1997 > ../newoutputs/t2532
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2531.tr
echo ">>>>>>>>running test 2533"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1998 > ../newoutputs/t2533
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2532.tr
echo ">>>>>>>>running test 2534"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.1999 > ../newoutputs/t2534
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2533.tr
echo ">>>>>>>>running test 2535"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.20 > ../newoutputs/t2535
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2534.tr
echo ">>>>>>>>running test 2536"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.2000 > ../newoutputs/t2536
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2535.tr
echo ">>>>>>>>running test 2537"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.201 > ../newoutputs/t2537
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2536.tr
echo ">>>>>>>>running test 2538"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.204 > ../newoutputs/t2538
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2537.tr
echo ">>>>>>>>running test 2539"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.206 > ../newoutputs/t2539
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2538.tr
echo ">>>>>>>>running test 2540"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.207 > ../newoutputs/t2540
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2539.tr
echo ">>>>>>>>running test 2541"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.208 > ../newoutputs/t2541
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2540.tr
echo ">>>>>>>>running test 2542"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.209 > ../newoutputs/t2542
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2541.tr
echo ">>>>>>>>running test 2543"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.21 > ../newoutputs/t2543
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2542.tr
echo ">>>>>>>>running test 2544"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.210 > ../newoutputs/t2544
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2543.tr
echo ">>>>>>>>running test 2545"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.213 > ../newoutputs/t2545
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2544.tr
echo ">>>>>>>>running test 2546"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.214 > ../newoutputs/t2546
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2545.tr
echo ">>>>>>>>running test 2547"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.215 > ../newoutputs/t2547
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2546.tr
echo ">>>>>>>>running test 2548"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.22 > ../newoutputs/t2548
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2547.tr
echo ">>>>>>>>running test 2549"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.225 > ../newoutputs/t2549
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2548.tr
echo ">>>>>>>>running test 2550"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.226 > ../newoutputs/t2550
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2549.tr
echo ">>>>>>>>running test 2551"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.230 > ../newoutputs/t2551
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2550.tr
echo ">>>>>>>>running test 2552"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.233 > ../newoutputs/t2552
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2551.tr
echo ">>>>>>>>running test 2553"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.234 > ../newoutputs/t2553
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2552.tr
echo ">>>>>>>>running test 2554"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.237 > ../newoutputs/t2554
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2553.tr
echo ">>>>>>>>running test 2555"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.238 > ../newoutputs/t2555
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2554.tr
echo ">>>>>>>>running test 2556"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.239 > ../newoutputs/t2556
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2555.tr
echo ">>>>>>>>running test 2557"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.243 > ../newoutputs/t2557
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2556.tr
echo ">>>>>>>>running test 2558"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.244 > ../newoutputs/t2558
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2557.tr
echo ">>>>>>>>running test 2559"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.245 > ../newoutputs/t2559
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2558.tr
echo ">>>>>>>>running test 2560"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.246 > ../newoutputs/t2560
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2559.tr
echo ">>>>>>>>running test 2561"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.247 > ../newoutputs/t2561
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2560.tr
echo ">>>>>>>>running test 2562"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.248 > ../newoutputs/t2562
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2561.tr
echo ">>>>>>>>running test 2563"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.249 > ../newoutputs/t2563
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2562.tr
echo ">>>>>>>>running test 2564"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.25 > ../newoutputs/t2564
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2563.tr
echo ">>>>>>>>running test 2565"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.251 > ../newoutputs/t2565
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2564.tr
echo ">>>>>>>>running test 2566"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.252 > ../newoutputs/t2566
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2565.tr
echo ">>>>>>>>running test 2567"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.254 > ../newoutputs/t2567
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2566.tr
echo ">>>>>>>>running test 2568"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.256 > ../newoutputs/t2568
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2567.tr
echo ">>>>>>>>running test 2569"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.257 > ../newoutputs/t2569
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2568.tr
echo ">>>>>>>>running test 2570"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.258 > ../newoutputs/t2570
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2569.tr
echo ">>>>>>>>running test 2571"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.260 > ../newoutputs/t2571
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2570.tr
echo ">>>>>>>>running test 2572"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.264 > ../newoutputs/t2572
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2571.tr
echo ">>>>>>>>running test 2573"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.266 > ../newoutputs/t2573
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2572.tr
echo ">>>>>>>>running test 2574"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.267 > ../newoutputs/t2574
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2573.tr
echo ">>>>>>>>running test 2575"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.268 > ../newoutputs/t2575
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2574.tr
echo ">>>>>>>>running test 2576"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.27 > ../newoutputs/t2576
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2575.tr
echo ">>>>>>>>running test 2577"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.270 > ../newoutputs/t2577
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2576.tr
echo ">>>>>>>>running test 2578"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.271 > ../newoutputs/t2578
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2577.tr
echo ">>>>>>>>running test 2579"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.272 > ../newoutputs/t2579
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2578.tr
echo ">>>>>>>>running test 2580"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.275 > ../newoutputs/t2580
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2579.tr
echo ">>>>>>>>running test 2581"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.276 > ../newoutputs/t2581
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2580.tr
echo ">>>>>>>>running test 2582"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.277 > ../newoutputs/t2582
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2581.tr
echo ">>>>>>>>running test 2583"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.28 > ../newoutputs/t2583
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2582.tr
echo ">>>>>>>>running test 2584"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.280 > ../newoutputs/t2584
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2583.tr
echo ">>>>>>>>running test 2585"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.281 > ../newoutputs/t2585
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2584.tr
echo ">>>>>>>>running test 2586"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.282 > ../newoutputs/t2586
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2585.tr
echo ">>>>>>>>running test 2587"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.283 > ../newoutputs/t2587
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2586.tr
echo ">>>>>>>>running test 2588"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.286 > ../newoutputs/t2588
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2587.tr
echo ">>>>>>>>running test 2589"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.289 > ../newoutputs/t2589
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2588.tr
echo ">>>>>>>>running test 2590"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.294 > ../newoutputs/t2590
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2589.tr
echo ">>>>>>>>running test 2591"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.295 > ../newoutputs/t2591
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2590.tr
echo ">>>>>>>>running test 2592"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.296 > ../newoutputs/t2592
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2591.tr
echo ">>>>>>>>running test 2593"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.297 > ../newoutputs/t2593
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2592.tr
echo ">>>>>>>>running test 2594"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.298 > ../newoutputs/t2594
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2593.tr
echo ">>>>>>>>running test 2595"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.299 > ../newoutputs/t2595
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2594.tr
echo ">>>>>>>>running test 2596"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.30 > ../newoutputs/t2596
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2595.tr
echo ">>>>>>>>running test 2597"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.301 > ../newoutputs/t2597
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2596.tr
echo ">>>>>>>>running test 2598"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.302 > ../newoutputs/t2598
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2597.tr
echo ">>>>>>>>running test 2599"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.305 > ../newoutputs/t2599
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2598.tr
echo ">>>>>>>>running test 2600"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.306 > ../newoutputs/t2600
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2599.tr
echo ">>>>>>>>running test 2601"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.307 > ../newoutputs/t2601
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2600.tr
echo ">>>>>>>>running test 2602"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.31 > ../newoutputs/t2602
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2601.tr
echo ">>>>>>>>running test 2603"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.311 > ../newoutputs/t2603
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2602.tr
echo ">>>>>>>>running test 2604"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.318 > ../newoutputs/t2604
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2603.tr
echo ">>>>>>>>running test 2605"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.319 > ../newoutputs/t2605
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2604.tr
echo ">>>>>>>>running test 2606"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.320 > ../newoutputs/t2606
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2605.tr
echo ">>>>>>>>running test 2607"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.321 > ../newoutputs/t2607
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2606.tr
echo ">>>>>>>>running test 2608"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.322 > ../newoutputs/t2608
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2607.tr
echo ">>>>>>>>running test 2609"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.323 > ../newoutputs/t2609
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2608.tr
echo ">>>>>>>>running test 2610"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.325 > ../newoutputs/t2610
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2609.tr
echo ">>>>>>>>running test 2611"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.327 > ../newoutputs/t2611
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2610.tr
echo ">>>>>>>>running test 2612"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.329 > ../newoutputs/t2612
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2611.tr
echo ">>>>>>>>running test 2613"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.33 > ../newoutputs/t2613
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2612.tr
echo ">>>>>>>>running test 2614"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.330 > ../newoutputs/t2614
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2613.tr
echo ">>>>>>>>running test 2615"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.333 > ../newoutputs/t2615
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2614.tr
echo ">>>>>>>>running test 2616"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.335 > ../newoutputs/t2616
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2615.tr
echo ">>>>>>>>running test 2617"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.337 > ../newoutputs/t2617
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2616.tr
echo ">>>>>>>>running test 2618"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.339 > ../newoutputs/t2618
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2617.tr
echo ">>>>>>>>running test 2619"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.34 > ../newoutputs/t2619
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2618.tr
echo ">>>>>>>>running test 2620"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.340 > ../newoutputs/t2620
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2619.tr
echo ">>>>>>>>running test 2621"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.343 > ../newoutputs/t2621
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2620.tr
echo ">>>>>>>>running test 2622"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.344 > ../newoutputs/t2622
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2621.tr
echo ">>>>>>>>running test 2623"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.345 > ../newoutputs/t2623
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2622.tr
echo ">>>>>>>>running test 2624"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.348 > ../newoutputs/t2624
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2623.tr
echo ">>>>>>>>running test 2625"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.349 > ../newoutputs/t2625
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2624.tr
echo ">>>>>>>>running test 2626"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.350 > ../newoutputs/t2626
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2625.tr
echo ">>>>>>>>running test 2627"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.352 > ../newoutputs/t2627
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2626.tr
echo ">>>>>>>>running test 2628"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.353 > ../newoutputs/t2628
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2627.tr
echo ">>>>>>>>running test 2629"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.355 > ../newoutputs/t2629
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2628.tr
echo ">>>>>>>>running test 2630"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.36 > ../newoutputs/t2630
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2629.tr
echo ">>>>>>>>running test 2631"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.360 > ../newoutputs/t2631
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2630.tr
echo ">>>>>>>>running test 2632"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.362 > ../newoutputs/t2632
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2631.tr
echo ">>>>>>>>running test 2633"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.363 > ../newoutputs/t2633
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2632.tr
echo ">>>>>>>>running test 2634"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.367 > ../newoutputs/t2634
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2633.tr
echo ">>>>>>>>running test 2635"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.369 > ../newoutputs/t2635
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2634.tr
echo ">>>>>>>>running test 2636"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.37 > ../newoutputs/t2636
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2635.tr
echo ">>>>>>>>running test 2637"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.372 > ../newoutputs/t2637
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2636.tr
echo ">>>>>>>>running test 2638"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.377 > ../newoutputs/t2638
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2637.tr
echo ">>>>>>>>running test 2639"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.378 > ../newoutputs/t2639
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2638.tr
echo ">>>>>>>>running test 2640"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.379 > ../newoutputs/t2640
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2639.tr
echo ">>>>>>>>running test 2641"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.380 > ../newoutputs/t2641
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2640.tr
echo ">>>>>>>>running test 2642"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.383 > ../newoutputs/t2642
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2641.tr
echo ">>>>>>>>running test 2643"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.386 > ../newoutputs/t2643
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2642.tr
echo ">>>>>>>>running test 2644"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.387 > ../newoutputs/t2644
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2643.tr
echo ">>>>>>>>running test 2645"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.388 > ../newoutputs/t2645
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2644.tr
echo ">>>>>>>>running test 2646"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.392 > ../newoutputs/t2646
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2645.tr
echo ">>>>>>>>running test 2647"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.395 > ../newoutputs/t2647
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2646.tr
echo ">>>>>>>>running test 2648"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.396 > ../newoutputs/t2648
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2647.tr
echo ">>>>>>>>running test 2649"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.398 > ../newoutputs/t2649
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2648.tr
echo ">>>>>>>>running test 2650"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.4 > ../newoutputs/t2650
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2649.tr
echo ">>>>>>>>running test 2651"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.40 > ../newoutputs/t2651
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2650.tr
echo ">>>>>>>>running test 2652"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.402 > ../newoutputs/t2652
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2651.tr
echo ">>>>>>>>running test 2653"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.407 > ../newoutputs/t2653
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2652.tr
echo ">>>>>>>>running test 2654"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.41 > ../newoutputs/t2654
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2653.tr
echo ">>>>>>>>running test 2655"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.412 > ../newoutputs/t2655
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2654.tr
echo ">>>>>>>>running test 2656"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.413 > ../newoutputs/t2656
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2655.tr
echo ">>>>>>>>running test 2657"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.415 > ../newoutputs/t2657
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2656.tr
echo ">>>>>>>>running test 2658"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.418 > ../newoutputs/t2658
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2657.tr
echo ">>>>>>>>running test 2659"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.419 > ../newoutputs/t2659
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2658.tr
echo ">>>>>>>>running test 2660"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.42 > ../newoutputs/t2660
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2659.tr
echo ">>>>>>>>running test 2661"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.421 > ../newoutputs/t2661
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2660.tr
echo ">>>>>>>>running test 2662"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.423 > ../newoutputs/t2662
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2661.tr
echo ">>>>>>>>running test 2663"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.424 > ../newoutputs/t2663
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2662.tr
echo ">>>>>>>>running test 2664"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.425 > ../newoutputs/t2664
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2663.tr
echo ">>>>>>>>running test 2665"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.428 > ../newoutputs/t2665
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2664.tr
echo ">>>>>>>>running test 2666"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.430 > ../newoutputs/t2666
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2665.tr
echo ">>>>>>>>running test 2667"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.432 > ../newoutputs/t2667
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2666.tr
echo ">>>>>>>>running test 2668"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.433 > ../newoutputs/t2668
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2667.tr
echo ">>>>>>>>running test 2669"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.434 > ../newoutputs/t2669
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2668.tr
echo ">>>>>>>>running test 2670"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.435 > ../newoutputs/t2670
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2669.tr
echo ">>>>>>>>running test 2671"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.436 > ../newoutputs/t2671
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2670.tr
echo ">>>>>>>>running test 2672"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.438 > ../newoutputs/t2672
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2671.tr
echo ">>>>>>>>running test 2673"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.441 > ../newoutputs/t2673
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2672.tr
echo ">>>>>>>>running test 2674"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.442 > ../newoutputs/t2674
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2673.tr
echo ">>>>>>>>running test 2675"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.447 > ../newoutputs/t2675
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2674.tr
echo ">>>>>>>>running test 2676"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.448 > ../newoutputs/t2676
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2675.tr
echo ">>>>>>>>running test 2677"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.449 > ../newoutputs/t2677
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2676.tr
echo ">>>>>>>>running test 2678"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.450 > ../newoutputs/t2678
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2677.tr
echo ">>>>>>>>running test 2679"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.451 > ../newoutputs/t2679
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2678.tr
echo ">>>>>>>>running test 2680"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.455 > ../newoutputs/t2680
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2679.tr
echo ">>>>>>>>running test 2681"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.456 > ../newoutputs/t2681
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2680.tr
echo ">>>>>>>>running test 2682"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.457 > ../newoutputs/t2682
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2681.tr
echo ">>>>>>>>running test 2683"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.459 > ../newoutputs/t2683
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2682.tr
echo ">>>>>>>>running test 2684"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.462 > ../newoutputs/t2684
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2683.tr
echo ">>>>>>>>running test 2685"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.463 > ../newoutputs/t2685
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2684.tr
echo ">>>>>>>>running test 2686"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.467 > ../newoutputs/t2686
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2685.tr
echo ">>>>>>>>running test 2687"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.468 > ../newoutputs/t2687
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2686.tr
echo ">>>>>>>>running test 2688"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.469 > ../newoutputs/t2688
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2687.tr
echo ">>>>>>>>running test 2689"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.47 > ../newoutputs/t2689
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2688.tr
echo ">>>>>>>>running test 2690"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.475 > ../newoutputs/t2690
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2689.tr
echo ">>>>>>>>running test 2691"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.476 > ../newoutputs/t2691
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2690.tr
echo ">>>>>>>>running test 2692"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.477 > ../newoutputs/t2692
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2691.tr
echo ">>>>>>>>running test 2693"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.479 > ../newoutputs/t2693
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2692.tr
echo ">>>>>>>>running test 2694"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.48 > ../newoutputs/t2694
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2693.tr
echo ">>>>>>>>running test 2695"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.480 > ../newoutputs/t2695
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2694.tr
echo ">>>>>>>>running test 2696"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.483 > ../newoutputs/t2696
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2695.tr
echo ">>>>>>>>running test 2697"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.487 > ../newoutputs/t2697
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2696.tr
echo ">>>>>>>>running test 2698"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.489 > ../newoutputs/t2698
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2697.tr
echo ">>>>>>>>running test 2699"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.493 > ../newoutputs/t2699
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2698.tr
echo ">>>>>>>>running test 2700"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.494 > ../newoutputs/t2700
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2699.tr
echo ">>>>>>>>running test 2701"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.496 > ../newoutputs/t2701
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2700.tr
echo ">>>>>>>>running test 2702"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.50 > ../newoutputs/t2702
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2701.tr
echo ">>>>>>>>running test 2703"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.502 > ../newoutputs/t2703
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2702.tr
echo ">>>>>>>>running test 2704"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.504 > ../newoutputs/t2704
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2703.tr
echo ">>>>>>>>running test 2705"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.506 > ../newoutputs/t2705
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2704.tr
echo ">>>>>>>>running test 2706"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.507 > ../newoutputs/t2706
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2705.tr
echo ">>>>>>>>running test 2707"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.510 > ../newoutputs/t2707
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2706.tr
echo ">>>>>>>>running test 2708"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.511 > ../newoutputs/t2708
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2707.tr
echo ">>>>>>>>running test 2709"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.512 > ../newoutputs/t2709
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2708.tr
echo ">>>>>>>>running test 2710"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.513 > ../newoutputs/t2710
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2709.tr
echo ">>>>>>>>running test 2711"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.514 > ../newoutputs/t2711
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2710.tr
echo ">>>>>>>>running test 2712"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.515 > ../newoutputs/t2712
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2711.tr
echo ">>>>>>>>running test 2713"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.518 > ../newoutputs/t2713
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2712.tr
echo ">>>>>>>>running test 2714"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.519 > ../newoutputs/t2714
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2713.tr
echo ">>>>>>>>running test 2715"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.52 > ../newoutputs/t2715
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2714.tr
echo ">>>>>>>>running test 2716"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.520 > ../newoutputs/t2716
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2715.tr
echo ">>>>>>>>running test 2717"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.522 > ../newoutputs/t2717
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2716.tr
echo ">>>>>>>>running test 2718"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.525 > ../newoutputs/t2718
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2717.tr
echo ">>>>>>>>running test 2719"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.526 > ../newoutputs/t2719
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2718.tr
echo ">>>>>>>>running test 2720"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.527 > ../newoutputs/t2720
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2719.tr
echo ">>>>>>>>running test 2721"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.528 > ../newoutputs/t2721
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2720.tr
echo ">>>>>>>>running test 2722"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.533 > ../newoutputs/t2722
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2721.tr
echo ">>>>>>>>running test 2723"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.534 > ../newoutputs/t2723
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2722.tr
echo ">>>>>>>>running test 2724"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.537 > ../newoutputs/t2724
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2723.tr
echo ">>>>>>>>running test 2725"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.538 > ../newoutputs/t2725
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2724.tr
echo ">>>>>>>>running test 2726"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.539 > ../newoutputs/t2726
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2725.tr
echo ">>>>>>>>running test 2727"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.54 > ../newoutputs/t2727
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2726.tr
echo ">>>>>>>>running test 2728"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.540 > ../newoutputs/t2728
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2727.tr
echo ">>>>>>>>running test 2729"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.543 > ../newoutputs/t2729
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2728.tr
echo ">>>>>>>>running test 2730"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.544 > ../newoutputs/t2730
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2729.tr
echo ">>>>>>>>running test 2731"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.552 > ../newoutputs/t2731
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2730.tr
echo ">>>>>>>>running test 2732"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.553 > ../newoutputs/t2732
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2731.tr
echo ">>>>>>>>running test 2733"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.558 > ../newoutputs/t2733
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2732.tr
echo ">>>>>>>>running test 2734"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.562 > ../newoutputs/t2734
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2733.tr
echo ">>>>>>>>running test 2735"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.566 > ../newoutputs/t2735
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2734.tr
echo ">>>>>>>>running test 2736"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.568 > ../newoutputs/t2736
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2735.tr
echo ">>>>>>>>running test 2737"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.569 > ../newoutputs/t2737
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2736.tr
echo ">>>>>>>>running test 2738"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.570 > ../newoutputs/t2738
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2737.tr
echo ">>>>>>>>running test 2739"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.571 > ../newoutputs/t2739
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2738.tr
echo ">>>>>>>>running test 2740"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.572 > ../newoutputs/t2740
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2739.tr
echo ">>>>>>>>running test 2741"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.573 > ../newoutputs/t2741
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2740.tr
echo ">>>>>>>>running test 2742"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.574 > ../newoutputs/t2742
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2741.tr
echo ">>>>>>>>running test 2743"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.576 > ../newoutputs/t2743
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2742.tr
echo ">>>>>>>>running test 2744"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.577 > ../newoutputs/t2744
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2743.tr
echo ">>>>>>>>running test 2745"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.579 > ../newoutputs/t2745
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2744.tr
echo ">>>>>>>>running test 2746"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.58 > ../newoutputs/t2746
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2745.tr
echo ">>>>>>>>running test 2747"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.580 > ../newoutputs/t2747
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2746.tr
echo ">>>>>>>>running test 2748"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.581 > ../newoutputs/t2748
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2747.tr
echo ">>>>>>>>running test 2749"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.582 > ../newoutputs/t2749
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2748.tr
echo ">>>>>>>>running test 2750"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.583 > ../newoutputs/t2750
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2749.tr
echo ">>>>>>>>running test 2751"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.584 > ../newoutputs/t2751
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2750.tr
echo ">>>>>>>>running test 2752"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.585 > ../newoutputs/t2752
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2751.tr
echo ">>>>>>>>running test 2753"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.586 > ../newoutputs/t2753
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2752.tr
echo ">>>>>>>>running test 2754"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.592 > ../newoutputs/t2754
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2753.tr
echo ">>>>>>>>running test 2755"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.593 > ../newoutputs/t2755
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2754.tr
echo ">>>>>>>>running test 2756"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.594 > ../newoutputs/t2756
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2755.tr
echo ">>>>>>>>running test 2757"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.596 > ../newoutputs/t2757
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2756.tr
echo ">>>>>>>>running test 2758"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.597 > ../newoutputs/t2758
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2757.tr
echo ">>>>>>>>running test 2759"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.598 > ../newoutputs/t2759
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2758.tr
echo ">>>>>>>>running test 2760"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.60 > ../newoutputs/t2760
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2759.tr
echo ">>>>>>>>running test 2761"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.602 > ../newoutputs/t2761
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2760.tr
echo ">>>>>>>>running test 2762"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.605 > ../newoutputs/t2762
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2761.tr
echo ">>>>>>>>running test 2763"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.607 > ../newoutputs/t2763
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2762.tr
echo ">>>>>>>>running test 2764"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.611 > ../newoutputs/t2764
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2763.tr
echo ">>>>>>>>running test 2765"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.614 > ../newoutputs/t2765
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2764.tr
echo ">>>>>>>>running test 2766"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.615 > ../newoutputs/t2766
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2765.tr
echo ">>>>>>>>running test 2767"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.616 > ../newoutputs/t2767
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2766.tr
echo ">>>>>>>>running test 2768"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.617 > ../newoutputs/t2768
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2767.tr
echo ">>>>>>>>running test 2769"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.619 > ../newoutputs/t2769
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2768.tr
echo ">>>>>>>>running test 2770"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.62 > ../newoutputs/t2770
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2769.tr
echo ">>>>>>>>running test 2771"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.621 > ../newoutputs/t2771
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2770.tr
echo ">>>>>>>>running test 2772"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.623 > ../newoutputs/t2772
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2771.tr
echo ">>>>>>>>running test 2773"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.624 > ../newoutputs/t2773
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2772.tr
echo ">>>>>>>>running test 2774"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.625 > ../newoutputs/t2774
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2773.tr
echo ">>>>>>>>running test 2775"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.626 > ../newoutputs/t2775
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2774.tr
echo ">>>>>>>>running test 2776"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.627 > ../newoutputs/t2776
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2775.tr
echo ">>>>>>>>running test 2777"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.63 > ../newoutputs/t2777
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2776.tr
echo ">>>>>>>>running test 2778"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.630 > ../newoutputs/t2778
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2777.tr
echo ">>>>>>>>running test 2779"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.633 > ../newoutputs/t2779
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2778.tr
echo ">>>>>>>>running test 2780"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.636 > ../newoutputs/t2780
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2779.tr
echo ">>>>>>>>running test 2781"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.64 > ../newoutputs/t2781
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2780.tr
echo ">>>>>>>>running test 2782"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.640 > ../newoutputs/t2782
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2781.tr
echo ">>>>>>>>running test 2783"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.642 > ../newoutputs/t2783
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2782.tr
echo ">>>>>>>>running test 2784"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.647 > ../newoutputs/t2784
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2783.tr
echo ">>>>>>>>running test 2785"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.648 > ../newoutputs/t2785
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2784.tr
echo ">>>>>>>>running test 2786"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.650 > ../newoutputs/t2786
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2785.tr
echo ">>>>>>>>running test 2787"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.655 > ../newoutputs/t2787
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2786.tr
echo ">>>>>>>>running test 2788"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.656 > ../newoutputs/t2788
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2787.tr
echo ">>>>>>>>running test 2789"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.659 > ../newoutputs/t2789
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2788.tr
echo ">>>>>>>>running test 2790"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.662 > ../newoutputs/t2790
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2789.tr
echo ">>>>>>>>running test 2791"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.663 > ../newoutputs/t2791
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2790.tr
echo ">>>>>>>>running test 2792"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.665 > ../newoutputs/t2792
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2791.tr
echo ">>>>>>>>running test 2793"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.668 > ../newoutputs/t2793
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2792.tr
echo ">>>>>>>>running test 2794"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.669 > ../newoutputs/t2794
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2793.tr
echo ">>>>>>>>running test 2795"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.67 > ../newoutputs/t2795
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2794.tr
echo ">>>>>>>>running test 2796"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.670 > ../newoutputs/t2796
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2795.tr
echo ">>>>>>>>running test 2797"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.673 > ../newoutputs/t2797
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2796.tr
echo ">>>>>>>>running test 2798"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.674 > ../newoutputs/t2798
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2797.tr
echo ">>>>>>>>running test 2799"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.676 > ../newoutputs/t2799
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2798.tr
echo ">>>>>>>>running test 2800"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.677 > ../newoutputs/t2800
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2799.tr
echo ">>>>>>>>running test 2801"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.679 > ../newoutputs/t2801
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2800.tr
echo ">>>>>>>>running test 2802"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.68 > ../newoutputs/t2802
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2801.tr
echo ">>>>>>>>running test 2803"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.680 > ../newoutputs/t2803
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2802.tr
echo ">>>>>>>>running test 2804"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.682 > ../newoutputs/t2804
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2803.tr
echo ">>>>>>>>running test 2805"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.686 > ../newoutputs/t2805
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2804.tr
echo ">>>>>>>>running test 2806"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.691 > ../newoutputs/t2806
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2805.tr
echo ">>>>>>>>running test 2807"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.695 > ../newoutputs/t2807
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2806.tr
echo ">>>>>>>>running test 2808"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.70 > ../newoutputs/t2808
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2807.tr
echo ">>>>>>>>running test 2809"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.701 > ../newoutputs/t2809
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2808.tr
echo ">>>>>>>>running test 2810"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.704 > ../newoutputs/t2810
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2809.tr
echo ">>>>>>>>running test 2811"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.706 > ../newoutputs/t2811
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2810.tr
echo ">>>>>>>>running test 2812"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.708 > ../newoutputs/t2812
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2811.tr
echo ">>>>>>>>running test 2813"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.709 > ../newoutputs/t2813
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2812.tr
echo ">>>>>>>>running test 2814"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.71 > ../newoutputs/t2814
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2813.tr
echo ">>>>>>>>running test 2815"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.712 > ../newoutputs/t2815
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2814.tr
echo ">>>>>>>>running test 2816"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.713 > ../newoutputs/t2816
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2815.tr
echo ">>>>>>>>running test 2817"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.716 > ../newoutputs/t2817
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2816.tr
echo ">>>>>>>>running test 2818"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.717 > ../newoutputs/t2818
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2817.tr
echo ">>>>>>>>running test 2819"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.719 > ../newoutputs/t2819
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2818.tr
echo ">>>>>>>>running test 2820"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.72 > ../newoutputs/t2820
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2819.tr
echo ">>>>>>>>running test 2821"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.721 > ../newoutputs/t2821
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2820.tr
echo ">>>>>>>>running test 2822"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.723 > ../newoutputs/t2822
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2821.tr
echo ">>>>>>>>running test 2823"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.727 > ../newoutputs/t2823
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2822.tr
echo ">>>>>>>>running test 2824"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.728 > ../newoutputs/t2824
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2823.tr
echo ">>>>>>>>running test 2825"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.734 > ../newoutputs/t2825
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2824.tr
echo ">>>>>>>>running test 2826"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.736 > ../newoutputs/t2826
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2825.tr
echo ">>>>>>>>running test 2827"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.738 > ../newoutputs/t2827
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2826.tr
echo ">>>>>>>>running test 2828"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.74 > ../newoutputs/t2828
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2827.tr
echo ">>>>>>>>running test 2829"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.742 > ../newoutputs/t2829
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2828.tr
echo ">>>>>>>>running test 2830"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.744 > ../newoutputs/t2830
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2829.tr
echo ">>>>>>>>running test 2831"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.746 > ../newoutputs/t2831
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2830.tr
echo ">>>>>>>>running test 2832"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.747 > ../newoutputs/t2832
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2831.tr
echo ">>>>>>>>running test 2833"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.748 > ../newoutputs/t2833
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2832.tr
echo ">>>>>>>>running test 2834"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.75 > ../newoutputs/t2834
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2833.tr
echo ">>>>>>>>running test 2835"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.751 > ../newoutputs/t2835
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2834.tr
echo ">>>>>>>>running test 2836"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.752 > ../newoutputs/t2836
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2835.tr
echo ">>>>>>>>running test 2837"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.753 > ../newoutputs/t2837
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2836.tr
echo ">>>>>>>>running test 2838"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.756 > ../newoutputs/t2838
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2837.tr
echo ">>>>>>>>running test 2839"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.758 > ../newoutputs/t2839
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2838.tr
echo ">>>>>>>>running test 2840"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.76 > ../newoutputs/t2840
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2839.tr
echo ">>>>>>>>running test 2841"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.760 > ../newoutputs/t2841
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2840.tr
echo ">>>>>>>>running test 2842"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.761 > ../newoutputs/t2842
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2841.tr
echo ">>>>>>>>running test 2843"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.765 > ../newoutputs/t2843
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2842.tr
echo ">>>>>>>>running test 2844"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.766 > ../newoutputs/t2844
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2843.tr
echo ">>>>>>>>running test 2845"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.767 > ../newoutputs/t2845
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2844.tr
echo ">>>>>>>>running test 2846"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.768 > ../newoutputs/t2846
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2845.tr
echo ">>>>>>>>running test 2847"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.769 > ../newoutputs/t2847
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2846.tr
echo ">>>>>>>>running test 2848"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.77 > ../newoutputs/t2848
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2847.tr
echo ">>>>>>>>running test 2849"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.772 > ../newoutputs/t2849
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2848.tr
echo ">>>>>>>>running test 2850"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.773 > ../newoutputs/t2850
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2849.tr
echo ">>>>>>>>running test 2851"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.775 > ../newoutputs/t2851
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2850.tr
echo ">>>>>>>>running test 2852"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.776 > ../newoutputs/t2852
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2851.tr
echo ">>>>>>>>running test 2853"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.777 > ../newoutputs/t2853
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2852.tr
echo ">>>>>>>>running test 2854"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.778 > ../newoutputs/t2854
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2853.tr
echo ">>>>>>>>running test 2855"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.779 > ../newoutputs/t2855
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2854.tr
echo ">>>>>>>>running test 2856"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.78 > ../newoutputs/t2856
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2855.tr
echo ">>>>>>>>running test 2857"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.781 > ../newoutputs/t2857
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2856.tr
echo ">>>>>>>>running test 2858"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.784 > ../newoutputs/t2858
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2857.tr
echo ">>>>>>>>running test 2859"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.786 > ../newoutputs/t2859
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2858.tr
echo ">>>>>>>>running test 2860"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.787 > ../newoutputs/t2860
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2859.tr
echo ">>>>>>>>running test 2861"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.788 > ../newoutputs/t2861
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2860.tr
echo ">>>>>>>>running test 2862"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.789 > ../newoutputs/t2862
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2861.tr
echo ">>>>>>>>running test 2863"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.79 > ../newoutputs/t2863
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2862.tr
echo ">>>>>>>>running test 2864"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.790 > ../newoutputs/t2864
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2863.tr
echo ">>>>>>>>running test 2865"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.791 > ../newoutputs/t2865
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2864.tr
echo ">>>>>>>>running test 2866"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.793 > ../newoutputs/t2866
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2865.tr
echo ">>>>>>>>running test 2867"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.798 > ../newoutputs/t2867
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2866.tr
echo ">>>>>>>>running test 2868"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.80 > ../newoutputs/t2868
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2867.tr
echo ">>>>>>>>running test 2869"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.803 > ../newoutputs/t2869
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2868.tr
echo ">>>>>>>>running test 2870"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.807 > ../newoutputs/t2870
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2869.tr
echo ">>>>>>>>running test 2871"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.808 > ../newoutputs/t2871
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2870.tr
echo ">>>>>>>>running test 2872"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.811 > ../newoutputs/t2872
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2871.tr
echo ">>>>>>>>running test 2873"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.814 > ../newoutputs/t2873
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2872.tr
echo ">>>>>>>>running test 2874"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.816 > ../newoutputs/t2874
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2873.tr
echo ">>>>>>>>running test 2875"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.818 > ../newoutputs/t2875
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2874.tr
echo ">>>>>>>>running test 2876"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.82 > ../newoutputs/t2876
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2875.tr
echo ">>>>>>>>running test 2877"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.821 > ../newoutputs/t2877
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2876.tr
echo ">>>>>>>>running test 2878"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.823 > ../newoutputs/t2878
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2877.tr
echo ">>>>>>>>running test 2879"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.825 > ../newoutputs/t2879
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2878.tr
echo ">>>>>>>>running test 2880"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.828 > ../newoutputs/t2880
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2879.tr
echo ">>>>>>>>running test 2881"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.829 > ../newoutputs/t2881
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2880.tr
echo ">>>>>>>>running test 2882"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.83 > ../newoutputs/t2882
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2881.tr
echo ">>>>>>>>running test 2883"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.831 > ../newoutputs/t2883
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2882.tr
echo ">>>>>>>>running test 2884"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.832 > ../newoutputs/t2884
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2883.tr
echo ">>>>>>>>running test 2885"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.834 > ../newoutputs/t2885
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2884.tr
echo ">>>>>>>>running test 2886"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.836 > ../newoutputs/t2886
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2885.tr
echo ">>>>>>>>running test 2887"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.837 > ../newoutputs/t2887
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2886.tr
echo ">>>>>>>>running test 2888"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.840 > ../newoutputs/t2888
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2887.tr
echo ">>>>>>>>running test 2889"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.843 > ../newoutputs/t2889
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2888.tr
echo ">>>>>>>>running test 2890"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.85 > ../newoutputs/t2890
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2889.tr
echo ">>>>>>>>running test 2891"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.851 > ../newoutputs/t2891
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2890.tr
echo ">>>>>>>>running test 2892"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.855 > ../newoutputs/t2892
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2891.tr
echo ">>>>>>>>running test 2893"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.858 > ../newoutputs/t2893
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2892.tr
echo ">>>>>>>>running test 2894"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.860 > ../newoutputs/t2894
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2893.tr
echo ">>>>>>>>running test 2895"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.862 > ../newoutputs/t2895
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2894.tr
echo ">>>>>>>>running test 2896"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.864 > ../newoutputs/t2896
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2895.tr
echo ">>>>>>>>running test 2897"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.865 > ../newoutputs/t2897
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2896.tr
echo ">>>>>>>>running test 2898"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.866 > ../newoutputs/t2898
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2897.tr
echo ">>>>>>>>running test 2899"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.87 > ../newoutputs/t2899
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2898.tr
echo ">>>>>>>>running test 2900"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.871 > ../newoutputs/t2900
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2899.tr
echo ">>>>>>>>running test 2901"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.88 > ../newoutputs/t2901
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2900.tr
echo ">>>>>>>>running test 2902"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.880 > ../newoutputs/t2902
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2901.tr
echo ">>>>>>>>running test 2903"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.888 > ../newoutputs/t2903
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2902.tr
echo ">>>>>>>>running test 2904"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.89 > ../newoutputs/t2904
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2903.tr
echo ">>>>>>>>running test 2905"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.892 > ../newoutputs/t2905
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2904.tr
echo ">>>>>>>>running test 2906"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.895 > ../newoutputs/t2906
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2905.tr
echo ">>>>>>>>running test 2907"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.896 > ../newoutputs/t2907
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2906.tr
echo ">>>>>>>>running test 2908"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.898 > ../newoutputs/t2908
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2907.tr
echo ">>>>>>>>running test 2909"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.9 > ../newoutputs/t2909
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2908.tr
echo ">>>>>>>>running test 2910"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.903 > ../newoutputs/t2910
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2909.tr
echo ">>>>>>>>running test 2911"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.904 > ../newoutputs/t2911
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2910.tr
echo ">>>>>>>>running test 2912"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.905 > ../newoutputs/t2912
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2911.tr
echo ">>>>>>>>running test 2913"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.906 > ../newoutputs/t2913
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2912.tr
echo ">>>>>>>>running test 2914"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.910 > ../newoutputs/t2914
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2913.tr
echo ">>>>>>>>running test 2915"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.913 > ../newoutputs/t2915
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2914.tr
echo ">>>>>>>>running test 2916"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.914 > ../newoutputs/t2916
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2915.tr
echo ">>>>>>>>running test 2917"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.92 > ../newoutputs/t2917
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2916.tr
echo ">>>>>>>>running test 2918"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.920 > ../newoutputs/t2918
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2917.tr
echo ">>>>>>>>running test 2919"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.922 > ../newoutputs/t2919
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2918.tr
echo ">>>>>>>>running test 2920"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.923 > ../newoutputs/t2920
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2919.tr
echo ">>>>>>>>running test 2921"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.924 > ../newoutputs/t2921
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2920.tr
echo ">>>>>>>>running test 2922"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.926 > ../newoutputs/t2922
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2921.tr
echo ">>>>>>>>running test 2923"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.927 > ../newoutputs/t2923
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2922.tr
echo ">>>>>>>>running test 2924"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.93 > ../newoutputs/t2924
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2923.tr
echo ">>>>>>>>running test 2925"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.930 > ../newoutputs/t2925
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2924.tr
echo ">>>>>>>>running test 2926"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.933 > ../newoutputs/t2926
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2925.tr
echo ">>>>>>>>running test 2927"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.937 > ../newoutputs/t2927
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2926.tr
echo ">>>>>>>>running test 2928"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.94 > ../newoutputs/t2928
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2927.tr
echo ">>>>>>>>running test 2929"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.942 > ../newoutputs/t2929
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2928.tr
echo ">>>>>>>>running test 2930"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.944 > ../newoutputs/t2930
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2929.tr
echo ">>>>>>>>running test 2931"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.945 > ../newoutputs/t2931
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2930.tr
echo ">>>>>>>>running test 2932"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.949 > ../newoutputs/t2932
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2931.tr
echo ">>>>>>>>running test 2933"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.954 > ../newoutputs/t2933
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2932.tr
echo ">>>>>>>>running test 2934"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.955 > ../newoutputs/t2934
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2933.tr
echo ">>>>>>>>running test 2935"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.957 > ../newoutputs/t2935
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2934.tr
echo ">>>>>>>>running test 2936"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.958 > ../newoutputs/t2936
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2935.tr
echo ">>>>>>>>running test 2937"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.96 > ../newoutputs/t2937
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2936.tr
echo ">>>>>>>>running test 2938"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.960 > ../newoutputs/t2938
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2937.tr
echo ">>>>>>>>running test 2939"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.961 > ../newoutputs/t2939
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2938.tr
echo ">>>>>>>>running test 2940"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.962 > ../newoutputs/t2940
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2939.tr
echo ">>>>>>>>running test 2941"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.964 > ../newoutputs/t2941
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2940.tr
echo ">>>>>>>>running test 2942"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.966 > ../newoutputs/t2942
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2941.tr
echo ">>>>>>>>running test 2943"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.968 > ../newoutputs/t2943
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2942.tr
echo ">>>>>>>>running test 2944"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.969 > ../newoutputs/t2944
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2943.tr
echo ">>>>>>>>running test 2945"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.97 > ../newoutputs/t2945
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2944.tr
echo ">>>>>>>>running test 2946"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.971 > ../newoutputs/t2946
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2945.tr
echo ">>>>>>>>running test 2947"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.973 > ../newoutputs/t2947
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2946.tr
echo ">>>>>>>>running test 2948"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.974 > ../newoutputs/t2948
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2947.tr
echo ">>>>>>>>running test 2949"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.978 > ../newoutputs/t2949
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2948.tr
echo ">>>>>>>>running test 2950"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.98 > ../newoutputs/t2950
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2949.tr
echo ">>>>>>>>running test 2951"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.981 > ../newoutputs/t2951
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2950.tr
echo ">>>>>>>>running test 2952"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.982 > ../newoutputs/t2952
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2951.tr
echo ">>>>>>>>running test 2953"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.984 > ../newoutputs/t2953
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2952.tr
echo ">>>>>>>>running test 2954"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.987 > ../newoutputs/t2954
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2953.tr
echo ">>>>>>>>running test 2955"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.989 > ../newoutputs/t2955
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2954.tr
echo ">>>>>>>>running test 2956"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.99 > ../newoutputs/t2956
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2955.tr
echo ">>>>>>>>running test 2957"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.991 > ../newoutputs/t2957
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2956.tr
echo ">>>>>>>>running test 2958"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.992 > ../newoutputs/t2958
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2957.tr
echo ">>>>>>>>running test 2959"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.993 > ../newoutputs/t2959
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2958.tr
echo ">>>>>>>>running test 2960"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.994 > ../newoutputs/t2960
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2959.tr
echo ">>>>>>>>running test 2961"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.995 > ../newoutputs/t2961
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2960.tr
echo ">>>>>>>>running test 2962"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.996 > ../newoutputs/t2962
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2961.tr
echo ">>>>>>>>running test 2963"
../source/print_tokens.c.inst.exe  < ../inputs/uslin.999 > ../newoutputs/t2963
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2962.tr
echo ">>>>>>>>running test 2964"
../source/print_tokens.c.inst.exe ../inputs/garbage/nothing     > ../newoutputs/t2964
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2963.tr
echo ">>>>>>>>running test 2965"
../source/print_tokens.c.inst.exe ../inputs/jk1     > ../newoutputs/t2965
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2964.tr
echo ">>>>>>>>running test 2966"
../source/print_tokens.c.inst.exe ../inputs/jk10     > ../newoutputs/t2966
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2965.tr
echo ">>>>>>>>running test 2967"
../source/print_tokens.c.inst.exe ../inputs/jk11     > ../newoutputs/t2967
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2966.tr
echo ">>>>>>>>running test 2968"
../source/print_tokens.c.inst.exe ../inputs/jk12     > ../newoutputs/t2968
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2967.tr
echo ">>>>>>>>running test 2969"
../source/print_tokens.c.inst.exe ../inputs/jk13     > ../newoutputs/t2969
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2968.tr
echo ">>>>>>>>running test 2970"
../source/print_tokens.c.inst.exe ../inputs/jk14     > ../newoutputs/t2970
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2969.tr
echo ">>>>>>>>running test 2971"
../source/print_tokens.c.inst.exe ../inputs/jk15     > ../newoutputs/t2971
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2970.tr
echo ">>>>>>>>running test 2972"
../source/print_tokens.c.inst.exe ../inputs/jk16     > ../newoutputs/t2972
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2971.tr
echo ">>>>>>>>running test 2973"
../source/print_tokens.c.inst.exe ../inputs/jk17     > ../newoutputs/t2973
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2972.tr
echo ">>>>>>>>running test 2974"
../source/print_tokens.c.inst.exe ../inputs/jk18     > ../newoutputs/t2974
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2973.tr
echo ">>>>>>>>running test 2975"
../source/print_tokens.c.inst.exe ../inputs/jk19     > ../newoutputs/t2975
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2974.tr
echo ">>>>>>>>running test 2976"
../source/print_tokens.c.inst.exe ../inputs/jk2     > ../newoutputs/t2976
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2975.tr
echo ">>>>>>>>running test 2977"
../source/print_tokens.c.inst.exe ../inputs/jk20     > ../newoutputs/t2977
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2976.tr
echo ">>>>>>>>running test 2978"
../source/print_tokens.c.inst.exe ../inputs/jk21     > ../newoutputs/t2978
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2977.tr
echo ">>>>>>>>running test 2979"
../source/print_tokens.c.inst.exe ../inputs/jk22     > ../newoutputs/t2979
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2978.tr
echo ">>>>>>>>running test 2980"
../source/print_tokens.c.inst.exe ../inputs/jk23     > ../newoutputs/t2980
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2979.tr
echo ">>>>>>>>running test 2981"
../source/print_tokens.c.inst.exe ../inputs/jk24     > ../newoutputs/t2981
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2980.tr
echo ">>>>>>>>running test 2982"
../source/print_tokens.c.inst.exe ../inputs/jk25     > ../newoutputs/t2982
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2981.tr
echo ">>>>>>>>running test 2983"
../source/print_tokens.c.inst.exe ../inputs/jk26     > ../newoutputs/t2983
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2982.tr
echo ">>>>>>>>running test 2984"
../source/print_tokens.c.inst.exe ../inputs/jk27     > ../newoutputs/t2984
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2983.tr
echo ">>>>>>>>running test 2985"
../source/print_tokens.c.inst.exe ../inputs/jk28     > ../newoutputs/t2985
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2984.tr
echo ">>>>>>>>running test 2986"
../source/print_tokens.c.inst.exe ../inputs/jk29     > ../newoutputs/t2986
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2985.tr
echo ">>>>>>>>running test 2987"
../source/print_tokens.c.inst.exe ../inputs/jk3     > ../newoutputs/t2987
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2986.tr
echo ">>>>>>>>running test 2988"
../source/print_tokens.c.inst.exe ../inputs/jk30     > ../newoutputs/t2988
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2987.tr
echo ">>>>>>>>running test 2989"
../source/print_tokens.c.inst.exe ../inputs/jk31     > ../newoutputs/t2989
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2988.tr
echo ">>>>>>>>running test 2990"
../source/print_tokens.c.inst.exe ../inputs/jk32     > ../newoutputs/t2990
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2989.tr
echo ">>>>>>>>running test 2991"
../source/print_tokens.c.inst.exe ../inputs/jk33     > ../newoutputs/t2991
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2990.tr
echo ">>>>>>>>running test 2992"
../source/print_tokens.c.inst.exe ../inputs/jk34     > ../newoutputs/t2992
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2991.tr
echo ">>>>>>>>running test 2993"
../source/print_tokens.c.inst.exe ../inputs/jk35     > ../newoutputs/t2993
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2992.tr
echo ">>>>>>>>running test 2994"
../source/print_tokens.c.inst.exe ../inputs/jk36     > ../newoutputs/t2994
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2993.tr
echo ">>>>>>>>running test 2995"
../source/print_tokens.c.inst.exe ../inputs/jk37     > ../newoutputs/t2995
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2994.tr
echo ">>>>>>>>running test 2996"
../source/print_tokens.c.inst.exe ../inputs/jk38     > ../newoutputs/t2996
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2995.tr
echo ">>>>>>>>running test 2997"
../source/print_tokens.c.inst.exe ../inputs/jk39     > ../newoutputs/t2997
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2996.tr
echo ">>>>>>>>running test 2998"
../source/print_tokens.c.inst.exe ../inputs/jk4     > ../newoutputs/t2998
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2997.tr
echo ">>>>>>>>running test 2999"
../source/print_tokens.c.inst.exe ../inputs/jk40     > ../newoutputs/t2999
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2998.tr
echo ">>>>>>>>running test 3000"
../source/print_tokens.c.inst.exe ../inputs/jk41     > ../newoutputs/t3000
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/2999.tr
echo ">>>>>>>>running test 3001"
../source/print_tokens.c.inst.exe ../inputs/jk42     > ../newoutputs/t3001
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3000.tr
echo ">>>>>>>>running test 3002"
../source/print_tokens.c.inst.exe ../inputs/jk43     > ../newoutputs/t3002
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3001.tr
echo ">>>>>>>>running test 3003"
../source/print_tokens.c.inst.exe ../inputs/jk44     > ../newoutputs/t3003
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3002.tr
echo ">>>>>>>>running test 3004"
../source/print_tokens.c.inst.exe ../inputs/jk45     > ../newoutputs/t3004
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3003.tr
echo ">>>>>>>>running test 3005"
../source/print_tokens.c.inst.exe ../inputs/jk46     > ../newoutputs/t3005
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3004.tr
echo ">>>>>>>>running test 3006"
../source/print_tokens.c.inst.exe ../inputs/jk47     > ../newoutputs/t3006
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3005.tr
echo ">>>>>>>>running test 3007"
../source/print_tokens.c.inst.exe ../inputs/jk48     > ../newoutputs/t3007
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3006.tr
echo ">>>>>>>>running test 3008"
../source/print_tokens.c.inst.exe ../inputs/jk49     > ../newoutputs/t3008
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3007.tr
echo ">>>>>>>>running test 3009"
../source/print_tokens.c.inst.exe ../inputs/jk5     > ../newoutputs/t3009
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3008.tr
echo ">>>>>>>>running test 3010"
../source/print_tokens.c.inst.exe ../inputs/jk50     > ../newoutputs/t3010
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3009.tr
echo ">>>>>>>>running test 3011"
../source/print_tokens.c.inst.exe ../inputs/jk6     > ../newoutputs/t3011
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3010.tr
echo ">>>>>>>>running test 3012"
../source/print_tokens.c.inst.exe ../inputs/jk7     > ../newoutputs/t3012
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3011.tr
echo ">>>>>>>>running test 3013"
../source/print_tokens.c.inst.exe ../inputs/jk8     > ../newoutputs/t3013
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3012.tr
echo ">>>>>>>>running test 3014"
../source/print_tokens.c.inst.exe ../inputs/jk9     > ../newoutputs/t3014
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3013.tr
echo ">>>>>>>>running test 3015"
../source/print_tokens.c.inst.exe ../inputs/newtst522.tst.noeof     > ../newoutputs/t3015
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3014.tr
echo ">>>>>>>>running test 3016"
../source/print_tokens.c.inst.exe ../inputs/tc240.noeof     > ../newoutputs/t3016
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3015.tr
echo ">>>>>>>>running test 3017"
../source/print_tokens.c.inst.exe ../inputs/test287.noeof     > ../newoutputs/t3017
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3016.tr
echo ">>>>>>>>running test 3018"
../source/print_tokens.c.inst.exe ../inputs/test330.noeof     > ../newoutputs/t3018
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3017.tr
echo ">>>>>>>>running test 3019"
../source/print_tokens.c.inst.exe ../inputs/test373.noeof     > ../newoutputs/t3019
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3018.tr
echo ">>>>>>>>running test 3020"
../source/print_tokens.c.inst.exe ../inputs/ts516.noeof     > ../newoutputs/t3020
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3019.tr
echo ">>>>>>>>running test 3021"
../source/print_tokens.c.inst.exe ../inputs/ts583.noeof     > ../newoutputs/t3021
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3020.tr
echo ">>>>>>>>running test 3022"
../source/print_tokens.c.inst.exe ../inputs/ts609.noeof     > ../newoutputs/t3022
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3021.tr
echo ">>>>>>>>running test 3023"
../source/print_tokens.c.inst.exe ../inputs/tst110.noeof     > ../newoutputs/t3023
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3022.tr
echo ">>>>>>>>running test 3024"
../source/print_tokens.c.inst.exe ../inputs/tst52.noeof     > ../newoutputs/t3024
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3023.tr
echo ">>>>>>>>running test 3025"
../source/print_tokens.c.inst.exe ../inputs/uslin.1     > ../newoutputs/t3025
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3024.tr
echo ">>>>>>>>running test 3026"
../source/print_tokens.c.inst.exe ../inputs/uslin.10     > ../newoutputs/t3026
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3025.tr
echo ">>>>>>>>running test 3027"
../source/print_tokens.c.inst.exe ../inputs/uslin.1000     > ../newoutputs/t3027
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3026.tr
echo ">>>>>>>>running test 3028"
../source/print_tokens.c.inst.exe ../inputs/uslin.1001     > ../newoutputs/t3028
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3027.tr
echo ">>>>>>>>running test 3029"
../source/print_tokens.c.inst.exe ../inputs/uslin.1003     > ../newoutputs/t3029
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3028.tr
echo ">>>>>>>>running test 3030"
../source/print_tokens.c.inst.exe ../inputs/uslin.1004     > ../newoutputs/t3030
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3029.tr
echo ">>>>>>>>running test 3031"
../source/print_tokens.c.inst.exe ../inputs/uslin.1005     > ../newoutputs/t3031
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3030.tr
echo ">>>>>>>>running test 3032"
../source/print_tokens.c.inst.exe ../inputs/uslin.1008     > ../newoutputs/t3032
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3031.tr
echo ">>>>>>>>running test 3033"
../source/print_tokens.c.inst.exe ../inputs/uslin.1009     > ../newoutputs/t3033
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3032.tr
echo ">>>>>>>>running test 3034"
../source/print_tokens.c.inst.exe ../inputs/uslin.1010     > ../newoutputs/t3034
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3033.tr
echo ">>>>>>>>running test 3035"
../source/print_tokens.c.inst.exe ../inputs/uslin.1014     > ../newoutputs/t3035
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3034.tr
echo ">>>>>>>>running test 3036"
../source/print_tokens.c.inst.exe ../inputs/uslin.1014.noeof     > ../newoutputs/t3036
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3035.tr
echo ">>>>>>>>running test 3037"
../source/print_tokens.c.inst.exe ../inputs/uslin.1015     > ../newoutputs/t3037
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3036.tr
echo ">>>>>>>>running test 3038"
../source/print_tokens.c.inst.exe ../inputs/uslin.1018     > ../newoutputs/t3038
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3037.tr
echo ">>>>>>>>running test 3039"
../source/print_tokens.c.inst.exe ../inputs/uslin.1020     > ../newoutputs/t3039
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3038.tr
echo ">>>>>>>>running test 3040"
../source/print_tokens.c.inst.exe ../inputs/uslin.1024     > ../newoutputs/t3040
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3039.tr
echo ">>>>>>>>running test 3041"
../source/print_tokens.c.inst.exe ../inputs/uslin.1025     > ../newoutputs/t3041
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3040.tr
echo ">>>>>>>>running test 3042"
../source/print_tokens.c.inst.exe ../inputs/uslin.1030     > ../newoutputs/t3042
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3041.tr
echo ">>>>>>>>running test 3043"
../source/print_tokens.c.inst.exe ../inputs/uslin.1031     > ../newoutputs/t3043
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3042.tr
echo ">>>>>>>>running test 3044"
../source/print_tokens.c.inst.exe ../inputs/uslin.1032     > ../newoutputs/t3044
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3043.tr
echo ">>>>>>>>running test 3045"
../source/print_tokens.c.inst.exe ../inputs/uslin.1034     > ../newoutputs/t3045
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3044.tr
echo ">>>>>>>>running test 3046"
../source/print_tokens.c.inst.exe ../inputs/uslin.1035     > ../newoutputs/t3046
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3045.tr
echo ">>>>>>>>running test 3047"
../source/print_tokens.c.inst.exe ../inputs/uslin.1036     > ../newoutputs/t3047
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3046.tr
echo ">>>>>>>>running test 3048"
../source/print_tokens.c.inst.exe ../inputs/uslin.1038     > ../newoutputs/t3048
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3047.tr
echo ">>>>>>>>running test 3049"
../source/print_tokens.c.inst.exe ../inputs/uslin.1038.noeof     > ../newoutputs/t3049
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3048.tr
echo ">>>>>>>>running test 3050"
../source/print_tokens.c.inst.exe ../inputs/uslin.1039     > ../newoutputs/t3050
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3049.tr
echo ">>>>>>>>running test 3051"
../source/print_tokens.c.inst.exe ../inputs/uslin.1040     > ../newoutputs/t3051
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3050.tr
echo ">>>>>>>>running test 3052"
../source/print_tokens.c.inst.exe ../inputs/uslin.1042     > ../newoutputs/t3052
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3051.tr
echo ">>>>>>>>running test 3053"
../source/print_tokens.c.inst.exe ../inputs/uslin.1043     > ../newoutputs/t3053
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3052.tr
echo ">>>>>>>>running test 3054"
../source/print_tokens.c.inst.exe ../inputs/uslin.1045     > ../newoutputs/t3054
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3053.tr
echo ">>>>>>>>running test 3055"
../source/print_tokens.c.inst.exe ../inputs/uslin.1046     > ../newoutputs/t3055
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3054.tr
echo ">>>>>>>>running test 3056"
../source/print_tokens.c.inst.exe ../inputs/uslin.1047     > ../newoutputs/t3056
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3055.tr
echo ">>>>>>>>running test 3057"
../source/print_tokens.c.inst.exe ../inputs/uslin.1048     > ../newoutputs/t3057
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3056.tr
echo ">>>>>>>>running test 3058"
../source/print_tokens.c.inst.exe ../inputs/uslin.1049     > ../newoutputs/t3058
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3057.tr
echo ">>>>>>>>running test 3059"
../source/print_tokens.c.inst.exe ../inputs/uslin.105     > ../newoutputs/t3059
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3058.tr
echo ">>>>>>>>running test 3060"
../source/print_tokens.c.inst.exe ../inputs/uslin.1050     > ../newoutputs/t3060
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3059.tr
echo ">>>>>>>>running test 3061"
../source/print_tokens.c.inst.exe ../inputs/uslin.1054     > ../newoutputs/t3061
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3060.tr
echo ">>>>>>>>running test 3062"
../source/print_tokens.c.inst.exe ../inputs/uslin.1057     > ../newoutputs/t3062
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3061.tr
echo ">>>>>>>>running test 3063"
../source/print_tokens.c.inst.exe ../inputs/uslin.1059     > ../newoutputs/t3063
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3062.tr
echo ">>>>>>>>running test 3064"
../source/print_tokens.c.inst.exe ../inputs/uslin.106     > ../newoutputs/t3064
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3063.tr
echo ">>>>>>>>running test 3065"
../source/print_tokens.c.inst.exe ../inputs/uslin.1061     > ../newoutputs/t3065
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3064.tr
echo ">>>>>>>>running test 3066"
../source/print_tokens.c.inst.exe ../inputs/uslin.1065     > ../newoutputs/t3066
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3065.tr
echo ">>>>>>>>running test 3067"
../source/print_tokens.c.inst.exe ../inputs/uslin.1067     > ../newoutputs/t3067
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3066.tr
echo ">>>>>>>>running test 3068"
../source/print_tokens.c.inst.exe ../inputs/uslin.1068     > ../newoutputs/t3068
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3067.tr
echo ">>>>>>>>running test 3069"
../source/print_tokens.c.inst.exe ../inputs/uslin.1069     > ../newoutputs/t3069
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3068.tr
echo ">>>>>>>>running test 3070"
../source/print_tokens.c.inst.exe ../inputs/uslin.107     > ../newoutputs/t3070
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3069.tr
echo ">>>>>>>>running test 3071"
../source/print_tokens.c.inst.exe ../inputs/uslin.1071     > ../newoutputs/t3071
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3070.tr
echo ">>>>>>>>running test 3072"
../source/print_tokens.c.inst.exe ../inputs/uslin.1074     > ../newoutputs/t3072
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3071.tr
echo ">>>>>>>>running test 3073"
../source/print_tokens.c.inst.exe ../inputs/uslin.1075     > ../newoutputs/t3073
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3072.tr
echo ">>>>>>>>running test 3074"
../source/print_tokens.c.inst.exe ../inputs/uslin.1076     > ../newoutputs/t3074
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3073.tr
echo ">>>>>>>>running test 3075"
../source/print_tokens.c.inst.exe ../inputs/uslin.1077     > ../newoutputs/t3075
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3074.tr
echo ">>>>>>>>running test 3076"
../source/print_tokens.c.inst.exe ../inputs/uslin.1078     > ../newoutputs/t3076
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3075.tr
echo ">>>>>>>>running test 3077"
../source/print_tokens.c.inst.exe ../inputs/uslin.1080     > ../newoutputs/t3077
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3076.tr
echo ">>>>>>>>running test 3078"
../source/print_tokens.c.inst.exe ../inputs/uslin.1082     > ../newoutputs/t3078
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3077.tr
echo ">>>>>>>>running test 3079"
../source/print_tokens.c.inst.exe ../inputs/uslin.1084     > ../newoutputs/t3079
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3078.tr
echo ">>>>>>>>running test 3080"
../source/print_tokens.c.inst.exe ../inputs/uslin.1085     > ../newoutputs/t3080
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3079.tr
echo ">>>>>>>>running test 3081"
../source/print_tokens.c.inst.exe ../inputs/uslin.109     > ../newoutputs/t3081
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3080.tr
echo ">>>>>>>>running test 3082"
../source/print_tokens.c.inst.exe ../inputs/uslin.1091     > ../newoutputs/t3082
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3081.tr
echo ">>>>>>>>running test 3083"
../source/print_tokens.c.inst.exe ../inputs/uslin.1092     > ../newoutputs/t3083
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3082.tr
echo ">>>>>>>>running test 3084"
../source/print_tokens.c.inst.exe ../inputs/uslin.1093     > ../newoutputs/t3084
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3083.tr
echo ">>>>>>>>running test 3085"
../source/print_tokens.c.inst.exe ../inputs/uslin.1094     > ../newoutputs/t3085
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3084.tr
echo ">>>>>>>>running test 3086"
../source/print_tokens.c.inst.exe ../inputs/uslin.1095     > ../newoutputs/t3086
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3085.tr
echo ">>>>>>>>running test 3087"
../source/print_tokens.c.inst.exe ../inputs/uslin.1096     > ../newoutputs/t3087
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3086.tr
echo ">>>>>>>>running test 3088"
../source/print_tokens.c.inst.exe ../inputs/uslin.1101     > ../newoutputs/t3088
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3087.tr
echo ">>>>>>>>running test 3089"
../source/print_tokens.c.inst.exe ../inputs/uslin.1103     > ../newoutputs/t3089
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3088.tr
echo ">>>>>>>>running test 3090"
../source/print_tokens.c.inst.exe ../inputs/uslin.1105     > ../newoutputs/t3090
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3089.tr
echo ">>>>>>>>running test 3091"
../source/print_tokens.c.inst.exe ../inputs/uslin.1109      > ../newoutputs/t3091
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3090.tr
echo ">>>>>>>>running test 3092"
../source/print_tokens.c.inst.exe ../inputs/uslin.111     > ../newoutputs/t3092
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3091.tr
echo ">>>>>>>>running test 3093"
../source/print_tokens.c.inst.exe ../inputs/uslin.1112     > ../newoutputs/t3093
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3092.tr
echo ">>>>>>>>running test 3094"
../source/print_tokens.c.inst.exe ../inputs/uslin.1113     > ../newoutputs/t3094
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3093.tr
echo ">>>>>>>>running test 3095"
../source/print_tokens.c.inst.exe ../inputs/uslin.1114     > ../newoutputs/t3095
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3094.tr
echo ">>>>>>>>running test 3096"
../source/print_tokens.c.inst.exe ../inputs/uslin.1115     > ../newoutputs/t3096
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3095.tr
echo ">>>>>>>>running test 3097"
../source/print_tokens.c.inst.exe ../inputs/uslin.1119     > ../newoutputs/t3097
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3096.tr
echo ">>>>>>>>running test 3098"
../source/print_tokens.c.inst.exe ../inputs/uslin.1120     > ../newoutputs/t3098
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3097.tr
echo ">>>>>>>>running test 3099"
../source/print_tokens.c.inst.exe ../inputs/uslin.1121     > ../newoutputs/t3099
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3098.tr
echo ">>>>>>>>running test 3100"
../source/print_tokens.c.inst.exe ../inputs/uslin.1124      > ../newoutputs/t3100
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3099.tr
echo ">>>>>>>>running test 3101"
../source/print_tokens.c.inst.exe ../inputs/uslin.1125     > ../newoutputs/t3101
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3100.tr
echo ">>>>>>>>running test 3102"
../source/print_tokens.c.inst.exe ../inputs/uslin.1126     > ../newoutputs/t3102
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3101.tr
echo ">>>>>>>>running test 3103"
../source/print_tokens.c.inst.exe ../inputs/uslin.1127     > ../newoutputs/t3103
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3102.tr
echo ">>>>>>>>running test 3104"
../source/print_tokens.c.inst.exe ../inputs/uslin.1130     > ../newoutputs/t3104
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3103.tr
echo ">>>>>>>>running test 3105"
../source/print_tokens.c.inst.exe ../inputs/uslin.1139     > ../newoutputs/t3105
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3104.tr
echo ">>>>>>>>running test 3106"
../source/print_tokens.c.inst.exe ../inputs/uslin.114     > ../newoutputs/t3106
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3105.tr
echo ">>>>>>>>running test 3107"
../source/print_tokens.c.inst.exe ../inputs/uslin.1140     > ../newoutputs/t3107
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3106.tr
echo ">>>>>>>>running test 3108"
../source/print_tokens.c.inst.exe ../inputs/uslin.1141     > ../newoutputs/t3108
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3107.tr
echo ">>>>>>>>running test 3109"
../source/print_tokens.c.inst.exe ../inputs/uslin.1142     > ../newoutputs/t3109
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3108.tr
echo ">>>>>>>>running test 3110"
../source/print_tokens.c.inst.exe ../inputs/uslin.1144     > ../newoutputs/t3110
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3109.tr
echo ">>>>>>>>running test 3111"
../source/print_tokens.c.inst.exe ../inputs/uslin.115     > ../newoutputs/t3111
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3110.tr
echo ">>>>>>>>running test 3112"
../source/print_tokens.c.inst.exe ../inputs/uslin.1155     > ../newoutputs/t3112
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3111.tr
echo ">>>>>>>>running test 3113"
../source/print_tokens.c.inst.exe ../inputs/uslin.1156      > ../newoutputs/t3113
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3112.tr
echo ">>>>>>>>running test 3114"
../source/print_tokens.c.inst.exe ../inputs/uslin.1159     > ../newoutputs/t3114
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3113.tr
echo ">>>>>>>>running test 3115"
../source/print_tokens.c.inst.exe ../inputs/uslin.1160     > ../newoutputs/t3115
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3114.tr
echo ">>>>>>>>running test 3116"
../source/print_tokens.c.inst.exe ../inputs/uslin.1162     > ../newoutputs/t3116
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3115.tr
echo ">>>>>>>>running test 3117"
../source/print_tokens.c.inst.exe ../inputs/uslin.1163     > ../newoutputs/t3117
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3116.tr
echo ">>>>>>>>running test 3118"
../source/print_tokens.c.inst.exe ../inputs/uslin.1165     > ../newoutputs/t3118
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3117.tr
echo ">>>>>>>>running test 3119"
../source/print_tokens.c.inst.exe ../inputs/uslin.1166     > ../newoutputs/t3119
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3118.tr
echo ">>>>>>>>running test 3120"
../source/print_tokens.c.inst.exe ../inputs/uslin.1167     > ../newoutputs/t3120
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3119.tr
echo ">>>>>>>>running test 3121"
../source/print_tokens.c.inst.exe ../inputs/uslin.117     > ../newoutputs/t3121
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3120.tr
echo ">>>>>>>>running test 3122"
../source/print_tokens.c.inst.exe ../inputs/uslin.1173     > ../newoutputs/t3122
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3121.tr
echo ">>>>>>>>running test 3123"
../source/print_tokens.c.inst.exe ../inputs/uslin.1174     > ../newoutputs/t3123
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3122.tr
echo ">>>>>>>>running test 3124"
../source/print_tokens.c.inst.exe ../inputs/uslin.1179     > ../newoutputs/t3124
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3123.tr
echo ">>>>>>>>running test 3125"
../source/print_tokens.c.inst.exe ../inputs/uslin.1180     > ../newoutputs/t3125
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3124.tr
echo ">>>>>>>>running test 3126"
../source/print_tokens.c.inst.exe ../inputs/uslin.1182     > ../newoutputs/t3126
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3125.tr
echo ">>>>>>>>running test 3127"
../source/print_tokens.c.inst.exe ../inputs/uslin.1184     > ../newoutputs/t3127
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3126.tr
echo ">>>>>>>>running test 3128"
../source/print_tokens.c.inst.exe ../inputs/uslin.1185     > ../newoutputs/t3128
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3127.tr
echo ">>>>>>>>running test 3129"
../source/print_tokens.c.inst.exe ../inputs/uslin.1186     > ../newoutputs/t3129
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3128.tr
echo ">>>>>>>>running test 3130"
../source/print_tokens.c.inst.exe ../inputs/uslin.1187     > ../newoutputs/t3130
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3129.tr
echo ">>>>>>>>running test 3131"
../source/print_tokens.c.inst.exe ../inputs/uslin.1189     > ../newoutputs/t3131
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3130.tr
echo ">>>>>>>>running test 3132"
../source/print_tokens.c.inst.exe ../inputs/uslin.119     > ../newoutputs/t3132
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3131.tr
echo ">>>>>>>>running test 3133"
../source/print_tokens.c.inst.exe ../inputs/uslin.1191     > ../newoutputs/t3133
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3132.tr
echo ">>>>>>>>running test 3134"
../source/print_tokens.c.inst.exe ../inputs/uslin.1192     > ../newoutputs/t3134
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3133.tr
echo ">>>>>>>>running test 3135"
../source/print_tokens.c.inst.exe ../inputs/uslin.1193     > ../newoutputs/t3135
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3134.tr
echo ">>>>>>>>running test 3136"
../source/print_tokens.c.inst.exe ../inputs/uslin.1196     > ../newoutputs/t3136
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3135.tr
echo ">>>>>>>>running test 3137"
../source/print_tokens.c.inst.exe ../inputs/uslin.1198     > ../newoutputs/t3137
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3136.tr
echo ">>>>>>>>running test 3138"
../source/print_tokens.c.inst.exe ../inputs/uslin.1200     > ../newoutputs/t3138
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3137.tr
echo ">>>>>>>>running test 3139"
../source/print_tokens.c.inst.exe ../inputs/uslin.1202     > ../newoutputs/t3139
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3138.tr
echo ">>>>>>>>running test 3140"
../source/print_tokens.c.inst.exe ../inputs/uslin.1206     > ../newoutputs/t3140
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3139.tr
echo ">>>>>>>>running test 3141"
../source/print_tokens.c.inst.exe ../inputs/uslin.1207     > ../newoutputs/t3141
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3140.tr
echo ">>>>>>>>running test 3142"
../source/print_tokens.c.inst.exe ../inputs/uslin.1209     > ../newoutputs/t3142
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3141.tr
echo ">>>>>>>>running test 3143"
../source/print_tokens.c.inst.exe ../inputs/uslin.121     > ../newoutputs/t3143
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3142.tr
echo ">>>>>>>>running test 3144"
../source/print_tokens.c.inst.exe ../inputs/uslin.1212     > ../newoutputs/t3144
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3143.tr
echo ">>>>>>>>running test 3145"
../source/print_tokens.c.inst.exe ../inputs/uslin.1217     > ../newoutputs/t3145
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3144.tr
echo ">>>>>>>>running test 3146"
../source/print_tokens.c.inst.exe ../inputs/uslin.1219     > ../newoutputs/t3146
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3145.tr
echo ">>>>>>>>running test 3147"
../source/print_tokens.c.inst.exe ../inputs/uslin.1224     > ../newoutputs/t3147
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3146.tr
echo ">>>>>>>>running test 3148"
../source/print_tokens.c.inst.exe ../inputs/uslin.1226     > ../newoutputs/t3148
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3147.tr
echo ">>>>>>>>running test 3149"
../source/print_tokens.c.inst.exe ../inputs/uslin.1233     > ../newoutputs/t3149
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3148.tr
echo ">>>>>>>>running test 3150"
../source/print_tokens.c.inst.exe ../inputs/uslin.1234     > ../newoutputs/t3150
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3149.tr
echo ">>>>>>>>running test 3151"
../source/print_tokens.c.inst.exe ../inputs/uslin.1235     > ../newoutputs/t3151
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3150.tr
echo ">>>>>>>>running test 3152"
../source/print_tokens.c.inst.exe ../inputs/uslin.1237     > ../newoutputs/t3152
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3151.tr
echo ">>>>>>>>running test 3153"
../source/print_tokens.c.inst.exe ../inputs/uslin.1239     > ../newoutputs/t3153
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3152.tr
echo ">>>>>>>>running test 3154"
../source/print_tokens.c.inst.exe ../inputs/uslin.1241     > ../newoutputs/t3154
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3153.tr
echo ">>>>>>>>running test 3155"
../source/print_tokens.c.inst.exe ../inputs/uslin.1243     > ../newoutputs/t3155
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3154.tr
echo ">>>>>>>>running test 3156"
../source/print_tokens.c.inst.exe ../inputs/uslin.1245     > ../newoutputs/t3156
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3155.tr
echo ">>>>>>>>running test 3157"
../source/print_tokens.c.inst.exe ../inputs/uslin.1246     > ../newoutputs/t3157
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3156.tr
echo ">>>>>>>>running test 3158"
../source/print_tokens.c.inst.exe ../inputs/uslin.1249     > ../newoutputs/t3158
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3157.tr
echo ">>>>>>>>running test 3159"
../source/print_tokens.c.inst.exe ../inputs/uslin.125     > ../newoutputs/t3159
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3158.tr
echo ">>>>>>>>running test 3160"
../source/print_tokens.c.inst.exe ../inputs/uslin.1250     > ../newoutputs/t3160
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3159.tr
echo ">>>>>>>>running test 3161"
../source/print_tokens.c.inst.exe ../inputs/uslin.1252     > ../newoutputs/t3161
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3160.tr
echo ">>>>>>>>running test 3162"
../source/print_tokens.c.inst.exe ../inputs/uslin.1253     > ../newoutputs/t3162
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3161.tr
echo ">>>>>>>>running test 3163"
../source/print_tokens.c.inst.exe ../inputs/uslin.1255      > ../newoutputs/t3163
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3162.tr
echo ">>>>>>>>running test 3164"
../source/print_tokens.c.inst.exe ../inputs/uslin.1256     > ../newoutputs/t3164
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3163.tr
echo ">>>>>>>>running test 3165"
../source/print_tokens.c.inst.exe ../inputs/uslin.1258     > ../newoutputs/t3165
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3164.tr
echo ">>>>>>>>running test 3166"
../source/print_tokens.c.inst.exe ../inputs/uslin.126     > ../newoutputs/t3166
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3165.tr
echo ">>>>>>>>running test 3167"
../source/print_tokens.c.inst.exe ../inputs/uslin.1260      > ../newoutputs/t3167
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3166.tr
echo ">>>>>>>>running test 3168"
../source/print_tokens.c.inst.exe ../inputs/uslin.1264     > ../newoutputs/t3168
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3167.tr
echo ">>>>>>>>running test 3169"
../source/print_tokens.c.inst.exe ../inputs/uslin.1265     > ../newoutputs/t3169
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3168.tr
echo ">>>>>>>>running test 3170"
../source/print_tokens.c.inst.exe ../inputs/uslin.1266     > ../newoutputs/t3170
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3169.tr
echo ">>>>>>>>running test 3171"
../source/print_tokens.c.inst.exe ../inputs/uslin.1267     > ../newoutputs/t3171
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3170.tr
echo ">>>>>>>>running test 3172"
../source/print_tokens.c.inst.exe ../inputs/uslin.1268     > ../newoutputs/t3172
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3171.tr
echo ">>>>>>>>running test 3173"
../source/print_tokens.c.inst.exe ../inputs/uslin.127     > ../newoutputs/t3173
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3172.tr
echo ">>>>>>>>running test 3174"
../source/print_tokens.c.inst.exe ../inputs/uslin.1270     > ../newoutputs/t3174
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3173.tr
echo ">>>>>>>>running test 3175"
../source/print_tokens.c.inst.exe ../inputs/uslin.1272     > ../newoutputs/t3175
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3174.tr
echo ">>>>>>>>running test 3176"
../source/print_tokens.c.inst.exe ../inputs/uslin.1276     > ../newoutputs/t3176
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3175.tr
echo ">>>>>>>>running test 3177"
../source/print_tokens.c.inst.exe ../inputs/uslin.1278     > ../newoutputs/t3177
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3176.tr
echo ">>>>>>>>running test 3178"
../source/print_tokens.c.inst.exe ../inputs/uslin.128     > ../newoutputs/t3178
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3177.tr
echo ">>>>>>>>running test 3179"
../source/print_tokens.c.inst.exe ../inputs/uslin.1281     > ../newoutputs/t3179
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3178.tr
echo ">>>>>>>>running test 3180"
../source/print_tokens.c.inst.exe ../inputs/uslin.1283     > ../newoutputs/t3180
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3179.tr
echo ">>>>>>>>running test 3181"
../source/print_tokens.c.inst.exe ../inputs/uslin.1287     > ../newoutputs/t3181
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3180.tr
echo ">>>>>>>>running test 3182"
../source/print_tokens.c.inst.exe ../inputs/uslin.1289     > ../newoutputs/t3182
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3181.tr
echo ">>>>>>>>running test 3183"
../source/print_tokens.c.inst.exe ../inputs/uslin.129     > ../newoutputs/t3183
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3182.tr
echo ">>>>>>>>running test 3184"
../source/print_tokens.c.inst.exe ../inputs/uslin.1290     > ../newoutputs/t3184
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3183.tr
echo ">>>>>>>>running test 3185"
../source/print_tokens.c.inst.exe ../inputs/uslin.1291     > ../newoutputs/t3185
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3184.tr
echo ">>>>>>>>running test 3186"
../source/print_tokens.c.inst.exe ../inputs/uslin.1292     > ../newoutputs/t3186
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3185.tr
echo ">>>>>>>>running test 3187"
../source/print_tokens.c.inst.exe ../inputs/uslin.1294     > ../newoutputs/t3187
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3186.tr
echo ">>>>>>>>running test 3188"
../source/print_tokens.c.inst.exe ../inputs/uslin.1298     > ../newoutputs/t3188
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3187.tr
echo ">>>>>>>>running test 3189"
../source/print_tokens.c.inst.exe ../inputs/uslin.1302     > ../newoutputs/t3189
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3188.tr
echo ">>>>>>>>running test 3190"
../source/print_tokens.c.inst.exe ../inputs/uslin.1303     > ../newoutputs/t3190
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3189.tr
echo ">>>>>>>>running test 3191"
../source/print_tokens.c.inst.exe ../inputs/uslin.1305     > ../newoutputs/t3191
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3190.tr
echo ">>>>>>>>running test 3192"
../source/print_tokens.c.inst.exe ../inputs/uslin.1306     > ../newoutputs/t3192
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3191.tr
echo ">>>>>>>>running test 3193"
../source/print_tokens.c.inst.exe ../inputs/uslin.131     > ../newoutputs/t3193
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3192.tr
echo ">>>>>>>>running test 3194"
../source/print_tokens.c.inst.exe ../inputs/uslin.1316     > ../newoutputs/t3194
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3193.tr
echo ">>>>>>>>running test 3195"
../source/print_tokens.c.inst.exe ../inputs/uslin.1317     > ../newoutputs/t3195
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3194.tr
echo ">>>>>>>>running test 3196"
../source/print_tokens.c.inst.exe ../inputs/uslin.132     > ../newoutputs/t3196
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3195.tr
echo ">>>>>>>>running test 3197"
../source/print_tokens.c.inst.exe ../inputs/uslin.1321     > ../newoutputs/t3197
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3196.tr
echo ">>>>>>>>running test 3198"
../source/print_tokens.c.inst.exe ../inputs/uslin.1322     > ../newoutputs/t3198
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3197.tr
echo ">>>>>>>>running test 3199"
../source/print_tokens.c.inst.exe ../inputs/uslin.1324     > ../newoutputs/t3199
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3198.tr
echo ">>>>>>>>running test 3200"
../source/print_tokens.c.inst.exe ../inputs/uslin.1325     > ../newoutputs/t3200
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3199.tr
echo ">>>>>>>>running test 3201"
../source/print_tokens.c.inst.exe ../inputs/uslin.1327     > ../newoutputs/t3201
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3200.tr
echo ">>>>>>>>running test 3202"
../source/print_tokens.c.inst.exe ../inputs/uslin.1328     > ../newoutputs/t3202
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3201.tr
echo ">>>>>>>>running test 3203"
../source/print_tokens.c.inst.exe ../inputs/uslin.1330     > ../newoutputs/t3203
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3202.tr
echo ">>>>>>>>running test 3204"
../source/print_tokens.c.inst.exe ../inputs/uslin.1333     > ../newoutputs/t3204
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3203.tr
echo ">>>>>>>>running test 3205"
../source/print_tokens.c.inst.exe ../inputs/uslin.1334     > ../newoutputs/t3205
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3204.tr
echo ">>>>>>>>running test 3206"
../source/print_tokens.c.inst.exe ../inputs/uslin.1335     > ../newoutputs/t3206
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3205.tr
echo ">>>>>>>>running test 3207"
../source/print_tokens.c.inst.exe ../inputs/uslin.1337     > ../newoutputs/t3207
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3206.tr
echo ">>>>>>>>running test 3208"
../source/print_tokens.c.inst.exe ../inputs/uslin.1339     > ../newoutputs/t3208
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3207.tr
echo ">>>>>>>>running test 3209"
../source/print_tokens.c.inst.exe ../inputs/uslin.134     > ../newoutputs/t3209
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3208.tr
echo ">>>>>>>>running test 3210"
../source/print_tokens.c.inst.exe ../inputs/uslin.1340     > ../newoutputs/t3210
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3209.tr
echo ">>>>>>>>running test 3211"
../source/print_tokens.c.inst.exe ../inputs/uslin.1341     > ../newoutputs/t3211
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3210.tr
echo ">>>>>>>>running test 3212"
../source/print_tokens.c.inst.exe ../inputs/uslin.1342     > ../newoutputs/t3212
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3211.tr
echo ">>>>>>>>running test 3213"
../source/print_tokens.c.inst.exe ../inputs/uslin.1346     > ../newoutputs/t3213
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3212.tr
echo ">>>>>>>>running test 3214"
../source/print_tokens.c.inst.exe ../inputs/uslin.1348     > ../newoutputs/t3214
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3213.tr
echo ">>>>>>>>running test 3215"
../source/print_tokens.c.inst.exe ../inputs/uslin.1352     > ../newoutputs/t3215
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3214.tr
echo ">>>>>>>>running test 3216"
../source/print_tokens.c.inst.exe ../inputs/uslin.1353     > ../newoutputs/t3216
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3215.tr
echo ">>>>>>>>running test 3217"
../source/print_tokens.c.inst.exe ../inputs/uslin.1354     > ../newoutputs/t3217
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3216.tr
echo ">>>>>>>>running test 3218"
../source/print_tokens.c.inst.exe ../inputs/uslin.1358     > ../newoutputs/t3218
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3217.tr
echo ">>>>>>>>running test 3219"
../source/print_tokens.c.inst.exe ../inputs/uslin.1359     > ../newoutputs/t3219
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3218.tr
echo ">>>>>>>>running test 3220"
../source/print_tokens.c.inst.exe ../inputs/uslin.1364     > ../newoutputs/t3220
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3219.tr
echo ">>>>>>>>running test 3221"
../source/print_tokens.c.inst.exe ../inputs/uslin.1368     > ../newoutputs/t3221
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3220.tr
echo ">>>>>>>>running test 3222"
../source/print_tokens.c.inst.exe ../inputs/uslin.137     > ../newoutputs/t3222
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3221.tr
echo ">>>>>>>>running test 3223"
../source/print_tokens.c.inst.exe ../inputs/uslin.1370     > ../newoutputs/t3223
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3222.tr
echo ">>>>>>>>running test 3224"
../source/print_tokens.c.inst.exe ../inputs/uslin.1371     > ../newoutputs/t3224
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3223.tr
echo ">>>>>>>>running test 3225"
../source/print_tokens.c.inst.exe ../inputs/uslin.1373     > ../newoutputs/t3225
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3224.tr
echo ">>>>>>>>running test 3226"
../source/print_tokens.c.inst.exe ../inputs/uslin.1374     > ../newoutputs/t3226
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3225.tr
echo ">>>>>>>>running test 3227"
../source/print_tokens.c.inst.exe ../inputs/uslin.1375     > ../newoutputs/t3227
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3226.tr
echo ">>>>>>>>running test 3228"
../source/print_tokens.c.inst.exe ../inputs/uslin.1376     > ../newoutputs/t3228
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3227.tr
echo ">>>>>>>>running test 3229"
../source/print_tokens.c.inst.exe ../inputs/uslin.1378     > ../newoutputs/t3229
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3228.tr
echo ">>>>>>>>running test 3230"
../source/print_tokens.c.inst.exe ../inputs/uslin.1379     > ../newoutputs/t3230
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3229.tr
echo ">>>>>>>>running test 3231"
../source/print_tokens.c.inst.exe ../inputs/uslin.138     > ../newoutputs/t3231
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3230.tr
echo ">>>>>>>>running test 3232"
../source/print_tokens.c.inst.exe ../inputs/uslin.1380     > ../newoutputs/t3232
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3231.tr
echo ">>>>>>>>running test 3233"
../source/print_tokens.c.inst.exe ../inputs/uslin.1384     > ../newoutputs/t3233
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3232.tr
echo ">>>>>>>>running test 3234"
../source/print_tokens.c.inst.exe ../inputs/uslin.1385     > ../newoutputs/t3234
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3233.tr
echo ">>>>>>>>running test 3235"
../source/print_tokens.c.inst.exe ../inputs/uslin.1386     > ../newoutputs/t3235
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3234.tr
echo ">>>>>>>>running test 3236"
../source/print_tokens.c.inst.exe ../inputs/uslin.1389     > ../newoutputs/t3236
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3235.tr
echo ">>>>>>>>running test 3237"
../source/print_tokens.c.inst.exe ../inputs/uslin.139     > ../newoutputs/t3237
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3236.tr
echo ">>>>>>>>running test 3238"
../source/print_tokens.c.inst.exe ../inputs/uslin.1390     > ../newoutputs/t3238
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3237.tr
echo ">>>>>>>>running test 3239"
../source/print_tokens.c.inst.exe ../inputs/uslin.1391     > ../newoutputs/t3239
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3238.tr
echo ">>>>>>>>running test 3240"
../source/print_tokens.c.inst.exe ../inputs/uslin.1394     > ../newoutputs/t3240
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3239.tr
echo ">>>>>>>>running test 3241"
../source/print_tokens.c.inst.exe ../inputs/uslin.1395     > ../newoutputs/t3241
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3240.tr
echo ">>>>>>>>running test 3242"
../source/print_tokens.c.inst.exe ../inputs/uslin.1398     > ../newoutputs/t3242
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3241.tr
echo ">>>>>>>>running test 3243"
../source/print_tokens.c.inst.exe ../inputs/uslin.1399     > ../newoutputs/t3243
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3242.tr
echo ">>>>>>>>running test 3244"
../source/print_tokens.c.inst.exe ../inputs/uslin.14     > ../newoutputs/t3244
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3243.tr
echo ">>>>>>>>running test 3245"
../source/print_tokens.c.inst.exe ../inputs/uslin.1401     > ../newoutputs/t3245
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3244.tr
echo ">>>>>>>>running test 3246"
../source/print_tokens.c.inst.exe ../inputs/uslin.1402     > ../newoutputs/t3246
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3245.tr
echo ">>>>>>>>running test 3247"
../source/print_tokens.c.inst.exe ../inputs/uslin.1403     > ../newoutputs/t3247
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3246.tr
echo ">>>>>>>>running test 3248"
../source/print_tokens.c.inst.exe ../inputs/uslin.1406     > ../newoutputs/t3248
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3247.tr
echo ">>>>>>>>running test 3249"
../source/print_tokens.c.inst.exe ../inputs/uslin.1407     > ../newoutputs/t3249
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3248.tr
echo ">>>>>>>>running test 3250"
../source/print_tokens.c.inst.exe ../inputs/uslin.141     > ../newoutputs/t3250
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3249.tr
echo ">>>>>>>>running test 3251"
../source/print_tokens.c.inst.exe ../inputs/uslin.1411     > ../newoutputs/t3251
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3250.tr
echo ">>>>>>>>running test 3252"
../source/print_tokens.c.inst.exe ../inputs/uslin.1412     > ../newoutputs/t3252
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3251.tr
echo ">>>>>>>>running test 3253"
../source/print_tokens.c.inst.exe ../inputs/uslin.1414     > ../newoutputs/t3253
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3252.tr
echo ">>>>>>>>running test 3254"
../source/print_tokens.c.inst.exe ../inputs/uslin.1416     > ../newoutputs/t3254
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3253.tr
echo ">>>>>>>>running test 3255"
../source/print_tokens.c.inst.exe ../inputs/uslin.1417     > ../newoutputs/t3255
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3254.tr
echo ">>>>>>>>running test 3256"
../source/print_tokens.c.inst.exe ../inputs/uslin.1418      > ../newoutputs/t3256
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3255.tr
echo ">>>>>>>>running test 3257"
../source/print_tokens.c.inst.exe ../inputs/uslin.1419     > ../newoutputs/t3257
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3256.tr
echo ">>>>>>>>running test 3258"
../source/print_tokens.c.inst.exe ../inputs/uslin.1422     > ../newoutputs/t3258
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3257.tr
echo ">>>>>>>>running test 3259"
../source/print_tokens.c.inst.exe ../inputs/uslin.1423     > ../newoutputs/t3259
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3258.tr
echo ">>>>>>>>running test 3260"
../source/print_tokens.c.inst.exe ../inputs/uslin.1426     > ../newoutputs/t3260
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3259.tr
echo ">>>>>>>>running test 3261"
../source/print_tokens.c.inst.exe ../inputs/uslin.1427     > ../newoutputs/t3261
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3260.tr
echo ">>>>>>>>running test 3262"
../source/print_tokens.c.inst.exe ../inputs/uslin.1428     > ../newoutputs/t3262
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3261.tr
echo ">>>>>>>>running test 3263"
../source/print_tokens.c.inst.exe ../inputs/uslin.1431     > ../newoutputs/t3263
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3262.tr
echo ">>>>>>>>running test 3264"
../source/print_tokens.c.inst.exe ../inputs/uslin.1432     > ../newoutputs/t3264
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3263.tr
echo ">>>>>>>>running test 3265"
../source/print_tokens.c.inst.exe ../inputs/uslin.1433     > ../newoutputs/t3265
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3264.tr
echo ">>>>>>>>running test 3266"
../source/print_tokens.c.inst.exe ../inputs/uslin.1434     > ../newoutputs/t3266
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3265.tr
echo ">>>>>>>>running test 3267"
../source/print_tokens.c.inst.exe ../inputs/uslin.1435     > ../newoutputs/t3267
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3266.tr
echo ">>>>>>>>running test 3268"
../source/print_tokens.c.inst.exe ../inputs/uslin.1436     > ../newoutputs/t3268
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3267.tr
echo ">>>>>>>>running test 3269"
../source/print_tokens.c.inst.exe ../inputs/uslin.144     > ../newoutputs/t3269
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3268.tr
echo ">>>>>>>>running test 3270"
../source/print_tokens.c.inst.exe ../inputs/uslin.1440     > ../newoutputs/t3270
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3269.tr
echo ">>>>>>>>running test 3271"
../source/print_tokens.c.inst.exe ../inputs/uslin.1444     > ../newoutputs/t3271
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3270.tr
echo ">>>>>>>>running test 3272"
../source/print_tokens.c.inst.exe ../inputs/uslin.1445     > ../newoutputs/t3272
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3271.tr
echo ">>>>>>>>running test 3273"
../source/print_tokens.c.inst.exe ../inputs/uslin.1446     > ../newoutputs/t3273
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3272.tr
echo ">>>>>>>>running test 3274"
../source/print_tokens.c.inst.exe ../inputs/uslin.1447     > ../newoutputs/t3274
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3273.tr
echo ">>>>>>>>running test 3275"
../source/print_tokens.c.inst.exe ../inputs/uslin.1448     > ../newoutputs/t3275
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3274.tr
echo ">>>>>>>>running test 3276"
../source/print_tokens.c.inst.exe ../inputs/uslin.1449     > ../newoutputs/t3276
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3275.tr
echo ">>>>>>>>running test 3277"
../source/print_tokens.c.inst.exe ../inputs/uslin.1450     > ../newoutputs/t3277
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3276.tr
echo ">>>>>>>>running test 3278"
../source/print_tokens.c.inst.exe ../inputs/uslin.1451     > ../newoutputs/t3278
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3277.tr
echo ">>>>>>>>running test 3279"
../source/print_tokens.c.inst.exe ../inputs/uslin.1452     > ../newoutputs/t3279
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3278.tr
echo ">>>>>>>>running test 3280"
../source/print_tokens.c.inst.exe ../inputs/uslin.1453     > ../newoutputs/t3280
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3279.tr
echo ">>>>>>>>running test 3281"
../source/print_tokens.c.inst.exe ../inputs/uslin.1454     > ../newoutputs/t3281
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3280.tr
echo ">>>>>>>>running test 3282"
../source/print_tokens.c.inst.exe ../inputs/uslin.1456     > ../newoutputs/t3282
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3281.tr
echo ">>>>>>>>running test 3283"
../source/print_tokens.c.inst.exe ../inputs/uslin.1458     > ../newoutputs/t3283
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3282.tr
echo ">>>>>>>>running test 3284"
../source/print_tokens.c.inst.exe ../inputs/uslin.146     > ../newoutputs/t3284
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3283.tr
echo ">>>>>>>>running test 3285"
../source/print_tokens.c.inst.exe ../inputs/uslin.1460     > ../newoutputs/t3285
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3284.tr
echo ">>>>>>>>running test 3286"
../source/print_tokens.c.inst.exe ../inputs/uslin.1462     > ../newoutputs/t3286
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3285.tr
echo ">>>>>>>>running test 3287"
../source/print_tokens.c.inst.exe ../inputs/uslin.1463     > ../newoutputs/t3287
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3286.tr
echo ">>>>>>>>running test 3288"
../source/print_tokens.c.inst.exe ../inputs/uslin.1464     > ../newoutputs/t3288
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3287.tr
echo ">>>>>>>>running test 3289"
../source/print_tokens.c.inst.exe ../inputs/uslin.1465     > ../newoutputs/t3289
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3288.tr
echo ">>>>>>>>running test 3290"
../source/print_tokens.c.inst.exe ../inputs/uslin.1466     > ../newoutputs/t3290
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3289.tr
echo ">>>>>>>>running test 3291"
../source/print_tokens.c.inst.exe ../inputs/uslin.1467     > ../newoutputs/t3291
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3290.tr
echo ">>>>>>>>running test 3292"
../source/print_tokens.c.inst.exe ../inputs/uslin.1471     > ../newoutputs/t3292
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3291.tr
echo ">>>>>>>>running test 3293"
../source/print_tokens.c.inst.exe ../inputs/uslin.1472     > ../newoutputs/t3293
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3292.tr
echo ">>>>>>>>running test 3294"
../source/print_tokens.c.inst.exe ../inputs/uslin.1473     > ../newoutputs/t3294
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3293.tr
echo ">>>>>>>>running test 3295"
../source/print_tokens.c.inst.exe ../inputs/uslin.1474     > ../newoutputs/t3295
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3294.tr
echo ">>>>>>>>running test 3296"
../source/print_tokens.c.inst.exe ../inputs/uslin.1477     > ../newoutputs/t3296
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3295.tr
echo ">>>>>>>>running test 3297"
../source/print_tokens.c.inst.exe ../inputs/uslin.1478     > ../newoutputs/t3297
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3296.tr
echo ">>>>>>>>running test 3298"
../source/print_tokens.c.inst.exe ../inputs/uslin.1479     > ../newoutputs/t3298
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3297.tr
echo ">>>>>>>>running test 3299"
../source/print_tokens.c.inst.exe ../inputs/uslin.148     > ../newoutputs/t3299
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3298.tr
echo ">>>>>>>>running test 3300"
../source/print_tokens.c.inst.exe ../inputs/uslin.1481     > ../newoutputs/t3300
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3299.tr
echo ">>>>>>>>running test 3301"
../source/print_tokens.c.inst.exe ../inputs/uslin.1482     > ../newoutputs/t3301
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3300.tr
echo ">>>>>>>>running test 3302"
../source/print_tokens.c.inst.exe ../inputs/uslin.1484     > ../newoutputs/t3302
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3301.tr
echo ">>>>>>>>running test 3303"
../source/print_tokens.c.inst.exe ../inputs/uslin.1485     > ../newoutputs/t3303
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3302.tr
echo ">>>>>>>>running test 3304"
../source/print_tokens.c.inst.exe ../inputs/uslin.1487     > ../newoutputs/t3304
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3303.tr
echo ">>>>>>>>running test 3305"
../source/print_tokens.c.inst.exe ../inputs/uslin.1488     > ../newoutputs/t3305
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3304.tr
echo ">>>>>>>>running test 3306"
../source/print_tokens.c.inst.exe ../inputs/uslin.1489     > ../newoutputs/t3306
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3305.tr
echo ">>>>>>>>running test 3307"
../source/print_tokens.c.inst.exe ../inputs/uslin.149     > ../newoutputs/t3307
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3306.tr
echo ">>>>>>>>running test 3308"
../source/print_tokens.c.inst.exe ../inputs/uslin.1495     > ../newoutputs/t3308
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3307.tr
echo ">>>>>>>>running test 3309"
../source/print_tokens.c.inst.exe ../inputs/uslin.1498     > ../newoutputs/t3309
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3308.tr
echo ">>>>>>>>running test 3310"
../source/print_tokens.c.inst.exe ../inputs/uslin.1499     > ../newoutputs/t3310
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3309.tr
echo ">>>>>>>>running test 3311"
../source/print_tokens.c.inst.exe ../inputs/uslin.150     > ../newoutputs/t3311
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3310.tr
echo ">>>>>>>>running test 3312"
../source/print_tokens.c.inst.exe ../inputs/uslin.1500     > ../newoutputs/t3312
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3311.tr
echo ">>>>>>>>running test 3313"
../source/print_tokens.c.inst.exe ../inputs/uslin.1503     > ../newoutputs/t3313
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3312.tr
echo ">>>>>>>>running test 3314"
../source/print_tokens.c.inst.exe ../inputs/uslin.1505     > ../newoutputs/t3314
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3313.tr
echo ">>>>>>>>running test 3315"
../source/print_tokens.c.inst.exe ../inputs/uslin.1506     > ../newoutputs/t3315
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3314.tr
echo ">>>>>>>>running test 3316"
../source/print_tokens.c.inst.exe ../inputs/uslin.1507     > ../newoutputs/t3316
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3315.tr
echo ">>>>>>>>running test 3317"
../source/print_tokens.c.inst.exe ../inputs/uslin.1508     > ../newoutputs/t3317
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3316.tr
echo ">>>>>>>>running test 3318"
../source/print_tokens.c.inst.exe ../inputs/uslin.1511     > ../newoutputs/t3318
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3317.tr
echo ">>>>>>>>running test 3319"
../source/print_tokens.c.inst.exe ../inputs/uslin.1512     > ../newoutputs/t3319
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3318.tr
echo ">>>>>>>>running test 3320"
../source/print_tokens.c.inst.exe ../inputs/uslin.1513     > ../newoutputs/t3320
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3319.tr
echo ">>>>>>>>running test 3321"
../source/print_tokens.c.inst.exe ../inputs/uslin.1514     > ../newoutputs/t3321
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3320.tr
echo ">>>>>>>>running test 3322"
../source/print_tokens.c.inst.exe ../inputs/uslin.1515     > ../newoutputs/t3322
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3321.tr
echo ">>>>>>>>running test 3323"
../source/print_tokens.c.inst.exe ../inputs/uslin.152      > ../newoutputs/t3323
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3322.tr
echo ">>>>>>>>running test 3324"
../source/print_tokens.c.inst.exe ../inputs/uslin.1520     > ../newoutputs/t3324
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3323.tr
echo ">>>>>>>>running test 3325"
../source/print_tokens.c.inst.exe ../inputs/uslin.1521     > ../newoutputs/t3325
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3324.tr
echo ">>>>>>>>running test 3326"
../source/print_tokens.c.inst.exe ../inputs/uslin.1522      > ../newoutputs/t3326
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3325.tr
echo ">>>>>>>>running test 3327"
../source/print_tokens.c.inst.exe ../inputs/uslin.1523     > ../newoutputs/t3327
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3326.tr
echo ">>>>>>>>running test 3328"
../source/print_tokens.c.inst.exe ../inputs/uslin.1528     > ../newoutputs/t3328
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3327.tr
echo ">>>>>>>>running test 3329"
../source/print_tokens.c.inst.exe ../inputs/uslin.1531     > ../newoutputs/t3329
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3328.tr
echo ">>>>>>>>running test 3330"
../source/print_tokens.c.inst.exe ../inputs/uslin.1533     > ../newoutputs/t3330
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3329.tr
echo ">>>>>>>>running test 3331"
../source/print_tokens.c.inst.exe ../inputs/uslin.1535     > ../newoutputs/t3331
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3330.tr
echo ">>>>>>>>running test 3332"
../source/print_tokens.c.inst.exe ../inputs/uslin.1536     > ../newoutputs/t3332
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3331.tr
echo ">>>>>>>>running test 3333"
../source/print_tokens.c.inst.exe ../inputs/uslin.1537     > ../newoutputs/t3333
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3332.tr
echo ">>>>>>>>running test 3334"
../source/print_tokens.c.inst.exe ../inputs/uslin.1540     > ../newoutputs/t3334
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3333.tr
echo ">>>>>>>>running test 3335"
../source/print_tokens.c.inst.exe ../inputs/uslin.1543     > ../newoutputs/t3335
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3334.tr
echo ">>>>>>>>running test 3336"
../source/print_tokens.c.inst.exe ../inputs/uslin.1544     > ../newoutputs/t3336
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3335.tr
echo ">>>>>>>>running test 3337"
../source/print_tokens.c.inst.exe ../inputs/uslin.1545     > ../newoutputs/t3337
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3336.tr
echo ">>>>>>>>running test 3338"
../source/print_tokens.c.inst.exe ../inputs/uslin.1547      > ../newoutputs/t3338
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3337.tr
echo ">>>>>>>>running test 3339"
../source/print_tokens.c.inst.exe ../inputs/uslin.1548     > ../newoutputs/t3339
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3338.tr
echo ">>>>>>>>running test 3340"
../source/print_tokens.c.inst.exe ../inputs/uslin.1550     > ../newoutputs/t3340
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3339.tr
echo ">>>>>>>>running test 3341"
../source/print_tokens.c.inst.exe ../inputs/uslin.1552     > ../newoutputs/t3341
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3340.tr
echo ">>>>>>>>running test 3342"
../source/print_tokens.c.inst.exe ../inputs/uslin.1553     > ../newoutputs/t3342
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3341.tr
echo ">>>>>>>>running test 3343"
../source/print_tokens.c.inst.exe ../inputs/uslin.1555     > ../newoutputs/t3343
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3342.tr
echo ">>>>>>>>running test 3344"
../source/print_tokens.c.inst.exe ../inputs/uslin.1558     > ../newoutputs/t3344
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3343.tr
echo ">>>>>>>>running test 3345"
../source/print_tokens.c.inst.exe ../inputs/uslin.156     > ../newoutputs/t3345
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3344.tr
echo ">>>>>>>>running test 3346"
../source/print_tokens.c.inst.exe ../inputs/uslin.1560     > ../newoutputs/t3346
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3345.tr
echo ">>>>>>>>running test 3347"
../source/print_tokens.c.inst.exe ../inputs/uslin.1561     > ../newoutputs/t3347
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3346.tr
echo ">>>>>>>>running test 3348"
../source/print_tokens.c.inst.exe ../inputs/uslin.1564     > ../newoutputs/t3348
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3347.tr
echo ">>>>>>>>running test 3349"
../source/print_tokens.c.inst.exe ../inputs/uslin.1568     > ../newoutputs/t3349
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3348.tr
echo ">>>>>>>>running test 3350"
../source/print_tokens.c.inst.exe ../inputs/uslin.1571     > ../newoutputs/t3350
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3349.tr
echo ">>>>>>>>running test 3351"
../source/print_tokens.c.inst.exe ../inputs/uslin.1573     > ../newoutputs/t3351
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3350.tr
echo ">>>>>>>>running test 3352"
../source/print_tokens.c.inst.exe ../inputs/uslin.1574     > ../newoutputs/t3352
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3351.tr
echo ">>>>>>>>running test 3353"
../source/print_tokens.c.inst.exe ../inputs/uslin.1575      > ../newoutputs/t3353
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3352.tr
echo ">>>>>>>>running test 3354"
../source/print_tokens.c.inst.exe ../inputs/uslin.1577     > ../newoutputs/t3354
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3353.tr
echo ">>>>>>>>running test 3355"
../source/print_tokens.c.inst.exe ../inputs/uslin.158     > ../newoutputs/t3355
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3354.tr
echo ">>>>>>>>running test 3356"
../source/print_tokens.c.inst.exe ../inputs/uslin.1580     > ../newoutputs/t3356
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3355.tr
echo ">>>>>>>>running test 3357"
../source/print_tokens.c.inst.exe ../inputs/uslin.1581     > ../newoutputs/t3357
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3356.tr
echo ">>>>>>>>running test 3358"
../source/print_tokens.c.inst.exe ../inputs/uslin.1582     > ../newoutputs/t3358
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3357.tr
echo ">>>>>>>>running test 3359"
../source/print_tokens.c.inst.exe ../inputs/uslin.1583      > ../newoutputs/t3359
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3358.tr
echo ">>>>>>>>running test 3360"
../source/print_tokens.c.inst.exe ../inputs/uslin.1585     > ../newoutputs/t3360
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3359.tr
echo ">>>>>>>>running test 3361"
../source/print_tokens.c.inst.exe ../inputs/uslin.1586      > ../newoutputs/t3361
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3360.tr
echo ">>>>>>>>running test 3362"
../source/print_tokens.c.inst.exe ../inputs/uslin.159     > ../newoutputs/t3362
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3361.tr
echo ">>>>>>>>running test 3363"
../source/print_tokens.c.inst.exe ../inputs/uslin.1590     > ../newoutputs/t3363
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3362.tr
echo ">>>>>>>>running test 3364"
../source/print_tokens.c.inst.exe ../inputs/uslin.1591     > ../newoutputs/t3364
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3363.tr
echo ">>>>>>>>running test 3365"
../source/print_tokens.c.inst.exe ../inputs/uslin.1592     > ../newoutputs/t3365
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3364.tr
echo ">>>>>>>>running test 3366"
../source/print_tokens.c.inst.exe ../inputs/uslin.1594     > ../newoutputs/t3366
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3365.tr
echo ">>>>>>>>running test 3367"
../source/print_tokens.c.inst.exe ../inputs/uslin.1595      > ../newoutputs/t3367
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3366.tr
echo ">>>>>>>>running test 3368"
../source/print_tokens.c.inst.exe ../inputs/uslin.1597     > ../newoutputs/t3368
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3367.tr
echo ">>>>>>>>running test 3369"
../source/print_tokens.c.inst.exe ../inputs/uslin.1601     > ../newoutputs/t3369
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3368.tr
echo ">>>>>>>>running test 3370"
../source/print_tokens.c.inst.exe ../inputs/uslin.1602     > ../newoutputs/t3370
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3369.tr
echo ">>>>>>>>running test 3371"
../source/print_tokens.c.inst.exe ../inputs/uslin.1603     > ../newoutputs/t3371
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3370.tr
echo ">>>>>>>>running test 3372"
../source/print_tokens.c.inst.exe ../inputs/uslin.1606     > ../newoutputs/t3372
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3371.tr
echo ">>>>>>>>running test 3373"
../source/print_tokens.c.inst.exe ../inputs/uslin.1607     > ../newoutputs/t3373
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3372.tr
echo ">>>>>>>>running test 3374"
../source/print_tokens.c.inst.exe ../inputs/uslin.1608     > ../newoutputs/t3374
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3373.tr
echo ">>>>>>>>running test 3375"
../source/print_tokens.c.inst.exe ../inputs/uslin.1610      > ../newoutputs/t3375
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3374.tr
echo ">>>>>>>>running test 3376"
../source/print_tokens.c.inst.exe ../inputs/uslin.1614     > ../newoutputs/t3376
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3375.tr
echo ">>>>>>>>running test 3377"
../source/print_tokens.c.inst.exe ../inputs/uslin.1617     > ../newoutputs/t3377
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3376.tr
echo ">>>>>>>>running test 3378"
../source/print_tokens.c.inst.exe ../inputs/uslin.1618     > ../newoutputs/t3378
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3377.tr
echo ">>>>>>>>running test 3379"
../source/print_tokens.c.inst.exe ../inputs/uslin.1619     > ../newoutputs/t3379
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3378.tr
echo ">>>>>>>>running test 3380"
../source/print_tokens.c.inst.exe ../inputs/uslin.1620     > ../newoutputs/t3380
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3379.tr
echo ">>>>>>>>running test 3381"
../source/print_tokens.c.inst.exe ../inputs/uslin.1623     > ../newoutputs/t3381
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3380.tr
echo ">>>>>>>>running test 3382"
../source/print_tokens.c.inst.exe ../inputs/uslin.1624     > ../newoutputs/t3382
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3381.tr
echo ">>>>>>>>running test 3383"
../source/print_tokens.c.inst.exe ../inputs/uslin.1625     > ../newoutputs/t3383
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3382.tr
echo ">>>>>>>>running test 3384"
../source/print_tokens.c.inst.exe ../inputs/uslin.1626      > ../newoutputs/t3384
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3383.tr
echo ">>>>>>>>running test 3385"
../source/print_tokens.c.inst.exe ../inputs/uslin.1629     > ../newoutputs/t3385
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3384.tr
echo ">>>>>>>>running test 3386"
../source/print_tokens.c.inst.exe ../inputs/uslin.1630     > ../newoutputs/t3386
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3385.tr
echo ">>>>>>>>running test 3387"
../source/print_tokens.c.inst.exe ../inputs/uslin.1631     > ../newoutputs/t3387
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3386.tr
echo ">>>>>>>>running test 3388"
../source/print_tokens.c.inst.exe ../inputs/uslin.1632     > ../newoutputs/t3388
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3387.tr
echo ">>>>>>>>running test 3389"
../source/print_tokens.c.inst.exe ../inputs/uslin.1634     > ../newoutputs/t3389
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3388.tr
echo ">>>>>>>>running test 3390"
../source/print_tokens.c.inst.exe ../inputs/uslin.1635     > ../newoutputs/t3390
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3389.tr
echo ">>>>>>>>running test 3391"
../source/print_tokens.c.inst.exe ../inputs/uslin.1637     > ../newoutputs/t3391
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3390.tr
echo ">>>>>>>>running test 3392"
../source/print_tokens.c.inst.exe ../inputs/uslin.1638     > ../newoutputs/t3392
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3391.tr
echo ">>>>>>>>running test 3393"
../source/print_tokens.c.inst.exe ../inputs/uslin.1641     > ../newoutputs/t3393
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3392.tr
echo ">>>>>>>>running test 3394"
../source/print_tokens.c.inst.exe ../inputs/uslin.1644     > ../newoutputs/t3394
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3393.tr
echo ">>>>>>>>running test 3395"
../source/print_tokens.c.inst.exe ../inputs/uslin.1645     > ../newoutputs/t3395
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3394.tr
echo ">>>>>>>>running test 3396"
../source/print_tokens.c.inst.exe ../inputs/uslin.1646     > ../newoutputs/t3396
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3395.tr
echo ">>>>>>>>running test 3397"
../source/print_tokens.c.inst.exe ../inputs/uslin.165     > ../newoutputs/t3397
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3396.tr
echo ">>>>>>>>running test 3398"
../source/print_tokens.c.inst.exe ../inputs/uslin.1651     > ../newoutputs/t3398
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3397.tr
echo ">>>>>>>>running test 3399"
../source/print_tokens.c.inst.exe ../inputs/uslin.1652     > ../newoutputs/t3399
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3398.tr
echo ">>>>>>>>running test 3400"
../source/print_tokens.c.inst.exe ../inputs/uslin.1653     > ../newoutputs/t3400
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3399.tr
echo ">>>>>>>>running test 3401"
../source/print_tokens.c.inst.exe ../inputs/uslin.1654     > ../newoutputs/t3401
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3400.tr
echo ">>>>>>>>running test 3402"
../source/print_tokens.c.inst.exe ../inputs/uslin.1655     > ../newoutputs/t3402
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3401.tr
echo ">>>>>>>>running test 3403"
../source/print_tokens.c.inst.exe ../inputs/uslin.1656     > ../newoutputs/t3403
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3402.tr
echo ">>>>>>>>running test 3404"
../source/print_tokens.c.inst.exe ../inputs/uslin.1657     > ../newoutputs/t3404
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3403.tr
echo ">>>>>>>>running test 3405"
../source/print_tokens.c.inst.exe ../inputs/uslin.166     > ../newoutputs/t3405
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3404.tr
echo ">>>>>>>>running test 3406"
../source/print_tokens.c.inst.exe ../inputs/uslin.1661     > ../newoutputs/t3406
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3405.tr
echo ">>>>>>>>running test 3407"
../source/print_tokens.c.inst.exe ../inputs/uslin.1662     > ../newoutputs/t3407
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3406.tr
echo ">>>>>>>>running test 3408"
../source/print_tokens.c.inst.exe ../inputs/uslin.1663     > ../newoutputs/t3408
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3407.tr
echo ">>>>>>>>running test 3409"
../source/print_tokens.c.inst.exe ../inputs/uslin.1664     > ../newoutputs/t3409
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3408.tr
echo ">>>>>>>>running test 3410"
../source/print_tokens.c.inst.exe ../inputs/uslin.1665     > ../newoutputs/t3410
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3409.tr
echo ">>>>>>>>running test 3411"
../source/print_tokens.c.inst.exe ../inputs/uslin.167     > ../newoutputs/t3411
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3410.tr
echo ">>>>>>>>running test 3412"
../source/print_tokens.c.inst.exe ../inputs/uslin.1673     > ../newoutputs/t3412
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3411.tr
echo ">>>>>>>>running test 3413"
../source/print_tokens.c.inst.exe ../inputs/uslin.1674     > ../newoutputs/t3413
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3412.tr
echo ">>>>>>>>running test 3414"
../source/print_tokens.c.inst.exe ../inputs/uslin.1677      > ../newoutputs/t3414
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3413.tr
echo ">>>>>>>>running test 3415"
../source/print_tokens.c.inst.exe ../inputs/uslin.1678     > ../newoutputs/t3415
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3414.tr
echo ">>>>>>>>running test 3416"
../source/print_tokens.c.inst.exe ../inputs/uslin.168     > ../newoutputs/t3416
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3415.tr
echo ">>>>>>>>running test 3417"
../source/print_tokens.c.inst.exe ../inputs/uslin.1680     > ../newoutputs/t3417
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3416.tr
echo ">>>>>>>>running test 3418"
../source/print_tokens.c.inst.exe ../inputs/uslin.1682     > ../newoutputs/t3418
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3417.tr
echo ">>>>>>>>running test 3419"
../source/print_tokens.c.inst.exe ../inputs/uslin.1683     > ../newoutputs/t3419
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3418.tr
echo ">>>>>>>>running test 3420"
../source/print_tokens.c.inst.exe ../inputs/uslin.1684     > ../newoutputs/t3420
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3419.tr
echo ">>>>>>>>running test 3421"
../source/print_tokens.c.inst.exe ../inputs/uslin.1685     > ../newoutputs/t3421
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3420.tr
echo ">>>>>>>>running test 3422"
../source/print_tokens.c.inst.exe ../inputs/uslin.1687     > ../newoutputs/t3422
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3421.tr
echo ">>>>>>>>running test 3423"
../source/print_tokens.c.inst.exe ../inputs/uslin.1688     > ../newoutputs/t3423
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3422.tr
echo ">>>>>>>>running test 3424"
../source/print_tokens.c.inst.exe ../inputs/uslin.1689     > ../newoutputs/t3424
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3423.tr
echo ">>>>>>>>running test 3425"
../source/print_tokens.c.inst.exe ../inputs/uslin.1690     > ../newoutputs/t3425
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3424.tr
echo ">>>>>>>>running test 3426"
../source/print_tokens.c.inst.exe ../inputs/uslin.1692     > ../newoutputs/t3426
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3425.tr
echo ">>>>>>>>running test 3427"
../source/print_tokens.c.inst.exe ../inputs/uslin.1693     > ../newoutputs/t3427
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3426.tr
echo ">>>>>>>>running test 3428"
../source/print_tokens.c.inst.exe ../inputs/uslin.1696     > ../newoutputs/t3428
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3427.tr
echo ">>>>>>>>running test 3429"
../source/print_tokens.c.inst.exe ../inputs/uslin.1697     > ../newoutputs/t3429
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3428.tr
echo ">>>>>>>>running test 3430"
../source/print_tokens.c.inst.exe ../inputs/uslin.1699     > ../newoutputs/t3430
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3429.tr
echo ">>>>>>>>running test 3431"
../source/print_tokens.c.inst.exe ../inputs/uslin.1700     > ../newoutputs/t3431
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3430.tr
echo ">>>>>>>>running test 3432"
../source/print_tokens.c.inst.exe ../inputs/uslin.1701     > ../newoutputs/t3432
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3431.tr
echo ">>>>>>>>running test 3433"
../source/print_tokens.c.inst.exe ../inputs/uslin.1703     > ../newoutputs/t3433
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3432.tr
echo ">>>>>>>>running test 3434"
../source/print_tokens.c.inst.exe ../inputs/uslin.1704     > ../newoutputs/t3434
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3433.tr
echo ">>>>>>>>running test 3435"
../source/print_tokens.c.inst.exe ../inputs/uslin.1705     > ../newoutputs/t3435
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3434.tr
echo ">>>>>>>>running test 3436"
../source/print_tokens.c.inst.exe ../inputs/uslin.1706     > ../newoutputs/t3436
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3435.tr
echo ">>>>>>>>running test 3437"
../source/print_tokens.c.inst.exe ../inputs/uslin.1708     > ../newoutputs/t3437
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3436.tr
echo ">>>>>>>>running test 3438"
../source/print_tokens.c.inst.exe ../inputs/uslin.1709     > ../newoutputs/t3438
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3437.tr
echo ">>>>>>>>running test 3439"
../source/print_tokens.c.inst.exe ../inputs/uslin.1713     > ../newoutputs/t3439
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3438.tr
echo ">>>>>>>>running test 3440"
../source/print_tokens.c.inst.exe ../inputs/uslin.1714     > ../newoutputs/t3440
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3439.tr
echo ">>>>>>>>running test 3441"
../source/print_tokens.c.inst.exe ../inputs/uslin.1715     > ../newoutputs/t3441
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3440.tr
echo ">>>>>>>>running test 3442"
../source/print_tokens.c.inst.exe ../inputs/uslin.1717     > ../newoutputs/t3442
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3441.tr
echo ">>>>>>>>running test 3443"
../source/print_tokens.c.inst.exe ../inputs/uslin.1718     > ../newoutputs/t3443
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3442.tr
echo ">>>>>>>>running test 3444"
../source/print_tokens.c.inst.exe ../inputs/uslin.1719     > ../newoutputs/t3444
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3443.tr
echo ">>>>>>>>running test 3445"
../source/print_tokens.c.inst.exe ../inputs/uslin.172     > ../newoutputs/t3445
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3444.tr
echo ">>>>>>>>running test 3446"
../source/print_tokens.c.inst.exe ../inputs/uslin.1720     > ../newoutputs/t3446
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3445.tr
echo ">>>>>>>>running test 3447"
../source/print_tokens.c.inst.exe ../inputs/uslin.1721     > ../newoutputs/t3447
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3446.tr
echo ">>>>>>>>running test 3448"
../source/print_tokens.c.inst.exe ../inputs/uslin.1722     > ../newoutputs/t3448
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3447.tr
echo ">>>>>>>>running test 3449"
../source/print_tokens.c.inst.exe ../inputs/uslin.1723     > ../newoutputs/t3449
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3448.tr
echo ">>>>>>>>running test 3450"
../source/print_tokens.c.inst.exe ../inputs/uslin.1725     > ../newoutputs/t3450
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3449.tr
echo ">>>>>>>>running test 3451"
../source/print_tokens.c.inst.exe ../inputs/uslin.1726     > ../newoutputs/t3451
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3450.tr
echo ">>>>>>>>running test 3452"
../source/print_tokens.c.inst.exe ../inputs/uslin.1727     > ../newoutputs/t3452
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3451.tr
echo ">>>>>>>>running test 3453"
../source/print_tokens.c.inst.exe ../inputs/uslin.1729     > ../newoutputs/t3453
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3452.tr
echo ">>>>>>>>running test 3454"
../source/print_tokens.c.inst.exe ../inputs/uslin.173     > ../newoutputs/t3454
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3453.tr
echo ">>>>>>>>running test 3455"
../source/print_tokens.c.inst.exe ../inputs/uslin.1731     > ../newoutputs/t3455
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3454.tr
echo ">>>>>>>>running test 3456"
../source/print_tokens.c.inst.exe ../inputs/uslin.1732     > ../newoutputs/t3456
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3455.tr
echo ">>>>>>>>running test 3457"
../source/print_tokens.c.inst.exe ../inputs/uslin.1733     > ../newoutputs/t3457
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3456.tr
echo ">>>>>>>>running test 3458"
../source/print_tokens.c.inst.exe ../inputs/uslin.1734     > ../newoutputs/t3458
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3457.tr
echo ">>>>>>>>running test 3459"
../source/print_tokens.c.inst.exe ../inputs/uslin.1736     > ../newoutputs/t3459
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3458.tr
echo ">>>>>>>>running test 3460"
../source/print_tokens.c.inst.exe ../inputs/uslin.1739     > ../newoutputs/t3460
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3459.tr
echo ">>>>>>>>running test 3461"
../source/print_tokens.c.inst.exe ../inputs/uslin.174     > ../newoutputs/t3461
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3460.tr
echo ">>>>>>>>running test 3462"
../source/print_tokens.c.inst.exe ../inputs/uslin.1741     > ../newoutputs/t3462
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3461.tr
echo ">>>>>>>>running test 3463"
../source/print_tokens.c.inst.exe ../inputs/uslin.1743     > ../newoutputs/t3463
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3462.tr
echo ">>>>>>>>running test 3464"
../source/print_tokens.c.inst.exe ../inputs/uslin.1745     > ../newoutputs/t3464
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3463.tr
echo ">>>>>>>>running test 3465"
../source/print_tokens.c.inst.exe ../inputs/uslin.1746     > ../newoutputs/t3465
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3464.tr
echo ">>>>>>>>running test 3466"
../source/print_tokens.c.inst.exe ../inputs/uslin.1747     > ../newoutputs/t3466
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3465.tr
echo ">>>>>>>>running test 3467"
../source/print_tokens.c.inst.exe ../inputs/uslin.1748     > ../newoutputs/t3467
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3466.tr
echo ">>>>>>>>running test 3468"
../source/print_tokens.c.inst.exe ../inputs/uslin.1749     > ../newoutputs/t3468
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3467.tr
echo ">>>>>>>>running test 3469"
../source/print_tokens.c.inst.exe ../inputs/uslin.1750     > ../newoutputs/t3469
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3468.tr
echo ">>>>>>>>running test 3470"
../source/print_tokens.c.inst.exe ../inputs/uslin.1751     > ../newoutputs/t3470
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3469.tr
echo ">>>>>>>>running test 3471"
../source/print_tokens.c.inst.exe ../inputs/uslin.1752     > ../newoutputs/t3471
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3470.tr
echo ">>>>>>>>running test 3472"
../source/print_tokens.c.inst.exe ../inputs/uslin.1757     > ../newoutputs/t3472
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3471.tr
echo ">>>>>>>>running test 3473"
../source/print_tokens.c.inst.exe ../inputs/uslin.1758     > ../newoutputs/t3473
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3472.tr
echo ">>>>>>>>running test 3474"
../source/print_tokens.c.inst.exe ../inputs/uslin.1759     > ../newoutputs/t3474
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3473.tr
echo ">>>>>>>>running test 3475"
../source/print_tokens.c.inst.exe ../inputs/uslin.1761     > ../newoutputs/t3475
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3474.tr
echo ">>>>>>>>running test 3476"
../source/print_tokens.c.inst.exe ../inputs/uslin.1763     > ../newoutputs/t3476
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3475.tr
echo ">>>>>>>>running test 3477"
../source/print_tokens.c.inst.exe ../inputs/uslin.1765     > ../newoutputs/t3477
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3476.tr
echo ">>>>>>>>running test 3478"
../source/print_tokens.c.inst.exe ../inputs/uslin.1766     > ../newoutputs/t3478
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3477.tr
echo ">>>>>>>>running test 3479"
../source/print_tokens.c.inst.exe ../inputs/uslin.1767     > ../newoutputs/t3479
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3478.tr
echo ">>>>>>>>running test 3480"
../source/print_tokens.c.inst.exe ../inputs/uslin.1768     > ../newoutputs/t3480
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3479.tr
echo ">>>>>>>>running test 3481"
../source/print_tokens.c.inst.exe ../inputs/uslin.1769     > ../newoutputs/t3481
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3480.tr
echo ">>>>>>>>running test 3482"
../source/print_tokens.c.inst.exe ../inputs/uslin.1770     > ../newoutputs/t3482
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3481.tr
echo ">>>>>>>>running test 3483"
../source/print_tokens.c.inst.exe ../inputs/uslin.1772     > ../newoutputs/t3483
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3482.tr
echo ">>>>>>>>running test 3484"
../source/print_tokens.c.inst.exe ../inputs/uslin.1775     > ../newoutputs/t3484
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3483.tr
echo ">>>>>>>>running test 3485"
../source/print_tokens.c.inst.exe ../inputs/uslin.1777     > ../newoutputs/t3485
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3484.tr
echo ">>>>>>>>running test 3486"
../source/print_tokens.c.inst.exe ../inputs/uslin.1779     > ../newoutputs/t3486
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3485.tr
echo ">>>>>>>>running test 3487"
../source/print_tokens.c.inst.exe ../inputs/uslin.178     > ../newoutputs/t3487
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3486.tr
echo ">>>>>>>>running test 3488"
../source/print_tokens.c.inst.exe ../inputs/uslin.1780     > ../newoutputs/t3488
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3487.tr
echo ">>>>>>>>running test 3489"
../source/print_tokens.c.inst.exe ../inputs/uslin.1781     > ../newoutputs/t3489
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3488.tr
echo ">>>>>>>>running test 3490"
../source/print_tokens.c.inst.exe ../inputs/uslin.1784     > ../newoutputs/t3490
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3489.tr
echo ">>>>>>>>running test 3491"
../source/print_tokens.c.inst.exe ../inputs/uslin.1786     > ../newoutputs/t3491
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3490.tr
echo ">>>>>>>>running test 3492"
../source/print_tokens.c.inst.exe ../inputs/uslin.1788      > ../newoutputs/t3492
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3491.tr
echo ">>>>>>>>running test 3493"
../source/print_tokens.c.inst.exe ../inputs/uslin.179     > ../newoutputs/t3493
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3492.tr
echo ">>>>>>>>running test 3494"
../source/print_tokens.c.inst.exe ../inputs/uslin.1790     > ../newoutputs/t3494
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3493.tr
echo ">>>>>>>>running test 3495"
../source/print_tokens.c.inst.exe ../inputs/uslin.1791     > ../newoutputs/t3495
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3494.tr
echo ">>>>>>>>running test 3496"
../source/print_tokens.c.inst.exe ../inputs/uslin.1795      > ../newoutputs/t3496
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3495.tr
echo ">>>>>>>>running test 3497"
../source/print_tokens.c.inst.exe ../inputs/uslin.1796     > ../newoutputs/t3497
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3496.tr
echo ">>>>>>>>running test 3498"
../source/print_tokens.c.inst.exe ../inputs/uslin.1797     > ../newoutputs/t3498
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3497.tr
echo ">>>>>>>>running test 3499"
../source/print_tokens.c.inst.exe ../inputs/uslin.1799     > ../newoutputs/t3499
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3498.tr
echo ">>>>>>>>running test 3500"
../source/print_tokens.c.inst.exe ../inputs/uslin.18     > ../newoutputs/t3500
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3499.tr
echo ">>>>>>>>running test 3501"
../source/print_tokens.c.inst.exe ../inputs/uslin.180     > ../newoutputs/t3501
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3500.tr
echo ">>>>>>>>running test 3502"
../source/print_tokens.c.inst.exe ../inputs/uslin.1801     > ../newoutputs/t3502
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3501.tr
echo ">>>>>>>>running test 3503"
../source/print_tokens.c.inst.exe ../inputs/uslin.1803     > ../newoutputs/t3503
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3502.tr
echo ">>>>>>>>running test 3504"
../source/print_tokens.c.inst.exe ../inputs/uslin.1804     > ../newoutputs/t3504
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3503.tr
echo ">>>>>>>>running test 3505"
../source/print_tokens.c.inst.exe ../inputs/uslin.1805     > ../newoutputs/t3505
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3504.tr
echo ">>>>>>>>running test 3506"
../source/print_tokens.c.inst.exe ../inputs/uslin.1807     > ../newoutputs/t3506
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3505.tr
echo ">>>>>>>>running test 3507"
../source/print_tokens.c.inst.exe ../inputs/uslin.1808     > ../newoutputs/t3507
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3506.tr
echo ">>>>>>>>running test 3508"
../source/print_tokens.c.inst.exe ../inputs/uslin.1810     > ../newoutputs/t3508
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3507.tr
echo ">>>>>>>>running test 3509"
../source/print_tokens.c.inst.exe ../inputs/uslin.1811     > ../newoutputs/t3509
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3508.tr
echo ">>>>>>>>running test 3510"
../source/print_tokens.c.inst.exe ../inputs/uslin.1813     > ../newoutputs/t3510
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3509.tr
echo ">>>>>>>>running test 3511"
../source/print_tokens.c.inst.exe ../inputs/uslin.1815     > ../newoutputs/t3511
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3510.tr
echo ">>>>>>>>running test 3512"
../source/print_tokens.c.inst.exe ../inputs/uslin.1817     > ../newoutputs/t3512
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3511.tr
echo ">>>>>>>>running test 3513"
../source/print_tokens.c.inst.exe ../inputs/uslin.1820     > ../newoutputs/t3513
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3512.tr
echo ">>>>>>>>running test 3514"
../source/print_tokens.c.inst.exe ../inputs/uslin.1822     > ../newoutputs/t3514
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3513.tr
echo ">>>>>>>>running test 3515"
../source/print_tokens.c.inst.exe ../inputs/uslin.1824     > ../newoutputs/t3515
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3514.tr
echo ">>>>>>>>running test 3516"
../source/print_tokens.c.inst.exe ../inputs/uslin.1825     > ../newoutputs/t3516
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3515.tr
echo ">>>>>>>>running test 3517"
../source/print_tokens.c.inst.exe ../inputs/uslin.1826     > ../newoutputs/t3517
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3516.tr
echo ">>>>>>>>running test 3518"
../source/print_tokens.c.inst.exe ../inputs/uslin.1828     > ../newoutputs/t3518
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3517.tr
echo ">>>>>>>>running test 3519"
../source/print_tokens.c.inst.exe ../inputs/uslin.183     > ../newoutputs/t3519
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3518.tr
echo ">>>>>>>>running test 3520"
../source/print_tokens.c.inst.exe ../inputs/uslin.1831     > ../newoutputs/t3520
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3519.tr
echo ">>>>>>>>running test 3521"
../source/print_tokens.c.inst.exe ../inputs/uslin.1833     > ../newoutputs/t3521
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3520.tr
echo ">>>>>>>>running test 3522"
../source/print_tokens.c.inst.exe ../inputs/uslin.1834     > ../newoutputs/t3522
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3521.tr
echo ">>>>>>>>running test 3523"
../source/print_tokens.c.inst.exe ../inputs/uslin.1840     > ../newoutputs/t3523
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3522.tr
echo ">>>>>>>>running test 3524"
../source/print_tokens.c.inst.exe ../inputs/uslin.1841     > ../newoutputs/t3524
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3523.tr
echo ">>>>>>>>running test 3525"
../source/print_tokens.c.inst.exe ../inputs/uslin.1842     > ../newoutputs/t3525
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3524.tr
echo ">>>>>>>>running test 3526"
../source/print_tokens.c.inst.exe ../inputs/uslin.1843     > ../newoutputs/t3526
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3525.tr
echo ">>>>>>>>running test 3527"
../source/print_tokens.c.inst.exe ../inputs/uslin.1844     > ../newoutputs/t3527
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3526.tr
echo ">>>>>>>>running test 3528"
../source/print_tokens.c.inst.exe ../inputs/uslin.1846     > ../newoutputs/t3528
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3527.tr
echo ">>>>>>>>running test 3529"
../source/print_tokens.c.inst.exe ../inputs/uslin.1849     > ../newoutputs/t3529
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3528.tr
echo ">>>>>>>>running test 3530"
../source/print_tokens.c.inst.exe ../inputs/uslin.1851     > ../newoutputs/t3530
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3529.tr
echo ">>>>>>>>running test 3531"
../source/print_tokens.c.inst.exe ../inputs/uslin.1852     > ../newoutputs/t3531
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3530.tr
echo ">>>>>>>>running test 3532"
../source/print_tokens.c.inst.exe ../inputs/uslin.1853      > ../newoutputs/t3532
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3531.tr
echo ">>>>>>>>running test 3533"
../source/print_tokens.c.inst.exe ../inputs/uslin.1854      > ../newoutputs/t3533
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3532.tr
echo ">>>>>>>>running test 3534"
../source/print_tokens.c.inst.exe ../inputs/uslin.1857     > ../newoutputs/t3534
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3533.tr
echo ">>>>>>>>running test 3535"
../source/print_tokens.c.inst.exe ../inputs/uslin.1857.noeof     > ../newoutputs/t3535
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3534.tr
echo ">>>>>>>>running test 3536"
../source/print_tokens.c.inst.exe ../inputs/uslin.1859     > ../newoutputs/t3536
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3535.tr
echo ">>>>>>>>running test 3537"
../source/print_tokens.c.inst.exe ../inputs/uslin.186     > ../newoutputs/t3537
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3536.tr
echo ">>>>>>>>running test 3538"
../source/print_tokens.c.inst.exe ../inputs/uslin.1860     > ../newoutputs/t3538
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3537.tr
echo ">>>>>>>>running test 3539"
../source/print_tokens.c.inst.exe ../inputs/uslin.1861     > ../newoutputs/t3539
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3538.tr
echo ">>>>>>>>running test 3540"
../source/print_tokens.c.inst.exe ../inputs/uslin.1864     > ../newoutputs/t3540
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3539.tr
echo ">>>>>>>>running test 3541"
../source/print_tokens.c.inst.exe ../inputs/uslin.1866     > ../newoutputs/t3541
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3540.tr
echo ">>>>>>>>running test 3542"
../source/print_tokens.c.inst.exe ../inputs/uslin.1867     > ../newoutputs/t3542
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3541.tr
echo ">>>>>>>>running test 3543"
../source/print_tokens.c.inst.exe ../inputs/uslin.1868     > ../newoutputs/t3543
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3542.tr
echo ">>>>>>>>running test 3544"
../source/print_tokens.c.inst.exe ../inputs/uslin.1869     > ../newoutputs/t3544
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3543.tr
echo ">>>>>>>>running test 3545"
../source/print_tokens.c.inst.exe ../inputs/uslin.187     > ../newoutputs/t3545
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3544.tr
echo ">>>>>>>>running test 3546"
../source/print_tokens.c.inst.exe ../inputs/uslin.1870     > ../newoutputs/t3546
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3545.tr
echo ">>>>>>>>running test 3547"
../source/print_tokens.c.inst.exe ../inputs/uslin.1875     > ../newoutputs/t3547
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3546.tr
echo ">>>>>>>>running test 3548"
../source/print_tokens.c.inst.exe ../inputs/uslin.1879     > ../newoutputs/t3548
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3547.tr
echo ">>>>>>>>running test 3549"
../source/print_tokens.c.inst.exe ../inputs/uslin.1883     > ../newoutputs/t3549
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3548.tr
echo ">>>>>>>>running test 3550"
../source/print_tokens.c.inst.exe ../inputs/uslin.1884     > ../newoutputs/t3550
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3549.tr
echo ">>>>>>>>running test 3551"
../source/print_tokens.c.inst.exe ../inputs/uslin.1888     > ../newoutputs/t3551
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3550.tr
echo ">>>>>>>>running test 3552"
../source/print_tokens.c.inst.exe ../inputs/uslin.1889     > ../newoutputs/t3552
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3551.tr
echo ">>>>>>>>running test 3553"
../source/print_tokens.c.inst.exe ../inputs/uslin.1890     > ../newoutputs/t3553
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3552.tr
echo ">>>>>>>>running test 3554"
../source/print_tokens.c.inst.exe ../inputs/uslin.1894     > ../newoutputs/t3554
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3553.tr
echo ">>>>>>>>running test 3555"
../source/print_tokens.c.inst.exe ../inputs/uslin.1899     > ../newoutputs/t3555
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3554.tr
echo ">>>>>>>>running test 3556"
../source/print_tokens.c.inst.exe ../inputs/uslin.19     > ../newoutputs/t3556
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3555.tr
echo ">>>>>>>>running test 3557"
../source/print_tokens.c.inst.exe ../inputs/uslin.1900     > ../newoutputs/t3557
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3556.tr
echo ">>>>>>>>running test 3558"
../source/print_tokens.c.inst.exe ../inputs/uslin.1901     > ../newoutputs/t3558
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3557.tr
echo ">>>>>>>>running test 3559"
../source/print_tokens.c.inst.exe ../inputs/uslin.1902     > ../newoutputs/t3559
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3558.tr
echo ">>>>>>>>running test 3560"
../source/print_tokens.c.inst.exe ../inputs/uslin.1904     > ../newoutputs/t3560
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3559.tr
echo ">>>>>>>>running test 3561"
../source/print_tokens.c.inst.exe ../inputs/uslin.1906     > ../newoutputs/t3561
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3560.tr
echo ">>>>>>>>running test 3562"
../source/print_tokens.c.inst.exe ../inputs/uslin.1909     > ../newoutputs/t3562
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3561.tr
echo ">>>>>>>>running test 3563"
../source/print_tokens.c.inst.exe ../inputs/uslin.1910     > ../newoutputs/t3563
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3562.tr
echo ">>>>>>>>running test 3564"
../source/print_tokens.c.inst.exe ../inputs/uslin.1911     > ../newoutputs/t3564
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3563.tr
echo ">>>>>>>>running test 3565"
../source/print_tokens.c.inst.exe ../inputs/uslin.1915     > ../newoutputs/t3565
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3564.tr
echo ">>>>>>>>running test 3566"
../source/print_tokens.c.inst.exe ../inputs/uslin.1919     > ../newoutputs/t3566
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3565.tr
echo ">>>>>>>>running test 3567"
../source/print_tokens.c.inst.exe ../inputs/uslin.192     > ../newoutputs/t3567
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3566.tr
echo ">>>>>>>>running test 3568"
../source/print_tokens.c.inst.exe ../inputs/uslin.1921     > ../newoutputs/t3568
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3567.tr
echo ">>>>>>>>running test 3569"
../source/print_tokens.c.inst.exe ../inputs/uslin.1923     > ../newoutputs/t3569
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3568.tr
echo ">>>>>>>>running test 3570"
../source/print_tokens.c.inst.exe ../inputs/uslin.1927     > ../newoutputs/t3570
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3569.tr
echo ">>>>>>>>running test 3571"
../source/print_tokens.c.inst.exe ../inputs/uslin.1928      > ../newoutputs/t3571
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3570.tr
echo ">>>>>>>>running test 3572"
../source/print_tokens.c.inst.exe ../inputs/uslin.1930     > ../newoutputs/t3572
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3571.tr
echo ">>>>>>>>running test 3573"
../source/print_tokens.c.inst.exe ../inputs/uslin.1939     > ../newoutputs/t3573
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3572.tr
echo ">>>>>>>>running test 3574"
../source/print_tokens.c.inst.exe ../inputs/uslin.194     > ../newoutputs/t3574
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3573.tr
echo ">>>>>>>>running test 3575"
../source/print_tokens.c.inst.exe ../inputs/uslin.1940     > ../newoutputs/t3575
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3574.tr
echo ">>>>>>>>running test 3576"
../source/print_tokens.c.inst.exe ../inputs/uslin.1941     > ../newoutputs/t3576
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3575.tr
echo ">>>>>>>>running test 3577"
../source/print_tokens.c.inst.exe ../inputs/uslin.1942     > ../newoutputs/t3577
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3576.tr
echo ">>>>>>>>running test 3578"
../source/print_tokens.c.inst.exe ../inputs/uslin.1943     > ../newoutputs/t3578
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3577.tr
echo ">>>>>>>>running test 3579"
../source/print_tokens.c.inst.exe ../inputs/uslin.1949     > ../newoutputs/t3579
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3578.tr
echo ">>>>>>>>running test 3580"
../source/print_tokens.c.inst.exe ../inputs/uslin.1951     > ../newoutputs/t3580
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3579.tr
echo ">>>>>>>>running test 3581"
../source/print_tokens.c.inst.exe ../inputs/uslin.1952     > ../newoutputs/t3581
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3580.tr
echo ">>>>>>>>running test 3582"
../source/print_tokens.c.inst.exe ../inputs/uslin.1953     > ../newoutputs/t3582
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3581.tr
echo ">>>>>>>>running test 3583"
../source/print_tokens.c.inst.exe ../inputs/uslin.1954     > ../newoutputs/t3583
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3582.tr
echo ">>>>>>>>running test 3584"
../source/print_tokens.c.inst.exe ../inputs/uslin.1956     > ../newoutputs/t3584
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3583.tr
echo ">>>>>>>>running test 3585"
../source/print_tokens.c.inst.exe ../inputs/uslin.1957     > ../newoutputs/t3585
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3584.tr
echo ">>>>>>>>running test 3586"
../source/print_tokens.c.inst.exe ../inputs/uslin.196     > ../newoutputs/t3586
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3585.tr
echo ">>>>>>>>running test 3587"
../source/print_tokens.c.inst.exe ../inputs/uslin.1960     > ../newoutputs/t3587
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3586.tr
echo ">>>>>>>>running test 3588"
../source/print_tokens.c.inst.exe ../inputs/uslin.1962     > ../newoutputs/t3588
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3587.tr
echo ">>>>>>>>running test 3589"
../source/print_tokens.c.inst.exe ../inputs/uslin.1963     > ../newoutputs/t3589
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3588.tr
echo ">>>>>>>>running test 3590"
../source/print_tokens.c.inst.exe ../inputs/uslin.1965     > ../newoutputs/t3590
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3589.tr
echo ">>>>>>>>running test 3591"
../source/print_tokens.c.inst.exe ../inputs/uslin.1966     > ../newoutputs/t3591
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3590.tr
echo ">>>>>>>>running test 3592"
../source/print_tokens.c.inst.exe ../inputs/uslin.1967     > ../newoutputs/t3592
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3591.tr
echo ">>>>>>>>running test 3593"
../source/print_tokens.c.inst.exe ../inputs/uslin.1968     > ../newoutputs/t3593
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3592.tr
echo ">>>>>>>>running test 3594"
../source/print_tokens.c.inst.exe ../inputs/uslin.1969     > ../newoutputs/t3594
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3593.tr
echo ">>>>>>>>running test 3595"
../source/print_tokens.c.inst.exe ../inputs/uslin.197      > ../newoutputs/t3595
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3594.tr
echo ">>>>>>>>running test 3596"
../source/print_tokens.c.inst.exe ../inputs/uslin.1973     > ../newoutputs/t3596
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3595.tr
echo ">>>>>>>>running test 3597"
../source/print_tokens.c.inst.exe ../inputs/uslin.1976     > ../newoutputs/t3597
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3596.tr
echo ">>>>>>>>running test 3598"
../source/print_tokens.c.inst.exe ../inputs/uslin.1977     > ../newoutputs/t3598
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3597.tr
echo ">>>>>>>>running test 3599"
../source/print_tokens.c.inst.exe ../inputs/uslin.1978     > ../newoutputs/t3599
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3598.tr
echo ">>>>>>>>running test 3600"
../source/print_tokens.c.inst.exe ../inputs/uslin.198     > ../newoutputs/t3600
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3599.tr
echo ">>>>>>>>running test 3601"
../source/print_tokens.c.inst.exe ../inputs/uslin.1980     > ../newoutputs/t3601
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3600.tr
echo ">>>>>>>>running test 3602"
../source/print_tokens.c.inst.exe ../inputs/uslin.1981     > ../newoutputs/t3602
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3601.tr
echo ">>>>>>>>running test 3603"
../source/print_tokens.c.inst.exe ../inputs/uslin.1982     > ../newoutputs/t3603
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3602.tr
echo ">>>>>>>>running test 3604"
../source/print_tokens.c.inst.exe ../inputs/uslin.1983     > ../newoutputs/t3604
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3603.tr
echo ">>>>>>>>running test 3605"
../source/print_tokens.c.inst.exe ../inputs/uslin.1984.noeof     > ../newoutputs/t3605
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3604.tr
echo ">>>>>>>>running test 3606"
../source/print_tokens.c.inst.exe ../inputs/uslin.1986     > ../newoutputs/t3606
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3605.tr
echo ">>>>>>>>running test 3607"
../source/print_tokens.c.inst.exe ../inputs/uslin.1987     > ../newoutputs/t3607
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3606.tr
echo ">>>>>>>>running test 3608"
../source/print_tokens.c.inst.exe ../inputs/uslin.199     > ../newoutputs/t3608
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3607.tr
echo ">>>>>>>>running test 3609"
../source/print_tokens.c.inst.exe ../inputs/uslin.1991     > ../newoutputs/t3609
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3608.tr
echo ">>>>>>>>running test 3610"
../source/print_tokens.c.inst.exe ../inputs/uslin.1992      > ../newoutputs/t3610
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3609.tr
echo ">>>>>>>>running test 3611"
../source/print_tokens.c.inst.exe ../inputs/uslin.1993     > ../newoutputs/t3611
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3610.tr
echo ">>>>>>>>running test 3612"
../source/print_tokens.c.inst.exe ../inputs/uslin.1994     > ../newoutputs/t3612
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3611.tr
echo ">>>>>>>>running test 3613"
../source/print_tokens.c.inst.exe ../inputs/uslin.1996     > ../newoutputs/t3613
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3612.tr
echo ">>>>>>>>running test 3614"
../source/print_tokens.c.inst.exe ../inputs/uslin.200     > ../newoutputs/t3614
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3613.tr
echo ">>>>>>>>running test 3615"
../source/print_tokens.c.inst.exe ../inputs/uslin.202     > ../newoutputs/t3615
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3614.tr
echo ">>>>>>>>running test 3616"
../source/print_tokens.c.inst.exe ../inputs/uslin.203     > ../newoutputs/t3616
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3615.tr
echo ">>>>>>>>running test 3617"
../source/print_tokens.c.inst.exe ../inputs/uslin.205     > ../newoutputs/t3617
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3616.tr
echo ">>>>>>>>running test 3618"
../source/print_tokens.c.inst.exe ../inputs/uslin.211     > ../newoutputs/t3618
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3617.tr
echo ">>>>>>>>running test 3619"
../source/print_tokens.c.inst.exe ../inputs/uslin.212     > ../newoutputs/t3619
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3618.tr
echo ">>>>>>>>running test 3620"
../source/print_tokens.c.inst.exe ../inputs/uslin.216     > ../newoutputs/t3620
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3619.tr
echo ">>>>>>>>running test 3621"
../source/print_tokens.c.inst.exe ../inputs/uslin.217     > ../newoutputs/t3621
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3620.tr
echo ">>>>>>>>running test 3622"
../source/print_tokens.c.inst.exe ../inputs/uslin.218     > ../newoutputs/t3622
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3621.tr
echo ">>>>>>>>running test 3623"
../source/print_tokens.c.inst.exe ../inputs/uslin.219     > ../newoutputs/t3623
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3622.tr
echo ">>>>>>>>running test 3624"
../source/print_tokens.c.inst.exe ../inputs/uslin.220     > ../newoutputs/t3624
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3623.tr
echo ">>>>>>>>running test 3625"
../source/print_tokens.c.inst.exe ../inputs/uslin.221     > ../newoutputs/t3625
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3624.tr
echo ">>>>>>>>running test 3626"
../source/print_tokens.c.inst.exe ../inputs/uslin.222     > ../newoutputs/t3626
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3625.tr
echo ">>>>>>>>running test 3627"
../source/print_tokens.c.inst.exe ../inputs/uslin.223     > ../newoutputs/t3627
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3626.tr
echo ">>>>>>>>running test 3628"
../source/print_tokens.c.inst.exe ../inputs/uslin.224     > ../newoutputs/t3628
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3627.tr
echo ">>>>>>>>running test 3629"
../source/print_tokens.c.inst.exe ../inputs/uslin.227     > ../newoutputs/t3629
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3628.tr
echo ">>>>>>>>running test 3630"
../source/print_tokens.c.inst.exe ../inputs/uslin.228     > ../newoutputs/t3630
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3629.tr
echo ">>>>>>>>running test 3631"
../source/print_tokens.c.inst.exe ../inputs/uslin.229     > ../newoutputs/t3631
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3630.tr
echo ">>>>>>>>running test 3632"
../source/print_tokens.c.inst.exe ../inputs/uslin.23     > ../newoutputs/t3632
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3631.tr
echo ">>>>>>>>running test 3633"
../source/print_tokens.c.inst.exe ../inputs/uslin.231     > ../newoutputs/t3633
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3632.tr
echo ">>>>>>>>running test 3634"
../source/print_tokens.c.inst.exe ../inputs/uslin.232     > ../newoutputs/t3634
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3633.tr
echo ">>>>>>>>running test 3635"
../source/print_tokens.c.inst.exe ../inputs/uslin.235     > ../newoutputs/t3635
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3634.tr
echo ">>>>>>>>running test 3636"
../source/print_tokens.c.inst.exe ../inputs/uslin.236     > ../newoutputs/t3636
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3635.tr
echo ">>>>>>>>running test 3637"
../source/print_tokens.c.inst.exe ../inputs/uslin.24     > ../newoutputs/t3637
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3636.tr
echo ">>>>>>>>running test 3638"
../source/print_tokens.c.inst.exe ../inputs/uslin.240     > ../newoutputs/t3638
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3637.tr
echo ">>>>>>>>running test 3639"
../source/print_tokens.c.inst.exe ../inputs/uslin.241     > ../newoutputs/t3639
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3638.tr
echo ">>>>>>>>running test 3640"
../source/print_tokens.c.inst.exe ../inputs/uslin.242     > ../newoutputs/t3640
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3639.tr
echo ">>>>>>>>running test 3641"
../source/print_tokens.c.inst.exe ../inputs/uslin.250     > ../newoutputs/t3641
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3640.tr
echo ">>>>>>>>running test 3642"
../source/print_tokens.c.inst.exe ../inputs/uslin.253     > ../newoutputs/t3642
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3641.tr
echo ">>>>>>>>running test 3643"
../source/print_tokens.c.inst.exe ../inputs/uslin.255     > ../newoutputs/t3643
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3642.tr
echo ">>>>>>>>running test 3644"
../source/print_tokens.c.inst.exe ../inputs/uslin.259     > ../newoutputs/t3644
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3643.tr
echo ">>>>>>>>running test 3645"
../source/print_tokens.c.inst.exe ../inputs/uslin.26     > ../newoutputs/t3645
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3644.tr
echo ">>>>>>>>running test 3646"
../source/print_tokens.c.inst.exe ../inputs/uslin.261     > ../newoutputs/t3646
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3645.tr
echo ">>>>>>>>running test 3647"
../source/print_tokens.c.inst.exe ../inputs/uslin.262     > ../newoutputs/t3647
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3646.tr
echo ">>>>>>>>running test 3648"
../source/print_tokens.c.inst.exe ../inputs/uslin.263     > ../newoutputs/t3648
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3647.tr
echo ">>>>>>>>running test 3649"
../source/print_tokens.c.inst.exe ../inputs/uslin.265      > ../newoutputs/t3649
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3648.tr
echo ">>>>>>>>running test 3650"
../source/print_tokens.c.inst.exe ../inputs/uslin.269     > ../newoutputs/t3650
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3649.tr
echo ">>>>>>>>running test 3651"
../source/print_tokens.c.inst.exe ../inputs/uslin.273     > ../newoutputs/t3651
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3650.tr
echo ">>>>>>>>running test 3652"
../source/print_tokens.c.inst.exe ../inputs/uslin.274     > ../newoutputs/t3652
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3651.tr
echo ">>>>>>>>running test 3653"
../source/print_tokens.c.inst.exe ../inputs/uslin.278     > ../newoutputs/t3653
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3652.tr
echo ">>>>>>>>running test 3654"
../source/print_tokens.c.inst.exe ../inputs/uslin.279     > ../newoutputs/t3654
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3653.tr
echo ">>>>>>>>running test 3655"
../source/print_tokens.c.inst.exe ../inputs/uslin.284     > ../newoutputs/t3655
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3654.tr
echo ">>>>>>>>running test 3656"
../source/print_tokens.c.inst.exe ../inputs/uslin.285     > ../newoutputs/t3656
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3655.tr
echo ">>>>>>>>running test 3657"
../source/print_tokens.c.inst.exe ../inputs/uslin.288     > ../newoutputs/t3657
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3656.tr
echo ">>>>>>>>running test 3658"
../source/print_tokens.c.inst.exe ../inputs/uslin.29     > ../newoutputs/t3658
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3657.tr
echo ">>>>>>>>running test 3659"
../source/print_tokens.c.inst.exe ../inputs/uslin.290     > ../newoutputs/t3659
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3658.tr
echo ">>>>>>>>running test 3660"
../source/print_tokens.c.inst.exe ../inputs/uslin.291     > ../newoutputs/t3660
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3659.tr
echo ">>>>>>>>running test 3661"
../source/print_tokens.c.inst.exe ../inputs/uslin.292     > ../newoutputs/t3661
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3660.tr
echo ">>>>>>>>running test 3662"
../source/print_tokens.c.inst.exe ../inputs/uslin.293     > ../newoutputs/t3662
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3661.tr
echo ">>>>>>>>running test 3663"
../source/print_tokens.c.inst.exe ../inputs/uslin.3      > ../newoutputs/t3663
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3662.tr
echo ">>>>>>>>running test 3664"
../source/print_tokens.c.inst.exe ../inputs/uslin.300     > ../newoutputs/t3664
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3663.tr
echo ">>>>>>>>running test 3665"
../source/print_tokens.c.inst.exe ../inputs/uslin.303      > ../newoutputs/t3665
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3664.tr
echo ">>>>>>>>running test 3666"
../source/print_tokens.c.inst.exe ../inputs/uslin.304     > ../newoutputs/t3666
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3665.tr
echo ">>>>>>>>running test 3667"
../source/print_tokens.c.inst.exe ../inputs/uslin.308      > ../newoutputs/t3667
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3666.tr
echo ">>>>>>>>running test 3668"
../source/print_tokens.c.inst.exe ../inputs/uslin.309     > ../newoutputs/t3668
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3667.tr
echo ">>>>>>>>running test 3669"
../source/print_tokens.c.inst.exe ../inputs/uslin.310     > ../newoutputs/t3669
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3668.tr
echo ">>>>>>>>running test 3670"
../source/print_tokens.c.inst.exe ../inputs/uslin.312     > ../newoutputs/t3670
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3669.tr
echo ">>>>>>>>running test 3671"
../source/print_tokens.c.inst.exe ../inputs/uslin.313     > ../newoutputs/t3671
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3670.tr
echo ">>>>>>>>running test 3672"
../source/print_tokens.c.inst.exe ../inputs/uslin.314     > ../newoutputs/t3672
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3671.tr
echo ">>>>>>>>running test 3673"
../source/print_tokens.c.inst.exe ../inputs/uslin.315     > ../newoutputs/t3673
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3672.tr
echo ">>>>>>>>running test 3674"
../source/print_tokens.c.inst.exe ../inputs/uslin.316     > ../newoutputs/t3674
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3673.tr
echo ">>>>>>>>running test 3675"
../source/print_tokens.c.inst.exe ../inputs/uslin.317     > ../newoutputs/t3675
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3674.tr
echo ">>>>>>>>running test 3676"
../source/print_tokens.c.inst.exe ../inputs/uslin.32     > ../newoutputs/t3676
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3675.tr
echo ">>>>>>>>running test 3677"
../source/print_tokens.c.inst.exe ../inputs/uslin.324     > ../newoutputs/t3677
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3676.tr
echo ">>>>>>>>running test 3678"
../source/print_tokens.c.inst.exe ../inputs/uslin.326     > ../newoutputs/t3678
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3677.tr
echo ">>>>>>>>running test 3679"
../source/print_tokens.c.inst.exe ../inputs/uslin.328     > ../newoutputs/t3679
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3678.tr
echo ">>>>>>>>running test 3680"
../source/print_tokens.c.inst.exe ../inputs/uslin.331     > ../newoutputs/t3680
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3679.tr
echo ">>>>>>>>running test 3681"
../source/print_tokens.c.inst.exe ../inputs/uslin.332     > ../newoutputs/t3681
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3680.tr
echo ">>>>>>>>running test 3682"
../source/print_tokens.c.inst.exe ../inputs/uslin.336     > ../newoutputs/t3682
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3681.tr
echo ">>>>>>>>running test 3683"
../source/print_tokens.c.inst.exe ../inputs/uslin.338     > ../newoutputs/t3683
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3682.tr
echo ">>>>>>>>running test 3684"
../source/print_tokens.c.inst.exe ../inputs/uslin.341     > ../newoutputs/t3684
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3683.tr
echo ">>>>>>>>running test 3685"
../source/print_tokens.c.inst.exe ../inputs/uslin.342     > ../newoutputs/t3685
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3684.tr
echo ">>>>>>>>running test 3686"
../source/print_tokens.c.inst.exe ../inputs/uslin.346     > ../newoutputs/t3686
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3685.tr
echo ">>>>>>>>running test 3687"
../source/print_tokens.c.inst.exe ../inputs/uslin.347     > ../newoutputs/t3687
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3686.tr
echo ">>>>>>>>running test 3688"
../source/print_tokens.c.inst.exe ../inputs/uslin.35     > ../newoutputs/t3688
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3687.tr
echo ">>>>>>>>running test 3689"
../source/print_tokens.c.inst.exe ../inputs/uslin.351     > ../newoutputs/t3689
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3688.tr
echo ">>>>>>>>running test 3690"
../source/print_tokens.c.inst.exe ../inputs/uslin.354     > ../newoutputs/t3690
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3689.tr
echo ">>>>>>>>running test 3691"
../source/print_tokens.c.inst.exe ../inputs/uslin.356     > ../newoutputs/t3691
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3690.tr
echo ">>>>>>>>running test 3692"
../source/print_tokens.c.inst.exe ../inputs/uslin.357     > ../newoutputs/t3692
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3691.tr
echo ">>>>>>>>running test 3693"
../source/print_tokens.c.inst.exe ../inputs/uslin.358     > ../newoutputs/t3693
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3692.tr
echo ">>>>>>>>running test 3694"
../source/print_tokens.c.inst.exe ../inputs/uslin.359     > ../newoutputs/t3694
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3693.tr
echo ">>>>>>>>running test 3695"
../source/print_tokens.c.inst.exe ../inputs/uslin.361     > ../newoutputs/t3695
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3694.tr
echo ">>>>>>>>running test 3696"
../source/print_tokens.c.inst.exe ../inputs/uslin.364     > ../newoutputs/t3696
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3695.tr
echo ">>>>>>>>running test 3697"
../source/print_tokens.c.inst.exe ../inputs/uslin.365     > ../newoutputs/t3697
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3696.tr
echo ">>>>>>>>running test 3698"
../source/print_tokens.c.inst.exe ../inputs/uslin.366     > ../newoutputs/t3698
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3697.tr
echo ">>>>>>>>running test 3699"
../source/print_tokens.c.inst.exe ../inputs/uslin.368     > ../newoutputs/t3699
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3698.tr
echo ">>>>>>>>running test 3700"
../source/print_tokens.c.inst.exe ../inputs/uslin.370     > ../newoutputs/t3700
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3699.tr
echo ">>>>>>>>running test 3701"
../source/print_tokens.c.inst.exe ../inputs/uslin.371     > ../newoutputs/t3701
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3700.tr
echo ">>>>>>>>running test 3702"
../source/print_tokens.c.inst.exe ../inputs/uslin.373     > ../newoutputs/t3702
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3701.tr
echo ">>>>>>>>running test 3703"
../source/print_tokens.c.inst.exe ../inputs/uslin.374     > ../newoutputs/t3703
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3702.tr
echo ">>>>>>>>running test 3704"
../source/print_tokens.c.inst.exe ../inputs/uslin.375     > ../newoutputs/t3704
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3703.tr
echo ">>>>>>>>running test 3705"
../source/print_tokens.c.inst.exe ../inputs/uslin.376     > ../newoutputs/t3705
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3704.tr
echo ">>>>>>>>running test 3706"
../source/print_tokens.c.inst.exe ../inputs/uslin.38     > ../newoutputs/t3706
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3705.tr
echo ">>>>>>>>running test 3707"
../source/print_tokens.c.inst.exe ../inputs/uslin.381     > ../newoutputs/t3707
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3706.tr
echo ">>>>>>>>running test 3708"
../source/print_tokens.c.inst.exe ../inputs/uslin.382     > ../newoutputs/t3708
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3707.tr
echo ">>>>>>>>running test 3709"
../source/print_tokens.c.inst.exe ../inputs/uslin.384     > ../newoutputs/t3709
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3708.tr
echo ">>>>>>>>running test 3710"
../source/print_tokens.c.inst.exe ../inputs/uslin.385     > ../newoutputs/t3710
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3709.tr
echo ">>>>>>>>running test 3711"
../source/print_tokens.c.inst.exe ../inputs/uslin.389     > ../newoutputs/t3711
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3710.tr
echo ">>>>>>>>running test 3712"
../source/print_tokens.c.inst.exe ../inputs/uslin.39     > ../newoutputs/t3712
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3711.tr
echo ">>>>>>>>running test 3713"
../source/print_tokens.c.inst.exe ../inputs/uslin.390     > ../newoutputs/t3713
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3712.tr
echo ">>>>>>>>running test 3714"
../source/print_tokens.c.inst.exe ../inputs/uslin.391     > ../newoutputs/t3714
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3713.tr
echo ">>>>>>>>running test 3715"
../source/print_tokens.c.inst.exe ../inputs/uslin.393     > ../newoutputs/t3715
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3714.tr
echo ">>>>>>>>running test 3716"
../source/print_tokens.c.inst.exe ../inputs/uslin.394     > ../newoutputs/t3716
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3715.tr
echo ">>>>>>>>running test 3717"
../source/print_tokens.c.inst.exe ../inputs/uslin.396.noeof     > ../newoutputs/t3717
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3716.tr
echo ">>>>>>>>running test 3718"
../source/print_tokens.c.inst.exe ../inputs/uslin.397     > ../newoutputs/t3718
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3717.tr
echo ">>>>>>>>running test 3719"
../source/print_tokens.c.inst.exe ../inputs/uslin.399     > ../newoutputs/t3719
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3718.tr
echo ">>>>>>>>running test 3720"
../source/print_tokens.c.inst.exe ../inputs/uslin.400     > ../newoutputs/t3720
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3719.tr
echo ">>>>>>>>running test 3721"
../source/print_tokens.c.inst.exe ../inputs/uslin.401     > ../newoutputs/t3721
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3720.tr
echo ">>>>>>>>running test 3722"
../source/print_tokens.c.inst.exe ../inputs/uslin.403     > ../newoutputs/t3722
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3721.tr
echo ">>>>>>>>running test 3723"
../source/print_tokens.c.inst.exe ../inputs/uslin.404     > ../newoutputs/t3723
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3722.tr
echo ">>>>>>>>running test 3724"
../source/print_tokens.c.inst.exe ../inputs/uslin.405     > ../newoutputs/t3724
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3723.tr
echo ">>>>>>>>running test 3725"
../source/print_tokens.c.inst.exe ../inputs/uslin.406     > ../newoutputs/t3725
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3724.tr
echo ">>>>>>>>running test 3726"
../source/print_tokens.c.inst.exe ../inputs/uslin.408     > ../newoutputs/t3726
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3725.tr
echo ">>>>>>>>running test 3727"
../source/print_tokens.c.inst.exe ../inputs/uslin.409     > ../newoutputs/t3727
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3726.tr
echo ">>>>>>>>running test 3728"
../source/print_tokens.c.inst.exe ../inputs/uslin.410     > ../newoutputs/t3728
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3727.tr
echo ">>>>>>>>running test 3729"
../source/print_tokens.c.inst.exe ../inputs/uslin.411      > ../newoutputs/t3729
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3728.tr
echo ">>>>>>>>running test 3730"
../source/print_tokens.c.inst.exe ../inputs/uslin.414     > ../newoutputs/t3730
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3729.tr
echo ">>>>>>>>running test 3731"
../source/print_tokens.c.inst.exe ../inputs/uslin.416     > ../newoutputs/t3731
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3730.tr
echo ">>>>>>>>running test 3732"
../source/print_tokens.c.inst.exe ../inputs/uslin.416.noeof     > ../newoutputs/t3732
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3731.tr
echo ">>>>>>>>running test 3733"
../source/print_tokens.c.inst.exe ../inputs/uslin.417     > ../newoutputs/t3733
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3732.tr
echo ">>>>>>>>running test 3734"
../source/print_tokens.c.inst.exe ../inputs/uslin.420     > ../newoutputs/t3734
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3733.tr
echo ">>>>>>>>running test 3735"
../source/print_tokens.c.inst.exe ../inputs/uslin.422     > ../newoutputs/t3735
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3734.tr
echo ">>>>>>>>running test 3736"
../source/print_tokens.c.inst.exe ../inputs/uslin.426     > ../newoutputs/t3736
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3735.tr
echo ">>>>>>>>running test 3737"
../source/print_tokens.c.inst.exe ../inputs/uslin.427     > ../newoutputs/t3737
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3736.tr
echo ">>>>>>>>running test 3738"
../source/print_tokens.c.inst.exe ../inputs/uslin.429     > ../newoutputs/t3738
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3737.tr
echo ">>>>>>>>running test 3739"
../source/print_tokens.c.inst.exe ../inputs/uslin.43     > ../newoutputs/t3739
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3738.tr
echo ">>>>>>>>running test 3740"
../source/print_tokens.c.inst.exe ../inputs/uslin.431     > ../newoutputs/t3740
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3739.tr
echo ">>>>>>>>running test 3741"
../source/print_tokens.c.inst.exe ../inputs/uslin.437     > ../newoutputs/t3741
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3740.tr
echo ">>>>>>>>running test 3742"
../source/print_tokens.c.inst.exe ../inputs/uslin.439     > ../newoutputs/t3742
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3741.tr
echo ">>>>>>>>running test 3743"
../source/print_tokens.c.inst.exe ../inputs/uslin.44     > ../newoutputs/t3743
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3742.tr
echo ">>>>>>>>running test 3744"
../source/print_tokens.c.inst.exe ../inputs/uslin.440     > ../newoutputs/t3744
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3743.tr
echo ">>>>>>>>running test 3745"
../source/print_tokens.c.inst.exe ../inputs/uslin.441.noeof     > ../newoutputs/t3745
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3744.tr
echo ">>>>>>>>running test 3746"
../source/print_tokens.c.inst.exe ../inputs/uslin.443     > ../newoutputs/t3746
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3745.tr
echo ">>>>>>>>running test 3747"
../source/print_tokens.c.inst.exe ../inputs/uslin.444     > ../newoutputs/t3747
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3746.tr
echo ">>>>>>>>running test 3748"
../source/print_tokens.c.inst.exe ../inputs/uslin.445     > ../newoutputs/t3748
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3747.tr
echo ">>>>>>>>running test 3749"
../source/print_tokens.c.inst.exe ../inputs/uslin.446     > ../newoutputs/t3749
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3748.tr
echo ">>>>>>>>running test 3750"
../source/print_tokens.c.inst.exe ../inputs/uslin.45     > ../newoutputs/t3750
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3749.tr
echo ">>>>>>>>running test 3751"
../source/print_tokens.c.inst.exe ../inputs/uslin.452     > ../newoutputs/t3751
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3750.tr
echo ">>>>>>>>running test 3752"
../source/print_tokens.c.inst.exe ../inputs/uslin.453     > ../newoutputs/t3752
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3751.tr
echo ">>>>>>>>running test 3753"
../source/print_tokens.c.inst.exe ../inputs/uslin.454     > ../newoutputs/t3753
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3752.tr
echo ">>>>>>>>running test 3754"
../source/print_tokens.c.inst.exe ../inputs/uslin.458     > ../newoutputs/t3754
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3753.tr
echo ">>>>>>>>running test 3755"
../source/print_tokens.c.inst.exe ../inputs/uslin.46     > ../newoutputs/t3755
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3754.tr
echo ">>>>>>>>running test 3756"
../source/print_tokens.c.inst.exe ../inputs/uslin.460     > ../newoutputs/t3756
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3755.tr
echo ">>>>>>>>running test 3757"
../source/print_tokens.c.inst.exe ../inputs/uslin.461     > ../newoutputs/t3757
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3756.tr
echo ">>>>>>>>running test 3758"
../source/print_tokens.c.inst.exe ../inputs/uslin.464     > ../newoutputs/t3758
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3757.tr
echo ">>>>>>>>running test 3759"
../source/print_tokens.c.inst.exe ../inputs/uslin.465     > ../newoutputs/t3759
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3758.tr
echo ">>>>>>>>running test 3760"
../source/print_tokens.c.inst.exe ../inputs/uslin.466     > ../newoutputs/t3760
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3759.tr
echo ">>>>>>>>running test 3761"
../source/print_tokens.c.inst.exe ../inputs/uslin.470     > ../newoutputs/t3761
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3760.tr
echo ">>>>>>>>running test 3762"
../source/print_tokens.c.inst.exe ../inputs/uslin.471     > ../newoutputs/t3762
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3761.tr
echo ">>>>>>>>running test 3763"
../source/print_tokens.c.inst.exe ../inputs/uslin.472     > ../newoutputs/t3763
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3762.tr
echo ">>>>>>>>running test 3764"
../source/print_tokens.c.inst.exe ../inputs/uslin.473     > ../newoutputs/t3764
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3763.tr
echo ">>>>>>>>running test 3765"
../source/print_tokens.c.inst.exe ../inputs/uslin.474     > ../newoutputs/t3765
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3764.tr
echo ">>>>>>>>running test 3766"
../source/print_tokens.c.inst.exe ../inputs/uslin.478     > ../newoutputs/t3766
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3765.tr
echo ">>>>>>>>running test 3767"
../source/print_tokens.c.inst.exe ../inputs/uslin.481     > ../newoutputs/t3767
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3766.tr
echo ">>>>>>>>running test 3768"
../source/print_tokens.c.inst.exe ../inputs/uslin.482     > ../newoutputs/t3768
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3767.tr
echo ">>>>>>>>running test 3769"
../source/print_tokens.c.inst.exe ../inputs/uslin.484     > ../newoutputs/t3769
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3768.tr
echo ">>>>>>>>running test 3770"
../source/print_tokens.c.inst.exe ../inputs/uslin.485     > ../newoutputs/t3770
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3769.tr
echo ">>>>>>>>running test 3771"
../source/print_tokens.c.inst.exe ../inputs/uslin.486     > ../newoutputs/t3771
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3770.tr
echo ">>>>>>>>running test 3772"
../source/print_tokens.c.inst.exe ../inputs/uslin.488     > ../newoutputs/t3772
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3771.tr
echo ">>>>>>>>running test 3773"
../source/print_tokens.c.inst.exe ../inputs/uslin.49     > ../newoutputs/t3773
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3772.tr
echo ">>>>>>>>running test 3774"
../source/print_tokens.c.inst.exe ../inputs/uslin.490     > ../newoutputs/t3774
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3773.tr
echo ">>>>>>>>running test 3775"
../source/print_tokens.c.inst.exe ../inputs/uslin.491     > ../newoutputs/t3775
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3774.tr
echo ">>>>>>>>running test 3776"
../source/print_tokens.c.inst.exe ../inputs/uslin.492     > ../newoutputs/t3776
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3775.tr
echo ">>>>>>>>running test 3777"
../source/print_tokens.c.inst.exe ../inputs/uslin.495     > ../newoutputs/t3777
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3776.tr
echo ">>>>>>>>running test 3778"
../source/print_tokens.c.inst.exe ../inputs/uslin.497     > ../newoutputs/t3778
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3777.tr
echo ">>>>>>>>running test 3779"
../source/print_tokens.c.inst.exe ../inputs/uslin.498     > ../newoutputs/t3779
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3778.tr
echo ">>>>>>>>running test 3780"
../source/print_tokens.c.inst.exe ../inputs/uslin.499     > ../newoutputs/t3780
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3779.tr
echo ">>>>>>>>running test 3781"
../source/print_tokens.c.inst.exe ../inputs/uslin.5      > ../newoutputs/t3781
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3780.tr
echo ">>>>>>>>running test 3782"
../source/print_tokens.c.inst.exe ../inputs/uslin.5.noeof     > ../newoutputs/t3782
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3781.tr
echo ">>>>>>>>running test 3783"
../source/print_tokens.c.inst.exe ../inputs/uslin.500     > ../newoutputs/t3783
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3782.tr
echo ">>>>>>>>running test 3784"
../source/print_tokens.c.inst.exe ../inputs/uslin.501     > ../newoutputs/t3784
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3783.tr
echo ">>>>>>>>running test 3785"
../source/print_tokens.c.inst.exe ../inputs/uslin.503     > ../newoutputs/t3785
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3784.tr
echo ">>>>>>>>running test 3786"
../source/print_tokens.c.inst.exe ../inputs/uslin.505     > ../newoutputs/t3786
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3785.tr
echo ">>>>>>>>running test 3787"
../source/print_tokens.c.inst.exe ../inputs/uslin.508     > ../newoutputs/t3787
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3786.tr
echo ">>>>>>>>running test 3788"
../source/print_tokens.c.inst.exe ../inputs/uslin.509     > ../newoutputs/t3788
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3787.tr
echo ">>>>>>>>running test 3789"
../source/print_tokens.c.inst.exe ../inputs/uslin.51     > ../newoutputs/t3789
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3788.tr
echo ">>>>>>>>running test 3790"
../source/print_tokens.c.inst.exe ../inputs/uslin.516     > ../newoutputs/t3790
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3789.tr
echo ">>>>>>>>running test 3791"
../source/print_tokens.c.inst.exe ../inputs/uslin.517     > ../newoutputs/t3791
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3790.tr
echo ">>>>>>>>running test 3792"
../source/print_tokens.c.inst.exe ../inputs/uslin.521     > ../newoutputs/t3792
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3791.tr
echo ">>>>>>>>running test 3793"
../source/print_tokens.c.inst.exe ../inputs/uslin.523     > ../newoutputs/t3793
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3792.tr
echo ">>>>>>>>running test 3794"
../source/print_tokens.c.inst.exe ../inputs/uslin.524     > ../newoutputs/t3794
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3793.tr
echo ">>>>>>>>running test 3795"
../source/print_tokens.c.inst.exe ../inputs/uslin.529     > ../newoutputs/t3795
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3794.tr
echo ">>>>>>>>running test 3796"
../source/print_tokens.c.inst.exe ../inputs/uslin.53     > ../newoutputs/t3796
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3795.tr
echo ">>>>>>>>running test 3797"
../source/print_tokens.c.inst.exe ../inputs/uslin.530     > ../newoutputs/t3797
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3796.tr
echo ">>>>>>>>running test 3798"
../source/print_tokens.c.inst.exe ../inputs/uslin.531     > ../newoutputs/t3798
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3797.tr
echo ">>>>>>>>running test 3799"
../source/print_tokens.c.inst.exe ../inputs/uslin.532     > ../newoutputs/t3799
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3798.tr
echo ">>>>>>>>running test 3800"
../source/print_tokens.c.inst.exe ../inputs/uslin.535     > ../newoutputs/t3800
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3799.tr
echo ">>>>>>>>running test 3801"
../source/print_tokens.c.inst.exe ../inputs/uslin.536     > ../newoutputs/t3801
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3800.tr
echo ">>>>>>>>running test 3802"
../source/print_tokens.c.inst.exe ../inputs/uslin.541     > ../newoutputs/t3802
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3801.tr
echo ">>>>>>>>running test 3803"
../source/print_tokens.c.inst.exe ../inputs/uslin.542     > ../newoutputs/t3803
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3802.tr
echo ">>>>>>>>running test 3804"
../source/print_tokens.c.inst.exe ../inputs/uslin.545     > ../newoutputs/t3804
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3803.tr
echo ">>>>>>>>running test 3805"
../source/print_tokens.c.inst.exe ../inputs/uslin.546     > ../newoutputs/t3805
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3804.tr
echo ">>>>>>>>running test 3806"
../source/print_tokens.c.inst.exe ../inputs/uslin.547     > ../newoutputs/t3806
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3805.tr
echo ">>>>>>>>running test 3807"
../source/print_tokens.c.inst.exe ../inputs/uslin.548     > ../newoutputs/t3807
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3806.tr
echo ">>>>>>>>running test 3808"
../source/print_tokens.c.inst.exe ../inputs/uslin.549     > ../newoutputs/t3808
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3807.tr
echo ">>>>>>>>running test 3809"
../source/print_tokens.c.inst.exe ../inputs/uslin.55     > ../newoutputs/t3809
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3808.tr
echo ">>>>>>>>running test 3810"
../source/print_tokens.c.inst.exe ../inputs/uslin.550      > ../newoutputs/t3810
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3809.tr
echo ">>>>>>>>running test 3811"
../source/print_tokens.c.inst.exe ../inputs/uslin.551     > ../newoutputs/t3811
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3810.tr
echo ">>>>>>>>running test 3812"
../source/print_tokens.c.inst.exe ../inputs/uslin.554     > ../newoutputs/t3812
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3811.tr
echo ">>>>>>>>running test 3813"
../source/print_tokens.c.inst.exe ../inputs/uslin.555     > ../newoutputs/t3813
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3812.tr
echo ">>>>>>>>running test 3814"
../source/print_tokens.c.inst.exe ../inputs/uslin.556     > ../newoutputs/t3814
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3813.tr
echo ">>>>>>>>running test 3815"
../source/print_tokens.c.inst.exe ../inputs/uslin.559     > ../newoutputs/t3815
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3814.tr
echo ">>>>>>>>running test 3816"
../source/print_tokens.c.inst.exe ../inputs/uslin.56     > ../newoutputs/t3816
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3815.tr
echo ">>>>>>>>running test 3817"
../source/print_tokens.c.inst.exe ../inputs/uslin.560     > ../newoutputs/t3817
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3816.tr
echo ">>>>>>>>running test 3818"
../source/print_tokens.c.inst.exe ../inputs/uslin.561     > ../newoutputs/t3818
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3817.tr
echo ">>>>>>>>running test 3819"
../source/print_tokens.c.inst.exe ../inputs/uslin.563     > ../newoutputs/t3819
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3818.tr
echo ">>>>>>>>running test 3820"
../source/print_tokens.c.inst.exe ../inputs/uslin.564     > ../newoutputs/t3820
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3819.tr
echo ">>>>>>>>running test 3821"
../source/print_tokens.c.inst.exe ../inputs/uslin.565     > ../newoutputs/t3821
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3820.tr
echo ">>>>>>>>running test 3822"
../source/print_tokens.c.inst.exe ../inputs/uslin.567     > ../newoutputs/t3822
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3821.tr
echo ">>>>>>>>running test 3823"
../source/print_tokens.c.inst.exe ../inputs/uslin.57     > ../newoutputs/t3823
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3822.tr
echo ">>>>>>>>running test 3824"
../source/print_tokens.c.inst.exe ../inputs/uslin.575     > ../newoutputs/t3824
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3823.tr
echo ">>>>>>>>running test 3825"
../source/print_tokens.c.inst.exe ../inputs/uslin.578     > ../newoutputs/t3825
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3824.tr
echo ">>>>>>>>running test 3826"
../source/print_tokens.c.inst.exe ../inputs/uslin.587     > ../newoutputs/t3826
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3825.tr
echo ">>>>>>>>running test 3827"
../source/print_tokens.c.inst.exe ../inputs/uslin.588     > ../newoutputs/t3827
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3826.tr
echo ">>>>>>>>running test 3828"
../source/print_tokens.c.inst.exe ../inputs/uslin.589     > ../newoutputs/t3828
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3827.tr
echo ">>>>>>>>running test 3829"
../source/print_tokens.c.inst.exe ../inputs/uslin.59     > ../newoutputs/t3829
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3828.tr
echo ">>>>>>>>running test 3830"
../source/print_tokens.c.inst.exe ../inputs/uslin.590     > ../newoutputs/t3830
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3829.tr
echo ">>>>>>>>running test 3831"
../source/print_tokens.c.inst.exe ../inputs/uslin.591     > ../newoutputs/t3831
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3830.tr
echo ">>>>>>>>running test 3832"
../source/print_tokens.c.inst.exe ../inputs/uslin.595     > ../newoutputs/t3832
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3831.tr
echo ">>>>>>>>running test 3833"
../source/print_tokens.c.inst.exe ../inputs/uslin.599     > ../newoutputs/t3833
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3832.tr
echo ">>>>>>>>running test 3834"
../source/print_tokens.c.inst.exe ../inputs/uslin.6     > ../newoutputs/t3834
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3833.tr
echo ">>>>>>>>running test 3835"
../source/print_tokens.c.inst.exe ../inputs/uslin.600     > ../newoutputs/t3835
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3834.tr
echo ">>>>>>>>running test 3836"
../source/print_tokens.c.inst.exe ../inputs/uslin.601     > ../newoutputs/t3836
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3835.tr
echo ">>>>>>>>running test 3837"
../source/print_tokens.c.inst.exe ../inputs/uslin.603     > ../newoutputs/t3837
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3836.tr
echo ">>>>>>>>running test 3838"
../source/print_tokens.c.inst.exe ../inputs/uslin.604     > ../newoutputs/t3838
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3837.tr
echo ">>>>>>>>running test 3839"
../source/print_tokens.c.inst.exe ../inputs/uslin.606     > ../newoutputs/t3839
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3838.tr
echo ">>>>>>>>running test 3840"
../source/print_tokens.c.inst.exe ../inputs/uslin.608     > ../newoutputs/t3840
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3839.tr
echo ">>>>>>>>running test 3841"
../source/print_tokens.c.inst.exe ../inputs/uslin.609      > ../newoutputs/t3841
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3840.tr
echo ">>>>>>>>running test 3842"
../source/print_tokens.c.inst.exe ../inputs/uslin.61     > ../newoutputs/t3842
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3841.tr
echo ">>>>>>>>running test 3843"
../source/print_tokens.c.inst.exe ../inputs/uslin.610     > ../newoutputs/t3843
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3842.tr
echo ">>>>>>>>running test 3844"
../source/print_tokens.c.inst.exe ../inputs/uslin.612     > ../newoutputs/t3844
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3843.tr
echo ">>>>>>>>running test 3845"
../source/print_tokens.c.inst.exe ../inputs/uslin.613     > ../newoutputs/t3845
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3844.tr
echo ">>>>>>>>running test 3846"
../source/print_tokens.c.inst.exe ../inputs/uslin.618     > ../newoutputs/t3846
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3845.tr
echo ">>>>>>>>running test 3847"
../source/print_tokens.c.inst.exe ../inputs/uslin.620     > ../newoutputs/t3847
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3846.tr
echo ">>>>>>>>running test 3848"
../source/print_tokens.c.inst.exe ../inputs/uslin.622     > ../newoutputs/t3848
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3847.tr
echo ">>>>>>>>running test 3849"
../source/print_tokens.c.inst.exe ../inputs/uslin.628     > ../newoutputs/t3849
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3848.tr
echo ">>>>>>>>running test 3850"
../source/print_tokens.c.inst.exe ../inputs/uslin.629      > ../newoutputs/t3850
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3849.tr
echo ">>>>>>>>running test 3851"
../source/print_tokens.c.inst.exe ../inputs/uslin.631     > ../newoutputs/t3851
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3850.tr
echo ">>>>>>>>running test 3852"
../source/print_tokens.c.inst.exe ../inputs/uslin.632     > ../newoutputs/t3852
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3851.tr
echo ">>>>>>>>running test 3853"
../source/print_tokens.c.inst.exe ../inputs/uslin.634     > ../newoutputs/t3853
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3852.tr
echo ">>>>>>>>running test 3854"
../source/print_tokens.c.inst.exe ../inputs/uslin.635     > ../newoutputs/t3854
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3853.tr
echo ">>>>>>>>running test 3855"
../source/print_tokens.c.inst.exe ../inputs/uslin.637     > ../newoutputs/t3855
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3854.tr
echo ">>>>>>>>running test 3856"
../source/print_tokens.c.inst.exe ../inputs/uslin.637.noeof     > ../newoutputs/t3856
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3855.tr
echo ">>>>>>>>running test 3857"
../source/print_tokens.c.inst.exe ../inputs/uslin.638     > ../newoutputs/t3857
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3856.tr
echo ">>>>>>>>running test 3858"
../source/print_tokens.c.inst.exe ../inputs/uslin.639     > ../newoutputs/t3858
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3857.tr
echo ">>>>>>>>running test 3859"
../source/print_tokens.c.inst.exe ../inputs/uslin.639.noeof     > ../newoutputs/t3859
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3858.tr
echo ">>>>>>>>running test 3860"
../source/print_tokens.c.inst.exe ../inputs/uslin.641     > ../newoutputs/t3860
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3859.tr
echo ">>>>>>>>running test 3861"
../source/print_tokens.c.inst.exe ../inputs/uslin.643     > ../newoutputs/t3861
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3860.tr
echo ">>>>>>>>running test 3862"
../source/print_tokens.c.inst.exe ../inputs/uslin.644     > ../newoutputs/t3862
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3861.tr
echo ">>>>>>>>running test 3863"
../source/print_tokens.c.inst.exe ../inputs/uslin.645     > ../newoutputs/t3863
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3862.tr
echo ">>>>>>>>running test 3864"
../source/print_tokens.c.inst.exe ../inputs/uslin.646     > ../newoutputs/t3864
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3863.tr
echo ">>>>>>>>running test 3865"
../source/print_tokens.c.inst.exe ../inputs/uslin.649     > ../newoutputs/t3865
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3864.tr
echo ">>>>>>>>running test 3866"
../source/print_tokens.c.inst.exe ../inputs/uslin.65     > ../newoutputs/t3866
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3865.tr
echo ">>>>>>>>running test 3867"
../source/print_tokens.c.inst.exe ../inputs/uslin.651     > ../newoutputs/t3867
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3866.tr
echo ">>>>>>>>running test 3868"
../source/print_tokens.c.inst.exe ../inputs/uslin.652     > ../newoutputs/t3868
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3867.tr
echo ">>>>>>>>running test 3869"
../source/print_tokens.c.inst.exe ../inputs/uslin.653     > ../newoutputs/t3869
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3868.tr
echo ">>>>>>>>running test 3870"
../source/print_tokens.c.inst.exe ../inputs/uslin.654     > ../newoutputs/t3870
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3869.tr
echo ">>>>>>>>running test 3871"
../source/print_tokens.c.inst.exe ../inputs/uslin.657     > ../newoutputs/t3871
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3870.tr
echo ">>>>>>>>running test 3872"
../source/print_tokens.c.inst.exe ../inputs/uslin.658     > ../newoutputs/t3872
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3871.tr
echo ">>>>>>>>running test 3873"
../source/print_tokens.c.inst.exe ../inputs/uslin.66      > ../newoutputs/t3873
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3872.tr
echo ">>>>>>>>running test 3874"
../source/print_tokens.c.inst.exe ../inputs/uslin.660     > ../newoutputs/t3874
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3873.tr
echo ">>>>>>>>running test 3875"
../source/print_tokens.c.inst.exe ../inputs/uslin.661     > ../newoutputs/t3875
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3874.tr
echo ">>>>>>>>running test 3876"
../source/print_tokens.c.inst.exe ../inputs/uslin.664     > ../newoutputs/t3876
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3875.tr
echo ">>>>>>>>running test 3877"
../source/print_tokens.c.inst.exe ../inputs/uslin.666     > ../newoutputs/t3877
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3876.tr
echo ">>>>>>>>running test 3878"
../source/print_tokens.c.inst.exe ../inputs/uslin.667     > ../newoutputs/t3878
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3877.tr
echo ">>>>>>>>running test 3879"
../source/print_tokens.c.inst.exe ../inputs/uslin.671     > ../newoutputs/t3879
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3878.tr
echo ">>>>>>>>running test 3880"
../source/print_tokens.c.inst.exe ../inputs/uslin.672     > ../newoutputs/t3880
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3879.tr
echo ">>>>>>>>running test 3881"
../source/print_tokens.c.inst.exe ../inputs/uslin.675     > ../newoutputs/t3881
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3880.tr
echo ">>>>>>>>running test 3882"
../source/print_tokens.c.inst.exe ../inputs/uslin.678     > ../newoutputs/t3882
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3881.tr
echo ">>>>>>>>running test 3883"
../source/print_tokens.c.inst.exe ../inputs/uslin.681     > ../newoutputs/t3883
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3882.tr
echo ">>>>>>>>running test 3884"
../source/print_tokens.c.inst.exe ../inputs/uslin.683     > ../newoutputs/t3884
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3883.tr
echo ">>>>>>>>running test 3885"
../source/print_tokens.c.inst.exe ../inputs/uslin.684     > ../newoutputs/t3885
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3884.tr
echo ">>>>>>>>running test 3886"
../source/print_tokens.c.inst.exe ../inputs/uslin.685     > ../newoutputs/t3886
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3885.tr
echo ">>>>>>>>running test 3887"
../source/print_tokens.c.inst.exe ../inputs/uslin.687     > ../newoutputs/t3887
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3886.tr
echo ">>>>>>>>running test 3888"
../source/print_tokens.c.inst.exe ../inputs/uslin.688     > ../newoutputs/t3888
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3887.tr
echo ">>>>>>>>running test 3889"
../source/print_tokens.c.inst.exe ../inputs/uslin.689     > ../newoutputs/t3889
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3888.tr
echo ">>>>>>>>running test 3890"
../source/print_tokens.c.inst.exe ../inputs/uslin.69     > ../newoutputs/t3890
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3889.tr
echo ">>>>>>>>running test 3891"
../source/print_tokens.c.inst.exe ../inputs/uslin.690     > ../newoutputs/t3891
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3890.tr
echo ">>>>>>>>running test 3892"
../source/print_tokens.c.inst.exe ../inputs/uslin.692     > ../newoutputs/t3892
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3891.tr
echo ">>>>>>>>running test 3893"
../source/print_tokens.c.inst.exe ../inputs/uslin.693     > ../newoutputs/t3893
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3892.tr
echo ">>>>>>>>running test 3894"
../source/print_tokens.c.inst.exe ../inputs/uslin.694     > ../newoutputs/t3894
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3893.tr
echo ">>>>>>>>running test 3895"
../source/print_tokens.c.inst.exe ../inputs/uslin.696     > ../newoutputs/t3895
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3894.tr
echo ">>>>>>>>running test 3896"
../source/print_tokens.c.inst.exe ../inputs/uslin.697     > ../newoutputs/t3896
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3895.tr
echo ">>>>>>>>running test 3897"
../source/print_tokens.c.inst.exe ../inputs/uslin.698     > ../newoutputs/t3897
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3896.tr
echo ">>>>>>>>running test 3898"
../source/print_tokens.c.inst.exe ../inputs/uslin.699     > ../newoutputs/t3898
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3897.tr
echo ">>>>>>>>running test 3899"
../source/print_tokens.c.inst.exe ../inputs/uslin.700     > ../newoutputs/t3899
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3898.tr
echo ">>>>>>>>running test 3900"
../source/print_tokens.c.inst.exe ../inputs/uslin.702     > ../newoutputs/t3900
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3899.tr
echo ">>>>>>>>running test 3901"
../source/print_tokens.c.inst.exe ../inputs/uslin.703     > ../newoutputs/t3901
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3900.tr
echo ">>>>>>>>running test 3902"
../source/print_tokens.c.inst.exe ../inputs/uslin.705     > ../newoutputs/t3902
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3901.tr
echo ">>>>>>>>running test 3903"
../source/print_tokens.c.inst.exe ../inputs/uslin.707     > ../newoutputs/t3903
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3902.tr
echo ">>>>>>>>running test 3904"
../source/print_tokens.c.inst.exe ../inputs/uslin.710     > ../newoutputs/t3904
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3903.tr
echo ">>>>>>>>running test 3905"
../source/print_tokens.c.inst.exe ../inputs/uslin.714     > ../newoutputs/t3905
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3904.tr
echo ">>>>>>>>running test 3906"
../source/print_tokens.c.inst.exe ../inputs/uslin.715     > ../newoutputs/t3906
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3905.tr
echo ">>>>>>>>running test 3907"
../source/print_tokens.c.inst.exe ../inputs/uslin.718     > ../newoutputs/t3907
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3906.tr
echo ">>>>>>>>running test 3908"
../source/print_tokens.c.inst.exe ../inputs/uslin.720     > ../newoutputs/t3908
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3907.tr
echo ">>>>>>>>running test 3909"
../source/print_tokens.c.inst.exe ../inputs/uslin.722     > ../newoutputs/t3909
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3908.tr
echo ">>>>>>>>running test 3910"
../source/print_tokens.c.inst.exe ../inputs/uslin.724     > ../newoutputs/t3910
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3909.tr
echo ">>>>>>>>running test 3911"
../source/print_tokens.c.inst.exe ../inputs/uslin.724.noeof     > ../newoutputs/t3911
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3910.tr
echo ">>>>>>>>running test 3912"
../source/print_tokens.c.inst.exe ../inputs/uslin.725     > ../newoutputs/t3912
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3911.tr
echo ">>>>>>>>running test 3913"
../source/print_tokens.c.inst.exe ../inputs/uslin.726     > ../newoutputs/t3913
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3912.tr
echo ">>>>>>>>running test 3914"
../source/print_tokens.c.inst.exe ../inputs/uslin.729     > ../newoutputs/t3914
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3913.tr
echo ">>>>>>>>running test 3915"
../source/print_tokens.c.inst.exe ../inputs/uslin.73     > ../newoutputs/t3915
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3914.tr
echo ">>>>>>>>running test 3916"
../source/print_tokens.c.inst.exe ../inputs/uslin.730     > ../newoutputs/t3916
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3915.tr
echo ">>>>>>>>running test 3917"
../source/print_tokens.c.inst.exe ../inputs/uslin.731     > ../newoutputs/t3917
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3916.tr
echo ">>>>>>>>running test 3918"
../source/print_tokens.c.inst.exe ../inputs/uslin.732     > ../newoutputs/t3918
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3917.tr
echo ">>>>>>>>running test 3919"
../source/print_tokens.c.inst.exe ../inputs/uslin.733     > ../newoutputs/t3919
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3918.tr
echo ">>>>>>>>running test 3920"
../source/print_tokens.c.inst.exe ../inputs/uslin.735     > ../newoutputs/t3920
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3919.tr
echo ">>>>>>>>running test 3921"
../source/print_tokens.c.inst.exe ../inputs/uslin.737     > ../newoutputs/t3921
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3920.tr
echo ">>>>>>>>running test 3922"
../source/print_tokens.c.inst.exe ../inputs/uslin.739     > ../newoutputs/t3922
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3921.tr
echo ">>>>>>>>running test 3923"
../source/print_tokens.c.inst.exe ../inputs/uslin.740     > ../newoutputs/t3923
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3922.tr
echo ">>>>>>>>running test 3924"
../source/print_tokens.c.inst.exe ../inputs/uslin.741     > ../newoutputs/t3924
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3923.tr
echo ">>>>>>>>running test 3925"
../source/print_tokens.c.inst.exe ../inputs/uslin.743     > ../newoutputs/t3925
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3924.tr
echo ">>>>>>>>running test 3926"
../source/print_tokens.c.inst.exe ../inputs/uslin.745      > ../newoutputs/t3926
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3925.tr
echo ">>>>>>>>running test 3927"
../source/print_tokens.c.inst.exe ../inputs/uslin.749     > ../newoutputs/t3927
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3926.tr
echo ">>>>>>>>running test 3928"
../source/print_tokens.c.inst.exe ../inputs/uslin.750     > ../newoutputs/t3928
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3927.tr
echo ">>>>>>>>running test 3929"
../source/print_tokens.c.inst.exe ../inputs/uslin.754     > ../newoutputs/t3929
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3928.tr
echo ">>>>>>>>running test 3930"
../source/print_tokens.c.inst.exe ../inputs/uslin.755     > ../newoutputs/t3930
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3929.tr
echo ">>>>>>>>running test 3931"
../source/print_tokens.c.inst.exe ../inputs/uslin.757     > ../newoutputs/t3931
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3930.tr
echo ">>>>>>>>running test 3932"
../source/print_tokens.c.inst.exe ../inputs/uslin.759     > ../newoutputs/t3932
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3931.tr
echo ">>>>>>>>running test 3933"
../source/print_tokens.c.inst.exe ../inputs/uslin.762     > ../newoutputs/t3933
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3932.tr
echo ">>>>>>>>running test 3934"
../source/print_tokens.c.inst.exe ../inputs/uslin.763     > ../newoutputs/t3934
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3933.tr
echo ">>>>>>>>running test 3935"
../source/print_tokens.c.inst.exe ../inputs/uslin.764     > ../newoutputs/t3935
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3934.tr
echo ">>>>>>>>running test 3936"
../source/print_tokens.c.inst.exe ../inputs/uslin.77.noeof     > ../newoutputs/t3936
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3935.tr
echo ">>>>>>>>running test 3937"
../source/print_tokens.c.inst.exe ../inputs/uslin.770     > ../newoutputs/t3937
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3936.tr
echo ">>>>>>>>running test 3938"
../source/print_tokens.c.inst.exe ../inputs/uslin.771     > ../newoutputs/t3938
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3937.tr
echo ">>>>>>>>running test 3939"
../source/print_tokens.c.inst.exe ../inputs/uslin.774     > ../newoutputs/t3939
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3938.tr
echo ">>>>>>>>running test 3940"
../source/print_tokens.c.inst.exe ../inputs/uslin.780     > ../newoutputs/t3940
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3939.tr
echo ">>>>>>>>running test 3941"
../source/print_tokens.c.inst.exe ../inputs/uslin.782     > ../newoutputs/t3941
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3940.tr
echo ">>>>>>>>running test 3942"
../source/print_tokens.c.inst.exe ../inputs/uslin.783     > ../newoutputs/t3942
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3941.tr
echo ">>>>>>>>running test 3943"
../source/print_tokens.c.inst.exe ../inputs/uslin.785     > ../newoutputs/t3943
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3942.tr
echo ">>>>>>>>running test 3944"
../source/print_tokens.c.inst.exe ../inputs/uslin.792     > ../newoutputs/t3944
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3943.tr
echo ">>>>>>>>running test 3945"
../source/print_tokens.c.inst.exe ../inputs/uslin.794     > ../newoutputs/t3945
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3944.tr
echo ">>>>>>>>running test 3946"
../source/print_tokens.c.inst.exe ../inputs/uslin.795     > ../newoutputs/t3946
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3945.tr
echo ">>>>>>>>running test 3947"
../source/print_tokens.c.inst.exe ../inputs/uslin.796     > ../newoutputs/t3947
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3946.tr
echo ">>>>>>>>running test 3948"
../source/print_tokens.c.inst.exe ../inputs/uslin.797      > ../newoutputs/t3948
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3947.tr
echo ">>>>>>>>running test 3949"
../source/print_tokens.c.inst.exe ../inputs/uslin.799     > ../newoutputs/t3949
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3948.tr
echo ">>>>>>>>running test 3950"
../source/print_tokens.c.inst.exe ../inputs/uslin.800     > ../newoutputs/t3950
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3949.tr
echo ">>>>>>>>running test 3951"
../source/print_tokens.c.inst.exe ../inputs/uslin.801     > ../newoutputs/t3951
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3950.tr
echo ">>>>>>>>running test 3952"
../source/print_tokens.c.inst.exe ../inputs/uslin.802     > ../newoutputs/t3952
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3951.tr
echo ">>>>>>>>running test 3953"
../source/print_tokens.c.inst.exe ../inputs/uslin.804     > ../newoutputs/t3953
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3952.tr
echo ">>>>>>>>running test 3954"
../source/print_tokens.c.inst.exe ../inputs/uslin.805     > ../newoutputs/t3954
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3953.tr
echo ">>>>>>>>running test 3955"
../source/print_tokens.c.inst.exe ../inputs/uslin.806     > ../newoutputs/t3955
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3954.tr
echo ">>>>>>>>running test 3956"
../source/print_tokens.c.inst.exe ../inputs/uslin.809     > ../newoutputs/t3956
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3955.tr
echo ">>>>>>>>running test 3957"
../source/print_tokens.c.inst.exe ../inputs/uslin.81     > ../newoutputs/t3957
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3956.tr
echo ">>>>>>>>running test 3958"
../source/print_tokens.c.inst.exe ../inputs/uslin.810     > ../newoutputs/t3958
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3957.tr
echo ">>>>>>>>running test 3959"
../source/print_tokens.c.inst.exe ../inputs/uslin.812     > ../newoutputs/t3959
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3958.tr
echo ">>>>>>>>running test 3960"
../source/print_tokens.c.inst.exe ../inputs/uslin.813     > ../newoutputs/t3960
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3959.tr
echo ">>>>>>>>running test 3961"
../source/print_tokens.c.inst.exe ../inputs/uslin.815      > ../newoutputs/t3961
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3960.tr
echo ">>>>>>>>running test 3962"
../source/print_tokens.c.inst.exe ../inputs/uslin.817     > ../newoutputs/t3962
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3961.tr
echo ">>>>>>>>running test 3963"
../source/print_tokens.c.inst.exe ../inputs/uslin.819     > ../newoutputs/t3963
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3962.tr
echo ">>>>>>>>running test 3964"
../source/print_tokens.c.inst.exe ../inputs/uslin.820     > ../newoutputs/t3964
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3963.tr
echo ">>>>>>>>running test 3965"
../source/print_tokens.c.inst.exe ../inputs/uslin.822     > ../newoutputs/t3965
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3964.tr
echo ">>>>>>>>running test 3966"
../source/print_tokens.c.inst.exe ../inputs/uslin.824     > ../newoutputs/t3966
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3965.tr
echo ">>>>>>>>running test 3967"
../source/print_tokens.c.inst.exe ../inputs/uslin.826     > ../newoutputs/t3967
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3966.tr
echo ">>>>>>>>running test 3968"
../source/print_tokens.c.inst.exe ../inputs/uslin.827      > ../newoutputs/t3968
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3967.tr
echo ">>>>>>>>running test 3969"
../source/print_tokens.c.inst.exe ../inputs/uslin.830     > ../newoutputs/t3969
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3968.tr
echo ">>>>>>>>running test 3970"
../source/print_tokens.c.inst.exe ../inputs/uslin.833     > ../newoutputs/t3970
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3969.tr
echo ">>>>>>>>running test 3971"
../source/print_tokens.c.inst.exe ../inputs/uslin.835     > ../newoutputs/t3971
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3970.tr
echo ">>>>>>>>running test 3972"
../source/print_tokens.c.inst.exe ../inputs/uslin.838     > ../newoutputs/t3972
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3971.tr
echo ">>>>>>>>running test 3973"
../source/print_tokens.c.inst.exe ../inputs/uslin.839     > ../newoutputs/t3973
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3972.tr
echo ">>>>>>>>running test 3974"
../source/print_tokens.c.inst.exe ../inputs/uslin.84     > ../newoutputs/t3974
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3973.tr
echo ">>>>>>>>running test 3975"
../source/print_tokens.c.inst.exe ../inputs/uslin.841     > ../newoutputs/t3975
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3974.tr
echo ">>>>>>>>running test 3976"
../source/print_tokens.c.inst.exe ../inputs/uslin.842     > ../newoutputs/t3976
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3975.tr
echo ">>>>>>>>running test 3977"
../source/print_tokens.c.inst.exe ../inputs/uslin.844     > ../newoutputs/t3977
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3976.tr
echo ">>>>>>>>running test 3978"
../source/print_tokens.c.inst.exe ../inputs/uslin.845     > ../newoutputs/t3978
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3977.tr
echo ">>>>>>>>running test 3979"
../source/print_tokens.c.inst.exe ../inputs/uslin.846     > ../newoutputs/t3979
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3978.tr
echo ">>>>>>>>running test 3980"
../source/print_tokens.c.inst.exe ../inputs/uslin.847     > ../newoutputs/t3980
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3979.tr
echo ">>>>>>>>running test 3981"
../source/print_tokens.c.inst.exe ../inputs/uslin.848     > ../newoutputs/t3981
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3980.tr
echo ">>>>>>>>running test 3982"
../source/print_tokens.c.inst.exe ../inputs/uslin.849      > ../newoutputs/t3982
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3981.tr
echo ">>>>>>>>running test 3983"
../source/print_tokens.c.inst.exe ../inputs/uslin.850     > ../newoutputs/t3983
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3982.tr
echo ">>>>>>>>running test 3984"
../source/print_tokens.c.inst.exe ../inputs/uslin.852     > ../newoutputs/t3984
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3983.tr
echo ">>>>>>>>running test 3985"
../source/print_tokens.c.inst.exe ../inputs/uslin.853     > ../newoutputs/t3985
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3984.tr
echo ">>>>>>>>running test 3986"
../source/print_tokens.c.inst.exe ../inputs/uslin.854     > ../newoutputs/t3986
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3985.tr
echo ">>>>>>>>running test 3987"
../source/print_tokens.c.inst.exe ../inputs/uslin.856     > ../newoutputs/t3987
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3986.tr
echo ">>>>>>>>running test 3988"
../source/print_tokens.c.inst.exe ../inputs/uslin.857     > ../newoutputs/t3988
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3987.tr
echo ">>>>>>>>running test 3989"
../source/print_tokens.c.inst.exe ../inputs/uslin.859     > ../newoutputs/t3989
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3988.tr
echo ">>>>>>>>running test 3990"
../source/print_tokens.c.inst.exe ../inputs/uslin.86     > ../newoutputs/t3990
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3989.tr
echo ">>>>>>>>running test 3991"
../source/print_tokens.c.inst.exe ../inputs/uslin.861     > ../newoutputs/t3991
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3990.tr
echo ">>>>>>>>running test 3992"
../source/print_tokens.c.inst.exe ../inputs/uslin.863     > ../newoutputs/t3992
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3991.tr
echo ">>>>>>>>running test 3993"
../source/print_tokens.c.inst.exe ../inputs/uslin.867     > ../newoutputs/t3993
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3992.tr
echo ">>>>>>>>running test 3994"
../source/print_tokens.c.inst.exe ../inputs/uslin.868     > ../newoutputs/t3994
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3993.tr
echo ">>>>>>>>running test 3995"
../source/print_tokens.c.inst.exe ../inputs/uslin.869     > ../newoutputs/t3995
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3994.tr
echo ">>>>>>>>running test 3996"
../source/print_tokens.c.inst.exe ../inputs/uslin.870     > ../newoutputs/t3996
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3995.tr
echo ">>>>>>>>running test 3997"
../source/print_tokens.c.inst.exe ../inputs/uslin.870.noeof     > ../newoutputs/t3997
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3996.tr
echo ">>>>>>>>running test 3998"
../source/print_tokens.c.inst.exe ../inputs/uslin.873     > ../newoutputs/t3998
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3997.tr
echo ">>>>>>>>running test 3999"
../source/print_tokens.c.inst.exe ../inputs/uslin.874     > ../newoutputs/t3999
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3998.tr
echo ">>>>>>>>running test 4000"
../source/print_tokens.c.inst.exe ../inputs/uslin.877      > ../newoutputs/t4000
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/3999.tr
echo ">>>>>>>>running test 4001"
../source/print_tokens.c.inst.exe ../inputs/uslin.878     > ../newoutputs/t4001
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4000.tr
echo ">>>>>>>>running test 4002"
../source/print_tokens.c.inst.exe ../inputs/uslin.879     > ../newoutputs/t4002
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4001.tr
echo ">>>>>>>>running test 4003"
../source/print_tokens.c.inst.exe ../inputs/uslin.881     > ../newoutputs/t4003
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4002.tr
echo ">>>>>>>>running test 4004"
../source/print_tokens.c.inst.exe ../inputs/uslin.882     > ../newoutputs/t4004
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4003.tr
echo ">>>>>>>>running test 4005"
../source/print_tokens.c.inst.exe ../inputs/uslin.883     > ../newoutputs/t4005
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4004.tr
echo ">>>>>>>>running test 4006"
../source/print_tokens.c.inst.exe ../inputs/uslin.884     > ../newoutputs/t4006
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4005.tr
echo ">>>>>>>>running test 4007"
../source/print_tokens.c.inst.exe ../inputs/uslin.885     > ../newoutputs/t4007
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4006.tr
echo ">>>>>>>>running test 4008"
../source/print_tokens.c.inst.exe ../inputs/uslin.885.noeof     > ../newoutputs/t4008
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4007.tr
echo ">>>>>>>>running test 4009"
../source/print_tokens.c.inst.exe ../inputs/uslin.886     > ../newoutputs/t4009
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4008.tr
echo ">>>>>>>>running test 4010"
../source/print_tokens.c.inst.exe ../inputs/uslin.887     > ../newoutputs/t4010
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4009.tr
echo ">>>>>>>>running test 4011"
../source/print_tokens.c.inst.exe ../inputs/uslin.889     > ../newoutputs/t4011
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4010.tr
echo ">>>>>>>>running test 4012"
../source/print_tokens.c.inst.exe ../inputs/uslin.890     > ../newoutputs/t4012
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4011.tr
echo ">>>>>>>>running test 4013"
../source/print_tokens.c.inst.exe ../inputs/uslin.891     > ../newoutputs/t4013
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4012.tr
echo ">>>>>>>>running test 4014"
../source/print_tokens.c.inst.exe ../inputs/uslin.893     > ../newoutputs/t4014
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4013.tr
echo ">>>>>>>>running test 4015"
../source/print_tokens.c.inst.exe ../inputs/uslin.894     > ../newoutputs/t4015
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4014.tr
echo ">>>>>>>>running test 4016"
../source/print_tokens.c.inst.exe ../inputs/uslin.897     > ../newoutputs/t4016
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4015.tr
echo ">>>>>>>>running test 4017"
../source/print_tokens.c.inst.exe ../inputs/uslin.899     > ../newoutputs/t4017
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4016.tr
echo ">>>>>>>>running test 4018"
../source/print_tokens.c.inst.exe ../inputs/uslin.90     > ../newoutputs/t4018
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4017.tr
echo ">>>>>>>>running test 4019"
../source/print_tokens.c.inst.exe ../inputs/uslin.900     > ../newoutputs/t4019
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4018.tr
echo ">>>>>>>>running test 4020"
../source/print_tokens.c.inst.exe ../inputs/uslin.901     > ../newoutputs/t4020
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4019.tr
echo ">>>>>>>>running test 4021"
../source/print_tokens.c.inst.exe ../inputs/uslin.902     > ../newoutputs/t4021
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4020.tr
echo ">>>>>>>>running test 4022"
../source/print_tokens.c.inst.exe ../inputs/uslin.907     > ../newoutputs/t4022
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4021.tr
echo ">>>>>>>>running test 4023"
../source/print_tokens.c.inst.exe ../inputs/uslin.908     > ../newoutputs/t4023
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4022.tr
echo ">>>>>>>>running test 4024"
../source/print_tokens.c.inst.exe ../inputs/uslin.909     > ../newoutputs/t4024
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4023.tr
echo ">>>>>>>>running test 4025"
../source/print_tokens.c.inst.exe ../inputs/uslin.91     > ../newoutputs/t4025
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4024.tr
echo ">>>>>>>>running test 4026"
../source/print_tokens.c.inst.exe ../inputs/uslin.911     > ../newoutputs/t4026
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4025.tr
echo ">>>>>>>>running test 4027"
../source/print_tokens.c.inst.exe ../inputs/uslin.912     > ../newoutputs/t4027
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4026.tr
echo ">>>>>>>>running test 4028"
../source/print_tokens.c.inst.exe ../inputs/uslin.916     > ../newoutputs/t4028
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4027.tr
echo ">>>>>>>>running test 4029"
../source/print_tokens.c.inst.exe ../inputs/uslin.917     > ../newoutputs/t4029
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4028.tr
echo ">>>>>>>>running test 4030"
../source/print_tokens.c.inst.exe ../inputs/uslin.918     > ../newoutputs/t4030
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4029.tr
echo ">>>>>>>>running test 4031"
../source/print_tokens.c.inst.exe ../inputs/uslin.919     > ../newoutputs/t4031
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4030.tr
echo ">>>>>>>>running test 4032"
../source/print_tokens.c.inst.exe ../inputs/uslin.921     > ../newoutputs/t4032
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4031.tr
echo ">>>>>>>>running test 4033"
../source/print_tokens.c.inst.exe ../inputs/uslin.925      > ../newoutputs/t4033
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4032.tr
echo ">>>>>>>>running test 4034"
../source/print_tokens.c.inst.exe ../inputs/uslin.928     > ../newoutputs/t4034
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4033.tr
echo ">>>>>>>>running test 4035"
../source/print_tokens.c.inst.exe ../inputs/uslin.929     > ../newoutputs/t4035
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4034.tr
echo ">>>>>>>>running test 4036"
../source/print_tokens.c.inst.exe ../inputs/uslin.931     > ../newoutputs/t4036
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4035.tr
echo ">>>>>>>>running test 4037"
../source/print_tokens.c.inst.exe ../inputs/uslin.932     > ../newoutputs/t4037
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4036.tr
echo ">>>>>>>>running test 4038"
../source/print_tokens.c.inst.exe ../inputs/uslin.934     > ../newoutputs/t4038
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4037.tr
echo ">>>>>>>>running test 4039"
../source/print_tokens.c.inst.exe ../inputs/uslin.935     > ../newoutputs/t4039
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4038.tr
echo ">>>>>>>>running test 4040"
../source/print_tokens.c.inst.exe ../inputs/uslin.936     > ../newoutputs/t4040
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4039.tr
echo ">>>>>>>>running test 4041"
../source/print_tokens.c.inst.exe ../inputs/uslin.938     > ../newoutputs/t4041
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4040.tr
echo ">>>>>>>>running test 4042"
../source/print_tokens.c.inst.exe ../inputs/uslin.939     > ../newoutputs/t4042
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4041.tr
echo ">>>>>>>>running test 4043"
../source/print_tokens.c.inst.exe ../inputs/uslin.940     > ../newoutputs/t4043
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4042.tr
echo ">>>>>>>>running test 4044"
../source/print_tokens.c.inst.exe ../inputs/uslin.941     > ../newoutputs/t4044
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4043.tr
echo ">>>>>>>>running test 4045"
../source/print_tokens.c.inst.exe ../inputs/uslin.943     > ../newoutputs/t4045
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4044.tr
echo ">>>>>>>>running test 4046"
../source/print_tokens.c.inst.exe ../inputs/uslin.946     > ../newoutputs/t4046
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4045.tr
echo ">>>>>>>>running test 4047"
../source/print_tokens.c.inst.exe ../inputs/uslin.947     > ../newoutputs/t4047
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4046.tr
echo ">>>>>>>>running test 4048"
../source/print_tokens.c.inst.exe ../inputs/uslin.948     > ../newoutputs/t4048
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4047.tr
echo ">>>>>>>>running test 4049"
../source/print_tokens.c.inst.exe ../inputs/uslin.95     > ../newoutputs/t4049
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4048.tr
echo ">>>>>>>>running test 4050"
../source/print_tokens.c.inst.exe ../inputs/uslin.950     > ../newoutputs/t4050
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4049.tr
echo ">>>>>>>>running test 4051"
../source/print_tokens.c.inst.exe ../inputs/uslin.951     > ../newoutputs/t4051
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4050.tr
echo ">>>>>>>>running test 4052"
../source/print_tokens.c.inst.exe ../inputs/uslin.952     > ../newoutputs/t4052
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4051.tr
echo ">>>>>>>>running test 4053"
../source/print_tokens.c.inst.exe ../inputs/uslin.956     > ../newoutputs/t4053
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4052.tr
echo ">>>>>>>>running test 4054"
../source/print_tokens.c.inst.exe ../inputs/uslin.959     > ../newoutputs/t4054
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4053.tr
echo ">>>>>>>>running test 4055"
../source/print_tokens.c.inst.exe ../inputs/uslin.963     > ../newoutputs/t4055
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4054.tr
echo ">>>>>>>>running test 4056"
../source/print_tokens.c.inst.exe ../inputs/uslin.965     > ../newoutputs/t4056
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4055.tr
echo ">>>>>>>>running test 4057"
../source/print_tokens.c.inst.exe ../inputs/uslin.967     > ../newoutputs/t4057
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4056.tr
echo ">>>>>>>>running test 4058"
../source/print_tokens.c.inst.exe ../inputs/uslin.970     > ../newoutputs/t4058
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4057.tr
echo ">>>>>>>>running test 4059"
../source/print_tokens.c.inst.exe ../inputs/uslin.972     > ../newoutputs/t4059
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4058.tr
echo ">>>>>>>>running test 4060"
../source/print_tokens.c.inst.exe ../inputs/uslin.975     > ../newoutputs/t4060
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4059.tr
echo ">>>>>>>>running test 4061"
../source/print_tokens.c.inst.exe ../inputs/uslin.976     > ../newoutputs/t4061
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4060.tr
echo ">>>>>>>>running test 4062"
../source/print_tokens.c.inst.exe ../inputs/uslin.977     > ../newoutputs/t4062
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4061.tr
echo ">>>>>>>>running test 4063"
../source/print_tokens.c.inst.exe ../inputs/uslin.979     > ../newoutputs/t4063
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4062.tr
echo ">>>>>>>>running test 4064"
../source/print_tokens.c.inst.exe ../inputs/uslin.980     > ../newoutputs/t4064
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4063.tr
echo ">>>>>>>>running test 4065"
../source/print_tokens.c.inst.exe ../inputs/uslin.983     > ../newoutputs/t4065
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4064.tr
echo ">>>>>>>>running test 4066"
../source/print_tokens.c.inst.exe ../inputs/uslin.985     > ../newoutputs/t4066
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4065.tr
echo ">>>>>>>>running test 4067"
../source/print_tokens.c.inst.exe ../inputs/uslin.986     > ../newoutputs/t4067
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4066.tr
echo ">>>>>>>>running test 4068"
../source/print_tokens.c.inst.exe ../inputs/uslin.988     > ../newoutputs/t4068
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4067.tr
echo ">>>>>>>>running test 4069"
../source/print_tokens.c.inst.exe ../inputs/uslin.990     > ../newoutputs/t4069
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4068.tr
echo ">>>>>>>>running test 4070"
../source/print_tokens.c.inst.exe ../inputs/uslin.997     > ../newoutputs/t4070
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4069.tr
echo ">>>>>>>>running test 4071"
../source/print_tokens.c.inst.exe ../inputs/uslin.998     > ../newoutputs/t4071
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4070.tr
echo ">>>>>>>>running test 4072"
../source/print_tokens.c.inst.exe ../inputs/garbage/nothing     > ../newoutputs/t4072
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4071.tr
echo ">>>>>>>>running test 4073"
../source/print_tokens.c.inst.exe ../inputs/garbage/nothing     > ../newoutputs/t4073
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4072.tr
echo ">>>>>>>>running test 4074"
../source/print_tokens.c.inst.exe ../inputs/garbage/nothing     > ../newoutputs/t4074
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4073.tr
echo ">>>>>>>>running test 4075"
../source/print_tokens.c.inst.exe ../inputs/garbage/nothing     > ../newoutputs/t4075
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4074.tr
echo ">>>>>>>>running test 4076"
../source/print_tokens.c.inst.exe ../inputs/garbage/nothing     > ../newoutputs/t4076
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4075.tr
echo ">>>>>>>>running test 4077"
../source/print_tokens.c.inst.exe ../inputs/garbage/nothing     > ../newoutputs/t4077
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4076.tr
echo ">>>>>>>>running test 4078"
../source/print_tokens.c.inst.exe ../inputs/garbage/nothing     > ../newoutputs/t4078
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4077.tr
echo ">>>>>>>>running test 4079"
../source/print_tokens.c.inst.exe ../inputs/garbage/nothing     > ../newoutputs/t4079
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4078.tr
echo ">>>>>>>>running test 4080"
../source/print_tokens.c.inst.exe ../inputs/garbage/nothing     > ../newoutputs/t4080
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4079.tr
echo ">>>>>>>>running test 4081"
../source/print_tokens.c.inst.exe ../inputs/garbage/nothing     > ../newoutputs/t4081
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4080.tr
echo ">>>>>>>>running test 4082"
../source/print_tokens.c.inst.exe ../inputs/garbage/nothing     > ../newoutputs/t4082
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4081.tr
echo ">>>>>>>>running test 4083"
../source/print_tokens.c.inst.exe ../inputs/garbage/nothing     > ../newoutputs/t4083
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4082.tr
echo ">>>>>>>>running test 4084"
../source/print_tokens.c.inst.exe ../inputs/garbage/nothing     > ../newoutputs/t4084
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4083.tr
echo ">>>>>>>>running test 4085"
../source/print_tokens.c.inst.exe ../inputs/garbage/nothing     > ../newoutputs/t4085
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4084.tr
echo ">>>>>>>>running test 4086"
../source/print_tokens.c.inst.exe ../inputs/garbage/nothing     > ../newoutputs/t4086
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4085.tr
echo ">>>>>>>>running test 4087"
../source/print_tokens.c.inst.exe ../inputs/garbage/nothing     > ../newoutputs/t4087
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4086.tr
echo ">>>>>>>>running test 4088"
../source/print_tokens.c.inst.exe ../inputs/garbage/nothing     > ../newoutputs/t4088
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4087.tr
echo ">>>>>>>>running test 4089"
../source/print_tokens.c.inst.exe ../inputs/garbage/nothing     > ../newoutputs/t4089
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4088.tr
echo ">>>>>>>>running test 4090"
../source/print_tokens.c.inst.exe ../inputs/garbage/nothing     > ../newoutputs/t4090
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4089.tr
echo ">>>>>>>>running test 4091"
../source/print_tokens.c.inst.exe ../inputs/garbage/nothing     > ../newoutputs/t4091
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4090.tr
echo ">>>>>>>>running test 4092"
../source/print_tokens.c.inst.exe ../inputs/garbage/nothing     > ../newoutputs/t4092
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4091.tr
echo ">>>>>>>>running test 4093"
../source/print_tokens.c.inst.exe ../inputs/garbage/nothing     > ../newoutputs/t4093
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4092.tr
echo ">>>>>>>>running test 4094"
../source/print_tokens.c.inst.exe ../inputs/garbage/nothing     > ../newoutputs/t4094
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4093.tr
echo ">>>>>>>>running test 4095"
../source/print_tokens.c.inst.exe ../inputs/garbage/nothing     > ../newoutputs/t4095
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4094.tr
echo ">>>>>>>>running test 4096"
../source/print_tokens.c.inst.exe ../inputs/garbage/nothing     > ../newoutputs/t4096
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4095.tr
echo ">>>>>>>>running test 4097"
../source/print_tokens.c.inst.exe ../inputs/garbage/nothing     > ../newoutputs/t4097
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4096.tr
echo ">>>>>>>>running test 4098"
../source/print_tokens.c.inst.exe ../inputs/garbage/nothing     > ../newoutputs/t4098
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4097.tr
echo ">>>>>>>>running test 4099"
../source/print_tokens.c.inst.exe ../inputs/garbage/nothing     > ../newoutputs/t4099
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4098.tr
echo ">>>>>>>>running test 4100"
../source/print_tokens.c.inst.exe ../inputs/garbage/nothing     > ../newoutputs/t4100
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4099.tr
echo ">>>>>>>>running test 4101"
../source/print_tokens.c.inst.exe one doesntliketwo     > ../newoutputs/t4101
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4100.tr
echo ">>>>>>>>running test 4102"
../source/print_tokens.c.inst.exe one doesntliketwo     > ../newoutputs/t4102
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4101.tr
echo ">>>>>>>>running test 4103"
../source/print_tokens.c.inst.exe one doesntliketwo     > ../newoutputs/t4103
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4102.tr
echo ">>>>>>>>running test 4104"
../source/print_tokens.c.inst.exe one doesntliketwo     > ../newoutputs/t4104
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4103.tr
echo ">>>>>>>>running test 4105"
../source/print_tokens.c.inst.exe one doesntliketwo     > ../newoutputs/t4105
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4104.tr
echo ">>>>>>>>running test 4106"
../source/print_tokens.c.inst.exe one doesntliketwo     > ../newoutputs/t4106
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4105.tr
echo ">>>>>>>>running test 4107"
../source/print_tokens.c.inst.exe one doesntliketwo     > ../newoutputs/t4107
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4106.tr
echo ">>>>>>>>running test 4108"
../source/print_tokens.c.inst.exe one doesntliketwo     > ../newoutputs/t4108
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4107.tr
echo ">>>>>>>>running test 4109"
../source/print_tokens.c.inst.exe one doesntliketwo     > ../newoutputs/t4109
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4108.tr
echo ">>>>>>>>running test 4110"
../source/print_tokens.c.inst.exe one doesntliketwo     > ../newoutputs/t4110
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4109.tr
echo ">>>>>>>>running test 4111"
../source/print_tokens.c.inst.exe one doesntliketwo     > ../newoutputs/t4111
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4110.tr
echo ">>>>>>>>running test 4112"
../source/print_tokens.c.inst.exe one doesntliketwo     > ../newoutputs/t4112
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4111.tr
echo ">>>>>>>>running test 4113"
../source/print_tokens.c.inst.exe one doesntliketwo     > ../newoutputs/t4113
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4112.tr
echo ">>>>>>>>running test 4114"
../source/print_tokens.c.inst.exe one doesntliketwo     > ../newoutputs/t4114
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4113.tr
echo ">>>>>>>>running test 4115"
../source/print_tokens.c.inst.exe one doesntliketwo     > ../newoutputs/t4115
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4114.tr
echo ">>>>>>>>running test 4116"
../source/print_tokens.c.inst.exe one doesntliketwo     > ../newoutputs/t4116
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4115.tr
echo ">>>>>>>>running test 4117"
../source/print_tokens.c.inst.exe one doesntliketwo     > ../newoutputs/t4117
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4116.tr
echo ">>>>>>>>running test 4118"
../source/print_tokens.c.inst.exe one doesntliketwo     > ../newoutputs/t4118
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4117.tr
echo ">>>>>>>>running test 4119"
../source/print_tokens.c.inst.exe one doesntliketwo     > ../newoutputs/t4119
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4118.tr
echo ">>>>>>>>running test 4120"
../source/print_tokens.c.inst.exe one doesntliketwo     > ../newoutputs/t4120
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4119.tr
echo ">>>>>>>>running test 4121"
../source/print_tokens.c.inst.exe one doesntliketwo     > ../newoutputs/t4121
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4120.tr
echo ">>>>>>>>running test 4122"
../source/print_tokens.c.inst.exe one doesntliketwo     > ../newoutputs/t4122
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4121.tr
echo ">>>>>>>>running test 4123"
../source/print_tokens.c.inst.exe one doesntliketwo     > ../newoutputs/t4123
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4122.tr
echo ">>>>>>>>running test 4124"
../source/print_tokens.c.inst.exe one doesntliketwo     > ../newoutputs/t4124
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4123.tr
echo ">>>>>>>>running test 4125"
../source/print_tokens.c.inst.exe one doesntliketwo     > ../newoutputs/t4125
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4124.tr
echo ">>>>>>>>running test 4126"
../source/print_tokens.c.inst.exe one doesntliketwo     > ../newoutputs/t4126
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4125.tr
echo ">>>>>>>>running test 4127"
../source/print_tokens.c.inst.exe one doesntliketwo     > ../newoutputs/t4127
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4126.tr
echo ">>>>>>>>running test 4128"
../source/print_tokens.c.inst.exe one doesntliketwo     > ../newoutputs/t4128
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4127.tr
echo ">>>>>>>>running test 4129"
../source/print_tokens.c.inst.exe one doesntliketwo     > ../newoutputs/t4129
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4128.tr
echo ">>>>>>>>running test 4130"
../source/print_tokens.c.inst.exe one doesntliketwo     > ../newoutputs/t4130
cp $ARISTOTLE_DB_DIR/print_tokens.c.tr ../traces/4129.tr
