echo script type: R
echo ">>>>>>>>running test 1"
../source/print_tokens.exe  < ../inputs/newtst148.tst > ../outputs/t1
echo ">>>>>>>>running test 2"
../source/print_tokens.exe  < ../inputs/newtst1.tst > ../outputs/t2
echo ">>>>>>>>running test 3"
../source/print_tokens.exe  < ../inputs/newtst1.tst.tst > ../outputs/t3
echo ">>>>>>>>running test 4"
../source/print_tokens.exe  < ../inputs/newtst10.tst > ../outputs/t4
echo ">>>>>>>>running test 5"
../source/print_tokens.exe  < ../inputs/newtst100.tst > ../outputs/t5
echo ">>>>>>>>running test 6"
../source/print_tokens.exe  < ../inputs/newtst101.tst > ../outputs/t6
echo ">>>>>>>>running test 7"
../source/print_tokens.exe  < ../inputs/newtst102.tst > ../outputs/t7
echo ">>>>>>>>running test 8"
../source/print_tokens.exe  < ../inputs/newtst103.tst > ../outputs/t8
echo ">>>>>>>>running test 9"
../source/print_tokens.exe  < ../inputs/newtst104.tst > ../outputs/t9
echo ">>>>>>>>running test 10"
../source/print_tokens.exe  < ../inputs/newtst105.tst > ../outputs/t10
echo ">>>>>>>>running test 11"
../source/print_tokens.exe  < ../inputs/newtst106.tst > ../outputs/t11
echo ">>>>>>>>running test 12"
../source/print_tokens.exe  < ../inputs/newtst107.tst > ../outputs/t12
echo ">>>>>>>>running test 13"
../source/print_tokens.exe  < ../inputs/newtst108.tst > ../outputs/t13
echo ">>>>>>>>running test 14"
../source/print_tokens.exe  < ../inputs/newtst109.tst > ../outputs/t14
echo ">>>>>>>>running test 15"
../source/print_tokens.exe  < ../inputs/newtst11.tst > ../outputs/t15
echo ">>>>>>>>running test 16"
../source/print_tokens.exe  < ../inputs/newtst110.tst > ../outputs/t16
echo ">>>>>>>>running test 17"
../source/print_tokens.exe  < ../inputs/newtst111.tst > ../outputs/t17
echo ">>>>>>>>running test 18"
../source/print_tokens.exe  < ../inputs/newtst112.tst > ../outputs/t18
echo ">>>>>>>>running test 19"
../source/print_tokens.exe  < ../inputs/newtst113.tst > ../outputs/t19
echo ">>>>>>>>running test 20"
../source/print_tokens.exe  < ../inputs/newtst114.tst > ../outputs/t20
echo ">>>>>>>>running test 21"
../source/print_tokens.exe  < ../inputs/newtst115.tst > ../outputs/t21
echo ">>>>>>>>running test 22"
../source/print_tokens.exe  < ../inputs/newtst116.tst > ../outputs/t22
echo ">>>>>>>>running test 23"
../source/print_tokens.exe  < ../inputs/newtst117.tst > ../outputs/t23
echo ">>>>>>>>running test 24"
../source/print_tokens.exe  < ../inputs/newtst118.tst > ../outputs/t24
echo ">>>>>>>>running test 25"
../source/print_tokens.exe  < ../inputs/newtst119.tst > ../outputs/t25
echo ">>>>>>>>running test 26"
../source/print_tokens.exe  < ../inputs/newtst12.tst > ../outputs/t26
echo ">>>>>>>>running test 27"
../source/print_tokens.exe  < ../inputs/newtst120.tst > ../outputs/t27
echo ">>>>>>>>running test 28"
../source/print_tokens.exe  < ../inputs/newtst121.tst > ../outputs/t28
echo ">>>>>>>>running test 29"
../source/print_tokens.exe  < ../inputs/newtst122.tst > ../outputs/t29
echo ">>>>>>>>running test 30"
../source/print_tokens.exe  < ../inputs/newtst123.tst > ../outputs/t30
echo ">>>>>>>>running test 31"
../source/print_tokens.exe  < ../inputs/newtst124.tst > ../outputs/t31
echo ">>>>>>>>running test 32"
../source/print_tokens.exe  < ../inputs/newtst125.tst > ../outputs/t32
echo ">>>>>>>>running test 33"
../source/print_tokens.exe  < ../inputs/newtst126.tst > ../outputs/t33
echo ">>>>>>>>running test 34"
../source/print_tokens.exe  < ../inputs/newtst127.tst > ../outputs/t34
echo ">>>>>>>>running test 35"
../source/print_tokens.exe  < ../inputs/newtst128.tst > ../outputs/t35
echo ">>>>>>>>running test 36"
../source/print_tokens.exe  < ../inputs/newtst129.tst > ../outputs/t36
echo ">>>>>>>>running test 37"
../source/print_tokens.exe  < ../inputs/newtst13.tst > ../outputs/t37
echo ">>>>>>>>running test 38"
../source/print_tokens.exe  < ../inputs/newtst130.tst > ../outputs/t38
echo ">>>>>>>>running test 39"
../source/print_tokens.exe  < ../inputs/newtst131.tst > ../outputs/t39
echo ">>>>>>>>running test 40"
../source/print_tokens.exe  < ../inputs/newtst132.tst > ../outputs/t40
echo ">>>>>>>>running test 41"
../source/print_tokens.exe  < ../inputs/newtst133.tst > ../outputs/t41
echo ">>>>>>>>running test 42"
../source/print_tokens.exe  < ../inputs/newtst134.tst > ../outputs/t42
echo ">>>>>>>>running test 43"
../source/print_tokens.exe  < ../inputs/newtst135.tst > ../outputs/t43
echo ">>>>>>>>running test 44"
../source/print_tokens.exe  < ../inputs/newtst136.tst > ../outputs/t44
echo ">>>>>>>>running test 45"
../source/print_tokens.exe  < ../inputs/newtst137.tst > ../outputs/t45
echo ">>>>>>>>running test 46"
../source/print_tokens.exe  < ../inputs/newtst138.tst > ../outputs/t46
echo ">>>>>>>>running test 47"
../source/print_tokens.exe  < ../inputs/newtst139.tst > ../outputs/t47
echo ">>>>>>>>running test 48"
../source/print_tokens.exe  < ../inputs/newtst14.tst > ../outputs/t48
echo ">>>>>>>>running test 49"
../source/print_tokens.exe  < ../inputs/newtst140.tst > ../outputs/t49
echo ">>>>>>>>running test 50"
../source/print_tokens.exe  < ../inputs/newtst141.tst > ../outputs/t50
echo ">>>>>>>>running test 51"
../source/print_tokens.exe  < ../inputs/newtst142.tst > ../outputs/t51
echo ">>>>>>>>running test 52"
../source/print_tokens.exe  < ../inputs/newtst143.tst > ../outputs/t52
echo ">>>>>>>>running test 53"
../source/print_tokens.exe  < ../inputs/newtst144.tst > ../outputs/t53
echo ">>>>>>>>running test 54"
../source/print_tokens.exe  < ../inputs/newtst145.tst > ../outputs/t54
echo ">>>>>>>>running test 55"
../source/print_tokens.exe  < ../inputs/newtst146.tst > ../outputs/t55
echo ">>>>>>>>running test 56"
../source/print_tokens.exe  < ../inputs/newtst147.tst > ../outputs/t56
echo ">>>>>>>>running test 57"
../source/print_tokens.exe  < ../inputs/newtst149.tst > ../outputs/t57
echo ">>>>>>>>running test 58"
../source/print_tokens.exe  < ../inputs/newtst15.tst > ../outputs/t58
echo ">>>>>>>>running test 59"
../source/print_tokens.exe  < ../inputs/newtst150.tst > ../outputs/t59
echo ">>>>>>>>running test 60"
../source/print_tokens.exe  < ../inputs/newtst151.tst > ../outputs/t60
echo ">>>>>>>>running test 61"
../source/print_tokens.exe  < ../inputs/newtst152.tst > ../outputs/t61
echo ">>>>>>>>running test 62"
../source/print_tokens.exe  < ../inputs/newtst153.tst > ../outputs/t62
echo ">>>>>>>>running test 63"
../source/print_tokens.exe  < ../inputs/newtst154.tst > ../outputs/t63
echo ">>>>>>>>running test 64"
../source/print_tokens.exe  < ../inputs/newtst155.tst > ../outputs/t64
echo ">>>>>>>>running test 65"
../source/print_tokens.exe  < ../inputs/newtst156.tst > ../outputs/t65
echo ">>>>>>>>running test 66"
../source/print_tokens.exe  < ../inputs/newtst157.tst > ../outputs/t66
echo ">>>>>>>>running test 67"
../source/print_tokens.exe  < ../inputs/newtst158.tst > ../outputs/t67
echo ">>>>>>>>running test 68"
../source/print_tokens.exe  < ../inputs/newtst159.tst > ../outputs/t68
echo ">>>>>>>>running test 69"
../source/print_tokens.exe  < ../inputs/newtst16.tst > ../outputs/t69
echo ">>>>>>>>running test 70"
../source/print_tokens.exe  < ../inputs/newtst160.tst > ../outputs/t70
echo ">>>>>>>>running test 71"
../source/print_tokens.exe  < ../inputs/newtst161.tst > ../outputs/t71
echo ">>>>>>>>running test 72"
../source/print_tokens.exe  < ../inputs/newtst162.tst > ../outputs/t72
echo ">>>>>>>>running test 73"
../source/print_tokens.exe  < ../inputs/newtst163.tst > ../outputs/t73
echo ">>>>>>>>running test 74"
../source/print_tokens.exe  < ../inputs/newtst164.tst > ../outputs/t74
echo ">>>>>>>>running test 75"
../source/print_tokens.exe  < ../inputs/newtst165.tst > ../outputs/t75
echo ">>>>>>>>running test 76"
../source/print_tokens.exe  < ../inputs/newtst166.tst > ../outputs/t76
echo ">>>>>>>>running test 77"
../source/print_tokens.exe  < ../inputs/newtst167.tst > ../outputs/t77
echo ">>>>>>>>running test 78"
../source/print_tokens.exe  < ../inputs/newtst168.tst > ../outputs/t78
echo ">>>>>>>>running test 79"
../source/print_tokens.exe  < ../inputs/newtst169.tst > ../outputs/t79
echo ">>>>>>>>running test 80"
../source/print_tokens.exe  < ../inputs/newtst17.tst > ../outputs/t80
echo ">>>>>>>>running test 81"
../source/print_tokens.exe  < ../inputs/newtst170.tst > ../outputs/t81
echo ">>>>>>>>running test 82"
../source/print_tokens.exe  < ../inputs/newtst171.tst > ../outputs/t82
echo ">>>>>>>>running test 83"
../source/print_tokens.exe  < ../inputs/newtst172.tst > ../outputs/t83
echo ">>>>>>>>running test 84"
../source/print_tokens.exe  < ../inputs/newtst173.tst > ../outputs/t84
echo ">>>>>>>>running test 85"
../source/print_tokens.exe  < ../inputs/newtst174.tst > ../outputs/t85
echo ">>>>>>>>running test 86"
../source/print_tokens.exe  < ../inputs/newtst175.tst > ../outputs/t86
echo ">>>>>>>>running test 87"
../source/print_tokens.exe  < ../inputs/newtst176.tst > ../outputs/t87
echo ">>>>>>>>running test 88"
../source/print_tokens.exe  < ../inputs/newtst177.tst > ../outputs/t88
echo ">>>>>>>>running test 89"
../source/print_tokens.exe  < ../inputs/newtst178.tst > ../outputs/t89
echo ">>>>>>>>running test 90"
../source/print_tokens.exe  < ../inputs/newtst179.tst > ../outputs/t90
echo ">>>>>>>>running test 91"
../source/print_tokens.exe  < ../inputs/newtst18.tst > ../outputs/t91
echo ">>>>>>>>running test 92"
../source/print_tokens.exe  < ../inputs/newtst180.tst > ../outputs/t92
echo ">>>>>>>>running test 93"
../source/print_tokens.exe  < ../inputs/newtst181.tst > ../outputs/t93
echo ">>>>>>>>running test 94"
../source/print_tokens.exe  < ../inputs/newtst182.tst > ../outputs/t94
echo ">>>>>>>>running test 95"
../source/print_tokens.exe  < ../inputs/newtst183.tst > ../outputs/t95
echo ">>>>>>>>running test 96"
../source/print_tokens.exe  < ../inputs/newtst184.tst > ../outputs/t96
echo ">>>>>>>>running test 97"
../source/print_tokens.exe  < ../inputs/newtst185.tst > ../outputs/t97
echo ">>>>>>>>running test 98"
../source/print_tokens.exe  < ../inputs/newtst186.tst > ../outputs/t98
echo ">>>>>>>>running test 99"
../source/print_tokens.exe  < ../inputs/newtst187.tst > ../outputs/t99
echo ">>>>>>>>running test 100"
../source/print_tokens.exe  < ../inputs/newtst188.tst > ../outputs/t100
echo ">>>>>>>>running test 101"
../source/print_tokens.exe  < ../inputs/newtst189.tst > ../outputs/t101
echo ">>>>>>>>running test 102"
../source/print_tokens.exe  < ../inputs/newtst19.tst > ../outputs/t102
echo ">>>>>>>>running test 103"
../source/print_tokens.exe  < ../inputs/newtst190.tst > ../outputs/t103
echo ">>>>>>>>running test 104"
../source/print_tokens.exe  < ../inputs/newtst191.tst > ../outputs/t104
echo ">>>>>>>>running test 105"
../source/print_tokens.exe  < ../inputs/newtst192.tst > ../outputs/t105
echo ">>>>>>>>running test 106"
../source/print_tokens.exe  < ../inputs/newtst193.tst > ../outputs/t106
echo ">>>>>>>>running test 107"
../source/print_tokens.exe  < ../inputs/newtst194.tst > ../outputs/t107
echo ">>>>>>>>running test 108"
../source/print_tokens.exe  < ../inputs/newtst195.tst > ../outputs/t108
echo ">>>>>>>>running test 109"
../source/print_tokens.exe  < ../inputs/newtst196.tst > ../outputs/t109
echo ">>>>>>>>running test 110"
../source/print_tokens.exe  < ../inputs/newtst197.tst > ../outputs/t110
echo ">>>>>>>>running test 111"
../source/print_tokens.exe  < ../inputs/newtst198.tst > ../outputs/t111
echo ">>>>>>>>running test 112"
../source/print_tokens.exe  < ../inputs/newtst199.tst > ../outputs/t112
echo ">>>>>>>>running test 113"
../source/print_tokens.exe  < ../inputs/newtst2.tst > ../outputs/t113
echo ">>>>>>>>running test 114"
../source/print_tokens.exe  < ../inputs/newtst2.tst.tst > ../outputs/t114
echo ">>>>>>>>running test 115"
../source/print_tokens.exe  < ../inputs/newtst20.tst > ../outputs/t115
echo ">>>>>>>>running test 116"
../source/print_tokens.exe  < ../inputs/newtst200.tst > ../outputs/t116
echo ">>>>>>>>running test 117"
../source/print_tokens.exe  < ../inputs/newtst201.tst > ../outputs/t117
echo ">>>>>>>>running test 118"
../source/print_tokens.exe  < ../inputs/newtst202.tst > ../outputs/t118
echo ">>>>>>>>running test 119"
../source/print_tokens.exe  < ../inputs/newtst203.tst > ../outputs/t119
echo ">>>>>>>>running test 120"
../source/print_tokens.exe  < ../inputs/newtst204.tst > ../outputs/t120
echo ">>>>>>>>running test 121"
../source/print_tokens.exe  < ../inputs/newtst205.tst > ../outputs/t121
echo ">>>>>>>>running test 122"
../source/print_tokens.exe  < ../inputs/newtst206.tst > ../outputs/t122
echo ">>>>>>>>running test 123"
../source/print_tokens.exe  < ../inputs/newtst207.tst > ../outputs/t123
echo ">>>>>>>>running test 124"
../source/print_tokens.exe  < ../inputs/newtst208.tst > ../outputs/t124
echo ">>>>>>>>running test 125"
../source/print_tokens.exe  < ../inputs/newtst209.tst > ../outputs/t125
echo ">>>>>>>>running test 126"
../source/print_tokens.exe  < ../inputs/newtst21.tst > ../outputs/t126
echo ">>>>>>>>running test 127"
../source/print_tokens.exe  < ../inputs/newtst21.tst.tst > ../outputs/t127
echo ">>>>>>>>running test 128"
../source/print_tokens.exe  < ../inputs/newtst210.tst > ../outputs/t128
echo ">>>>>>>>running test 129"
../source/print_tokens.exe  < ../inputs/newtst211.tst > ../outputs/t129
echo ">>>>>>>>running test 130"
../source/print_tokens.exe  < ../inputs/newtst212.tst > ../outputs/t130
echo ">>>>>>>>running test 131"
../source/print_tokens.exe  < ../inputs/newtst213.tst > ../outputs/t131
echo ">>>>>>>>running test 132"
../source/print_tokens.exe  < ../inputs/newtst214.tst > ../outputs/t132
echo ">>>>>>>>running test 133"
../source/print_tokens.exe  < ../inputs/newtst215.tst > ../outputs/t133
echo ">>>>>>>>running test 134"
../source/print_tokens.exe  < ../inputs/newtst216.tst > ../outputs/t134
echo ">>>>>>>>running test 135"
../source/print_tokens.exe  < ../inputs/newtst217.tst > ../outputs/t135
echo ">>>>>>>>running test 136"
../source/print_tokens.exe  < ../inputs/newtst218.tst > ../outputs/t136
echo ">>>>>>>>running test 137"
../source/print_tokens.exe  < ../inputs/newtst219.tst > ../outputs/t137
echo ">>>>>>>>running test 138"
../source/print_tokens.exe  < ../inputs/newtst22.tst > ../outputs/t138
echo ">>>>>>>>running test 139"
../source/print_tokens.exe  < ../inputs/newtst220.tst > ../outputs/t139
echo ">>>>>>>>running test 140"
../source/print_tokens.exe  < ../inputs/newtst221.tst > ../outputs/t140
echo ">>>>>>>>running test 141"
../source/print_tokens.exe  < ../inputs/newtst222.tst > ../outputs/t141
echo ">>>>>>>>running test 142"
../source/print_tokens.exe  < ../inputs/newtst223.tst > ../outputs/t142
echo ">>>>>>>>running test 143"
../source/print_tokens.exe  < ../inputs/newtst224.tst > ../outputs/t143
echo ">>>>>>>>running test 144"
../source/print_tokens.exe  < ../inputs/newtst225.tst > ../outputs/t144
echo ">>>>>>>>running test 145"
../source/print_tokens.exe  < ../inputs/newtst226.tst > ../outputs/t145
echo ">>>>>>>>running test 146"
../source/print_tokens.exe  < ../inputs/newtst227.tst > ../outputs/t146
echo ">>>>>>>>running test 147"
../source/print_tokens.exe  < ../inputs/newtst228.tst > ../outputs/t147
echo ">>>>>>>>running test 148"
../source/print_tokens.exe  < ../inputs/newtst229.tst > ../outputs/t148
echo ">>>>>>>>running test 149"
../source/print_tokens.exe  < ../inputs/newtst23.tst > ../outputs/t149
echo ">>>>>>>>running test 150"
../source/print_tokens.exe  < ../inputs/newtst230.tst > ../outputs/t150
echo ">>>>>>>>running test 151"
../source/print_tokens.exe  < ../inputs/newtst231.tst > ../outputs/t151
echo ">>>>>>>>running test 152"
../source/print_tokens.exe  < ../inputs/newtst232.tst > ../outputs/t152
echo ">>>>>>>>running test 153"
../source/print_tokens.exe  < ../inputs/newtst233.tst > ../outputs/t153
echo ">>>>>>>>running test 154"
../source/print_tokens.exe  < ../inputs/newtst234.tst > ../outputs/t154
echo ">>>>>>>>running test 155"
../source/print_tokens.exe  < ../inputs/newtst234.tst.tst > ../outputs/t155
echo ">>>>>>>>running test 156"
../source/print_tokens.exe  < ../inputs/newtst235.tst > ../outputs/t156
echo ">>>>>>>>running test 157"
../source/print_tokens.exe  < ../inputs/newtst236.tst > ../outputs/t157
echo ">>>>>>>>running test 158"
../source/print_tokens.exe  < ../inputs/newtst237.tst > ../outputs/t158
echo ">>>>>>>>running test 159"
../source/print_tokens.exe  < ../inputs/newtst238.tst > ../outputs/t159
echo ">>>>>>>>running test 160"
../source/print_tokens.exe  < ../inputs/newtst239.tst > ../outputs/t160
echo ">>>>>>>>running test 161"
../source/print_tokens.exe  < ../inputs/newtst24.tst > ../outputs/t161
echo ">>>>>>>>running test 162"
../source/print_tokens.exe  < ../inputs/newtst240.tst > ../outputs/t162
echo ">>>>>>>>running test 163"
../source/print_tokens.exe  < ../inputs/newtst240.tst.tst > ../outputs/t163
echo ">>>>>>>>running test 164"
../source/print_tokens.exe  < ../inputs/newtst241.tst > ../outputs/t164
echo ">>>>>>>>running test 165"
../source/print_tokens.exe  < ../inputs/newtst241.tst.tst > ../outputs/t165
echo ">>>>>>>>running test 166"
../source/print_tokens.exe  < ../inputs/newtst242.tst > ../outputs/t166
echo ">>>>>>>>running test 167"
../source/print_tokens.exe  < ../inputs/newtst242.tst.tst > ../outputs/t167
echo ">>>>>>>>running test 168"
../source/print_tokens.exe  < ../inputs/newtst243.tst > ../outputs/t168
echo ">>>>>>>>running test 169"
../source/print_tokens.exe  < ../inputs/newtst243.tst.tst > ../outputs/t169
echo ">>>>>>>>running test 170"
../source/print_tokens.exe  < ../inputs/newtst244.tst > ../outputs/t170
echo ">>>>>>>>running test 171"
../source/print_tokens.exe  < ../inputs/newtst244.tst.tst > ../outputs/t171
echo ">>>>>>>>running test 172"
../source/print_tokens.exe  < ../inputs/newtst245.tst > ../outputs/t172
echo ">>>>>>>>running test 173"
../source/print_tokens.exe  < ../inputs/newtst245.tst.tst > ../outputs/t173
echo ">>>>>>>>running test 174"
../source/print_tokens.exe  < ../inputs/newtst246.tst > ../outputs/t174
echo ">>>>>>>>running test 175"
../source/print_tokens.exe  < ../inputs/newtst246.tst.tst > ../outputs/t175
echo ">>>>>>>>running test 176"
../source/print_tokens.exe  < ../inputs/newtst247.tst > ../outputs/t176
echo ">>>>>>>>running test 177"
../source/print_tokens.exe  < ../inputs/newtst247.tst.tst > ../outputs/t177
echo ">>>>>>>>running test 178"
../source/print_tokens.exe  < ../inputs/newtst248.tst > ../outputs/t178
echo ">>>>>>>>running test 179"
../source/print_tokens.exe  < ../inputs/newtst248.tst.tst > ../outputs/t179
echo ">>>>>>>>running test 180"
../source/print_tokens.exe  < ../inputs/newtst249.tst > ../outputs/t180
echo ">>>>>>>>running test 181"
../source/print_tokens.exe  < ../inputs/newtst249.tst.tst > ../outputs/t181
echo ">>>>>>>>running test 182"
../source/print_tokens.exe  < ../inputs/newtst25.tst > ../outputs/t182
echo ">>>>>>>>running test 183"
../source/print_tokens.exe  < ../inputs/newtst250.tst > ../outputs/t183
echo ">>>>>>>>running test 184"
../source/print_tokens.exe  < ../inputs/newtst251.tst > ../outputs/t184
echo ">>>>>>>>running test 185"
../source/print_tokens.exe  < ../inputs/newtst252.tst > ../outputs/t185
echo ">>>>>>>>running test 186"
../source/print_tokens.exe  < ../inputs/newtst253.tst > ../outputs/t186
echo ">>>>>>>>running test 187"
../source/print_tokens.exe  < ../inputs/newtst254.tst > ../outputs/t187
echo ">>>>>>>>running test 188"
../source/print_tokens.exe  < ../inputs/newtst254.tst.tst > ../outputs/t188
echo ">>>>>>>>running test 189"
../source/print_tokens.exe  < ../inputs/newtst255.tst > ../outputs/t189
echo ">>>>>>>>running test 190"
../source/print_tokens.exe  < ../inputs/newtst256.tst > ../outputs/t190
echo ">>>>>>>>running test 191"
../source/print_tokens.exe  < ../inputs/newtst257.tst > ../outputs/t191
echo ">>>>>>>>running test 192"
../source/print_tokens.exe  < ../inputs/newtst258.tst > ../outputs/t192
echo ">>>>>>>>running test 193"
../source/print_tokens.exe  < ../inputs/newtst259.tst > ../outputs/t193
echo ">>>>>>>>running test 194"
../source/print_tokens.exe  < ../inputs/newtst26.tst > ../outputs/t194
echo ">>>>>>>>running test 195"
../source/print_tokens.exe  < ../inputs/newtst260.tst > ../outputs/t195
echo ">>>>>>>>running test 196"
../source/print_tokens.exe  < ../inputs/newtst261.tst > ../outputs/t196
echo ">>>>>>>>running test 197"
../source/print_tokens.exe  < ../inputs/newtst262.tst > ../outputs/t197
echo ">>>>>>>>running test 198"
../source/print_tokens.exe  < ../inputs/newtst263.tst > ../outputs/t198
echo ">>>>>>>>running test 199"
../source/print_tokens.exe  < ../inputs/newtst264.tst > ../outputs/t199
echo ">>>>>>>>running test 200"
../source/print_tokens.exe  < ../inputs/newtst265.tst > ../outputs/t200
echo ">>>>>>>>running test 201"
../source/print_tokens.exe  < ../inputs/newtst266.tst > ../outputs/t201
echo ">>>>>>>>running test 202"
../source/print_tokens.exe  < ../inputs/newtst267.tst > ../outputs/t202
echo ">>>>>>>>running test 203"
../source/print_tokens.exe  < ../inputs/newtst268.tst > ../outputs/t203
echo ">>>>>>>>running test 204"
../source/print_tokens.exe  < ../inputs/newtst269.tst > ../outputs/t204
echo ">>>>>>>>running test 205"
../source/print_tokens.exe  < ../inputs/newtst27.tst > ../outputs/t205
echo ">>>>>>>>running test 206"
../source/print_tokens.exe  < ../inputs/newtst270.tst > ../outputs/t206
echo ">>>>>>>>running test 207"
../source/print_tokens.exe  < ../inputs/newtst271.tst > ../outputs/t207
echo ">>>>>>>>running test 208"
../source/print_tokens.exe  < ../inputs/newtst272.tst > ../outputs/t208
echo ">>>>>>>>running test 209"
../source/print_tokens.exe  < ../inputs/newtst273.tst > ../outputs/t209
echo ">>>>>>>>running test 210"
../source/print_tokens.exe  < ../inputs/newtst274.tst > ../outputs/t210
echo ">>>>>>>>running test 211"
../source/print_tokens.exe  < ../inputs/newtst275.tst > ../outputs/t211
echo ">>>>>>>>running test 212"
../source/print_tokens.exe  < ../inputs/newtst276.tst > ../outputs/t212
echo ">>>>>>>>running test 213"
../source/print_tokens.exe  < ../inputs/newtst277.tst > ../outputs/t213
echo ">>>>>>>>running test 214"
../source/print_tokens.exe  < ../inputs/newtst278.tst > ../outputs/t214
echo ">>>>>>>>running test 215"
../source/print_tokens.exe  < ../inputs/newtst279.tst > ../outputs/t215
echo ">>>>>>>>running test 216"
../source/print_tokens.exe  < ../inputs/newtst28.tst > ../outputs/t216
echo ">>>>>>>>running test 217"
../source/print_tokens.exe  < ../inputs/newtst280.tst > ../outputs/t217
echo ">>>>>>>>running test 218"
../source/print_tokens.exe  < ../inputs/newtst281.tst > ../outputs/t218
echo ">>>>>>>>running test 219"
../source/print_tokens.exe  < ../inputs/newtst282.tst > ../outputs/t219
echo ">>>>>>>>running test 220"
../source/print_tokens.exe  < ../inputs/newtst283.tst > ../outputs/t220
echo ">>>>>>>>running test 221"
../source/print_tokens.exe  < ../inputs/newtst284.tst > ../outputs/t221
echo ">>>>>>>>running test 222"
../source/print_tokens.exe  < ../inputs/newtst285.tst > ../outputs/t222
echo ">>>>>>>>running test 223"
../source/print_tokens.exe  < ../inputs/newtst286.tst > ../outputs/t223
echo ">>>>>>>>running test 224"
../source/print_tokens.exe  < ../inputs/newtst287.tst > ../outputs/t224
echo ">>>>>>>>running test 225"
../source/print_tokens.exe  < ../inputs/newtst288.tst > ../outputs/t225
echo ">>>>>>>>running test 226"
../source/print_tokens.exe  < ../inputs/newtst289.tst > ../outputs/t226
echo ">>>>>>>>running test 227"
../source/print_tokens.exe  < ../inputs/newtst29.tst > ../outputs/t227
echo ">>>>>>>>running test 228"
../source/print_tokens.exe  < ../inputs/newtst290.tst > ../outputs/t228
echo ">>>>>>>>running test 229"
../source/print_tokens.exe  < ../inputs/newtst291.tst > ../outputs/t229
echo ">>>>>>>>running test 230"
../source/print_tokens.exe  < ../inputs/newtst292.tst > ../outputs/t230
echo ">>>>>>>>running test 231"
../source/print_tokens.exe  < ../inputs/newtst293.tst > ../outputs/t231
echo ">>>>>>>>running test 232"
../source/print_tokens.exe  < ../inputs/newtst294.tst > ../outputs/t232
echo ">>>>>>>>running test 233"
../source/print_tokens.exe  < ../inputs/newtst295.tst > ../outputs/t233
echo ">>>>>>>>running test 234"
../source/print_tokens.exe  < ../inputs/newtst296.tst > ../outputs/t234
echo ">>>>>>>>running test 235"
../source/print_tokens.exe  < ../inputs/newtst297.tst > ../outputs/t235
echo ">>>>>>>>running test 236"
../source/print_tokens.exe  < ../inputs/newtst298.tst > ../outputs/t236
echo ">>>>>>>>running test 237"
../source/print_tokens.exe  < ../inputs/newtst299.tst > ../outputs/t237
echo ">>>>>>>>running test 238"
../source/print_tokens.exe  < ../inputs/newtst3.tst > ../outputs/t238
echo ">>>>>>>>running test 239"
../source/print_tokens.exe  < ../inputs/newtst3.tst.tst > ../outputs/t239
echo ">>>>>>>>running test 240"
../source/print_tokens.exe  < ../inputs/newtst30.tst > ../outputs/t240
echo ">>>>>>>>running test 241"
../source/print_tokens.exe  < ../inputs/newtst300.tst > ../outputs/t241
echo ">>>>>>>>running test 242"
../source/print_tokens.exe  < ../inputs/newtst301.tst > ../outputs/t242
echo ">>>>>>>>running test 243"
../source/print_tokens.exe  < ../inputs/newtst302.tst > ../outputs/t243
echo ">>>>>>>>running test 244"
../source/print_tokens.exe  < ../inputs/newtst303.tst > ../outputs/t244
echo ">>>>>>>>running test 245"
../source/print_tokens.exe  < ../inputs/newtst304.tst > ../outputs/t245
echo ">>>>>>>>running test 246"
../source/print_tokens.exe  < ../inputs/newtst305.tst > ../outputs/t246
echo ">>>>>>>>running test 247"
../source/print_tokens.exe  < ../inputs/newtst306.tst > ../outputs/t247
echo ">>>>>>>>running test 248"
../source/print_tokens.exe  < ../inputs/newtst307.tst > ../outputs/t248
echo ">>>>>>>>running test 249"
../source/print_tokens.exe  < ../inputs/newtst308.tst > ../outputs/t249
echo ">>>>>>>>running test 250"
../source/print_tokens.exe  < ../inputs/newtst309.tst > ../outputs/t250
echo ">>>>>>>>running test 251"
../source/print_tokens.exe  < ../inputs/newtst31.tst > ../outputs/t251
echo ">>>>>>>>running test 252"
../source/print_tokens.exe  < ../inputs/newtst31.tst.tst > ../outputs/t252
echo ">>>>>>>>running test 253"
../source/print_tokens.exe  < ../inputs/newtst310.tst > ../outputs/t253
echo ">>>>>>>>running test 254"
../source/print_tokens.exe  < ../inputs/newtst311.tst > ../outputs/t254
echo ">>>>>>>>running test 255"
../source/print_tokens.exe  < ../inputs/newtst312.tst > ../outputs/t255
echo ">>>>>>>>running test 256"
../source/print_tokens.exe  < ../inputs/newtst313.tst > ../outputs/t256
echo ">>>>>>>>running test 257"
../source/print_tokens.exe  < ../inputs/newtst314.tst > ../outputs/t257
echo ">>>>>>>>running test 258"
../source/print_tokens.exe  < ../inputs/newtst315.tst > ../outputs/t258
echo ">>>>>>>>running test 259"
../source/print_tokens.exe  < ../inputs/newtst316.tst > ../outputs/t259
echo ">>>>>>>>running test 260"
../source/print_tokens.exe  < ../inputs/newtst317.tst > ../outputs/t260
echo ">>>>>>>>running test 261"
../source/print_tokens.exe  < ../inputs/newtst318.tst > ../outputs/t261
echo ">>>>>>>>running test 262"
../source/print_tokens.exe  < ../inputs/newtst319.tst > ../outputs/t262
echo ">>>>>>>>running test 263"
../source/print_tokens.exe  < ../inputs/newtst32.tst > ../outputs/t263
echo ">>>>>>>>running test 264"
../source/print_tokens.exe  < ../inputs/newtst320.tst > ../outputs/t264
echo ">>>>>>>>running test 265"
../source/print_tokens.exe  < ../inputs/newtst321.tst > ../outputs/t265
echo ">>>>>>>>running test 266"
../source/print_tokens.exe  < ../inputs/newtst322.tst > ../outputs/t266
echo ">>>>>>>>running test 267"
../source/print_tokens.exe  < ../inputs/newtst323.tst > ../outputs/t267
echo ">>>>>>>>running test 268"
../source/print_tokens.exe  < ../inputs/newtst324.tst > ../outputs/t268
echo ">>>>>>>>running test 269"
../source/print_tokens.exe  < ../inputs/newtst325.tst > ../outputs/t269
echo ">>>>>>>>running test 270"
../source/print_tokens.exe  < ../inputs/newtst326.tst > ../outputs/t270
echo ">>>>>>>>running test 271"
../source/print_tokens.exe  < ../inputs/newtst327.tst > ../outputs/t271
echo ">>>>>>>>running test 272"
../source/print_tokens.exe  < ../inputs/newtst328.tst > ../outputs/t272
echo ">>>>>>>>running test 273"
../source/print_tokens.exe  < ../inputs/newtst329.tst > ../outputs/t273
echo ">>>>>>>>running test 274"
../source/print_tokens.exe  < ../inputs/newtst33.tst > ../outputs/t274
echo ">>>>>>>>running test 275"
../source/print_tokens.exe  < ../inputs/newtst330.tst > ../outputs/t275
echo ">>>>>>>>running test 276"
../source/print_tokens.exe  < ../inputs/newtst331.tst > ../outputs/t276
echo ">>>>>>>>running test 277"
../source/print_tokens.exe  < ../inputs/newtst332.tst > ../outputs/t277
echo ">>>>>>>>running test 278"
../source/print_tokens.exe  < ../inputs/newtst333.tst > ../outputs/t278
echo ">>>>>>>>running test 279"
../source/print_tokens.exe  < ../inputs/newtst334.tst > ../outputs/t279
echo ">>>>>>>>running test 280"
../source/print_tokens.exe  < ../inputs/newtst335.tst > ../outputs/t280
echo ">>>>>>>>running test 281"
../source/print_tokens.exe  < ../inputs/newtst336.tst > ../outputs/t281
echo ">>>>>>>>running test 282"
../source/print_tokens.exe  < ../inputs/newtst337.tst > ../outputs/t282
echo ">>>>>>>>running test 283"
../source/print_tokens.exe  < ../inputs/newtst338.tst > ../outputs/t283
echo ">>>>>>>>running test 284"
../source/print_tokens.exe  < ../inputs/newtst339.tst > ../outputs/t284
echo ">>>>>>>>running test 285"
../source/print_tokens.exe  < ../inputs/newtst34.tst > ../outputs/t285
echo ">>>>>>>>running test 286"
../source/print_tokens.exe  < ../inputs/newtst340.tst > ../outputs/t286
echo ">>>>>>>>running test 287"
../source/print_tokens.exe  < ../inputs/newtst341.tst > ../outputs/t287
echo ">>>>>>>>running test 288"
../source/print_tokens.exe  < ../inputs/newtst342.tst > ../outputs/t288
echo ">>>>>>>>running test 289"
../source/print_tokens.exe  < ../inputs/newtst343.tst > ../outputs/t289
echo ">>>>>>>>running test 290"
../source/print_tokens.exe  < ../inputs/newtst344.tst > ../outputs/t290
echo ">>>>>>>>running test 291"
../source/print_tokens.exe  < ../inputs/newtst345.tst > ../outputs/t291
echo ">>>>>>>>running test 292"
../source/print_tokens.exe  < ../inputs/newtst346.tst > ../outputs/t292
echo ">>>>>>>>running test 293"
../source/print_tokens.exe  < ../inputs/newtst347.tst > ../outputs/t293
echo ">>>>>>>>running test 294"
../source/print_tokens.exe  < ../inputs/newtst348.tst > ../outputs/t294
echo ">>>>>>>>running test 295"
../source/print_tokens.exe  < ../inputs/newtst349.tst > ../outputs/t295
echo ">>>>>>>>running test 296"
../source/print_tokens.exe  < ../inputs/newtst35.tst > ../outputs/t296
echo ">>>>>>>>running test 297"
../source/print_tokens.exe  < ../inputs/newtst350.tst > ../outputs/t297
echo ">>>>>>>>running test 298"
../source/print_tokens.exe  < ../inputs/newtst352.tst > ../outputs/t298
echo ">>>>>>>>running test 299"
../source/print_tokens.exe  < ../inputs/newtst353.tst > ../outputs/t299
echo ">>>>>>>>running test 300"
../source/print_tokens.exe  < ../inputs/newtst354.tst > ../outputs/t300
echo ">>>>>>>>running test 301"
../source/print_tokens.exe  < ../inputs/newtst355.tst > ../outputs/t301
echo ">>>>>>>>running test 302"
../source/print_tokens.exe  < ../inputs/newtst356.tst > ../outputs/t302
echo ">>>>>>>>running test 303"
../source/print_tokens.exe  < ../inputs/newtst357.tst > ../outputs/t303
echo ">>>>>>>>running test 304"
../source/print_tokens.exe  < ../inputs/newtst358.tst > ../outputs/t304
echo ">>>>>>>>running test 305"
../source/print_tokens.exe  < ../inputs/newtst359.tst > ../outputs/t305
echo ">>>>>>>>running test 306"
../source/print_tokens.exe  < ../inputs/newtst36.tst > ../outputs/t306
echo ">>>>>>>>running test 307"
../source/print_tokens.exe  < ../inputs/newtst360.tst > ../outputs/t307
echo ">>>>>>>>running test 308"
../source/print_tokens.exe  < ../inputs/newtst361.tst > ../outputs/t308
echo ">>>>>>>>running test 309"
../source/print_tokens.exe  < ../inputs/newtst362.tst > ../outputs/t309
echo ">>>>>>>>running test 310"
../source/print_tokens.exe  < ../inputs/newtst363.tst > ../outputs/t310
echo ">>>>>>>>running test 311"
../source/print_tokens.exe  < ../inputs/newtst364.tst > ../outputs/t311
echo ">>>>>>>>running test 312"
../source/print_tokens.exe  < ../inputs/newtst365.tst > ../outputs/t312
echo ">>>>>>>>running test 313"
../source/print_tokens.exe  < ../inputs/newtst366.tst > ../outputs/t313
echo ">>>>>>>>running test 314"
../source/print_tokens.exe  < ../inputs/newtst367.tst > ../outputs/t314
echo ">>>>>>>>running test 315"
../source/print_tokens.exe  < ../inputs/newtst368.tst > ../outputs/t315
echo ">>>>>>>>running test 316"
../source/print_tokens.exe  < ../inputs/newtst369.tst > ../outputs/t316
echo ">>>>>>>>running test 317"
../source/print_tokens.exe  < ../inputs/newtst37.tst > ../outputs/t317
echo ">>>>>>>>running test 318"
../source/print_tokens.exe  < ../inputs/newtst370.tst > ../outputs/t318
echo ">>>>>>>>running test 319"
../source/print_tokens.exe  < ../inputs/newtst371.tst > ../outputs/t319
echo ">>>>>>>>running test 320"
../source/print_tokens.exe  < ../inputs/newtst372.tst > ../outputs/t320
echo ">>>>>>>>running test 321"
../source/print_tokens.exe  < ../inputs/newtst373.tst > ../outputs/t321
echo ">>>>>>>>running test 322"
../source/print_tokens.exe  < ../inputs/newtst374.tst > ../outputs/t322
echo ">>>>>>>>running test 323"
../source/print_tokens.exe  < ../inputs/newtst375.tst > ../outputs/t323
echo ">>>>>>>>running test 324"
../source/print_tokens.exe  < ../inputs/newtst376.tst > ../outputs/t324
echo ">>>>>>>>running test 325"
../source/print_tokens.exe  < ../inputs/newtst377.tst > ../outputs/t325
echo ">>>>>>>>running test 326"
../source/print_tokens.exe  < ../inputs/newtst378.tst > ../outputs/t326
echo ">>>>>>>>running test 327"
../source/print_tokens.exe  < ../inputs/newtst379.tst > ../outputs/t327
echo ">>>>>>>>running test 328"
../source/print_tokens.exe  < ../inputs/newtst38.tst > ../outputs/t328
echo ">>>>>>>>running test 329"
../source/print_tokens.exe  < ../inputs/newtst380.tst > ../outputs/t329
echo ">>>>>>>>running test 330"
../source/print_tokens.exe  < ../inputs/newtst381.tst > ../outputs/t330
echo ">>>>>>>>running test 331"
../source/print_tokens.exe  < ../inputs/newtst382.tst > ../outputs/t331
echo ">>>>>>>>running test 332"
../source/print_tokens.exe  < ../inputs/newtst383.tst > ../outputs/t332
echo ">>>>>>>>running test 333"
../source/print_tokens.exe  < ../inputs/newtst384.tst > ../outputs/t333
echo ">>>>>>>>running test 334"
../source/print_tokens.exe  < ../inputs/newtst385.tst > ../outputs/t334
echo ">>>>>>>>running test 335"
../source/print_tokens.exe  < ../inputs/newtst386.tst > ../outputs/t335
echo ">>>>>>>>running test 336"
../source/print_tokens.exe  < ../inputs/newtst387.tst > ../outputs/t336
echo ">>>>>>>>running test 337"
../source/print_tokens.exe  < ../inputs/newtst388.tst > ../outputs/t337
echo ">>>>>>>>running test 338"
../source/print_tokens.exe  < ../inputs/newtst389.tst > ../outputs/t338
echo ">>>>>>>>running test 339"
../source/print_tokens.exe  < ../inputs/newtst39.tst > ../outputs/t339
echo ">>>>>>>>running test 340"
../source/print_tokens.exe  < ../inputs/newtst390.tst > ../outputs/t340
echo ">>>>>>>>running test 341"
../source/print_tokens.exe  < ../inputs/newtst391.tst > ../outputs/t341
echo ">>>>>>>>running test 342"
../source/print_tokens.exe  < ../inputs/newtst392.tst > ../outputs/t342
echo ">>>>>>>>running test 343"
../source/print_tokens.exe  < ../inputs/newtst393.tst > ../outputs/t343
echo ">>>>>>>>running test 344"
../source/print_tokens.exe  < ../inputs/newtst394.tst > ../outputs/t344
echo ">>>>>>>>running test 345"
../source/print_tokens.exe  < ../inputs/newtst395.tst > ../outputs/t345
echo ">>>>>>>>running test 346"
../source/print_tokens.exe  < ../inputs/newtst396.tst > ../outputs/t346
echo ">>>>>>>>running test 347"
../source/print_tokens.exe  < ../inputs/newtst397.tst > ../outputs/t347
echo ">>>>>>>>running test 348"
../source/print_tokens.exe  < ../inputs/newtst398.tst > ../outputs/t348
echo ">>>>>>>>running test 349"
../source/print_tokens.exe  < ../inputs/newtst399.tst > ../outputs/t349
echo ">>>>>>>>running test 350"
../source/print_tokens.exe  < ../inputs/newtst4.tst > ../outputs/t350
echo ">>>>>>>>running test 351"
../source/print_tokens.exe  < ../inputs/newtst4.tst.tst > ../outputs/t351
echo ">>>>>>>>running test 352"
../source/print_tokens.exe  < ../inputs/newtst40.tst > ../outputs/t352
echo ">>>>>>>>running test 353"
../source/print_tokens.exe  < ../inputs/newtst400.tst > ../outputs/t353
echo ">>>>>>>>running test 354"
../source/print_tokens.exe  < ../inputs/newtst401.tst > ../outputs/t354
echo ">>>>>>>>running test 355"
../source/print_tokens.exe  < ../inputs/newtst402.tst > ../outputs/t355
echo ">>>>>>>>running test 356"
../source/print_tokens.exe  < ../inputs/newtst403.tst > ../outputs/t356
echo ">>>>>>>>running test 357"
../source/print_tokens.exe  < ../inputs/newtst404.tst > ../outputs/t357
echo ">>>>>>>>running test 358"
../source/print_tokens.exe  < ../inputs/newtst405.tst > ../outputs/t358
echo ">>>>>>>>running test 359"
../source/print_tokens.exe  < ../inputs/newtst406.tst > ../outputs/t359
echo ">>>>>>>>running test 360"
../source/print_tokens.exe  < ../inputs/newtst407.tst > ../outputs/t360
echo ">>>>>>>>running test 361"
../source/print_tokens.exe  < ../inputs/newtst408.tst > ../outputs/t361
echo ">>>>>>>>running test 362"
../source/print_tokens.exe  < ../inputs/newtst409.tst > ../outputs/t362
echo ">>>>>>>>running test 363"
../source/print_tokens.exe  < ../inputs/newtst41.tst > ../outputs/t363
echo ">>>>>>>>running test 364"
../source/print_tokens.exe  < ../inputs/newtst410.tst > ../outputs/t364
echo ">>>>>>>>running test 365"
../source/print_tokens.exe  < ../inputs/newtst411.tst > ../outputs/t365
echo ">>>>>>>>running test 366"
../source/print_tokens.exe  < ../inputs/newtst412.tst > ../outputs/t366
echo ">>>>>>>>running test 367"
../source/print_tokens.exe  < ../inputs/newtst413.tst > ../outputs/t367
echo ">>>>>>>>running test 368"
../source/print_tokens.exe  < ../inputs/newtst414.tst > ../outputs/t368
echo ">>>>>>>>running test 369"
../source/print_tokens.exe  < ../inputs/newtst415.tst > ../outputs/t369
echo ">>>>>>>>running test 370"
../source/print_tokens.exe  < ../inputs/newtst416.tst > ../outputs/t370
echo ">>>>>>>>running test 371"
../source/print_tokens.exe  < ../inputs/newtst417.tst > ../outputs/t371
echo ">>>>>>>>running test 372"
../source/print_tokens.exe  < ../inputs/newtst418.tst > ../outputs/t372
echo ">>>>>>>>running test 373"
../source/print_tokens.exe  < ../inputs/newtst419.tst > ../outputs/t373
echo ">>>>>>>>running test 374"
../source/print_tokens.exe  < ../inputs/newtst42.tst > ../outputs/t374
echo ">>>>>>>>running test 375"
../source/print_tokens.exe  < ../inputs/newtst420.tst > ../outputs/t375
echo ">>>>>>>>running test 376"
../source/print_tokens.exe  < ../inputs/newtst421.tst > ../outputs/t376
echo ">>>>>>>>running test 377"
../source/print_tokens.exe  < ../inputs/newtst422.tst > ../outputs/t377
echo ">>>>>>>>running test 378"
../source/print_tokens.exe  < ../inputs/newtst423.tst > ../outputs/t378
echo ">>>>>>>>running test 379"
../source/print_tokens.exe  < ../inputs/newtst424.tst > ../outputs/t379
echo ">>>>>>>>running test 380"
../source/print_tokens.exe  < ../inputs/newtst425.tst > ../outputs/t380
echo ">>>>>>>>running test 381"
../source/print_tokens.exe  < ../inputs/newtst426.tst > ../outputs/t381
echo ">>>>>>>>running test 382"
../source/print_tokens.exe  < ../inputs/newtst427.tst > ../outputs/t382
echo ">>>>>>>>running test 383"
../source/print_tokens.exe  < ../inputs/newtst428.tst > ../outputs/t383
echo ">>>>>>>>running test 384"
../source/print_tokens.exe  < ../inputs/newtst429.tst > ../outputs/t384
echo ">>>>>>>>running test 385"
../source/print_tokens.exe  < ../inputs/newtst43.tst > ../outputs/t385
echo ">>>>>>>>running test 386"
../source/print_tokens.exe  < ../inputs/newtst430.tst > ../outputs/t386
echo ">>>>>>>>running test 387"
../source/print_tokens.exe  < ../inputs/newtst431.tst > ../outputs/t387
echo ">>>>>>>>running test 388"
../source/print_tokens.exe  < ../inputs/newtst432.tst > ../outputs/t388
echo ">>>>>>>>running test 389"
../source/print_tokens.exe  < ../inputs/newtst433.tst > ../outputs/t389
echo ">>>>>>>>running test 390"
../source/print_tokens.exe  < ../inputs/newtst434.tst > ../outputs/t390
echo ">>>>>>>>running test 391"
../source/print_tokens.exe  < ../inputs/newtst435.tst > ../outputs/t391
echo ">>>>>>>>running test 392"
../source/print_tokens.exe  < ../inputs/newtst436.tst > ../outputs/t392
echo ">>>>>>>>running test 393"
../source/print_tokens.exe  < ../inputs/newtst437.tst > ../outputs/t393
echo ">>>>>>>>running test 394"
../source/print_tokens.exe  < ../inputs/newtst438.tst > ../outputs/t394
echo ">>>>>>>>running test 395"
../source/print_tokens.exe  < ../inputs/newtst439.tst > ../outputs/t395
echo ">>>>>>>>running test 396"
../source/print_tokens.exe  < ../inputs/newtst44.tst > ../outputs/t396
echo ">>>>>>>>running test 397"
../source/print_tokens.exe  < ../inputs/newtst440.tst > ../outputs/t397
echo ">>>>>>>>running test 398"
../source/print_tokens.exe  < ../inputs/newtst441.tst > ../outputs/t398
echo ">>>>>>>>running test 399"
../source/print_tokens.exe  < ../inputs/newtst442.tst > ../outputs/t399
echo ">>>>>>>>running test 400"
../source/print_tokens.exe  < ../inputs/newtst443.tst > ../outputs/t400
echo ">>>>>>>>running test 401"
../source/print_tokens.exe  < ../inputs/newtst444.tst > ../outputs/t401
echo ">>>>>>>>running test 402"
../source/print_tokens.exe  < ../inputs/newtst445.tst > ../outputs/t402
echo ">>>>>>>>running test 403"
../source/print_tokens.exe  < ../inputs/newtst446.tst > ../outputs/t403
echo ">>>>>>>>running test 404"
../source/print_tokens.exe  < ../inputs/newtst447.tst > ../outputs/t404
echo ">>>>>>>>running test 405"
../source/print_tokens.exe  < ../inputs/newtst448.tst > ../outputs/t405
echo ">>>>>>>>running test 406"
../source/print_tokens.exe  < ../inputs/newtst449.tst > ../outputs/t406
echo ">>>>>>>>running test 407"
../source/print_tokens.exe  < ../inputs/newtst45.tst > ../outputs/t407
echo ">>>>>>>>running test 408"
../source/print_tokens.exe  < ../inputs/newtst450.tst > ../outputs/t408
echo ">>>>>>>>running test 409"
../source/print_tokens.exe  < ../inputs/newtst451.tst > ../outputs/t409
echo ">>>>>>>>running test 410"
../source/print_tokens.exe  < ../inputs/newtst452.tst > ../outputs/t410
echo ">>>>>>>>running test 411"
../source/print_tokens.exe  < ../inputs/newtst453.tst > ../outputs/t411
echo ">>>>>>>>running test 412"
../source/print_tokens.exe  < ../inputs/newtst454.tst > ../outputs/t412
echo ">>>>>>>>running test 413"
../source/print_tokens.exe  < ../inputs/newtst455.tst > ../outputs/t413
echo ">>>>>>>>running test 414"
../source/print_tokens.exe  < ../inputs/newtst456.tst > ../outputs/t414
echo ">>>>>>>>running test 415"
../source/print_tokens.exe  < ../inputs/newtst457.tst > ../outputs/t415
echo ">>>>>>>>running test 416"
../source/print_tokens.exe  < ../inputs/newtst458.tst > ../outputs/t416
echo ">>>>>>>>running test 417"
../source/print_tokens.exe  < ../inputs/newtst459.tst > ../outputs/t417
echo ">>>>>>>>running test 418"
../source/print_tokens.exe  < ../inputs/newtst46.tst > ../outputs/t418
echo ">>>>>>>>running test 419"
../source/print_tokens.exe  < ../inputs/newtst460.tst > ../outputs/t419
echo ">>>>>>>>running test 420"
../source/print_tokens.exe  < ../inputs/newtst461.tst > ../outputs/t420
echo ">>>>>>>>running test 421"
../source/print_tokens.exe  < ../inputs/newtst462.tst > ../outputs/t421
echo ">>>>>>>>running test 422"
../source/print_tokens.exe  < ../inputs/newtst463.tst > ../outputs/t422
echo ">>>>>>>>running test 423"
../source/print_tokens.exe  < ../inputs/newtst464.tst > ../outputs/t423
echo ">>>>>>>>running test 424"
../source/print_tokens.exe  < ../inputs/newtst465.tst > ../outputs/t424
echo ">>>>>>>>running test 425"
../source/print_tokens.exe  < ../inputs/newtst466.tst > ../outputs/t425
echo ">>>>>>>>running test 426"
../source/print_tokens.exe  < ../inputs/newtst467.tst > ../outputs/t426
echo ">>>>>>>>running test 427"
../source/print_tokens.exe  < ../inputs/newtst468.tst > ../outputs/t427
echo ">>>>>>>>running test 428"
../source/print_tokens.exe  < ../inputs/newtst469.tst > ../outputs/t428
echo ">>>>>>>>running test 429"
../source/print_tokens.exe  < ../inputs/newtst47.tst > ../outputs/t429
echo ">>>>>>>>running test 430"
../source/print_tokens.exe  < ../inputs/newtst470.tst > ../outputs/t430
echo ">>>>>>>>running test 431"
../source/print_tokens.exe  < ../inputs/newtst471.tst > ../outputs/t431
echo ">>>>>>>>running test 432"
../source/print_tokens.exe  < ../inputs/newtst472.tst > ../outputs/t432
echo ">>>>>>>>running test 433"
../source/print_tokens.exe  < ../inputs/newtst473.tst > ../outputs/t433
echo ">>>>>>>>running test 434"
../source/print_tokens.exe  < ../inputs/newtst474.tst > ../outputs/t434
echo ">>>>>>>>running test 435"
../source/print_tokens.exe  < ../inputs/newtst475.tst > ../outputs/t435
echo ">>>>>>>>running test 436"
../source/print_tokens.exe  < ../inputs/newtst476.tst > ../outputs/t436
echo ">>>>>>>>running test 437"
../source/print_tokens.exe  < ../inputs/newtst477.tst > ../outputs/t437
echo ">>>>>>>>running test 438"
../source/print_tokens.exe  < ../inputs/newtst478.tst > ../outputs/t438
echo ">>>>>>>>running test 439"
../source/print_tokens.exe  < ../inputs/newtst479.tst > ../outputs/t439
echo ">>>>>>>>running test 440"
../source/print_tokens.exe  < ../inputs/newtst48.tst > ../outputs/t440
echo ">>>>>>>>running test 441"
../source/print_tokens.exe  < ../inputs/newtst480.tst > ../outputs/t441
echo ">>>>>>>>running test 442"
../source/print_tokens.exe  < ../inputs/newtst481.tst > ../outputs/t442
echo ">>>>>>>>running test 443"
../source/print_tokens.exe  < ../inputs/newtst482.tst > ../outputs/t443
echo ">>>>>>>>running test 444"
../source/print_tokens.exe  < ../inputs/newtst483.tst > ../outputs/t444
echo ">>>>>>>>running test 445"
../source/print_tokens.exe  < ../inputs/newtst484.tst > ../outputs/t445
echo ">>>>>>>>running test 446"
../source/print_tokens.exe  < ../inputs/newtst485.tst > ../outputs/t446
echo ">>>>>>>>running test 447"
../source/print_tokens.exe  < ../inputs/newtst486.tst > ../outputs/t447
echo ">>>>>>>>running test 448"
../source/print_tokens.exe  < ../inputs/newtst487.tst > ../outputs/t448
echo ">>>>>>>>running test 449"
../source/print_tokens.exe  < ../inputs/newtst488.tst > ../outputs/t449
echo ">>>>>>>>running test 450"
../source/print_tokens.exe  < ../inputs/newtst489.tst > ../outputs/t450
echo ">>>>>>>>running test 451"
../source/print_tokens.exe  < ../inputs/newtst49.tst > ../outputs/t451
echo ">>>>>>>>running test 452"
../source/print_tokens.exe  < ../inputs/newtst490.tst > ../outputs/t452
echo ">>>>>>>>running test 453"
../source/print_tokens.exe  < ../inputs/newtst491.tst > ../outputs/t453
echo ">>>>>>>>running test 454"
../source/print_tokens.exe  < ../inputs/newtst492.tst > ../outputs/t454
echo ">>>>>>>>running test 455"
../source/print_tokens.exe  < ../inputs/newtst493.tst > ../outputs/t455
echo ">>>>>>>>running test 456"
../source/print_tokens.exe  < ../inputs/newtst494.tst > ../outputs/t456
echo ">>>>>>>>running test 457"
../source/print_tokens.exe  < ../inputs/newtst495.tst > ../outputs/t457
echo ">>>>>>>>running test 458"
../source/print_tokens.exe  < ../inputs/newtst496.tst > ../outputs/t458
echo ">>>>>>>>running test 459"
../source/print_tokens.exe  < ../inputs/newtst497.tst > ../outputs/t459
echo ">>>>>>>>running test 460"
../source/print_tokens.exe  < ../inputs/newtst498.tst > ../outputs/t460
echo ">>>>>>>>running test 461"
../source/print_tokens.exe  < ../inputs/newtst499.tst > ../outputs/t461
echo ">>>>>>>>running test 462"
../source/print_tokens.exe  < ../inputs/newtst5.tst > ../outputs/t462
echo ">>>>>>>>running test 463"
../source/print_tokens.exe  < ../inputs/newtst5.tst.tst > ../outputs/t463
echo ">>>>>>>>running test 464"
../source/print_tokens.exe  < ../inputs/newtst50.tst > ../outputs/t464
echo ">>>>>>>>running test 465"
../source/print_tokens.exe  < ../inputs/newtst500.tst > ../outputs/t465
echo ">>>>>>>>running test 466"
../source/print_tokens.exe  < ../inputs/newtst501.tst > ../outputs/t466
echo ">>>>>>>>running test 467"
../source/print_tokens.exe  < ../inputs/newtst502.tst > ../outputs/t467
echo ">>>>>>>>running test 468"
../source/print_tokens.exe  < ../inputs/newtst503.tst > ../outputs/t468
echo ">>>>>>>>running test 469"
../source/print_tokens.exe  < ../inputs/newtst504.tst > ../outputs/t469
echo ">>>>>>>>running test 470"
../source/print_tokens.exe  < ../inputs/newtst505.tst > ../outputs/t470
echo ">>>>>>>>running test 471"
../source/print_tokens.exe  < ../inputs/newtst506.tst > ../outputs/t471
echo ">>>>>>>>running test 472"
../source/print_tokens.exe  < ../inputs/newtst507.tst > ../outputs/t472
echo ">>>>>>>>running test 473"
../source/print_tokens.exe  < ../inputs/newtst508.tst > ../outputs/t473
echo ">>>>>>>>running test 474"
../source/print_tokens.exe  < ../inputs/newtst509.tst > ../outputs/t474
echo ">>>>>>>>running test 475"
../source/print_tokens.exe  < ../inputs/newtst51.tst > ../outputs/t475
echo ">>>>>>>>running test 476"
../source/print_tokens.exe  < ../inputs/newtst510.tst > ../outputs/t476
echo ">>>>>>>>running test 477"
../source/print_tokens.exe  < ../inputs/newtst511.tst > ../outputs/t477
echo ">>>>>>>>running test 478"
../source/print_tokens.exe  < ../inputs/newtst512.tst > ../outputs/t478
echo ">>>>>>>>running test 479"
../source/print_tokens.exe  < ../inputs/newtst513.tst > ../outputs/t479
echo ">>>>>>>>running test 480"
../source/print_tokens.exe  < ../inputs/newtst514.tst > ../outputs/t480
echo ">>>>>>>>running test 481"
../source/print_tokens.exe  < ../inputs/newtst515.tst > ../outputs/t481
echo ">>>>>>>>running test 482"
../source/print_tokens.exe  < ../inputs/newtst516.tst > ../outputs/t482
echo ">>>>>>>>running test 483"
../source/print_tokens.exe  < ../inputs/newtst517.tst > ../outputs/t483
echo ">>>>>>>>running test 484"
../source/print_tokens.exe  < ../inputs/newtst518.tst > ../outputs/t484
echo ">>>>>>>>running test 485"
../source/print_tokens.exe  < ../inputs/newtst519.tst > ../outputs/t485
echo ">>>>>>>>running test 486"
../source/print_tokens.exe  < ../inputs/newtst52.tst > ../outputs/t486
echo ">>>>>>>>running test 487"
../source/print_tokens.exe  < ../inputs/newtst520.tst > ../outputs/t487
echo ">>>>>>>>running test 488"
../source/print_tokens.exe  < ../inputs/newtst521.tst > ../outputs/t488
echo ">>>>>>>>running test 489"
../source/print_tokens.exe  < ../inputs/newtst522.tst > ../outputs/t489
echo ">>>>>>>>running test 490"
../source/print_tokens.exe  < ../inputs/newtst523.tst > ../outputs/t490
echo ">>>>>>>>running test 491"
../source/print_tokens.exe  < ../inputs/newtst524.tst > ../outputs/t491
echo ">>>>>>>>running test 492"
../source/print_tokens.exe  < ../inputs/newtst525.tst > ../outputs/t492
echo ">>>>>>>>running test 493"
../source/print_tokens.exe  < ../inputs/newtst526.tst > ../outputs/t493
echo ">>>>>>>>running test 494"
../source/print_tokens.exe  < ../inputs/newtst527.tst > ../outputs/t494
echo ">>>>>>>>running test 495"
../source/print_tokens.exe  < ../inputs/newtst528.tst > ../outputs/t495
echo ">>>>>>>>running test 496"
../source/print_tokens.exe  < ../inputs/newtst529.tst > ../outputs/t496
echo ">>>>>>>>running test 497"
../source/print_tokens.exe  < ../inputs/newtst53.tst > ../outputs/t497
echo ">>>>>>>>running test 498"
../source/print_tokens.exe  < ../inputs/newtst530.tst > ../outputs/t498
echo ">>>>>>>>running test 499"
../source/print_tokens.exe  < ../inputs/newtst531.tst > ../outputs/t499
echo ">>>>>>>>running test 500"
../source/print_tokens.exe  < ../inputs/newtst532.tst > ../outputs/t500
echo ">>>>>>>>running test 501"
../source/print_tokens.exe  < ../inputs/newtst533.tst > ../outputs/t501
echo ">>>>>>>>running test 502"
../source/print_tokens.exe  < ../inputs/newtst534.tst > ../outputs/t502
echo ">>>>>>>>running test 503"
../source/print_tokens.exe  < ../inputs/newtst535.tst > ../outputs/t503
echo ">>>>>>>>running test 504"
../source/print_tokens.exe  < ../inputs/newtst536.tst > ../outputs/t504
echo ">>>>>>>>running test 505"
../source/print_tokens.exe  < ../inputs/newtst537.tst > ../outputs/t505
echo ">>>>>>>>running test 506"
../source/print_tokens.exe  < ../inputs/newtst538.tst > ../outputs/t506
echo ">>>>>>>>running test 507"
../source/print_tokens.exe  < ../inputs/newtst539.tst > ../outputs/t507
echo ">>>>>>>>running test 508"
../source/print_tokens.exe  < ../inputs/newtst54.tst > ../outputs/t508
echo ">>>>>>>>running test 509"
../source/print_tokens.exe  < ../inputs/newtst540.tst > ../outputs/t509
echo ">>>>>>>>running test 510"
../source/print_tokens.exe  < ../inputs/newtst541.tst > ../outputs/t510
echo ">>>>>>>>running test 511"
../source/print_tokens.exe  < ../inputs/newtst542.tst > ../outputs/t511
echo ">>>>>>>>running test 512"
../source/print_tokens.exe  < ../inputs/newtst543.tst > ../outputs/t512
echo ">>>>>>>>running test 513"
../source/print_tokens.exe  < ../inputs/newtst544.tst > ../outputs/t513
echo ">>>>>>>>running test 514"
../source/print_tokens.exe  < ../inputs/newtst545.tst > ../outputs/t514
echo ">>>>>>>>running test 515"
../source/print_tokens.exe  < ../inputs/newtst546.tst > ../outputs/t515
echo ">>>>>>>>running test 516"
../source/print_tokens.exe  < ../inputs/newtst547.tst > ../outputs/t516
echo ">>>>>>>>running test 517"
../source/print_tokens.exe  < ../inputs/newtst548.tst > ../outputs/t517
echo ">>>>>>>>running test 518"
../source/print_tokens.exe  < ../inputs/newtst549.tst > ../outputs/t518
echo ">>>>>>>>running test 519"
../source/print_tokens.exe  < ../inputs/newtst55.tst > ../outputs/t519
echo ">>>>>>>>running test 520"
../source/print_tokens.exe  < ../inputs/newtst550.tst > ../outputs/t520
echo ">>>>>>>>running test 521"
../source/print_tokens.exe  < ../inputs/newtst551.tst > ../outputs/t521
echo ">>>>>>>>running test 522"
../source/print_tokens.exe  < ../inputs/newtst552.tst > ../outputs/t522
echo ">>>>>>>>running test 523"
../source/print_tokens.exe  < ../inputs/newtst553.tst > ../outputs/t523
echo ">>>>>>>>running test 524"
../source/print_tokens.exe  < ../inputs/newtst554.tst > ../outputs/t524
echo ">>>>>>>>running test 525"
../source/print_tokens.exe  < ../inputs/newtst555.tst > ../outputs/t525
echo ">>>>>>>>running test 526"
../source/print_tokens.exe  < ../inputs/newtst556.tst > ../outputs/t526
echo ">>>>>>>>running test 527"
../source/print_tokens.exe  < ../inputs/newtst557.tst > ../outputs/t527
echo ">>>>>>>>running test 528"
../source/print_tokens.exe  < ../inputs/newtst558.tst > ../outputs/t528
echo ">>>>>>>>running test 529"
../source/print_tokens.exe  < ../inputs/newtst559.tst > ../outputs/t529
echo ">>>>>>>>running test 530"
../source/print_tokens.exe  < ../inputs/newtst56.tst > ../outputs/t530
echo ">>>>>>>>running test 531"
../source/print_tokens.exe  < ../inputs/newtst560.tst > ../outputs/t531
echo ">>>>>>>>running test 532"
../source/print_tokens.exe  < ../inputs/newtst561.tst > ../outputs/t532
echo ">>>>>>>>running test 533"
../source/print_tokens.exe  < ../inputs/newtst562.tst > ../outputs/t533
echo ">>>>>>>>running test 534"
../source/print_tokens.exe  < ../inputs/newtst563.tst > ../outputs/t534
echo ">>>>>>>>running test 535"
../source/print_tokens.exe  < ../inputs/newtst564.tst > ../outputs/t535
echo ">>>>>>>>running test 536"
../source/print_tokens.exe  < ../inputs/newtst565.tst > ../outputs/t536
echo ">>>>>>>>running test 537"
../source/print_tokens.exe  < ../inputs/newtst566.tst > ../outputs/t537
echo ">>>>>>>>running test 538"
../source/print_tokens.exe  < ../inputs/newtst567.tst > ../outputs/t538
echo ">>>>>>>>running test 539"
../source/print_tokens.exe  < ../inputs/newtst568.tst > ../outputs/t539
echo ">>>>>>>>running test 540"
../source/print_tokens.exe  < ../inputs/newtst569.tst > ../outputs/t540
echo ">>>>>>>>running test 541"
../source/print_tokens.exe  < ../inputs/newtst57.tst > ../outputs/t541
echo ">>>>>>>>running test 542"
../source/print_tokens.exe  < ../inputs/newtst570.tst > ../outputs/t542
echo ">>>>>>>>running test 543"
../source/print_tokens.exe  < ../inputs/newtst571.tst > ../outputs/t543
echo ">>>>>>>>running test 544"
../source/print_tokens.exe  < ../inputs/newtst572.tst > ../outputs/t544
echo ">>>>>>>>running test 545"
../source/print_tokens.exe  < ../inputs/newtst573.tst > ../outputs/t545
echo ">>>>>>>>running test 546"
../source/print_tokens.exe  < ../inputs/newtst574.tst > ../outputs/t546
echo ">>>>>>>>running test 547"
../source/print_tokens.exe  < ../inputs/newtst575.tst > ../outputs/t547
echo ">>>>>>>>running test 548"
../source/print_tokens.exe  < ../inputs/newtst576.tst > ../outputs/t548
echo ">>>>>>>>running test 549"
../source/print_tokens.exe  < ../inputs/newtst577.tst > ../outputs/t549
echo ">>>>>>>>running test 550"
../source/print_tokens.exe  < ../inputs/newtst578.tst > ../outputs/t550
echo ">>>>>>>>running test 551"
../source/print_tokens.exe  < ../inputs/newtst579.tst > ../outputs/t551
echo ">>>>>>>>running test 552"
../source/print_tokens.exe  < ../inputs/newtst58.tst > ../outputs/t552
echo ">>>>>>>>running test 553"
../source/print_tokens.exe  < ../inputs/newtst580.tst > ../outputs/t553
echo ">>>>>>>>running test 554"
../source/print_tokens.exe  < ../inputs/newtst581.tst > ../outputs/t554
echo ">>>>>>>>running test 555"
../source/print_tokens.exe  < ../inputs/newtst582.tst > ../outputs/t555
echo ">>>>>>>>running test 556"
../source/print_tokens.exe  < ../inputs/newtst583.tst > ../outputs/t556
echo ">>>>>>>>running test 557"
../source/print_tokens.exe  < ../inputs/newtst584.tst > ../outputs/t557
echo ">>>>>>>>running test 558"
../source/print_tokens.exe  < ../inputs/newtst585.tst > ../outputs/t558
echo ">>>>>>>>running test 559"
../source/print_tokens.exe  < ../inputs/newtst586.tst > ../outputs/t559
echo ">>>>>>>>running test 560"
../source/print_tokens.exe  < ../inputs/newtst587.tst > ../outputs/t560
echo ">>>>>>>>running test 561"
../source/print_tokens.exe  < ../inputs/newtst588.tst > ../outputs/t561
echo ">>>>>>>>running test 562"
../source/print_tokens.exe  < ../inputs/newtst589.tst > ../outputs/t562
echo ">>>>>>>>running test 563"
../source/print_tokens.exe  < ../inputs/newtst59.tst > ../outputs/t563
echo ">>>>>>>>running test 564"
../source/print_tokens.exe  < ../inputs/newtst590.tst > ../outputs/t564
echo ">>>>>>>>running test 565"
../source/print_tokens.exe  < ../inputs/newtst591.tst > ../outputs/t565
echo ">>>>>>>>running test 566"
../source/print_tokens.exe  < ../inputs/newtst592.tst > ../outputs/t566
echo ">>>>>>>>running test 567"
../source/print_tokens.exe  < ../inputs/newtst593.tst > ../outputs/t567
echo ">>>>>>>>running test 568"
../source/print_tokens.exe  < ../inputs/newtst594.tst > ../outputs/t568
echo ">>>>>>>>running test 569"
../source/print_tokens.exe  < ../inputs/newtst595.tst > ../outputs/t569
echo ">>>>>>>>running test 570"
../source/print_tokens.exe  < ../inputs/newtst596.tst > ../outputs/t570
echo ">>>>>>>>running test 571"
../source/print_tokens.exe  < ../inputs/newtst597.tst > ../outputs/t571
echo ">>>>>>>>running test 572"
../source/print_tokens.exe  < ../inputs/newtst598.tst > ../outputs/t572
echo ">>>>>>>>running test 573"
../source/print_tokens.exe  < ../inputs/newtst599.tst > ../outputs/t573
echo ">>>>>>>>running test 574"
../source/print_tokens.exe  < ../inputs/newtst6.tst > ../outputs/t574
echo ">>>>>>>>running test 575"
../source/print_tokens.exe  < ../inputs/newtst6.tst.tst > ../outputs/t575
echo ">>>>>>>>running test 576"
../source/print_tokens.exe  < ../inputs/newtst60.tst > ../outputs/t576
echo ">>>>>>>>running test 577"
../source/print_tokens.exe  < ../inputs/newtst600.tst > ../outputs/t577
echo ">>>>>>>>running test 578"
../source/print_tokens.exe  < ../inputs/newtst61.tst > ../outputs/t578
echo ">>>>>>>>running test 579"
../source/print_tokens.exe  < ../inputs/newtst62.tst > ../outputs/t579
echo ">>>>>>>>running test 580"
../source/print_tokens.exe  < ../inputs/newtst63.tst > ../outputs/t580
echo ">>>>>>>>running test 581"
../source/print_tokens.exe  < ../inputs/newtst64.tst > ../outputs/t581
echo ">>>>>>>>running test 582"
../source/print_tokens.exe  < ../inputs/newtst65.tst > ../outputs/t582
echo ">>>>>>>>running test 583"
../source/print_tokens.exe  < ../inputs/newtst66.tst > ../outputs/t583
echo ">>>>>>>>running test 584"
../source/print_tokens.exe  < ../inputs/newtst67.tst > ../outputs/t584
echo ">>>>>>>>running test 585"
../source/print_tokens.exe  < ../inputs/newtst68.tst > ../outputs/t585
echo ">>>>>>>>running test 586"
../source/print_tokens.exe  < ../inputs/newtst69.tst > ../outputs/t586
echo ">>>>>>>>running test 587"
../source/print_tokens.exe  < ../inputs/newtst7.tst > ../outputs/t587
echo ">>>>>>>>running test 588"
../source/print_tokens.exe  < ../inputs/newtst7.tst.tst > ../outputs/t588
echo ">>>>>>>>running test 589"
../source/print_tokens.exe  < ../inputs/newtst70.tst > ../outputs/t589
echo ">>>>>>>>running test 590"
../source/print_tokens.exe  < ../inputs/newtst71.tst > ../outputs/t590
echo ">>>>>>>>running test 591"
../source/print_tokens.exe  < ../inputs/newtst72.tst > ../outputs/t591
echo ">>>>>>>>running test 592"
../source/print_tokens.exe  < ../inputs/newtst73.tst > ../outputs/t592
echo ">>>>>>>>running test 593"
../source/print_tokens.exe  < ../inputs/newtst74.tst > ../outputs/t593
echo ">>>>>>>>running test 594"
../source/print_tokens.exe  < ../inputs/newtst75.tst > ../outputs/t594
echo ">>>>>>>>running test 595"
../source/print_tokens.exe  < ../inputs/newtst76.tst > ../outputs/t595
echo ">>>>>>>>running test 596"
../source/print_tokens.exe  < ../inputs/newtst77.tst > ../outputs/t596
echo ">>>>>>>>running test 597"
../source/print_tokens.exe  < ../inputs/newtst78.tst > ../outputs/t597
echo ">>>>>>>>running test 598"
../source/print_tokens.exe  < ../inputs/newtst79.tst > ../outputs/t598
echo ">>>>>>>>running test 599"
../source/print_tokens.exe  < ../inputs/newtst8.tst > ../outputs/t599
echo ">>>>>>>>running test 600"
../source/print_tokens.exe  < ../inputs/newtst8.tst.tst > ../outputs/t600
echo ">>>>>>>>running test 601"
../source/print_tokens.exe  < ../inputs/newtst80.tst > ../outputs/t601
echo ">>>>>>>>running test 602"
../source/print_tokens.exe  < ../inputs/newtst81.tst > ../outputs/t602
echo ">>>>>>>>running test 603"
../source/print_tokens.exe  < ../inputs/newtst82.tst > ../outputs/t603
echo ">>>>>>>>running test 604"
../source/print_tokens.exe  < ../inputs/newtst83.tst > ../outputs/t604
echo ">>>>>>>>running test 605"
../source/print_tokens.exe  < ../inputs/newtst84.tst > ../outputs/t605
echo ">>>>>>>>running test 606"
../source/print_tokens.exe  < ../inputs/newtst85.tst > ../outputs/t606
echo ">>>>>>>>running test 607"
../source/print_tokens.exe  < ../inputs/newtst86.tst > ../outputs/t607
echo ">>>>>>>>running test 608"
../source/print_tokens.exe  < ../inputs/newtst87.tst > ../outputs/t608
echo ">>>>>>>>running test 609"
../source/print_tokens.exe  < ../inputs/newtst88.tst > ../outputs/t609
echo ">>>>>>>>running test 610"
../source/print_tokens.exe  < ../inputs/newtst89.tst > ../outputs/t610
echo ">>>>>>>>running test 611"
../source/print_tokens.exe  < ../inputs/newtst9.tst > ../outputs/t611
echo ">>>>>>>>running test 612"
../source/print_tokens.exe  < ../inputs/newtst9.tst.tst > ../outputs/t612
echo ">>>>>>>>running test 613"
../source/print_tokens.exe  < ../inputs/newtst90.tst > ../outputs/t613
echo ">>>>>>>>running test 614"
../source/print_tokens.exe  < ../inputs/newtst91.tst > ../outputs/t614
echo ">>>>>>>>running test 615"
../source/print_tokens.exe  < ../inputs/newtst92.tst > ../outputs/t615
echo ">>>>>>>>running test 616"
../source/print_tokens.exe  < ../inputs/newtst93.tst > ../outputs/t616
echo ">>>>>>>>running test 617"
../source/print_tokens.exe  < ../inputs/newtst94.tst > ../outputs/t617
echo ">>>>>>>>running test 618"
../source/print_tokens.exe  < ../inputs/newtst95.tst > ../outputs/t618
echo ">>>>>>>>running test 619"
../source/print_tokens.exe  < ../inputs/newtst96.tst > ../outputs/t619
echo ">>>>>>>>running test 620"
../source/print_tokens.exe  < ../inputs/newtst97.tst > ../outputs/t620
echo ">>>>>>>>running test 621"
../source/print_tokens.exe  < ../inputs/newtst98.tst > ../outputs/t621
echo ">>>>>>>>running test 622"
../source/print_tokens.exe  < ../inputs/newtst99.tst > ../outputs/t622
echo ">>>>>>>>running test 623"
../source/print_tokens.exe  < ../inputs/tc1 > ../outputs/t623
echo ">>>>>>>>running test 624"
../source/print_tokens.exe  < ../inputs/tc10 > ../outputs/t624
echo ">>>>>>>>running test 625"
../source/print_tokens.exe  < ../inputs/tc100 > ../outputs/t625
echo ">>>>>>>>running test 626"
../source/print_tokens.exe  < ../inputs/tc101 > ../outputs/t626
echo ">>>>>>>>running test 627"
../source/print_tokens.exe  < ../inputs/tc102 > ../outputs/t627
echo ">>>>>>>>running test 628"
../source/print_tokens.exe  < ../inputs/tc103 > ../outputs/t628
echo ">>>>>>>>running test 629"
../source/print_tokens.exe  < ../inputs/tc104 > ../outputs/t629
echo ">>>>>>>>running test 630"
../source/print_tokens.exe  < ../inputs/tc105 > ../outputs/t630
echo ">>>>>>>>running test 631"
../source/print_tokens.exe  < ../inputs/tc106 > ../outputs/t631
echo ">>>>>>>>running test 632"
../source/print_tokens.exe  < ../inputs/tc107 > ../outputs/t632
echo ">>>>>>>>running test 633"
../source/print_tokens.exe  < ../inputs/tc108 > ../outputs/t633
echo ">>>>>>>>running test 634"
../source/print_tokens.exe  < ../inputs/tc109 > ../outputs/t634
echo ">>>>>>>>running test 635"
../source/print_tokens.exe  < ../inputs/tc11 > ../outputs/t635
echo ">>>>>>>>running test 636"
../source/print_tokens.exe  < ../inputs/tc110 > ../outputs/t636
echo ">>>>>>>>running test 637"
../source/print_tokens.exe  < ../inputs/tc111 > ../outputs/t637
echo ">>>>>>>>running test 638"
../source/print_tokens.exe  < ../inputs/tc112 > ../outputs/t638
echo ">>>>>>>>running test 639"
../source/print_tokens.exe  < ../inputs/tc113 > ../outputs/t639
echo ">>>>>>>>running test 640"
../source/print_tokens.exe  < ../inputs/tc114 > ../outputs/t640
echo ">>>>>>>>running test 641"
../source/print_tokens.exe  < ../inputs/tc115 > ../outputs/t641
echo ">>>>>>>>running test 642"
../source/print_tokens.exe  < ../inputs/tc116 > ../outputs/t642
echo ">>>>>>>>running test 643"
../source/print_tokens.exe  < ../inputs/tc117 > ../outputs/t643
echo ">>>>>>>>running test 644"
../source/print_tokens.exe  < ../inputs/tc118 > ../outputs/t644
echo ">>>>>>>>running test 645"
../source/print_tokens.exe  < ../inputs/tc119 > ../outputs/t645
echo ">>>>>>>>running test 646"
../source/print_tokens.exe  < ../inputs/tc12 > ../outputs/t646
echo ">>>>>>>>running test 647"
../source/print_tokens.exe  < ../inputs/tc120 > ../outputs/t647
echo ">>>>>>>>running test 648"
../source/print_tokens.exe  < ../inputs/tc121 > ../outputs/t648
echo ">>>>>>>>running test 649"
../source/print_tokens.exe  < ../inputs/tc122 > ../outputs/t649
echo ">>>>>>>>running test 650"
../source/print_tokens.exe  < ../inputs/tc123 > ../outputs/t650
echo ">>>>>>>>running test 651"
../source/print_tokens.exe  < ../inputs/tc124 > ../outputs/t651
echo ">>>>>>>>running test 652"
../source/print_tokens.exe  < ../inputs/tc125 > ../outputs/t652
echo ">>>>>>>>running test 653"
../source/print_tokens.exe  < ../inputs/tc126 > ../outputs/t653
echo ">>>>>>>>running test 654"
../source/print_tokens.exe  < ../inputs/tc127 > ../outputs/t654
echo ">>>>>>>>running test 655"
../source/print_tokens.exe  < ../inputs/tc128 > ../outputs/t655
echo ">>>>>>>>running test 656"
../source/print_tokens.exe  < ../inputs/tc129 > ../outputs/t656
echo ">>>>>>>>running test 657"
../source/print_tokens.exe  < ../inputs/tc13 > ../outputs/t657
echo ">>>>>>>>running test 658"
../source/print_tokens.exe  < ../inputs/tc130 > ../outputs/t658
echo ">>>>>>>>running test 659"
../source/print_tokens.exe  < ../inputs/tc131 > ../outputs/t659
echo ">>>>>>>>running test 660"
../source/print_tokens.exe  < ../inputs/tc132 > ../outputs/t660
echo ">>>>>>>>running test 661"
../source/print_tokens.exe  < ../inputs/tc133 > ../outputs/t661
echo ">>>>>>>>running test 662"
../source/print_tokens.exe  < ../inputs/tc134 > ../outputs/t662
echo ">>>>>>>>running test 663"
../source/print_tokens.exe  < ../inputs/tc135 > ../outputs/t663
echo ">>>>>>>>running test 664"
../source/print_tokens.exe  < ../inputs/tc136 > ../outputs/t664
echo ">>>>>>>>running test 665"
../source/print_tokens.exe  < ../inputs/tc137 > ../outputs/t665
echo ">>>>>>>>running test 666"
../source/print_tokens.exe  < ../inputs/tc138 > ../outputs/t666
echo ">>>>>>>>running test 667"
../source/print_tokens.exe  < ../inputs/tc139 > ../outputs/t667
echo ">>>>>>>>running test 668"
../source/print_tokens.exe  < ../inputs/tc14 > ../outputs/t668
echo ">>>>>>>>running test 669"
../source/print_tokens.exe  < ../inputs/tc140 > ../outputs/t669
echo ">>>>>>>>running test 670"
../source/print_tokens.exe  < ../inputs/tc141 > ../outputs/t670
echo ">>>>>>>>running test 671"
../source/print_tokens.exe  < ../inputs/tc142 > ../outputs/t671
echo ">>>>>>>>running test 672"
../source/print_tokens.exe  < ../inputs/tc143 > ../outputs/t672
echo ">>>>>>>>running test 673"
../source/print_tokens.exe  < ../inputs/tc144 > ../outputs/t673
echo ">>>>>>>>running test 674"
../source/print_tokens.exe  < ../inputs/tc145 > ../outputs/t674
echo ">>>>>>>>running test 675"
../source/print_tokens.exe  < ../inputs/tc146 > ../outputs/t675
echo ">>>>>>>>running test 676"
../source/print_tokens.exe  < ../inputs/tc147 > ../outputs/t676
echo ">>>>>>>>running test 677"
../source/print_tokens.exe  < ../inputs/tc148 > ../outputs/t677
echo ">>>>>>>>running test 678"
../source/print_tokens.exe  < ../inputs/tc149 > ../outputs/t678
echo ">>>>>>>>running test 679"
../source/print_tokens.exe  < ../inputs/tc15 > ../outputs/t679
echo ">>>>>>>>running test 680"
../source/print_tokens.exe  < ../inputs/tc150 > ../outputs/t680
echo ">>>>>>>>running test 681"
../source/print_tokens.exe  < ../inputs/tc151 > ../outputs/t681
echo ">>>>>>>>running test 682"
../source/print_tokens.exe  < ../inputs/tc152 > ../outputs/t682
echo ">>>>>>>>running test 683"
../source/print_tokens.exe  < ../inputs/tc153 > ../outputs/t683
echo ">>>>>>>>running test 684"
../source/print_tokens.exe  < ../inputs/tc154 > ../outputs/t684
echo ">>>>>>>>running test 685"
../source/print_tokens.exe  < ../inputs/tc155 > ../outputs/t685
echo ">>>>>>>>running test 686"
../source/print_tokens.exe  < ../inputs/tc156 > ../outputs/t686
echo ">>>>>>>>running test 687"
../source/print_tokens.exe  < ../inputs/tc157 > ../outputs/t687
echo ">>>>>>>>running test 688"
../source/print_tokens.exe  < ../inputs/tc158 > ../outputs/t688
echo ">>>>>>>>running test 689"
../source/print_tokens.exe  < ../inputs/tc159 > ../outputs/t689
echo ">>>>>>>>running test 690"
../source/print_tokens.exe  < ../inputs/tc16 > ../outputs/t690
echo ">>>>>>>>running test 691"
../source/print_tokens.exe  < ../inputs/tc160 > ../outputs/t691
echo ">>>>>>>>running test 692"
../source/print_tokens.exe  < ../inputs/tc161 > ../outputs/t692
echo ">>>>>>>>running test 693"
../source/print_tokens.exe  < ../inputs/tc162 > ../outputs/t693
echo ">>>>>>>>running test 694"
../source/print_tokens.exe  < ../inputs/tc163 > ../outputs/t694
echo ">>>>>>>>running test 695"
../source/print_tokens.exe  < ../inputs/tc164 > ../outputs/t695
echo ">>>>>>>>running test 696"
../source/print_tokens.exe  < ../inputs/tc165 > ../outputs/t696
echo ">>>>>>>>running test 697"
../source/print_tokens.exe  < ../inputs/tc166 > ../outputs/t697
echo ">>>>>>>>running test 698"
../source/print_tokens.exe  < ../inputs/tc167 > ../outputs/t698
echo ">>>>>>>>running test 699"
../source/print_tokens.exe  < ../inputs/tc168 > ../outputs/t699
echo ">>>>>>>>running test 700"
../source/print_tokens.exe  < ../inputs/tc169 > ../outputs/t700
echo ">>>>>>>>running test 701"
../source/print_tokens.exe  < ../inputs/tc17 > ../outputs/t701
echo ">>>>>>>>running test 702"
../source/print_tokens.exe  < ../inputs/tc170 > ../outputs/t702
echo ">>>>>>>>running test 703"
../source/print_tokens.exe  < ../inputs/tc171 > ../outputs/t703
echo ">>>>>>>>running test 704"
../source/print_tokens.exe  < ../inputs/tc172 > ../outputs/t704
echo ">>>>>>>>running test 705"
../source/print_tokens.exe  < ../inputs/tc173 > ../outputs/t705
echo ">>>>>>>>running test 706"
../source/print_tokens.exe  < ../inputs/tc174 > ../outputs/t706
echo ">>>>>>>>running test 707"
../source/print_tokens.exe  < ../inputs/tc175 > ../outputs/t707
echo ">>>>>>>>running test 708"
../source/print_tokens.exe  < ../inputs/tc176 > ../outputs/t708
echo ">>>>>>>>running test 709"
../source/print_tokens.exe  < ../inputs/tc177 > ../outputs/t709
echo ">>>>>>>>running test 710"
../source/print_tokens.exe  < ../inputs/tc178 > ../outputs/t710
echo ">>>>>>>>running test 711"
../source/print_tokens.exe  < ../inputs/tc179 > ../outputs/t711
echo ">>>>>>>>running test 712"
../source/print_tokens.exe  < ../inputs/tc18 > ../outputs/t712
echo ">>>>>>>>running test 713"
../source/print_tokens.exe  < ../inputs/tc180 > ../outputs/t713
echo ">>>>>>>>running test 714"
../source/print_tokens.exe  < ../inputs/tc181 > ../outputs/t714
echo ">>>>>>>>running test 715"
../source/print_tokens.exe  < ../inputs/tc182 > ../outputs/t715
echo ">>>>>>>>running test 716"
../source/print_tokens.exe  < ../inputs/tc183 > ../outputs/t716
echo ">>>>>>>>running test 717"
../source/print_tokens.exe  < ../inputs/tc184 > ../outputs/t717
echo ">>>>>>>>running test 718"
../source/print_tokens.exe  < ../inputs/tc185 > ../outputs/t718
echo ">>>>>>>>running test 719"
../source/print_tokens.exe  < ../inputs/tc186 > ../outputs/t719
echo ">>>>>>>>running test 720"
../source/print_tokens.exe  < ../inputs/tc187 > ../outputs/t720
echo ">>>>>>>>running test 721"
../source/print_tokens.exe  < ../inputs/tc188 > ../outputs/t721
echo ">>>>>>>>running test 722"
../source/print_tokens.exe  < ../inputs/tc189 > ../outputs/t722
echo ">>>>>>>>running test 723"
../source/print_tokens.exe  < ../inputs/tc19 > ../outputs/t723
echo ">>>>>>>>running test 724"
../source/print_tokens.exe  < ../inputs/tc190 > ../outputs/t724
echo ">>>>>>>>running test 725"
../source/print_tokens.exe  < ../inputs/tc191 > ../outputs/t725
echo ">>>>>>>>running test 726"
../source/print_tokens.exe  < ../inputs/tc192 > ../outputs/t726
echo ">>>>>>>>running test 727"
../source/print_tokens.exe  < ../inputs/tc193 > ../outputs/t727
echo ">>>>>>>>running test 728"
../source/print_tokens.exe  < ../inputs/tc194 > ../outputs/t728
echo ">>>>>>>>running test 729"
../source/print_tokens.exe  < ../inputs/tc195 > ../outputs/t729
echo ">>>>>>>>running test 730"
../source/print_tokens.exe  < ../inputs/tc196 > ../outputs/t730
echo ">>>>>>>>running test 731"
../source/print_tokens.exe  < ../inputs/tc197 > ../outputs/t731
echo ">>>>>>>>running test 732"
../source/print_tokens.exe  < ../inputs/tc198 > ../outputs/t732
echo ">>>>>>>>running test 733"
../source/print_tokens.exe  < ../inputs/tc199 > ../outputs/t733
echo ">>>>>>>>running test 734"
../source/print_tokens.exe  < ../inputs/tc2 > ../outputs/t734
echo ">>>>>>>>running test 735"
../source/print_tokens.exe  < ../inputs/tc20 > ../outputs/t735
echo ">>>>>>>>running test 736"
../source/print_tokens.exe  < ../inputs/tc200 > ../outputs/t736
echo ">>>>>>>>running test 737"
../source/print_tokens.exe  < ../inputs/tc201 > ../outputs/t737
echo ">>>>>>>>running test 738"
../source/print_tokens.exe  < ../inputs/tc202 > ../outputs/t738
echo ">>>>>>>>running test 739"
../source/print_tokens.exe  < ../inputs/tc203 > ../outputs/t739
echo ">>>>>>>>running test 740"
../source/print_tokens.exe  < ../inputs/tc204 > ../outputs/t740
echo ">>>>>>>>running test 741"
../source/print_tokens.exe  < ../inputs/tc205 > ../outputs/t741
echo ">>>>>>>>running test 742"
../source/print_tokens.exe  < ../inputs/tc206 > ../outputs/t742
echo ">>>>>>>>running test 743"
../source/print_tokens.exe  < ../inputs/tc207 > ../outputs/t743
echo ">>>>>>>>running test 744"
../source/print_tokens.exe  < ../inputs/tc208 > ../outputs/t744
echo ">>>>>>>>running test 745"
../source/print_tokens.exe  < ../inputs/tc209 > ../outputs/t745
echo ">>>>>>>>running test 746"
../source/print_tokens.exe  < ../inputs/tc21 > ../outputs/t746
echo ">>>>>>>>running test 747"
../source/print_tokens.exe  < ../inputs/tc210 > ../outputs/t747
echo ">>>>>>>>running test 748"
../source/print_tokens.exe  < ../inputs/tc211 > ../outputs/t748
echo ">>>>>>>>running test 749"
../source/print_tokens.exe  < ../inputs/tc212 > ../outputs/t749
echo ">>>>>>>>running test 750"
../source/print_tokens.exe  < ../inputs/tc213 > ../outputs/t750
echo ">>>>>>>>running test 751"
../source/print_tokens.exe  < ../inputs/tc214 > ../outputs/t751
echo ">>>>>>>>running test 752"
../source/print_tokens.exe  < ../inputs/tc215 > ../outputs/t752
echo ">>>>>>>>running test 753"
../source/print_tokens.exe  < ../inputs/tc216 > ../outputs/t753
echo ">>>>>>>>running test 754"
../source/print_tokens.exe  < ../inputs/tc217 > ../outputs/t754
echo ">>>>>>>>running test 755"
../source/print_tokens.exe  < ../inputs/tc218 > ../outputs/t755
echo ">>>>>>>>running test 756"
../source/print_tokens.exe  < ../inputs/tc219 > ../outputs/t756
echo ">>>>>>>>running test 757"
../source/print_tokens.exe  < ../inputs/tc22 > ../outputs/t757
echo ">>>>>>>>running test 758"
../source/print_tokens.exe  < ../inputs/tc220 > ../outputs/t758
echo ">>>>>>>>running test 759"
../source/print_tokens.exe  < ../inputs/tc221 > ../outputs/t759
echo ">>>>>>>>running test 760"
../source/print_tokens.exe  < ../inputs/tc222 > ../outputs/t760
echo ">>>>>>>>running test 761"
../source/print_tokens.exe  < ../inputs/tc223 > ../outputs/t761
echo ">>>>>>>>running test 762"
../source/print_tokens.exe  < ../inputs/tc224 > ../outputs/t762
echo ">>>>>>>>running test 763"
../source/print_tokens.exe  < ../inputs/tc225 > ../outputs/t763
echo ">>>>>>>>running test 764"
../source/print_tokens.exe  < ../inputs/tc226 > ../outputs/t764
echo ">>>>>>>>running test 765"
../source/print_tokens.exe  < ../inputs/tc227 > ../outputs/t765
echo ">>>>>>>>running test 766"
../source/print_tokens.exe  < ../inputs/tc228 > ../outputs/t766
echo ">>>>>>>>running test 767"
../source/print_tokens.exe  < ../inputs/tc229 > ../outputs/t767
echo ">>>>>>>>running test 768"
../source/print_tokens.exe  < ../inputs/tc23 > ../outputs/t768
echo ">>>>>>>>running test 769"
../source/print_tokens.exe  < ../inputs/tc230 > ../outputs/t769
echo ">>>>>>>>running test 770"
../source/print_tokens.exe  < ../inputs/tc231 > ../outputs/t770
echo ">>>>>>>>running test 771"
../source/print_tokens.exe  < ../inputs/tc232 > ../outputs/t771
echo ">>>>>>>>running test 772"
../source/print_tokens.exe  < ../inputs/tc233 > ../outputs/t772
echo ">>>>>>>>running test 773"
../source/print_tokens.exe  < ../inputs/tc234 > ../outputs/t773
echo ">>>>>>>>running test 774"
../source/print_tokens.exe  < ../inputs/tc235 > ../outputs/t774
echo ">>>>>>>>running test 775"
../source/print_tokens.exe  < ../inputs/tc236 > ../outputs/t775
echo ">>>>>>>>running test 776"
../source/print_tokens.exe  < ../inputs/tc237 > ../outputs/t776
echo ">>>>>>>>running test 777"
../source/print_tokens.exe  < ../inputs/tc238 > ../outputs/t777
echo ">>>>>>>>running test 778"
../source/print_tokens.exe  < ../inputs/tc239 > ../outputs/t778
echo ">>>>>>>>running test 779"
../source/print_tokens.exe  < ../inputs/tc24 > ../outputs/t779
echo ">>>>>>>>running test 780"
../source/print_tokens.exe  < ../inputs/tc240 > ../outputs/t780
echo ">>>>>>>>running test 781"
../source/print_tokens.exe  < ../inputs/tc241 > ../outputs/t781
echo ">>>>>>>>running test 782"
../source/print_tokens.exe  < ../inputs/tc242 > ../outputs/t782
echo ">>>>>>>>running test 783"
../source/print_tokens.exe  < ../inputs/tc243 > ../outputs/t783
echo ">>>>>>>>running test 784"
../source/print_tokens.exe  < ../inputs/tc244 > ../outputs/t784
echo ">>>>>>>>running test 785"
../source/print_tokens.exe  < ../inputs/tc245 > ../outputs/t785
echo ">>>>>>>>running test 786"
../source/print_tokens.exe  < ../inputs/tc246 > ../outputs/t786
echo ">>>>>>>>running test 787"
../source/print_tokens.exe  < ../inputs/tc247 > ../outputs/t787
echo ">>>>>>>>running test 788"
../source/print_tokens.exe  < ../inputs/tc248 > ../outputs/t788
echo ">>>>>>>>running test 789"
../source/print_tokens.exe  < ../inputs/tc249 > ../outputs/t789
echo ">>>>>>>>running test 790"
../source/print_tokens.exe  < ../inputs/tc25 > ../outputs/t790
echo ">>>>>>>>running test 791"
../source/print_tokens.exe  < ../inputs/tc250 > ../outputs/t791
echo ">>>>>>>>running test 792"
../source/print_tokens.exe  < ../inputs/tc251 > ../outputs/t792
echo ">>>>>>>>running test 793"
../source/print_tokens.exe  < ../inputs/tc252 > ../outputs/t793
echo ">>>>>>>>running test 794"
../source/print_tokens.exe  < ../inputs/tc253 > ../outputs/t794
echo ">>>>>>>>running test 795"
../source/print_tokens.exe  < ../inputs/tc254 > ../outputs/t795
echo ">>>>>>>>running test 796"
../source/print_tokens.exe  < ../inputs/tc255 > ../outputs/t796
echo ">>>>>>>>running test 797"
../source/print_tokens.exe  < ../inputs/tc256 > ../outputs/t797
echo ">>>>>>>>running test 798"
../source/print_tokens.exe  < ../inputs/tc257 > ../outputs/t798
echo ">>>>>>>>running test 799"
../source/print_tokens.exe  < ../inputs/tc258 > ../outputs/t799
echo ">>>>>>>>running test 800"
../source/print_tokens.exe  < ../inputs/tc259 > ../outputs/t800
echo ">>>>>>>>running test 801"
../source/print_tokens.exe  < ../inputs/tc26 > ../outputs/t801
echo ">>>>>>>>running test 802"
../source/print_tokens.exe  < ../inputs/tc260 > ../outputs/t802
echo ">>>>>>>>running test 803"
../source/print_tokens.exe  < ../inputs/tc261 > ../outputs/t803
echo ">>>>>>>>running test 804"
../source/print_tokens.exe  < ../inputs/tc262 > ../outputs/t804
echo ">>>>>>>>running test 805"
../source/print_tokens.exe  < ../inputs/tc263 > ../outputs/t805
echo ">>>>>>>>running test 806"
../source/print_tokens.exe  < ../inputs/tc264 > ../outputs/t806
echo ">>>>>>>>running test 807"
../source/print_tokens.exe  < ../inputs/tc265 > ../outputs/t807
echo ">>>>>>>>running test 808"
../source/print_tokens.exe  < ../inputs/tc266 > ../outputs/t808
echo ">>>>>>>>running test 809"
../source/print_tokens.exe  < ../inputs/tc267 > ../outputs/t809
echo ">>>>>>>>running test 810"
../source/print_tokens.exe  < ../inputs/tc268 > ../outputs/t810
echo ">>>>>>>>running test 811"
../source/print_tokens.exe  < ../inputs/tc269 > ../outputs/t811
echo ">>>>>>>>running test 812"
../source/print_tokens.exe  < ../inputs/tc27 > ../outputs/t812
echo ">>>>>>>>running test 813"
../source/print_tokens.exe  < ../inputs/tc270 > ../outputs/t813
echo ">>>>>>>>running test 814"
../source/print_tokens.exe  < ../inputs/tc271 > ../outputs/t814
echo ">>>>>>>>running test 815"
../source/print_tokens.exe  < ../inputs/tc272 > ../outputs/t815
echo ">>>>>>>>running test 816"
../source/print_tokens.exe  < ../inputs/tc273 > ../outputs/t816
echo ">>>>>>>>running test 817"
../source/print_tokens.exe  < ../inputs/tc274 > ../outputs/t817
echo ">>>>>>>>running test 818"
../source/print_tokens.exe  < ../inputs/tc275 > ../outputs/t818
echo ">>>>>>>>running test 819"
../source/print_tokens.exe  < ../inputs/tc276 > ../outputs/t819
echo ">>>>>>>>running test 820"
../source/print_tokens.exe  < ../inputs/tc277 > ../outputs/t820
echo ">>>>>>>>running test 821"
../source/print_tokens.exe  < ../inputs/tc278 > ../outputs/t821
echo ">>>>>>>>running test 822"
../source/print_tokens.exe  < ../inputs/tc279 > ../outputs/t822
echo ">>>>>>>>running test 823"
../source/print_tokens.exe  < ../inputs/tc28 > ../outputs/t823
echo ">>>>>>>>running test 824"
../source/print_tokens.exe  < ../inputs/tc280 > ../outputs/t824
echo ">>>>>>>>running test 825"
../source/print_tokens.exe  < ../inputs/tc281 > ../outputs/t825
echo ">>>>>>>>running test 826"
../source/print_tokens.exe  < ../inputs/tc282 > ../outputs/t826
echo ">>>>>>>>running test 827"
../source/print_tokens.exe  < ../inputs/tc283 > ../outputs/t827
echo ">>>>>>>>running test 828"
../source/print_tokens.exe  < ../inputs/tc284 > ../outputs/t828
echo ">>>>>>>>running test 829"
../source/print_tokens.exe  < ../inputs/tc285 > ../outputs/t829
echo ">>>>>>>>running test 830"
../source/print_tokens.exe  < ../inputs/tc286 > ../outputs/t830
echo ">>>>>>>>running test 831"
../source/print_tokens.exe  < ../inputs/tc287 > ../outputs/t831
echo ">>>>>>>>running test 832"
../source/print_tokens.exe  < ../inputs/tc288 > ../outputs/t832
echo ">>>>>>>>running test 833"
../source/print_tokens.exe  < ../inputs/tc289 > ../outputs/t833
echo ">>>>>>>>running test 834"
../source/print_tokens.exe  < ../inputs/tc29 > ../outputs/t834
echo ">>>>>>>>running test 835"
../source/print_tokens.exe  < ../inputs/tc290 > ../outputs/t835
echo ">>>>>>>>running test 836"
../source/print_tokens.exe  < ../inputs/tc291 > ../outputs/t836
echo ">>>>>>>>running test 837"
../source/print_tokens.exe  < ../inputs/tc292 > ../outputs/t837
echo ">>>>>>>>running test 838"
../source/print_tokens.exe  < ../inputs/tc293 > ../outputs/t838
echo ">>>>>>>>running test 839"
../source/print_tokens.exe  < ../inputs/tc294 > ../outputs/t839
echo ">>>>>>>>running test 840"
../source/print_tokens.exe  < ../inputs/tc295 > ../outputs/t840
echo ">>>>>>>>running test 841"
../source/print_tokens.exe  < ../inputs/tc296 > ../outputs/t841
echo ">>>>>>>>running test 842"
../source/print_tokens.exe  < ../inputs/tc297 > ../outputs/t842
echo ">>>>>>>>running test 843"
../source/print_tokens.exe  < ../inputs/tc298 > ../outputs/t843
echo ">>>>>>>>running test 844"
../source/print_tokens.exe  < ../inputs/tc299 > ../outputs/t844
echo ">>>>>>>>running test 845"
../source/print_tokens.exe  < ../inputs/tc3 > ../outputs/t845
echo ">>>>>>>>running test 846"
../source/print_tokens.exe  < ../inputs/tc30 > ../outputs/t846
echo ">>>>>>>>running test 847"
../source/print_tokens.exe  < ../inputs/tc300 > ../outputs/t847
echo ">>>>>>>>running test 848"
../source/print_tokens.exe  < ../inputs/tc301 > ../outputs/t848
echo ">>>>>>>>running test 849"
../source/print_tokens.exe  < ../inputs/tc302 > ../outputs/t849
echo ">>>>>>>>running test 850"
../source/print_tokens.exe  < ../inputs/tc303 > ../outputs/t850
echo ">>>>>>>>running test 851"
../source/print_tokens.exe  < ../inputs/tc304 > ../outputs/t851
echo ">>>>>>>>running test 852"
../source/print_tokens.exe  < ../inputs/tc305 > ../outputs/t852
echo ">>>>>>>>running test 853"
../source/print_tokens.exe  < ../inputs/tc306 > ../outputs/t853
echo ">>>>>>>>running test 854"
../source/print_tokens.exe  < ../inputs/tc307 > ../outputs/t854
echo ">>>>>>>>running test 855"
../source/print_tokens.exe  < ../inputs/tc308 > ../outputs/t855
echo ">>>>>>>>running test 856"
../source/print_tokens.exe  < ../inputs/tc309 > ../outputs/t856
echo ">>>>>>>>running test 857"
../source/print_tokens.exe  < ../inputs/tc31 > ../outputs/t857
echo ">>>>>>>>running test 858"
../source/print_tokens.exe  < ../inputs/tc310 > ../outputs/t858
echo ">>>>>>>>running test 859"
../source/print_tokens.exe  < ../inputs/tc311 > ../outputs/t859
echo ">>>>>>>>running test 860"
../source/print_tokens.exe  < ../inputs/tc312 > ../outputs/t860
echo ">>>>>>>>running test 861"
../source/print_tokens.exe  < ../inputs/tc313 > ../outputs/t861
echo ">>>>>>>>running test 862"
../source/print_tokens.exe  < ../inputs/tc314 > ../outputs/t862
echo ">>>>>>>>running test 863"
../source/print_tokens.exe  < ../inputs/tc315 > ../outputs/t863
echo ">>>>>>>>running test 864"
../source/print_tokens.exe  < ../inputs/tc316 > ../outputs/t864
echo ">>>>>>>>running test 865"
../source/print_tokens.exe  < ../inputs/tc317 > ../outputs/t865
echo ">>>>>>>>running test 866"
../source/print_tokens.exe  < ../inputs/tc318 > ../outputs/t866
echo ">>>>>>>>running test 867"
../source/print_tokens.exe  < ../inputs/tc319 > ../outputs/t867
echo ">>>>>>>>running test 868"
../source/print_tokens.exe  < ../inputs/tc32 > ../outputs/t868
echo ">>>>>>>>running test 869"
../source/print_tokens.exe  < ../inputs/tc320 > ../outputs/t869
echo ">>>>>>>>running test 870"
../source/print_tokens.exe  < ../inputs/tc321 > ../outputs/t870
echo ">>>>>>>>running test 871"
../source/print_tokens.exe  < ../inputs/tc322 > ../outputs/t871
echo ">>>>>>>>running test 872"
../source/print_tokens.exe  < ../inputs/tc323 > ../outputs/t872
echo ">>>>>>>>running test 873"
../source/print_tokens.exe  < ../inputs/tc324 > ../outputs/t873
echo ">>>>>>>>running test 874"
../source/print_tokens.exe  < ../inputs/tc325 > ../outputs/t874
echo ">>>>>>>>running test 875"
../source/print_tokens.exe  < ../inputs/tc326 > ../outputs/t875
echo ">>>>>>>>running test 876"
../source/print_tokens.exe  < ../inputs/tc327 > ../outputs/t876
echo ">>>>>>>>running test 877"
../source/print_tokens.exe  < ../inputs/tc328 > ../outputs/t877
echo ">>>>>>>>running test 878"
../source/print_tokens.exe  < ../inputs/tc329 > ../outputs/t878
echo ">>>>>>>>running test 879"
../source/print_tokens.exe  < ../inputs/tc33 > ../outputs/t879
echo ">>>>>>>>running test 880"
../source/print_tokens.exe  < ../inputs/tc330 > ../outputs/t880
echo ">>>>>>>>running test 881"
../source/print_tokens.exe  < ../inputs/tc331 > ../outputs/t881
echo ">>>>>>>>running test 882"
../source/print_tokens.exe  < ../inputs/tc332 > ../outputs/t882
echo ">>>>>>>>running test 883"
../source/print_tokens.exe  < ../inputs/tc333 > ../outputs/t883
echo ">>>>>>>>running test 884"
../source/print_tokens.exe  < ../inputs/tc334 > ../outputs/t884
echo ">>>>>>>>running test 885"
../source/print_tokens.exe  < ../inputs/tc335 > ../outputs/t885
echo ">>>>>>>>running test 886"
../source/print_tokens.exe  < ../inputs/tc336 > ../outputs/t886
echo ">>>>>>>>running test 887"
../source/print_tokens.exe  < ../inputs/tc337 > ../outputs/t887
echo ">>>>>>>>running test 888"
../source/print_tokens.exe  < ../inputs/tc338 > ../outputs/t888
echo ">>>>>>>>running test 889"
../source/print_tokens.exe  < ../inputs/tc339 > ../outputs/t889
echo ">>>>>>>>running test 890"
../source/print_tokens.exe  < ../inputs/tc34 > ../outputs/t890
echo ">>>>>>>>running test 891"
../source/print_tokens.exe  < ../inputs/tc340 > ../outputs/t891
echo ">>>>>>>>running test 892"
../source/print_tokens.exe  < ../inputs/tc341 > ../outputs/t892
echo ">>>>>>>>running test 893"
../source/print_tokens.exe  < ../inputs/tc342 > ../outputs/t893
echo ">>>>>>>>running test 894"
../source/print_tokens.exe  < ../inputs/tc343 > ../outputs/t894
echo ">>>>>>>>running test 895"
../source/print_tokens.exe  < ../inputs/tc344 > ../outputs/t895
echo ">>>>>>>>running test 896"
../source/print_tokens.exe  < ../inputs/tc345 > ../outputs/t896
echo ">>>>>>>>running test 897"
../source/print_tokens.exe  < ../inputs/tc346 > ../outputs/t897
echo ">>>>>>>>running test 898"
../source/print_tokens.exe  < ../inputs/tc347 > ../outputs/t898
echo ">>>>>>>>running test 899"
../source/print_tokens.exe  < ../inputs/tc348 > ../outputs/t899
echo ">>>>>>>>running test 900"
../source/print_tokens.exe  < ../inputs/tc349 > ../outputs/t900
echo ">>>>>>>>running test 901"
../source/print_tokens.exe  < ../inputs/tc35 > ../outputs/t901
echo ">>>>>>>>running test 902"
../source/print_tokens.exe  < ../inputs/tc350 > ../outputs/t902
echo ">>>>>>>>running test 903"
../source/print_tokens.exe  < ../inputs/tc351 > ../outputs/t903
echo ">>>>>>>>running test 904"
../source/print_tokens.exe  < ../inputs/tc352 > ../outputs/t904
echo ">>>>>>>>running test 905"
../source/print_tokens.exe  < ../inputs/tc353 > ../outputs/t905
echo ">>>>>>>>running test 906"
../source/print_tokens.exe  < ../inputs/tc354 > ../outputs/t906
echo ">>>>>>>>running test 907"
../source/print_tokens.exe  < ../inputs/tc355 > ../outputs/t907
echo ">>>>>>>>running test 908"
../source/print_tokens.exe  < ../inputs/tc356 > ../outputs/t908
echo ">>>>>>>>running test 909"
../source/print_tokens.exe  < ../inputs/tc357 > ../outputs/t909
echo ">>>>>>>>running test 910"
../source/print_tokens.exe  < ../inputs/tc358 > ../outputs/t910
echo ">>>>>>>>running test 911"
../source/print_tokens.exe  < ../inputs/tc359 > ../outputs/t911
echo ">>>>>>>>running test 912"
../source/print_tokens.exe  < ../inputs/tc36 > ../outputs/t912
echo ">>>>>>>>running test 913"
../source/print_tokens.exe  < ../inputs/tc360 > ../outputs/t913
echo ">>>>>>>>running test 914"
../source/print_tokens.exe  < ../inputs/tc361 > ../outputs/t914
echo ">>>>>>>>running test 915"
../source/print_tokens.exe  < ../inputs/tc362 > ../outputs/t915
echo ">>>>>>>>running test 916"
../source/print_tokens.exe  < ../inputs/tc363 > ../outputs/t916
echo ">>>>>>>>running test 917"
../source/print_tokens.exe  < ../inputs/tc364 > ../outputs/t917
echo ">>>>>>>>running test 918"
../source/print_tokens.exe  < ../inputs/tc365 > ../outputs/t918
echo ">>>>>>>>running test 919"
../source/print_tokens.exe  < ../inputs/tc366 > ../outputs/t919
echo ">>>>>>>>running test 920"
../source/print_tokens.exe  < ../inputs/tc367 > ../outputs/t920
echo ">>>>>>>>running test 921"
../source/print_tokens.exe  < ../inputs/tc368 > ../outputs/t921
echo ">>>>>>>>running test 922"
../source/print_tokens.exe  < ../inputs/tc369 > ../outputs/t922
echo ">>>>>>>>running test 923"
../source/print_tokens.exe  < ../inputs/tc37 > ../outputs/t923
echo ">>>>>>>>running test 924"
../source/print_tokens.exe  < ../inputs/tc370 > ../outputs/t924
echo ">>>>>>>>running test 925"
../source/print_tokens.exe  < ../inputs/tc371 > ../outputs/t925
echo ">>>>>>>>running test 926"
../source/print_tokens.exe  < ../inputs/tc372 > ../outputs/t926
echo ">>>>>>>>running test 927"
../source/print_tokens.exe  < ../inputs/tc373 > ../outputs/t927
echo ">>>>>>>>running test 928"
../source/print_tokens.exe  < ../inputs/tc374 > ../outputs/t928
echo ">>>>>>>>running test 929"
../source/print_tokens.exe  < ../inputs/tc375 > ../outputs/t929
echo ">>>>>>>>running test 930"
../source/print_tokens.exe  < ../inputs/tc376 > ../outputs/t930
echo ">>>>>>>>running test 931"
../source/print_tokens.exe  < ../inputs/tc377 > ../outputs/t931
echo ">>>>>>>>running test 932"
../source/print_tokens.exe  < ../inputs/tc378 > ../outputs/t932
echo ">>>>>>>>running test 933"
../source/print_tokens.exe  < ../inputs/tc379 > ../outputs/t933
echo ">>>>>>>>running test 934"
../source/print_tokens.exe  < ../inputs/tc38 > ../outputs/t934
echo ">>>>>>>>running test 935"
../source/print_tokens.exe  < ../inputs/tc380 > ../outputs/t935
echo ">>>>>>>>running test 936"
../source/print_tokens.exe  < ../inputs/tc381 > ../outputs/t936
echo ">>>>>>>>running test 937"
../source/print_tokens.exe  < ../inputs/tc382 > ../outputs/t937
echo ">>>>>>>>running test 938"
../source/print_tokens.exe  < ../inputs/tc383 > ../outputs/t938
echo ">>>>>>>>running test 939"
../source/print_tokens.exe  < ../inputs/tc384 > ../outputs/t939
echo ">>>>>>>>running test 940"
../source/print_tokens.exe  < ../inputs/tc385 > ../outputs/t940
echo ">>>>>>>>running test 941"
../source/print_tokens.exe  < ../inputs/tc386 > ../outputs/t941
echo ">>>>>>>>running test 942"
../source/print_tokens.exe  < ../inputs/tc387 > ../outputs/t942
echo ">>>>>>>>running test 943"
../source/print_tokens.exe  < ../inputs/tc388 > ../outputs/t943
echo ">>>>>>>>running test 944"
../source/print_tokens.exe  < ../inputs/tc389 > ../outputs/t944
echo ">>>>>>>>running test 945"
../source/print_tokens.exe  < ../inputs/tc39 > ../outputs/t945
echo ">>>>>>>>running test 946"
../source/print_tokens.exe  < ../inputs/tc390 > ../outputs/t946
echo ">>>>>>>>running test 947"
../source/print_tokens.exe  < ../inputs/tc391 > ../outputs/t947
echo ">>>>>>>>running test 948"
../source/print_tokens.exe  < ../inputs/tc392 > ../outputs/t948
echo ">>>>>>>>running test 949"
../source/print_tokens.exe  < ../inputs/tc393 > ../outputs/t949
echo ">>>>>>>>running test 950"
../source/print_tokens.exe  < ../inputs/tc394 > ../outputs/t950
echo ">>>>>>>>running test 951"
../source/print_tokens.exe  < ../inputs/tc395 > ../outputs/t951
echo ">>>>>>>>running test 952"
../source/print_tokens.exe  < ../inputs/tc396 > ../outputs/t952
echo ">>>>>>>>running test 953"
../source/print_tokens.exe  < ../inputs/tc397 > ../outputs/t953
echo ">>>>>>>>running test 954"
../source/print_tokens.exe  < ../inputs/tc398 > ../outputs/t954
echo ">>>>>>>>running test 955"
../source/print_tokens.exe  < ../inputs/tc399 > ../outputs/t955
echo ">>>>>>>>running test 956"
../source/print_tokens.exe  < ../inputs/tc4 > ../outputs/t956
echo ">>>>>>>>running test 957"
../source/print_tokens.exe  < ../inputs/tc40 > ../outputs/t957
echo ">>>>>>>>running test 958"
../source/print_tokens.exe  < ../inputs/tc400 > ../outputs/t958
echo ">>>>>>>>running test 959"
../source/print_tokens.exe  < ../inputs/tc41 > ../outputs/t959
echo ">>>>>>>>running test 960"
../source/print_tokens.exe  < ../inputs/tc42 > ../outputs/t960
echo ">>>>>>>>running test 961"
../source/print_tokens.exe  < ../inputs/tc43 > ../outputs/t961
echo ">>>>>>>>running test 962"
../source/print_tokens.exe  < ../inputs/tc44 > ../outputs/t962
echo ">>>>>>>>running test 963"
../source/print_tokens.exe  < ../inputs/tc45 > ../outputs/t963
echo ">>>>>>>>running test 964"
../source/print_tokens.exe  < ../inputs/tc46 > ../outputs/t964
echo ">>>>>>>>running test 965"
../source/print_tokens.exe  < ../inputs/tc47 > ../outputs/t965
echo ">>>>>>>>running test 966"
../source/print_tokens.exe  < ../inputs/tc48 > ../outputs/t966
echo ">>>>>>>>running test 967"
../source/print_tokens.exe  < ../inputs/tc49 > ../outputs/t967
echo ">>>>>>>>running test 968"
../source/print_tokens.exe  < ../inputs/tc5 > ../outputs/t968
echo ">>>>>>>>running test 969"
../source/print_tokens.exe  < ../inputs/tc50 > ../outputs/t969
echo ">>>>>>>>running test 970"
../source/print_tokens.exe  < ../inputs/tc51 > ../outputs/t970
echo ">>>>>>>>running test 971"
../source/print_tokens.exe  < ../inputs/tc52 > ../outputs/t971
echo ">>>>>>>>running test 972"
../source/print_tokens.exe  < ../inputs/tc53 > ../outputs/t972
echo ">>>>>>>>running test 973"
../source/print_tokens.exe  < ../inputs/tc54 > ../outputs/t973
echo ">>>>>>>>running test 974"
../source/print_tokens.exe  < ../inputs/tc55 > ../outputs/t974
echo ">>>>>>>>running test 975"
../source/print_tokens.exe  < ../inputs/tc56 > ../outputs/t975
echo ">>>>>>>>running test 976"
../source/print_tokens.exe  < ../inputs/tc57 > ../outputs/t976
echo ">>>>>>>>running test 977"
../source/print_tokens.exe  < ../inputs/tc58 > ../outputs/t977
echo ">>>>>>>>running test 978"
../source/print_tokens.exe  < ../inputs/tc59 > ../outputs/t978
echo ">>>>>>>>running test 979"
../source/print_tokens.exe  < ../inputs/tc6 > ../outputs/t979
echo ">>>>>>>>running test 980"
../source/print_tokens.exe  < ../inputs/tc60 > ../outputs/t980
echo ">>>>>>>>running test 981"
../source/print_tokens.exe  < ../inputs/tc61 > ../outputs/t981
echo ">>>>>>>>running test 982"
../source/print_tokens.exe  < ../inputs/tc62 > ../outputs/t982
echo ">>>>>>>>running test 983"
../source/print_tokens.exe  < ../inputs/tc63 > ../outputs/t983
echo ">>>>>>>>running test 984"
../source/print_tokens.exe  < ../inputs/tc64 > ../outputs/t984
echo ">>>>>>>>running test 985"
../source/print_tokens.exe  < ../inputs/tc65 > ../outputs/t985
echo ">>>>>>>>running test 986"
../source/print_tokens.exe  < ../inputs/tc66 > ../outputs/t986
echo ">>>>>>>>running test 987"
../source/print_tokens.exe  < ../inputs/tc67 > ../outputs/t987
echo ">>>>>>>>running test 988"
../source/print_tokens.exe  < ../inputs/tc68 > ../outputs/t988
echo ">>>>>>>>running test 989"
../source/print_tokens.exe  < ../inputs/tc69 > ../outputs/t989
echo ">>>>>>>>running test 990"
../source/print_tokens.exe  < ../inputs/tc7 > ../outputs/t990
echo ">>>>>>>>running test 991"
../source/print_tokens.exe  < ../inputs/tc70 > ../outputs/t991
echo ">>>>>>>>running test 992"
../source/print_tokens.exe  < ../inputs/tc71 > ../outputs/t992
echo ">>>>>>>>running test 993"
../source/print_tokens.exe  < ../inputs/tc72 > ../outputs/t993
echo ">>>>>>>>running test 994"
../source/print_tokens.exe  < ../inputs/tc73 > ../outputs/t994
echo ">>>>>>>>running test 995"
../source/print_tokens.exe  < ../inputs/tc74 > ../outputs/t995
echo ">>>>>>>>running test 996"
../source/print_tokens.exe  < ../inputs/tc75 > ../outputs/t996
echo ">>>>>>>>running test 997"
../source/print_tokens.exe  < ../inputs/tc76 > ../outputs/t997
echo ">>>>>>>>running test 998"
../source/print_tokens.exe  < ../inputs/tc77 > ../outputs/t998
echo ">>>>>>>>running test 999"
../source/print_tokens.exe  < ../inputs/tc78 > ../outputs/t999
echo ">>>>>>>>running test 1000"
../source/print_tokens.exe  < ../inputs/tc79 > ../outputs/t1000
echo ">>>>>>>>running test 1001"
../source/print_tokens.exe  < ../inputs/tc8 > ../outputs/t1001
echo ">>>>>>>>running test 1002"
../source/print_tokens.exe  < ../inputs/tc80 > ../outputs/t1002
echo ">>>>>>>>running test 1003"
../source/print_tokens.exe  < ../inputs/tc81 > ../outputs/t1003
echo ">>>>>>>>running test 1004"
../source/print_tokens.exe  < ../inputs/tc82 > ../outputs/t1004
echo ">>>>>>>>running test 1005"
../source/print_tokens.exe  < ../inputs/tc83 > ../outputs/t1005
echo ">>>>>>>>running test 1006"
../source/print_tokens.exe  < ../inputs/tc84 > ../outputs/t1006
echo ">>>>>>>>running test 1007"
../source/print_tokens.exe  < ../inputs/tc85 > ../outputs/t1007
echo ">>>>>>>>running test 1008"
../source/print_tokens.exe  < ../inputs/tc86 > ../outputs/t1008
echo ">>>>>>>>running test 1009"
../source/print_tokens.exe  < ../inputs/tc87 > ../outputs/t1009
echo ">>>>>>>>running test 1010"
../source/print_tokens.exe  < ../inputs/tc88 > ../outputs/t1010
echo ">>>>>>>>running test 1011"
../source/print_tokens.exe  < ../inputs/tc89 > ../outputs/t1011
echo ">>>>>>>>running test 1012"
../source/print_tokens.exe  < ../inputs/tc9 > ../outputs/t1012
echo ">>>>>>>>running test 1013"
../source/print_tokens.exe  < ../inputs/tc90 > ../outputs/t1013
echo ">>>>>>>>running test 1014"
../source/print_tokens.exe  < ../inputs/tc91 > ../outputs/t1014
echo ">>>>>>>>running test 1015"
../source/print_tokens.exe  < ../inputs/tc92 > ../outputs/t1015
echo ">>>>>>>>running test 1016"
../source/print_tokens.exe  < ../inputs/tc93 > ../outputs/t1016
echo ">>>>>>>>running test 1017"
../source/print_tokens.exe  < ../inputs/tc94 > ../outputs/t1017
echo ">>>>>>>>running test 1018"
../source/print_tokens.exe  < ../inputs/tc95 > ../outputs/t1018
echo ">>>>>>>>running test 1019"
../source/print_tokens.exe  < ../inputs/tc96 > ../outputs/t1019
echo ">>>>>>>>running test 1020"
../source/print_tokens.exe  < ../inputs/tc97 > ../outputs/t1020
echo ">>>>>>>>running test 1021"
../source/print_tokens.exe  < ../inputs/tc98 > ../outputs/t1021
echo ">>>>>>>>running test 1022"
../source/print_tokens.exe  < ../inputs/tc99 > ../outputs/t1022
echo ">>>>>>>>running test 1023"
../source/print_tokens.exe  < ../inputs/test1 > ../outputs/t1023
echo ">>>>>>>>running test 1024"
../source/print_tokens.exe  < ../inputs/test10 > ../outputs/t1024
echo ">>>>>>>>running test 1025"
../source/print_tokens.exe  < ../inputs/test100 > ../outputs/t1025
echo ">>>>>>>>running test 1026"
../source/print_tokens.exe  < ../inputs/test101 > ../outputs/t1026
echo ">>>>>>>>running test 1027"
../source/print_tokens.exe  < ../inputs/test102 > ../outputs/t1027
echo ">>>>>>>>running test 1028"
../source/print_tokens.exe  < ../inputs/test103 > ../outputs/t1028
echo ">>>>>>>>running test 1029"
../source/print_tokens.exe  < ../inputs/test104 > ../outputs/t1029
echo ">>>>>>>>running test 1030"
../source/print_tokens.exe  < ../inputs/test105 > ../outputs/t1030
echo ">>>>>>>>running test 1031"
../source/print_tokens.exe  < ../inputs/test106 > ../outputs/t1031
echo ">>>>>>>>running test 1032"
../source/print_tokens.exe  < ../inputs/test107 > ../outputs/t1032
echo ">>>>>>>>running test 1033"
../source/print_tokens.exe  < ../inputs/test108 > ../outputs/t1033
echo ">>>>>>>>running test 1034"
../source/print_tokens.exe  < ../inputs/test109 > ../outputs/t1034
echo ">>>>>>>>running test 1035"
../source/print_tokens.exe  < ../inputs/test11 > ../outputs/t1035
echo ">>>>>>>>running test 1036"
../source/print_tokens.exe  < ../inputs/test110 > ../outputs/t1036
echo ">>>>>>>>running test 1037"
../source/print_tokens.exe  < ../inputs/test111 > ../outputs/t1037
echo ">>>>>>>>running test 1038"
../source/print_tokens.exe  < ../inputs/test112 > ../outputs/t1038
echo ">>>>>>>>running test 1039"
../source/print_tokens.exe  < ../inputs/test113 > ../outputs/t1039
echo ">>>>>>>>running test 1040"
../source/print_tokens.exe  < ../inputs/test114 > ../outputs/t1040
echo ">>>>>>>>running test 1041"
../source/print_tokens.exe  < ../inputs/test115 > ../outputs/t1041
echo ">>>>>>>>running test 1042"
../source/print_tokens.exe  < ../inputs/test116 > ../outputs/t1042
echo ">>>>>>>>running test 1043"
../source/print_tokens.exe  < ../inputs/test117 > ../outputs/t1043
echo ">>>>>>>>running test 1044"
../source/print_tokens.exe  < ../inputs/test118 > ../outputs/t1044
echo ">>>>>>>>running test 1045"
../source/print_tokens.exe  < ../inputs/test119 > ../outputs/t1045
echo ">>>>>>>>running test 1046"
../source/print_tokens.exe  < ../inputs/test12 > ../outputs/t1046
echo ">>>>>>>>running test 1047"
../source/print_tokens.exe  < ../inputs/test120 > ../outputs/t1047
echo ">>>>>>>>running test 1048"
../source/print_tokens.exe  < ../inputs/test121 > ../outputs/t1048
echo ">>>>>>>>running test 1049"
../source/print_tokens.exe  < ../inputs/test122 > ../outputs/t1049
echo ">>>>>>>>running test 1050"
../source/print_tokens.exe  < ../inputs/test123 > ../outputs/t1050
echo ">>>>>>>>running test 1051"
../source/print_tokens.exe  < ../inputs/test124 > ../outputs/t1051
echo ">>>>>>>>running test 1052"
../source/print_tokens.exe  < ../inputs/test125 > ../outputs/t1052
echo ">>>>>>>>running test 1053"
../source/print_tokens.exe  < ../inputs/test126 > ../outputs/t1053
echo ">>>>>>>>running test 1054"
../source/print_tokens.exe  < ../inputs/test127 > ../outputs/t1054
echo ">>>>>>>>running test 1055"
../source/print_tokens.exe  < ../inputs/test128 > ../outputs/t1055
echo ">>>>>>>>running test 1056"
../source/print_tokens.exe  < ../inputs/test129 > ../outputs/t1056
echo ">>>>>>>>running test 1057"
../source/print_tokens.exe  < ../inputs/test13 > ../outputs/t1057
echo ">>>>>>>>running test 1058"
../source/print_tokens.exe  < ../inputs/test130 > ../outputs/t1058
echo ">>>>>>>>running test 1059"
../source/print_tokens.exe  < ../inputs/test131 > ../outputs/t1059
echo ">>>>>>>>running test 1060"
../source/print_tokens.exe  < ../inputs/test132 > ../outputs/t1060
echo ">>>>>>>>running test 1061"
../source/print_tokens.exe  < ../inputs/test133 > ../outputs/t1061
echo ">>>>>>>>running test 1062"
../source/print_tokens.exe  < ../inputs/test134 > ../outputs/t1062
echo ">>>>>>>>running test 1063"
../source/print_tokens.exe  < ../inputs/test135 > ../outputs/t1063
echo ">>>>>>>>running test 1064"
../source/print_tokens.exe  < ../inputs/test136 > ../outputs/t1064
echo ">>>>>>>>running test 1065"
../source/print_tokens.exe  < ../inputs/test137 > ../outputs/t1065
echo ">>>>>>>>running test 1066"
../source/print_tokens.exe  < ../inputs/test138 > ../outputs/t1066
echo ">>>>>>>>running test 1067"
../source/print_tokens.exe  < ../inputs/test139 > ../outputs/t1067
echo ">>>>>>>>running test 1068"
../source/print_tokens.exe  < ../inputs/test14 > ../outputs/t1068
echo ">>>>>>>>running test 1069"
../source/print_tokens.exe  < ../inputs/test140 > ../outputs/t1069
echo ">>>>>>>>running test 1070"
../source/print_tokens.exe  < ../inputs/test141 > ../outputs/t1070
echo ">>>>>>>>running test 1071"
../source/print_tokens.exe  < ../inputs/test142 > ../outputs/t1071
echo ">>>>>>>>running test 1072"
../source/print_tokens.exe  < ../inputs/test143 > ../outputs/t1072
echo ">>>>>>>>running test 1073"
../source/print_tokens.exe  < ../inputs/test144 > ../outputs/t1073
echo ">>>>>>>>running test 1074"
../source/print_tokens.exe  < ../inputs/test145 > ../outputs/t1074
echo ">>>>>>>>running test 1075"
../source/print_tokens.exe  < ../inputs/test146 > ../outputs/t1075
echo ">>>>>>>>running test 1076"
../source/print_tokens.exe  < ../inputs/test147 > ../outputs/t1076
echo ">>>>>>>>running test 1077"
../source/print_tokens.exe  < ../inputs/test148 > ../outputs/t1077
echo ">>>>>>>>running test 1078"
../source/print_tokens.exe  < ../inputs/test149 > ../outputs/t1078
echo ">>>>>>>>running test 1079"
../source/print_tokens.exe  < ../inputs/test15 > ../outputs/t1079
echo ">>>>>>>>running test 1080"
../source/print_tokens.exe  < ../inputs/test150 > ../outputs/t1080
echo ">>>>>>>>running test 1081"
../source/print_tokens.exe  < ../inputs/test151 > ../outputs/t1081
echo ">>>>>>>>running test 1082"
../source/print_tokens.exe  < ../inputs/test152 > ../outputs/t1082
echo ">>>>>>>>running test 1083"
../source/print_tokens.exe  < ../inputs/test153 > ../outputs/t1083
echo ">>>>>>>>running test 1084"
../source/print_tokens.exe  < ../inputs/test154 > ../outputs/t1084
echo ">>>>>>>>running test 1085"
../source/print_tokens.exe  < ../inputs/test155 > ../outputs/t1085
echo ">>>>>>>>running test 1086"
../source/print_tokens.exe  < ../inputs/test156 > ../outputs/t1086
echo ">>>>>>>>running test 1087"
../source/print_tokens.exe  < ../inputs/test157 > ../outputs/t1087
echo ">>>>>>>>running test 1088"
../source/print_tokens.exe  < ../inputs/test158 > ../outputs/t1088
echo ">>>>>>>>running test 1089"
../source/print_tokens.exe  < ../inputs/test159 > ../outputs/t1089
echo ">>>>>>>>running test 1090"
../source/print_tokens.exe  < ../inputs/test16 > ../outputs/t1090
echo ">>>>>>>>running test 1091"
../source/print_tokens.exe  < ../inputs/test160 > ../outputs/t1091
echo ">>>>>>>>running test 1092"
../source/print_tokens.exe  < ../inputs/test161 > ../outputs/t1092
echo ">>>>>>>>running test 1093"
../source/print_tokens.exe  < ../inputs/test162 > ../outputs/t1093
echo ">>>>>>>>running test 1094"
../source/print_tokens.exe  < ../inputs/test163 > ../outputs/t1094
echo ">>>>>>>>running test 1095"
../source/print_tokens.exe  < ../inputs/test164 > ../outputs/t1095
echo ">>>>>>>>running test 1096"
../source/print_tokens.exe  < ../inputs/test165 > ../outputs/t1096
echo ">>>>>>>>running test 1097"
../source/print_tokens.exe  < ../inputs/test166 > ../outputs/t1097
echo ">>>>>>>>running test 1098"
../source/print_tokens.exe  < ../inputs/test167 > ../outputs/t1098
echo ">>>>>>>>running test 1099"
../source/print_tokens.exe  < ../inputs/test168 > ../outputs/t1099
echo ">>>>>>>>running test 1100"
../source/print_tokens.exe  < ../inputs/test169 > ../outputs/t1100
echo ">>>>>>>>running test 1101"
../source/print_tokens.exe  < ../inputs/test17 > ../outputs/t1101
echo ">>>>>>>>running test 1102"
../source/print_tokens.exe  < ../inputs/test170 > ../outputs/t1102
echo ">>>>>>>>running test 1103"
../source/print_tokens.exe  < ../inputs/test171 > ../outputs/t1103
echo ">>>>>>>>running test 1104"
../source/print_tokens.exe  < ../inputs/test172 > ../outputs/t1104
echo ">>>>>>>>running test 1105"
../source/print_tokens.exe  < ../inputs/test173 > ../outputs/t1105
echo ">>>>>>>>running test 1106"
../source/print_tokens.exe  < ../inputs/test174 > ../outputs/t1106
echo ">>>>>>>>running test 1107"
../source/print_tokens.exe  < ../inputs/test175 > ../outputs/t1107
echo ">>>>>>>>running test 1108"
../source/print_tokens.exe  < ../inputs/test176 > ../outputs/t1108
echo ">>>>>>>>running test 1109"
../source/print_tokens.exe  < ../inputs/test177 > ../outputs/t1109
echo ">>>>>>>>running test 1110"
../source/print_tokens.exe  < ../inputs/test178 > ../outputs/t1110
echo ">>>>>>>>running test 1111"
../source/print_tokens.exe  < ../inputs/test179 > ../outputs/t1111
echo ">>>>>>>>running test 1112"
../source/print_tokens.exe  < ../inputs/test18 > ../outputs/t1112
echo ">>>>>>>>running test 1113"
../source/print_tokens.exe  < ../inputs/test180 > ../outputs/t1113
echo ">>>>>>>>running test 1114"
../source/print_tokens.exe  < ../inputs/test181 > ../outputs/t1114
echo ">>>>>>>>running test 1115"
../source/print_tokens.exe  < ../inputs/test182 > ../outputs/t1115
echo ">>>>>>>>running test 1116"
../source/print_tokens.exe  < ../inputs/test183 > ../outputs/t1116
echo ">>>>>>>>running test 1117"
../source/print_tokens.exe  < ../inputs/test184 > ../outputs/t1117
echo ">>>>>>>>running test 1118"
../source/print_tokens.exe  < ../inputs/test185 > ../outputs/t1118
echo ">>>>>>>>running test 1119"
../source/print_tokens.exe  < ../inputs/test186 > ../outputs/t1119
echo ">>>>>>>>running test 1120"
../source/print_tokens.exe  < ../inputs/test187 > ../outputs/t1120
echo ">>>>>>>>running test 1121"
../source/print_tokens.exe  < ../inputs/test188 > ../outputs/t1121
echo ">>>>>>>>running test 1122"
../source/print_tokens.exe  < ../inputs/test189 > ../outputs/t1122
echo ">>>>>>>>running test 1123"
../source/print_tokens.exe  < ../inputs/test19 > ../outputs/t1123
echo ">>>>>>>>running test 1124"
../source/print_tokens.exe  < ../inputs/test190 > ../outputs/t1124
echo ">>>>>>>>running test 1125"
../source/print_tokens.exe  < ../inputs/test191 > ../outputs/t1125
echo ">>>>>>>>running test 1126"
../source/print_tokens.exe  < ../inputs/test192 > ../outputs/t1126
echo ">>>>>>>>running test 1127"
../source/print_tokens.exe  < ../inputs/test193 > ../outputs/t1127
echo ">>>>>>>>running test 1128"
../source/print_tokens.exe  < ../inputs/test194 > ../outputs/t1128
echo ">>>>>>>>running test 1129"
../source/print_tokens.exe  < ../inputs/test195 > ../outputs/t1129
echo ">>>>>>>>running test 1130"
../source/print_tokens.exe  < ../inputs/test196 > ../outputs/t1130
echo ">>>>>>>>running test 1131"
../source/print_tokens.exe  < ../inputs/test197 > ../outputs/t1131
echo ">>>>>>>>running test 1132"
../source/print_tokens.exe  < ../inputs/test198 > ../outputs/t1132
echo ">>>>>>>>running test 1133"
../source/print_tokens.exe  < ../inputs/test199 > ../outputs/t1133
echo ">>>>>>>>running test 1134"
../source/print_tokens.exe  < ../inputs/test2 > ../outputs/t1134
echo ">>>>>>>>running test 1135"
../source/print_tokens.exe  < ../inputs/test20 > ../outputs/t1135
echo ">>>>>>>>running test 1136"
../source/print_tokens.exe  < ../inputs/test200 > ../outputs/t1136
echo ">>>>>>>>running test 1137"
../source/print_tokens.exe  < ../inputs/test201 > ../outputs/t1137
echo ">>>>>>>>running test 1138"
../source/print_tokens.exe  < ../inputs/test202 > ../outputs/t1138
echo ">>>>>>>>running test 1139"
../source/print_tokens.exe  < ../inputs/test203 > ../outputs/t1139
echo ">>>>>>>>running test 1140"
../source/print_tokens.exe  < ../inputs/test204 > ../outputs/t1140
echo ">>>>>>>>running test 1141"
../source/print_tokens.exe  < ../inputs/test205 > ../outputs/t1141
echo ">>>>>>>>running test 1142"
../source/print_tokens.exe  < ../inputs/test206 > ../outputs/t1142
echo ">>>>>>>>running test 1143"
../source/print_tokens.exe  < ../inputs/test207 > ../outputs/t1143
echo ">>>>>>>>running test 1144"
../source/print_tokens.exe  < ../inputs/test208 > ../outputs/t1144
echo ">>>>>>>>running test 1145"
../source/print_tokens.exe  < ../inputs/test209 > ../outputs/t1145
echo ">>>>>>>>running test 1146"
../source/print_tokens.exe  < ../inputs/test21 > ../outputs/t1146
echo ">>>>>>>>running test 1147"
../source/print_tokens.exe  < ../inputs/test210 > ../outputs/t1147
echo ">>>>>>>>running test 1148"
../source/print_tokens.exe  < ../inputs/test211 > ../outputs/t1148
echo ">>>>>>>>running test 1149"
../source/print_tokens.exe  < ../inputs/test212 > ../outputs/t1149
echo ">>>>>>>>running test 1150"
../source/print_tokens.exe  < ../inputs/test213 > ../outputs/t1150
echo ">>>>>>>>running test 1151"
../source/print_tokens.exe  < ../inputs/test214 > ../outputs/t1151
echo ">>>>>>>>running test 1152"
../source/print_tokens.exe  < ../inputs/test215 > ../outputs/t1152
echo ">>>>>>>>running test 1153"
../source/print_tokens.exe  < ../inputs/test216 > ../outputs/t1153
echo ">>>>>>>>running test 1154"
../source/print_tokens.exe  < ../inputs/test217 > ../outputs/t1154
echo ">>>>>>>>running test 1155"
../source/print_tokens.exe  < ../inputs/test218 > ../outputs/t1155
echo ">>>>>>>>running test 1156"
../source/print_tokens.exe  < ../inputs/test219 > ../outputs/t1156
echo ">>>>>>>>running test 1157"
../source/print_tokens.exe  < ../inputs/test22 > ../outputs/t1157
echo ">>>>>>>>running test 1158"
../source/print_tokens.exe  < ../inputs/test220 > ../outputs/t1158
echo ">>>>>>>>running test 1159"
../source/print_tokens.exe  < ../inputs/test221 > ../outputs/t1159
echo ">>>>>>>>running test 1160"
../source/print_tokens.exe  < ../inputs/test222 > ../outputs/t1160
echo ">>>>>>>>running test 1161"
../source/print_tokens.exe  < ../inputs/test223 > ../outputs/t1161
echo ">>>>>>>>running test 1162"
../source/print_tokens.exe  < ../inputs/test224 > ../outputs/t1162
echo ">>>>>>>>running test 1163"
../source/print_tokens.exe  < ../inputs/test225 > ../outputs/t1163
echo ">>>>>>>>running test 1164"
../source/print_tokens.exe  < ../inputs/test226 > ../outputs/t1164
echo ">>>>>>>>running test 1165"
../source/print_tokens.exe  < ../inputs/test227 > ../outputs/t1165
echo ">>>>>>>>running test 1166"
../source/print_tokens.exe  < ../inputs/test228 > ../outputs/t1166
echo ">>>>>>>>running test 1167"
../source/print_tokens.exe  < ../inputs/test229 > ../outputs/t1167
echo ">>>>>>>>running test 1168"
../source/print_tokens.exe  < ../inputs/test23 > ../outputs/t1168
echo ">>>>>>>>running test 1169"
../source/print_tokens.exe  < ../inputs/test230 > ../outputs/t1169
echo ">>>>>>>>running test 1170"
../source/print_tokens.exe  < ../inputs/test231 > ../outputs/t1170
echo ">>>>>>>>running test 1171"
../source/print_tokens.exe  < ../inputs/test232 > ../outputs/t1171
echo ">>>>>>>>running test 1172"
../source/print_tokens.exe  < ../inputs/test233 > ../outputs/t1172
echo ">>>>>>>>running test 1173"
../source/print_tokens.exe  < ../inputs/test234 > ../outputs/t1173
echo ">>>>>>>>running test 1174"
../source/print_tokens.exe  < ../inputs/test235 > ../outputs/t1174
echo ">>>>>>>>running test 1175"
../source/print_tokens.exe  < ../inputs/test236 > ../outputs/t1175
echo ">>>>>>>>running test 1176"
../source/print_tokens.exe  < ../inputs/test237 > ../outputs/t1176
echo ">>>>>>>>running test 1177"
../source/print_tokens.exe  < ../inputs/test238 > ../outputs/t1177
echo ">>>>>>>>running test 1178"
../source/print_tokens.exe  < ../inputs/test239 > ../outputs/t1178
echo ">>>>>>>>running test 1179"
../source/print_tokens.exe  < ../inputs/test24 > ../outputs/t1179
echo ">>>>>>>>running test 1180"
../source/print_tokens.exe  < ../inputs/test240 > ../outputs/t1180
echo ">>>>>>>>running test 1181"
../source/print_tokens.exe  < ../inputs/test241 > ../outputs/t1181
echo ">>>>>>>>running test 1182"
../source/print_tokens.exe  < ../inputs/test242 > ../outputs/t1182
echo ">>>>>>>>running test 1183"
../source/print_tokens.exe  < ../inputs/test243 > ../outputs/t1183
echo ">>>>>>>>running test 1184"
../source/print_tokens.exe  < ../inputs/test244 > ../outputs/t1184
echo ">>>>>>>>running test 1185"
../source/print_tokens.exe  < ../inputs/test245 > ../outputs/t1185
echo ">>>>>>>>running test 1186"
../source/print_tokens.exe  < ../inputs/test246 > ../outputs/t1186
echo ">>>>>>>>running test 1187"
../source/print_tokens.exe  < ../inputs/test247 > ../outputs/t1187
echo ">>>>>>>>running test 1188"
../source/print_tokens.exe  < ../inputs/test248 > ../outputs/t1188
echo ">>>>>>>>running test 1189"
../source/print_tokens.exe  < ../inputs/test249 > ../outputs/t1189
echo ">>>>>>>>running test 1190"
../source/print_tokens.exe  < ../inputs/test25 > ../outputs/t1190
echo ">>>>>>>>running test 1191"
../source/print_tokens.exe  < ../inputs/test250 > ../outputs/t1191
echo ">>>>>>>>running test 1192"
../source/print_tokens.exe  < ../inputs/test251 > ../outputs/t1192
echo ">>>>>>>>running test 1193"
../source/print_tokens.exe  < ../inputs/test252 > ../outputs/t1193
echo ">>>>>>>>running test 1194"
../source/print_tokens.exe  < ../inputs/test253 > ../outputs/t1194
echo ">>>>>>>>running test 1195"
../source/print_tokens.exe  < ../inputs/test254 > ../outputs/t1195
echo ">>>>>>>>running test 1196"
../source/print_tokens.exe  < ../inputs/test255 > ../outputs/t1196
echo ">>>>>>>>running test 1197"
../source/print_tokens.exe  < ../inputs/test256 > ../outputs/t1197
echo ">>>>>>>>running test 1198"
../source/print_tokens.exe  < ../inputs/test257 > ../outputs/t1198
echo ">>>>>>>>running test 1199"
../source/print_tokens.exe  < ../inputs/test258 > ../outputs/t1199
echo ">>>>>>>>running test 1200"
../source/print_tokens.exe  < ../inputs/test259 > ../outputs/t1200
echo ">>>>>>>>running test 1201"
../source/print_tokens.exe  < ../inputs/test26 > ../outputs/t1201
echo ">>>>>>>>running test 1202"
../source/print_tokens.exe  < ../inputs/test260 > ../outputs/t1202
echo ">>>>>>>>running test 1203"
../source/print_tokens.exe  < ../inputs/test261 > ../outputs/t1203
echo ">>>>>>>>running test 1204"
../source/print_tokens.exe  < ../inputs/test262 > ../outputs/t1204
echo ">>>>>>>>running test 1205"
../source/print_tokens.exe  < ../inputs/test263 > ../outputs/t1205
echo ">>>>>>>>running test 1206"
../source/print_tokens.exe  < ../inputs/test264 > ../outputs/t1206
echo ">>>>>>>>running test 1207"
../source/print_tokens.exe  < ../inputs/test265 > ../outputs/t1207
echo ">>>>>>>>running test 1208"
../source/print_tokens.exe  < ../inputs/test266 > ../outputs/t1208
echo ">>>>>>>>running test 1209"
../source/print_tokens.exe  < ../inputs/test267 > ../outputs/t1209
echo ">>>>>>>>running test 1210"
../source/print_tokens.exe  < ../inputs/test268 > ../outputs/t1210
echo ">>>>>>>>running test 1211"
../source/print_tokens.exe  < ../inputs/test269 > ../outputs/t1211
echo ">>>>>>>>running test 1212"
../source/print_tokens.exe  < ../inputs/test27 > ../outputs/t1212
echo ">>>>>>>>running test 1213"
../source/print_tokens.exe  < ../inputs/test270 > ../outputs/t1213
echo ">>>>>>>>running test 1214"
../source/print_tokens.exe  < ../inputs/test271 > ../outputs/t1214
echo ">>>>>>>>running test 1215"
../source/print_tokens.exe  < ../inputs/test272 > ../outputs/t1215
echo ">>>>>>>>running test 1216"
../source/print_tokens.exe  < ../inputs/test273 > ../outputs/t1216
echo ">>>>>>>>running test 1217"
../source/print_tokens.exe  < ../inputs/test274 > ../outputs/t1217
echo ">>>>>>>>running test 1218"
../source/print_tokens.exe  < ../inputs/test275 > ../outputs/t1218
echo ">>>>>>>>running test 1219"
../source/print_tokens.exe  < ../inputs/test276 > ../outputs/t1219
echo ">>>>>>>>running test 1220"
../source/print_tokens.exe  < ../inputs/test277 > ../outputs/t1220
echo ">>>>>>>>running test 1221"
../source/print_tokens.exe  < ../inputs/test278 > ../outputs/t1221
echo ">>>>>>>>running test 1222"
../source/print_tokens.exe  < ../inputs/test279 > ../outputs/t1222
echo ">>>>>>>>running test 1223"
../source/print_tokens.exe  < ../inputs/test28 > ../outputs/t1223
echo ">>>>>>>>running test 1224"
../source/print_tokens.exe  < ../inputs/test280 > ../outputs/t1224
echo ">>>>>>>>running test 1225"
../source/print_tokens.exe  < ../inputs/test281 > ../outputs/t1225
echo ">>>>>>>>running test 1226"
../source/print_tokens.exe  < ../inputs/test282 > ../outputs/t1226
echo ">>>>>>>>running test 1227"
../source/print_tokens.exe  < ../inputs/test283 > ../outputs/t1227
echo ">>>>>>>>running test 1228"
../source/print_tokens.exe  < ../inputs/test284 > ../outputs/t1228
echo ">>>>>>>>running test 1229"
../source/print_tokens.exe  < ../inputs/test285 > ../outputs/t1229
echo ">>>>>>>>running test 1230"
../source/print_tokens.exe  < ../inputs/test286 > ../outputs/t1230
echo ">>>>>>>>running test 1231"
../source/print_tokens.exe  < ../inputs/test287 > ../outputs/t1231
echo ">>>>>>>>running test 1232"
../source/print_tokens.exe  < ../inputs/test288 > ../outputs/t1232
echo ">>>>>>>>running test 1233"
../source/print_tokens.exe  < ../inputs/test289 > ../outputs/t1233
echo ">>>>>>>>running test 1234"
../source/print_tokens.exe  < ../inputs/test29 > ../outputs/t1234
echo ">>>>>>>>running test 1235"
../source/print_tokens.exe  < ../inputs/test290 > ../outputs/t1235
echo ">>>>>>>>running test 1236"
../source/print_tokens.exe  < ../inputs/test291 > ../outputs/t1236
echo ">>>>>>>>running test 1237"
../source/print_tokens.exe  < ../inputs/test292 > ../outputs/t1237
echo ">>>>>>>>running test 1238"
../source/print_tokens.exe  < ../inputs/test293 > ../outputs/t1238
echo ">>>>>>>>running test 1239"
../source/print_tokens.exe  < ../inputs/test294 > ../outputs/t1239
echo ">>>>>>>>running test 1240"
../source/print_tokens.exe  < ../inputs/test295 > ../outputs/t1240
echo ">>>>>>>>running test 1241"
../source/print_tokens.exe  < ../inputs/test296 > ../outputs/t1241
echo ">>>>>>>>running test 1242"
../source/print_tokens.exe  < ../inputs/test297 > ../outputs/t1242
echo ">>>>>>>>running test 1243"
../source/print_tokens.exe  < ../inputs/test298 > ../outputs/t1243
echo ">>>>>>>>running test 1244"
../source/print_tokens.exe  < ../inputs/test299 > ../outputs/t1244
echo ">>>>>>>>running test 1245"
../source/print_tokens.exe  < ../inputs/test3 > ../outputs/t1245
echo ">>>>>>>>running test 1246"
../source/print_tokens.exe  < ../inputs/test30 > ../outputs/t1246
echo ">>>>>>>>running test 1247"
../source/print_tokens.exe  < ../inputs/test300 > ../outputs/t1247
echo ">>>>>>>>running test 1248"
../source/print_tokens.exe  < ../inputs/test301 > ../outputs/t1248
echo ">>>>>>>>running test 1249"
../source/print_tokens.exe  < ../inputs/test302 > ../outputs/t1249
echo ">>>>>>>>running test 1250"
../source/print_tokens.exe  < ../inputs/test303 > ../outputs/t1250
echo ">>>>>>>>running test 1251"
../source/print_tokens.exe  < ../inputs/test304 > ../outputs/t1251
echo ">>>>>>>>running test 1252"
../source/print_tokens.exe  < ../inputs/test305 > ../outputs/t1252
echo ">>>>>>>>running test 1253"
../source/print_tokens.exe  < ../inputs/test306 > ../outputs/t1253
echo ">>>>>>>>running test 1254"
../source/print_tokens.exe  < ../inputs/test307 > ../outputs/t1254
echo ">>>>>>>>running test 1255"
../source/print_tokens.exe  < ../inputs/test308 > ../outputs/t1255
echo ">>>>>>>>running test 1256"
../source/print_tokens.exe  < ../inputs/test309 > ../outputs/t1256
echo ">>>>>>>>running test 1257"
../source/print_tokens.exe  < ../inputs/test31 > ../outputs/t1257
echo ">>>>>>>>running test 1258"
../source/print_tokens.exe  < ../inputs/test310 > ../outputs/t1258
echo ">>>>>>>>running test 1259"
../source/print_tokens.exe  < ../inputs/test311 > ../outputs/t1259
echo ">>>>>>>>running test 1260"
../source/print_tokens.exe  < ../inputs/test312 > ../outputs/t1260
echo ">>>>>>>>running test 1261"
../source/print_tokens.exe  < ../inputs/test313 > ../outputs/t1261
echo ">>>>>>>>running test 1262"
../source/print_tokens.exe  < ../inputs/test314 > ../outputs/t1262
echo ">>>>>>>>running test 1263"
../source/print_tokens.exe  < ../inputs/test315 > ../outputs/t1263
echo ">>>>>>>>running test 1264"
../source/print_tokens.exe  < ../inputs/test316 > ../outputs/t1264
echo ">>>>>>>>running test 1265"
../source/print_tokens.exe  < ../inputs/test317 > ../outputs/t1265
echo ">>>>>>>>running test 1266"
../source/print_tokens.exe  < ../inputs/test318 > ../outputs/t1266
echo ">>>>>>>>running test 1267"
../source/print_tokens.exe  < ../inputs/test319 > ../outputs/t1267
echo ">>>>>>>>running test 1268"
../source/print_tokens.exe  < ../inputs/test32 > ../outputs/t1268
echo ">>>>>>>>running test 1269"
../source/print_tokens.exe  < ../inputs/test320 > ../outputs/t1269
echo ">>>>>>>>running test 1270"
../source/print_tokens.exe  < ../inputs/test321 > ../outputs/t1270
echo ">>>>>>>>running test 1271"
../source/print_tokens.exe  < ../inputs/test322 > ../outputs/t1271
echo ">>>>>>>>running test 1272"
../source/print_tokens.exe  < ../inputs/test323 > ../outputs/t1272
echo ">>>>>>>>running test 1273"
../source/print_tokens.exe  < ../inputs/test324 > ../outputs/t1273
echo ">>>>>>>>running test 1274"
../source/print_tokens.exe  < ../inputs/test325 > ../outputs/t1274
echo ">>>>>>>>running test 1275"
../source/print_tokens.exe  < ../inputs/test326 > ../outputs/t1275
echo ">>>>>>>>running test 1276"
../source/print_tokens.exe  < ../inputs/test327 > ../outputs/t1276
echo ">>>>>>>>running test 1277"
../source/print_tokens.exe  < ../inputs/test328 > ../outputs/t1277
echo ">>>>>>>>running test 1278"
../source/print_tokens.exe  < ../inputs/test329 > ../outputs/t1278
echo ">>>>>>>>running test 1279"
../source/print_tokens.exe  < ../inputs/test33 > ../outputs/t1279
echo ">>>>>>>>running test 1280"
../source/print_tokens.exe  < ../inputs/test330 > ../outputs/t1280
echo ">>>>>>>>running test 1281"
../source/print_tokens.exe  < ../inputs/test331 > ../outputs/t1281
echo ">>>>>>>>running test 1282"
../source/print_tokens.exe  < ../inputs/test332 > ../outputs/t1282
echo ">>>>>>>>running test 1283"
../source/print_tokens.exe  < ../inputs/test333 > ../outputs/t1283
echo ">>>>>>>>running test 1284"
../source/print_tokens.exe  < ../inputs/test334 > ../outputs/t1284
echo ">>>>>>>>running test 1285"
../source/print_tokens.exe  < ../inputs/test335 > ../outputs/t1285
echo ">>>>>>>>running test 1286"
../source/print_tokens.exe  < ../inputs/test336 > ../outputs/t1286
echo ">>>>>>>>running test 1287"
../source/print_tokens.exe  < ../inputs/test337 > ../outputs/t1287
echo ">>>>>>>>running test 1288"
../source/print_tokens.exe  < ../inputs/test338 > ../outputs/t1288
echo ">>>>>>>>running test 1289"
../source/print_tokens.exe  < ../inputs/test339 > ../outputs/t1289
echo ">>>>>>>>running test 1290"
../source/print_tokens.exe  < ../inputs/test34 > ../outputs/t1290
echo ">>>>>>>>running test 1291"
../source/print_tokens.exe  < ../inputs/test340 > ../outputs/t1291
echo ">>>>>>>>running test 1292"
../source/print_tokens.exe  < ../inputs/test341 > ../outputs/t1292
echo ">>>>>>>>running test 1293"
../source/print_tokens.exe  < ../inputs/test342 > ../outputs/t1293
echo ">>>>>>>>running test 1294"
../source/print_tokens.exe  < ../inputs/test343 > ../outputs/t1294
echo ">>>>>>>>running test 1295"
../source/print_tokens.exe  < ../inputs/test344 > ../outputs/t1295
echo ">>>>>>>>running test 1296"
../source/print_tokens.exe  < ../inputs/test345 > ../outputs/t1296
echo ">>>>>>>>running test 1297"
../source/print_tokens.exe  < ../inputs/test346 > ../outputs/t1297
echo ">>>>>>>>running test 1298"
../source/print_tokens.exe  < ../inputs/test347 > ../outputs/t1298
echo ">>>>>>>>running test 1299"
../source/print_tokens.exe  < ../inputs/test348 > ../outputs/t1299
echo ">>>>>>>>running test 1300"
../source/print_tokens.exe  < ../inputs/test349 > ../outputs/t1300
echo ">>>>>>>>running test 1301"
../source/print_tokens.exe  < ../inputs/test35 > ../outputs/t1301
echo ">>>>>>>>running test 1302"
../source/print_tokens.exe  < ../inputs/test350 > ../outputs/t1302
echo ">>>>>>>>running test 1303"
../source/print_tokens.exe  < ../inputs/test351 > ../outputs/t1303
echo ">>>>>>>>running test 1304"
../source/print_tokens.exe  < ../inputs/test352 > ../outputs/t1304
echo ">>>>>>>>running test 1305"
../source/print_tokens.exe  < ../inputs/test353 > ../outputs/t1305
echo ">>>>>>>>running test 1306"
../source/print_tokens.exe  < ../inputs/test354 > ../outputs/t1306
echo ">>>>>>>>running test 1307"
../source/print_tokens.exe  < ../inputs/test355 > ../outputs/t1307
echo ">>>>>>>>running test 1308"
../source/print_tokens.exe  < ../inputs/test356 > ../outputs/t1308
echo ">>>>>>>>running test 1309"
../source/print_tokens.exe  < ../inputs/test357 > ../outputs/t1309
echo ">>>>>>>>running test 1310"
../source/print_tokens.exe  < ../inputs/test358 > ../outputs/t1310
echo ">>>>>>>>running test 1311"
../source/print_tokens.exe  < ../inputs/test359 > ../outputs/t1311
echo ">>>>>>>>running test 1312"
../source/print_tokens.exe  < ../inputs/test36 > ../outputs/t1312
echo ">>>>>>>>running test 1313"
../source/print_tokens.exe  < ../inputs/test360 > ../outputs/t1313
echo ">>>>>>>>running test 1314"
../source/print_tokens.exe  < ../inputs/test361 > ../outputs/t1314
echo ">>>>>>>>running test 1315"
../source/print_tokens.exe  < ../inputs/test362 > ../outputs/t1315
echo ">>>>>>>>running test 1316"
../source/print_tokens.exe  < ../inputs/test363 > ../outputs/t1316
echo ">>>>>>>>running test 1317"
../source/print_tokens.exe  < ../inputs/test364 > ../outputs/t1317
echo ">>>>>>>>running test 1318"
../source/print_tokens.exe  < ../inputs/test365 > ../outputs/t1318
echo ">>>>>>>>running test 1319"
../source/print_tokens.exe  < ../inputs/test366 > ../outputs/t1319
echo ">>>>>>>>running test 1320"
../source/print_tokens.exe  < ../inputs/test367 > ../outputs/t1320
echo ">>>>>>>>running test 1321"
../source/print_tokens.exe  < ../inputs/test368 > ../outputs/t1321
echo ">>>>>>>>running test 1322"
../source/print_tokens.exe  < ../inputs/test369 > ../outputs/t1322
echo ">>>>>>>>running test 1323"
../source/print_tokens.exe  < ../inputs/test37 > ../outputs/t1323
echo ">>>>>>>>running test 1324"
../source/print_tokens.exe  < ../inputs/test370 > ../outputs/t1324
echo ">>>>>>>>running test 1325"
../source/print_tokens.exe  < ../inputs/test371 > ../outputs/t1325
echo ">>>>>>>>running test 1326"
../source/print_tokens.exe  < ../inputs/test372 > ../outputs/t1326
echo ">>>>>>>>running test 1327"
../source/print_tokens.exe  < ../inputs/test373 > ../outputs/t1327
echo ">>>>>>>>running test 1328"
../source/print_tokens.exe  < ../inputs/test374 > ../outputs/t1328
echo ">>>>>>>>running test 1329"
../source/print_tokens.exe  < ../inputs/test375 > ../outputs/t1329
echo ">>>>>>>>running test 1330"
../source/print_tokens.exe  < ../inputs/test376 > ../outputs/t1330
echo ">>>>>>>>running test 1331"
../source/print_tokens.exe  < ../inputs/test377 > ../outputs/t1331
echo ">>>>>>>>running test 1332"
../source/print_tokens.exe  < ../inputs/test378 > ../outputs/t1332
echo ">>>>>>>>running test 1333"
../source/print_tokens.exe  < ../inputs/test379 > ../outputs/t1333
echo ">>>>>>>>running test 1334"
../source/print_tokens.exe  < ../inputs/test38 > ../outputs/t1334
echo ">>>>>>>>running test 1335"
../source/print_tokens.exe  < ../inputs/test380 > ../outputs/t1335
echo ">>>>>>>>running test 1336"
../source/print_tokens.exe  < ../inputs/test381 > ../outputs/t1336
echo ">>>>>>>>running test 1337"
../source/print_tokens.exe  < ../inputs/test382 > ../outputs/t1337
echo ">>>>>>>>running test 1338"
../source/print_tokens.exe  < ../inputs/test383 > ../outputs/t1338
echo ">>>>>>>>running test 1339"
../source/print_tokens.exe  < ../inputs/test384 > ../outputs/t1339
echo ">>>>>>>>running test 1340"
../source/print_tokens.exe  < ../inputs/test385 > ../outputs/t1340
echo ">>>>>>>>running test 1341"
../source/print_tokens.exe  < ../inputs/test386 > ../outputs/t1341
echo ">>>>>>>>running test 1342"
../source/print_tokens.exe  < ../inputs/test387 > ../outputs/t1342
echo ">>>>>>>>running test 1343"
../source/print_tokens.exe  < ../inputs/test388 > ../outputs/t1343
echo ">>>>>>>>running test 1344"
../source/print_tokens.exe  < ../inputs/test389 > ../outputs/t1344
echo ">>>>>>>>running test 1345"
../source/print_tokens.exe  < ../inputs/test39 > ../outputs/t1345
echo ">>>>>>>>running test 1346"
../source/print_tokens.exe  < ../inputs/test390 > ../outputs/t1346
echo ">>>>>>>>running test 1347"
../source/print_tokens.exe  < ../inputs/test391 > ../outputs/t1347
echo ">>>>>>>>running test 1348"
../source/print_tokens.exe  < ../inputs/test392 > ../outputs/t1348
echo ">>>>>>>>running test 1349"
../source/print_tokens.exe  < ../inputs/test393 > ../outputs/t1349
echo ">>>>>>>>running test 1350"
../source/print_tokens.exe  < ../inputs/test394 > ../outputs/t1350
echo ">>>>>>>>running test 1351"
../source/print_tokens.exe  < ../inputs/test395 > ../outputs/t1351
echo ">>>>>>>>running test 1352"
../source/print_tokens.exe  < ../inputs/test396 > ../outputs/t1352
echo ">>>>>>>>running test 1353"
../source/print_tokens.exe  < ../inputs/test397 > ../outputs/t1353
echo ">>>>>>>>running test 1354"
../source/print_tokens.exe  < ../inputs/test398 > ../outputs/t1354
echo ">>>>>>>>running test 1355"
../source/print_tokens.exe  < ../inputs/test399 > ../outputs/t1355
echo ">>>>>>>>running test 1356"
../source/print_tokens.exe  < ../inputs/test4 > ../outputs/t1356
echo ">>>>>>>>running test 1357"
../source/print_tokens.exe  < ../inputs/test40 > ../outputs/t1357
echo ">>>>>>>>running test 1358"
../source/print_tokens.exe  < ../inputs/test400 > ../outputs/t1358
echo ">>>>>>>>running test 1359"
../source/print_tokens.exe  < ../inputs/test41 > ../outputs/t1359
echo ">>>>>>>>running test 1360"
../source/print_tokens.exe  < ../inputs/test42 > ../outputs/t1360
echo ">>>>>>>>running test 1361"
../source/print_tokens.exe  < ../inputs/test43 > ../outputs/t1361
echo ">>>>>>>>running test 1362"
../source/print_tokens.exe  < ../inputs/test44 > ../outputs/t1362
echo ">>>>>>>>running test 1363"
../source/print_tokens.exe  < ../inputs/test45 > ../outputs/t1363
echo ">>>>>>>>running test 1364"
../source/print_tokens.exe  < ../inputs/test46 > ../outputs/t1364
echo ">>>>>>>>running test 1365"
../source/print_tokens.exe  < ../inputs/test47 > ../outputs/t1365
echo ">>>>>>>>running test 1366"
../source/print_tokens.exe  < ../inputs/test48 > ../outputs/t1366
echo ">>>>>>>>running test 1367"
../source/print_tokens.exe  < ../inputs/test49 > ../outputs/t1367
echo ">>>>>>>>running test 1368"
../source/print_tokens.exe  < ../inputs/test5 > ../outputs/t1368
echo ">>>>>>>>running test 1369"
../source/print_tokens.exe  < ../inputs/test50 > ../outputs/t1369
echo ">>>>>>>>running test 1370"
../source/print_tokens.exe  < ../inputs/test51 > ../outputs/t1370
echo ">>>>>>>>running test 1371"
../source/print_tokens.exe  < ../inputs/test52 > ../outputs/t1371
echo ">>>>>>>>running test 1372"
../source/print_tokens.exe  < ../inputs/test53 > ../outputs/t1372
echo ">>>>>>>>running test 1373"
../source/print_tokens.exe  < ../inputs/test54 > ../outputs/t1373
echo ">>>>>>>>running test 1374"
../source/print_tokens.exe  < ../inputs/test55 > ../outputs/t1374
echo ">>>>>>>>running test 1375"
../source/print_tokens.exe  < ../inputs/test56 > ../outputs/t1375
echo ">>>>>>>>running test 1376"
../source/print_tokens.exe  < ../inputs/test57 > ../outputs/t1376
echo ">>>>>>>>running test 1377"
../source/print_tokens.exe  < ../inputs/test58 > ../outputs/t1377
echo ">>>>>>>>running test 1378"
../source/print_tokens.exe  < ../inputs/test59 > ../outputs/t1378
echo ">>>>>>>>running test 1379"
../source/print_tokens.exe  < ../inputs/test6 > ../outputs/t1379
echo ">>>>>>>>running test 1380"
../source/print_tokens.exe  < ../inputs/test60 > ../outputs/t1380
echo ">>>>>>>>running test 1381"
../source/print_tokens.exe  < ../inputs/test61 > ../outputs/t1381
echo ">>>>>>>>running test 1382"
../source/print_tokens.exe  < ../inputs/test62 > ../outputs/t1382
echo ">>>>>>>>running test 1383"
../source/print_tokens.exe  < ../inputs/test63 > ../outputs/t1383
echo ">>>>>>>>running test 1384"
../source/print_tokens.exe  < ../inputs/test64 > ../outputs/t1384
echo ">>>>>>>>running test 1385"
../source/print_tokens.exe  < ../inputs/test65 > ../outputs/t1385
echo ">>>>>>>>running test 1386"
../source/print_tokens.exe  < ../inputs/test66 > ../outputs/t1386
echo ">>>>>>>>running test 1387"
../source/print_tokens.exe  < ../inputs/test67 > ../outputs/t1387
echo ">>>>>>>>running test 1388"
../source/print_tokens.exe  < ../inputs/test68 > ../outputs/t1388
echo ">>>>>>>>running test 1389"
../source/print_tokens.exe  < ../inputs/test69 > ../outputs/t1389
echo ">>>>>>>>running test 1390"
../source/print_tokens.exe  < ../inputs/test7 > ../outputs/t1390
echo ">>>>>>>>running test 1391"
../source/print_tokens.exe  < ../inputs/test70 > ../outputs/t1391
echo ">>>>>>>>running test 1392"
../source/print_tokens.exe  < ../inputs/test71 > ../outputs/t1392
echo ">>>>>>>>running test 1393"
../source/print_tokens.exe  < ../inputs/test72 > ../outputs/t1393
echo ">>>>>>>>running test 1394"
../source/print_tokens.exe  < ../inputs/test73 > ../outputs/t1394
echo ">>>>>>>>running test 1395"
../source/print_tokens.exe  < ../inputs/test74 > ../outputs/t1395
echo ">>>>>>>>running test 1396"
../source/print_tokens.exe  < ../inputs/test75 > ../outputs/t1396
echo ">>>>>>>>running test 1397"
../source/print_tokens.exe  < ../inputs/test76 > ../outputs/t1397
echo ">>>>>>>>running test 1398"
../source/print_tokens.exe  < ../inputs/test77 > ../outputs/t1398
echo ">>>>>>>>running test 1399"
../source/print_tokens.exe  < ../inputs/test78 > ../outputs/t1399
echo ">>>>>>>>running test 1400"
../source/print_tokens.exe  < ../inputs/test79 > ../outputs/t1400
echo ">>>>>>>>running test 1401"
../source/print_tokens.exe  < ../inputs/test8 > ../outputs/t1401
echo ">>>>>>>>running test 1402"
../source/print_tokens.exe  < ../inputs/test80 > ../outputs/t1402
echo ">>>>>>>>running test 1403"
../source/print_tokens.exe  < ../inputs/test81 > ../outputs/t1403
echo ">>>>>>>>running test 1404"
../source/print_tokens.exe  < ../inputs/test82 > ../outputs/t1404
echo ">>>>>>>>running test 1405"
../source/print_tokens.exe  < ../inputs/test83 > ../outputs/t1405
echo ">>>>>>>>running test 1406"
../source/print_tokens.exe  < ../inputs/test84 > ../outputs/t1406
echo ">>>>>>>>running test 1407"
../source/print_tokens.exe  < ../inputs/test85 > ../outputs/t1407
echo ">>>>>>>>running test 1408"
../source/print_tokens.exe  < ../inputs/test86 > ../outputs/t1408
echo ">>>>>>>>running test 1409"
../source/print_tokens.exe  < ../inputs/test87 > ../outputs/t1409
echo ">>>>>>>>running test 1410"
../source/print_tokens.exe  < ../inputs/test88 > ../outputs/t1410
echo ">>>>>>>>running test 1411"
../source/print_tokens.exe  < ../inputs/test89 > ../outputs/t1411
echo ">>>>>>>>running test 1412"
../source/print_tokens.exe  < ../inputs/test9 > ../outputs/t1412
echo ">>>>>>>>running test 1413"
../source/print_tokens.exe  < ../inputs/test90 > ../outputs/t1413
echo ">>>>>>>>running test 1414"
../source/print_tokens.exe  < ../inputs/test91 > ../outputs/t1414
echo ">>>>>>>>running test 1415"
../source/print_tokens.exe  < ../inputs/test92 > ../outputs/t1415
echo ">>>>>>>>running test 1416"
../source/print_tokens.exe  < ../inputs/test93 > ../outputs/t1416
echo ">>>>>>>>running test 1417"
../source/print_tokens.exe  < ../inputs/test94 > ../outputs/t1417
echo ">>>>>>>>running test 1418"
../source/print_tokens.exe  < ../inputs/test95 > ../outputs/t1418
echo ">>>>>>>>running test 1419"
../source/print_tokens.exe  < ../inputs/test96 > ../outputs/t1419
echo ">>>>>>>>running test 1420"
../source/print_tokens.exe  < ../inputs/test97 > ../outputs/t1420
echo ">>>>>>>>running test 1421"
../source/print_tokens.exe  < ../inputs/test98 > ../outputs/t1421
echo ">>>>>>>>running test 1422"
../source/print_tokens.exe  < ../inputs/test99 > ../outputs/t1422
echo ">>>>>>>>running test 1423"
../source/print_tokens.exe  < ../inputs/ts500 > ../outputs/t1423
echo ">>>>>>>>running test 1424"
../source/print_tokens.exe  < ../inputs/ts501 > ../outputs/t1424
echo ">>>>>>>>running test 1425"
../source/print_tokens.exe  < ../inputs/ts502 > ../outputs/t1425
echo ">>>>>>>>running test 1426"
../source/print_tokens.exe  < ../inputs/ts503 > ../outputs/t1426
echo ">>>>>>>>running test 1427"
../source/print_tokens.exe  < ../inputs/ts504 > ../outputs/t1427
echo ">>>>>>>>running test 1428"
../source/print_tokens.exe  < ../inputs/ts505 > ../outputs/t1428
echo ">>>>>>>>running test 1429"
../source/print_tokens.exe  < ../inputs/ts506 > ../outputs/t1429
echo ">>>>>>>>running test 1430"
../source/print_tokens.exe  < ../inputs/ts507 > ../outputs/t1430
echo ">>>>>>>>running test 1431"
../source/print_tokens.exe  < ../inputs/ts508 > ../outputs/t1431
echo ">>>>>>>>running test 1432"
../source/print_tokens.exe  < ../inputs/ts509 > ../outputs/t1432
echo ">>>>>>>>running test 1433"
../source/print_tokens.exe  < ../inputs/ts510 > ../outputs/t1433
echo ">>>>>>>>running test 1434"
../source/print_tokens.exe  < ../inputs/ts511 > ../outputs/t1434
echo ">>>>>>>>running test 1435"
../source/print_tokens.exe  < ../inputs/ts512 > ../outputs/t1435
echo ">>>>>>>>running test 1436"
../source/print_tokens.exe  < ../inputs/ts513 > ../outputs/t1436
echo ">>>>>>>>running test 1437"
../source/print_tokens.exe  < ../inputs/ts514 > ../outputs/t1437
echo ">>>>>>>>running test 1438"
../source/print_tokens.exe  < ../inputs/ts515 > ../outputs/t1438
echo ">>>>>>>>running test 1439"
../source/print_tokens.exe  < ../inputs/ts516 > ../outputs/t1439
echo ">>>>>>>>running test 1440"
../source/print_tokens.exe  < ../inputs/ts517 > ../outputs/t1440
echo ">>>>>>>>running test 1441"
../source/print_tokens.exe  < ../inputs/ts518 > ../outputs/t1441
echo ">>>>>>>>running test 1442"
../source/print_tokens.exe  < ../inputs/ts519 > ../outputs/t1442
echo ">>>>>>>>running test 1443"
../source/print_tokens.exe  < ../inputs/ts520 > ../outputs/t1443
echo ">>>>>>>>running test 1444"
../source/print_tokens.exe  < ../inputs/ts521 > ../outputs/t1444
echo ">>>>>>>>running test 1445"
../source/print_tokens.exe  < ../inputs/ts522 > ../outputs/t1445
echo ">>>>>>>>running test 1446"
../source/print_tokens.exe  < ../inputs/ts523 > ../outputs/t1446
echo ">>>>>>>>running test 1447"
../source/print_tokens.exe  < ../inputs/ts524 > ../outputs/t1447
echo ">>>>>>>>running test 1448"
../source/print_tokens.exe  < ../inputs/ts525 > ../outputs/t1448
echo ">>>>>>>>running test 1449"
../source/print_tokens.exe  < ../inputs/ts526 > ../outputs/t1449
echo ">>>>>>>>running test 1450"
../source/print_tokens.exe  < ../inputs/ts527 > ../outputs/t1450
echo ">>>>>>>>running test 1451"
../source/print_tokens.exe  < ../inputs/ts528 > ../outputs/t1451
echo ">>>>>>>>running test 1452"
../source/print_tokens.exe  < ../inputs/ts529 > ../outputs/t1452
echo ">>>>>>>>running test 1453"
../source/print_tokens.exe  < ../inputs/ts530 > ../outputs/t1453
echo ">>>>>>>>running test 1454"
../source/print_tokens.exe  < ../inputs/ts531 > ../outputs/t1454
echo ">>>>>>>>running test 1455"
../source/print_tokens.exe  < ../inputs/ts532 > ../outputs/t1455
echo ">>>>>>>>running test 1456"
../source/print_tokens.exe  < ../inputs/ts533 > ../outputs/t1456
echo ">>>>>>>>running test 1457"
../source/print_tokens.exe  < ../inputs/ts534 > ../outputs/t1457
echo ">>>>>>>>running test 1458"
../source/print_tokens.exe  < ../inputs/ts535 > ../outputs/t1458
echo ">>>>>>>>running test 1459"
../source/print_tokens.exe  < ../inputs/ts536 > ../outputs/t1459
echo ">>>>>>>>running test 1460"
../source/print_tokens.exe  < ../inputs/ts537 > ../outputs/t1460
echo ">>>>>>>>running test 1461"
../source/print_tokens.exe  < ../inputs/ts538 > ../outputs/t1461
echo ">>>>>>>>running test 1462"
../source/print_tokens.exe  < ../inputs/ts539 > ../outputs/t1462
echo ">>>>>>>>running test 1463"
../source/print_tokens.exe  < ../inputs/ts540 > ../outputs/t1463
echo ">>>>>>>>running test 1464"
../source/print_tokens.exe  < ../inputs/ts541 > ../outputs/t1464
echo ">>>>>>>>running test 1465"
../source/print_tokens.exe  < ../inputs/ts542 > ../outputs/t1465
echo ">>>>>>>>running test 1466"
../source/print_tokens.exe  < ../inputs/ts543 > ../outputs/t1466
echo ">>>>>>>>running test 1467"
../source/print_tokens.exe  < ../inputs/ts544 > ../outputs/t1467
echo ">>>>>>>>running test 1468"
../source/print_tokens.exe  < ../inputs/ts545 > ../outputs/t1468
echo ">>>>>>>>running test 1469"
../source/print_tokens.exe  < ../inputs/ts546 > ../outputs/t1469
echo ">>>>>>>>running test 1470"
../source/print_tokens.exe  < ../inputs/ts547 > ../outputs/t1470
echo ">>>>>>>>running test 1471"
../source/print_tokens.exe  < ../inputs/ts548 > ../outputs/t1471
echo ">>>>>>>>running test 1472"
../source/print_tokens.exe  < ../inputs/ts549 > ../outputs/t1472
echo ">>>>>>>>running test 1473"
../source/print_tokens.exe  < ../inputs/ts550 > ../outputs/t1473
echo ">>>>>>>>running test 1474"
../source/print_tokens.exe  < ../inputs/ts551 > ../outputs/t1474
echo ">>>>>>>>running test 1475"
../source/print_tokens.exe  < ../inputs/ts552 > ../outputs/t1475
echo ">>>>>>>>running test 1476"
../source/print_tokens.exe  < ../inputs/ts553 > ../outputs/t1476
echo ">>>>>>>>running test 1477"
../source/print_tokens.exe  < ../inputs/ts554 > ../outputs/t1477
echo ">>>>>>>>running test 1478"
../source/print_tokens.exe  < ../inputs/ts555 > ../outputs/t1478
echo ">>>>>>>>running test 1479"
../source/print_tokens.exe  < ../inputs/ts556 > ../outputs/t1479
echo ">>>>>>>>running test 1480"
../source/print_tokens.exe  < ../inputs/ts557 > ../outputs/t1480
echo ">>>>>>>>running test 1481"
../source/print_tokens.exe  < ../inputs/ts558 > ../outputs/t1481
echo ">>>>>>>>running test 1482"
../source/print_tokens.exe  < ../inputs/ts559 > ../outputs/t1482
echo ">>>>>>>>running test 1483"
../source/print_tokens.exe  < ../inputs/ts560 > ../outputs/t1483
echo ">>>>>>>>running test 1484"
../source/print_tokens.exe  < ../inputs/ts561 > ../outputs/t1484
echo ">>>>>>>>running test 1485"
../source/print_tokens.exe  < ../inputs/ts562 > ../outputs/t1485
echo ">>>>>>>>running test 1486"
../source/print_tokens.exe  < ../inputs/ts563 > ../outputs/t1486
echo ">>>>>>>>running test 1487"
../source/print_tokens.exe  < ../inputs/ts564 > ../outputs/t1487
echo ">>>>>>>>running test 1488"
../source/print_tokens.exe  < ../inputs/ts565 > ../outputs/t1488
echo ">>>>>>>>running test 1489"
../source/print_tokens.exe  < ../inputs/ts566 > ../outputs/t1489
echo ">>>>>>>>running test 1490"
../source/print_tokens.exe  < ../inputs/ts567 > ../outputs/t1490
echo ">>>>>>>>running test 1491"
../source/print_tokens.exe  < ../inputs/ts568 > ../outputs/t1491
echo ">>>>>>>>running test 1492"
../source/print_tokens.exe  < ../inputs/ts569 > ../outputs/t1492
echo ">>>>>>>>running test 1493"
../source/print_tokens.exe  < ../inputs/ts570 > ../outputs/t1493
echo ">>>>>>>>running test 1494"
../source/print_tokens.exe  < ../inputs/ts571 > ../outputs/t1494
echo ">>>>>>>>running test 1495"
../source/print_tokens.exe  < ../inputs/ts572 > ../outputs/t1495
echo ">>>>>>>>running test 1496"
../source/print_tokens.exe  < ../inputs/ts573 > ../outputs/t1496
echo ">>>>>>>>running test 1497"
../source/print_tokens.exe  < ../inputs/ts574 > ../outputs/t1497
echo ">>>>>>>>running test 1498"
../source/print_tokens.exe  < ../inputs/ts575 > ../outputs/t1498
echo ">>>>>>>>running test 1499"
../source/print_tokens.exe  < ../inputs/ts576 > ../outputs/t1499
echo ">>>>>>>>running test 1500"
../source/print_tokens.exe  < ../inputs/ts577 > ../outputs/t1500
echo ">>>>>>>>running test 1501"
../source/print_tokens.exe  < ../inputs/ts578 > ../outputs/t1501
echo ">>>>>>>>running test 1502"
../source/print_tokens.exe  < ../inputs/ts579 > ../outputs/t1502
echo ">>>>>>>>running test 1503"
../source/print_tokens.exe  < ../inputs/ts580 > ../outputs/t1503
echo ">>>>>>>>running test 1504"
../source/print_tokens.exe  < ../inputs/ts581 > ../outputs/t1504
echo ">>>>>>>>running test 1505"
../source/print_tokens.exe  < ../inputs/ts582 > ../outputs/t1505
echo ">>>>>>>>running test 1506"
../source/print_tokens.exe  < ../inputs/ts583 > ../outputs/t1506
echo ">>>>>>>>running test 1507"
../source/print_tokens.exe  < ../inputs/ts584 > ../outputs/t1507
echo ">>>>>>>>running test 1508"
../source/print_tokens.exe  < ../inputs/ts585 > ../outputs/t1508
echo ">>>>>>>>running test 1509"
../source/print_tokens.exe  < ../inputs/ts586 > ../outputs/t1509
echo ">>>>>>>>running test 1510"
../source/print_tokens.exe  < ../inputs/ts587 > ../outputs/t1510
echo ">>>>>>>>running test 1511"
../source/print_tokens.exe  < ../inputs/ts588 > ../outputs/t1511
echo ">>>>>>>>running test 1512"
../source/print_tokens.exe  < ../inputs/ts589 > ../outputs/t1512
echo ">>>>>>>>running test 1513"
../source/print_tokens.exe  < ../inputs/ts590 > ../outputs/t1513
echo ">>>>>>>>running test 1514"
../source/print_tokens.exe  < ../inputs/ts591 > ../outputs/t1514
echo ">>>>>>>>running test 1515"
../source/print_tokens.exe  < ../inputs/ts592 > ../outputs/t1515
echo ">>>>>>>>running test 1516"
../source/print_tokens.exe  < ../inputs/ts593 > ../outputs/t1516
echo ">>>>>>>>running test 1517"
../source/print_tokens.exe  < ../inputs/ts594 > ../outputs/t1517
echo ">>>>>>>>running test 1518"
../source/print_tokens.exe  < ../inputs/ts595 > ../outputs/t1518
echo ">>>>>>>>running test 1519"
../source/print_tokens.exe  < ../inputs/ts596 > ../outputs/t1519
echo ">>>>>>>>running test 1520"
../source/print_tokens.exe  < ../inputs/ts597 > ../outputs/t1520
echo ">>>>>>>>running test 1521"
../source/print_tokens.exe  < ../inputs/ts598 > ../outputs/t1521
echo ">>>>>>>>running test 1522"
../source/print_tokens.exe  < ../inputs/ts599 > ../outputs/t1522
echo ">>>>>>>>running test 1523"
../source/print_tokens.exe  < ../inputs/ts600 > ../outputs/t1523
echo ">>>>>>>>running test 1524"
../source/print_tokens.exe  < ../inputs/ts601 > ../outputs/t1524
echo ">>>>>>>>running test 1525"
../source/print_tokens.exe  < ../inputs/ts603 > ../outputs/t1525
echo ">>>>>>>>running test 1526"
../source/print_tokens.exe  < ../inputs/ts604 > ../outputs/t1526
echo ">>>>>>>>running test 1527"
../source/print_tokens.exe  < ../inputs/ts605 > ../outputs/t1527
echo ">>>>>>>>running test 1528"
../source/print_tokens.exe  < ../inputs/ts606 > ../outputs/t1528
echo ">>>>>>>>running test 1529"
../source/print_tokens.exe  < ../inputs/ts607 > ../outputs/t1529
echo ">>>>>>>>running test 1530"
../source/print_tokens.exe  < ../inputs/ts608 > ../outputs/t1530
echo ">>>>>>>>running test 1531"
../source/print_tokens.exe  < ../inputs/ts609 > ../outputs/t1531
echo ">>>>>>>>running test 1532"
../source/print_tokens.exe  < ../inputs/ts610 > ../outputs/t1532
echo ">>>>>>>>running test 1533"
../source/print_tokens.exe  < ../inputs/ts611 > ../outputs/t1533
echo ">>>>>>>>running test 1534"
../source/print_tokens.exe  < ../inputs/ts612 > ../outputs/t1534
echo ">>>>>>>>running test 1535"
../source/print_tokens.exe  < ../inputs/ts613 > ../outputs/t1535
echo ">>>>>>>>running test 1536"
../source/print_tokens.exe  < ../inputs/ts614 > ../outputs/t1536
echo ">>>>>>>>running test 1537"
../source/print_tokens.exe  < ../inputs/ts615 > ../outputs/t1537
echo ">>>>>>>>running test 1538"
../source/print_tokens.exe  < ../inputs/ts616 > ../outputs/t1538
echo ">>>>>>>>running test 1539"
../source/print_tokens.exe  < ../inputs/ts617 > ../outputs/t1539
echo ">>>>>>>>running test 1540"
../source/print_tokens.exe  < ../inputs/ts618 > ../outputs/t1540
echo ">>>>>>>>running test 1541"
../source/print_tokens.exe  < ../inputs/ts619 > ../outputs/t1541
echo ">>>>>>>>running test 1542"
../source/print_tokens.exe  < ../inputs/ts620 > ../outputs/t1542
echo ">>>>>>>>running test 1543"
../source/print_tokens.exe  < ../inputs/ts621 > ../outputs/t1543
echo ">>>>>>>>running test 1544"
../source/print_tokens.exe  < ../inputs/ts622 > ../outputs/t1544
echo ">>>>>>>>running test 1545"
../source/print_tokens.exe  < ../inputs/ts623 > ../outputs/t1545
echo ">>>>>>>>running test 1546"
../source/print_tokens.exe  < ../inputs/ts624 > ../outputs/t1546
echo ">>>>>>>>running test 1547"
../source/print_tokens.exe  < ../inputs/ts625 > ../outputs/t1547
echo ">>>>>>>>running test 1548"
../source/print_tokens.exe  < ../inputs/ts626 > ../outputs/t1548
echo ">>>>>>>>running test 1549"
../source/print_tokens.exe  < ../inputs/ts627 > ../outputs/t1549
echo ">>>>>>>>running test 1550"
../source/print_tokens.exe  < ../inputs/ts628 > ../outputs/t1550
echo ">>>>>>>>running test 1551"
../source/print_tokens.exe  < ../inputs/ts629 > ../outputs/t1551
echo ">>>>>>>>running test 1552"
../source/print_tokens.exe  < ../inputs/ts630 > ../outputs/t1552
echo ">>>>>>>>running test 1553"
../source/print_tokens.exe  < ../inputs/ts631 > ../outputs/t1553
echo ">>>>>>>>running test 1554"
../source/print_tokens.exe  < ../inputs/ts632 > ../outputs/t1554
echo ">>>>>>>>running test 1555"
../source/print_tokens.exe  < ../inputs/ts633 > ../outputs/t1555
echo ">>>>>>>>running test 1556"
../source/print_tokens.exe  < ../inputs/ts634 > ../outputs/t1556
echo ">>>>>>>>running test 1557"
../source/print_tokens.exe  < ../inputs/ts635 > ../outputs/t1557
echo ">>>>>>>>running test 1558"
../source/print_tokens.exe  < ../inputs/ts636 > ../outputs/t1558
echo ">>>>>>>>running test 1559"
../source/print_tokens.exe  < ../inputs/ts637 > ../outputs/t1559
echo ">>>>>>>>running test 1560"
../source/print_tokens.exe  < ../inputs/ts638 > ../outputs/t1560
echo ">>>>>>>>running test 1561"
../source/print_tokens.exe  < ../inputs/ts639 > ../outputs/t1561
echo ">>>>>>>>running test 1562"
../source/print_tokens.exe  < ../inputs/ts640 > ../outputs/t1562
echo ">>>>>>>>running test 1563"
../source/print_tokens.exe  < ../inputs/ts641 > ../outputs/t1563
echo ">>>>>>>>running test 1564"
../source/print_tokens.exe  < ../inputs/ts642 > ../outputs/t1564
echo ">>>>>>>>running test 1565"
../source/print_tokens.exe  < ../inputs/ts643 > ../outputs/t1565
echo ">>>>>>>>running test 1566"
../source/print_tokens.exe  < ../inputs/ts644 > ../outputs/t1566
echo ">>>>>>>>running test 1567"
../source/print_tokens.exe  < ../inputs/ts645 > ../outputs/t1567
echo ">>>>>>>>running test 1568"
../source/print_tokens.exe  < ../inputs/ts646 > ../outputs/t1568
echo ">>>>>>>>running test 1569"
../source/print_tokens.exe  < ../inputs/ts647 > ../outputs/t1569
echo ">>>>>>>>running test 1570"
../source/print_tokens.exe  < ../inputs/ts648 > ../outputs/t1570
echo ">>>>>>>>running test 1571"
../source/print_tokens.exe  < ../inputs/ts649 > ../outputs/t1571
echo ">>>>>>>>running test 1572"
../source/print_tokens.exe  < ../inputs/ts650 > ../outputs/t1572
echo ">>>>>>>>running test 1573"
../source/print_tokens.exe  < ../inputs/ts651 > ../outputs/t1573
echo ">>>>>>>>running test 1574"
../source/print_tokens.exe  < ../inputs/ts652 > ../outputs/t1574
echo ">>>>>>>>running test 1575"
../source/print_tokens.exe  < ../inputs/ts653 > ../outputs/t1575
echo ">>>>>>>>running test 1576"
../source/print_tokens.exe  < ../inputs/ts654 > ../outputs/t1576
echo ">>>>>>>>running test 1577"
../source/print_tokens.exe  < ../inputs/ts655 > ../outputs/t1577
echo ">>>>>>>>running test 1578"
../source/print_tokens.exe  < ../inputs/ts656 > ../outputs/t1578
echo ">>>>>>>>running test 1579"
../source/print_tokens.exe  < ../inputs/ts657 > ../outputs/t1579
echo ">>>>>>>>running test 1580"
../source/print_tokens.exe  < ../inputs/ts658 > ../outputs/t1580
echo ">>>>>>>>running test 1581"
../source/print_tokens.exe  < ../inputs/ts659 > ../outputs/t1581
echo ">>>>>>>>running test 1582"
../source/print_tokens.exe  < ../inputs/ts660 > ../outputs/t1582
echo ">>>>>>>>running test 1583"
../source/print_tokens.exe  < ../inputs/ts661 > ../outputs/t1583
echo ">>>>>>>>running test 1584"
../source/print_tokens.exe  < ../inputs/ts662 > ../outputs/t1584
echo ">>>>>>>>running test 1585"
../source/print_tokens.exe  < ../inputs/ts663 > ../outputs/t1585
echo ">>>>>>>>running test 1586"
../source/print_tokens.exe  < ../inputs/ts664 > ../outputs/t1586
echo ">>>>>>>>running test 1587"
../source/print_tokens.exe  < ../inputs/ts665 > ../outputs/t1587
echo ">>>>>>>>running test 1588"
../source/print_tokens.exe  < ../inputs/ts666 > ../outputs/t1588
echo ">>>>>>>>running test 1589"
../source/print_tokens.exe  < ../inputs/ts667 > ../outputs/t1589
echo ">>>>>>>>running test 1590"
../source/print_tokens.exe  < ../inputs/ts668 > ../outputs/t1590
echo ">>>>>>>>running test 1591"
../source/print_tokens.exe  < ../inputs/ts669 > ../outputs/t1591
echo ">>>>>>>>running test 1592"
../source/print_tokens.exe  < ../inputs/ts670 > ../outputs/t1592
echo ">>>>>>>>running test 1593"
../source/print_tokens.exe  < ../inputs/ts671 > ../outputs/t1593
echo ">>>>>>>>running test 1594"
../source/print_tokens.exe  < ../inputs/ts672 > ../outputs/t1594
echo ">>>>>>>>running test 1595"
../source/print_tokens.exe  < ../inputs/ts673 > ../outputs/t1595
echo ">>>>>>>>running test 1596"
../source/print_tokens.exe  < ../inputs/ts674 > ../outputs/t1596
echo ">>>>>>>>running test 1597"
../source/print_tokens.exe  < ../inputs/ts675 > ../outputs/t1597
echo ">>>>>>>>running test 1598"
../source/print_tokens.exe  < ../inputs/ts676 > ../outputs/t1598
echo ">>>>>>>>running test 1599"
../source/print_tokens.exe  < ../inputs/ts677 > ../outputs/t1599
echo ">>>>>>>>running test 1600"
../source/print_tokens.exe  < ../inputs/ts678 > ../outputs/t1600
echo ">>>>>>>>running test 1601"
../source/print_tokens.exe  < ../inputs/ts679 > ../outputs/t1601
echo ">>>>>>>>running test 1602"
../source/print_tokens.exe  < ../inputs/ts680 > ../outputs/t1602
echo ">>>>>>>>running test 1603"
../source/print_tokens.exe  < ../inputs/ts681 > ../outputs/t1603
echo ">>>>>>>>running test 1604"
../source/print_tokens.exe  < ../inputs/ts682 > ../outputs/t1604
echo ">>>>>>>>running test 1605"
../source/print_tokens.exe  < ../inputs/ts683 > ../outputs/t1605
echo ">>>>>>>>running test 1606"
../source/print_tokens.exe  < ../inputs/ts684 > ../outputs/t1606
echo ">>>>>>>>running test 1607"
../source/print_tokens.exe  < ../inputs/ts685 > ../outputs/t1607
echo ">>>>>>>>running test 1608"
../source/print_tokens.exe  < ../inputs/ts686 > ../outputs/t1608
echo ">>>>>>>>running test 1609"
../source/print_tokens.exe  < ../inputs/ts687 > ../outputs/t1609
echo ">>>>>>>>running test 1610"
../source/print_tokens.exe  < ../inputs/ts688 > ../outputs/t1610
echo ">>>>>>>>running test 1611"
../source/print_tokens.exe  < ../inputs/ts689 > ../outputs/t1611
echo ">>>>>>>>running test 1612"
../source/print_tokens.exe  < ../inputs/ts690 > ../outputs/t1612
echo ">>>>>>>>running test 1613"
../source/print_tokens.exe  < ../inputs/ts691 > ../outputs/t1613
echo ">>>>>>>>running test 1614"
../source/print_tokens.exe  < ../inputs/ts692 > ../outputs/t1614
echo ">>>>>>>>running test 1615"
../source/print_tokens.exe  < ../inputs/ts693 > ../outputs/t1615
echo ">>>>>>>>running test 1616"
../source/print_tokens.exe  < ../inputs/ts694 > ../outputs/t1616
echo ">>>>>>>>running test 1617"
../source/print_tokens.exe  < ../inputs/ts695 > ../outputs/t1617
echo ">>>>>>>>running test 1618"
../source/print_tokens.exe  < ../inputs/ts696 > ../outputs/t1618
echo ">>>>>>>>running test 1619"
../source/print_tokens.exe  < ../inputs/ts697 > ../outputs/t1619
echo ">>>>>>>>running test 1620"
../source/print_tokens.exe  < ../inputs/ts698 > ../outputs/t1620
echo ">>>>>>>>running test 1621"
../source/print_tokens.exe  < ../inputs/ts699 > ../outputs/t1621
echo ">>>>>>>>running test 1622"
../source/print_tokens.exe  < ../inputs/ts701 > ../outputs/t1622
echo ">>>>>>>>running test 1623"
../source/print_tokens.exe  < ../inputs/ts702 > ../outputs/t1623
echo ">>>>>>>>running test 1624"
../source/print_tokens.exe  < ../inputs/ts703 > ../outputs/t1624
echo ">>>>>>>>running test 1625"
../source/print_tokens.exe  < ../inputs/ts704 > ../outputs/t1625
echo ">>>>>>>>running test 1626"
../source/print_tokens.exe  < ../inputs/ts705 > ../outputs/t1626
echo ">>>>>>>>running test 1627"
../source/print_tokens.exe  < ../inputs/ts706 > ../outputs/t1627
echo ">>>>>>>>running test 1628"
../source/print_tokens.exe  < ../inputs/ts707 > ../outputs/t1628
echo ">>>>>>>>running test 1629"
../source/print_tokens.exe  < ../inputs/ts708 > ../outputs/t1629
echo ">>>>>>>>running test 1630"
../source/print_tokens.exe  < ../inputs/ts709 > ../outputs/t1630
echo ">>>>>>>>running test 1631"
../source/print_tokens.exe  < ../inputs/ts710 > ../outputs/t1631
echo ">>>>>>>>running test 1632"
../source/print_tokens.exe  < ../inputs/ts711 > ../outputs/t1632
echo ">>>>>>>>running test 1633"
../source/print_tokens.exe  < ../inputs/ts712 > ../outputs/t1633
echo ">>>>>>>>running test 1634"
../source/print_tokens.exe  < ../inputs/ts713 > ../outputs/t1634
echo ">>>>>>>>running test 1635"
../source/print_tokens.exe  < ../inputs/ts714 > ../outputs/t1635
echo ">>>>>>>>running test 1636"
../source/print_tokens.exe  < ../inputs/ts715 > ../outputs/t1636
echo ">>>>>>>>running test 1637"
../source/print_tokens.exe  < ../inputs/ts716 > ../outputs/t1637
echo ">>>>>>>>running test 1638"
../source/print_tokens.exe  < ../inputs/ts717 > ../outputs/t1638
echo ">>>>>>>>running test 1639"
../source/print_tokens.exe  < ../inputs/ts718 > ../outputs/t1639
echo ">>>>>>>>running test 1640"
../source/print_tokens.exe  < ../inputs/ts719 > ../outputs/t1640
echo ">>>>>>>>running test 1641"
../source/print_tokens.exe  < ../inputs/ts720 > ../outputs/t1641
echo ">>>>>>>>running test 1642"
../source/print_tokens.exe  < ../inputs/ts721 > ../outputs/t1642
echo ">>>>>>>>running test 1643"
../source/print_tokens.exe  < ../inputs/ts722 > ../outputs/t1643
echo ">>>>>>>>running test 1644"
../source/print_tokens.exe  < ../inputs/ts723 > ../outputs/t1644
echo ">>>>>>>>running test 1645"
../source/print_tokens.exe  < ../inputs/ts724 > ../outputs/t1645
echo ">>>>>>>>running test 1646"
../source/print_tokens.exe  < ../inputs/ts725 > ../outputs/t1646
echo ">>>>>>>>running test 1647"
../source/print_tokens.exe  < ../inputs/ts726 > ../outputs/t1647
echo ">>>>>>>>running test 1648"
../source/print_tokens.exe  < ../inputs/ts727 > ../outputs/t1648
echo ">>>>>>>>running test 1649"
../source/print_tokens.exe  < ../inputs/ts728 > ../outputs/t1649
echo ">>>>>>>>running test 1650"
../source/print_tokens.exe  < ../inputs/ts729 > ../outputs/t1650
echo ">>>>>>>>running test 1651"
../source/print_tokens.exe  < ../inputs/ts730 > ../outputs/t1651
echo ">>>>>>>>running test 1652"
../source/print_tokens.exe  < ../inputs/ts731 > ../outputs/t1652
echo ">>>>>>>>running test 1653"
../source/print_tokens.exe  < ../inputs/ts732 > ../outputs/t1653
echo ">>>>>>>>running test 1654"
../source/print_tokens.exe  < ../inputs/ts733 > ../outputs/t1654
echo ">>>>>>>>running test 1655"
../source/print_tokens.exe  < ../inputs/ts734 > ../outputs/t1655
echo ">>>>>>>>running test 1656"
../source/print_tokens.exe  < ../inputs/ts735 > ../outputs/t1656
echo ">>>>>>>>running test 1657"
../source/print_tokens.exe  < ../inputs/ts736 > ../outputs/t1657
echo ">>>>>>>>running test 1658"
../source/print_tokens.exe  < ../inputs/ts737 > ../outputs/t1658
echo ">>>>>>>>running test 1659"
../source/print_tokens.exe  < ../inputs/ts738 > ../outputs/t1659
echo ">>>>>>>>running test 1660"
../source/print_tokens.exe  < ../inputs/ts739 > ../outputs/t1660
echo ">>>>>>>>running test 1661"
../source/print_tokens.exe  < ../inputs/ts740 > ../outputs/t1661
echo ">>>>>>>>running test 1662"
../source/print_tokens.exe  < ../inputs/ts741 > ../outputs/t1662
echo ">>>>>>>>running test 1663"
../source/print_tokens.exe  < ../inputs/ts742 > ../outputs/t1663
echo ">>>>>>>>running test 1664"
../source/print_tokens.exe  < ../inputs/ts743 > ../outputs/t1664
echo ">>>>>>>>running test 1665"
../source/print_tokens.exe  < ../inputs/ts744 > ../outputs/t1665
echo ">>>>>>>>running test 1666"
../source/print_tokens.exe  < ../inputs/ts745 > ../outputs/t1666
echo ">>>>>>>>running test 1667"
../source/print_tokens.exe  < ../inputs/ts746 > ../outputs/t1667
echo ">>>>>>>>running test 1668"
../source/print_tokens.exe  < ../inputs/ts747 > ../outputs/t1668
echo ">>>>>>>>running test 1669"
../source/print_tokens.exe  < ../inputs/ts748 > ../outputs/t1669
echo ">>>>>>>>running test 1670"
../source/print_tokens.exe  < ../inputs/ts749 > ../outputs/t1670
echo ">>>>>>>>running test 1671"
../source/print_tokens.exe  < ../inputs/ts750 > ../outputs/t1671
echo ">>>>>>>>running test 1672"
../source/print_tokens.exe  < ../inputs/ts751 > ../outputs/t1672
echo ">>>>>>>>running test 1673"
../source/print_tokens.exe  < ../inputs/ts752 > ../outputs/t1673
echo ">>>>>>>>running test 1674"
../source/print_tokens.exe  < ../inputs/ts753 > ../outputs/t1674
echo ">>>>>>>>running test 1675"
../source/print_tokens.exe  < ../inputs/ts754 > ../outputs/t1675
echo ">>>>>>>>running test 1676"
../source/print_tokens.exe  < ../inputs/ts755 > ../outputs/t1676
echo ">>>>>>>>running test 1677"
../source/print_tokens.exe  < ../inputs/ts756 > ../outputs/t1677
echo ">>>>>>>>running test 1678"
../source/print_tokens.exe  < ../inputs/ts757 > ../outputs/t1678
echo ">>>>>>>>running test 1679"
../source/print_tokens.exe  < ../inputs/ts758 > ../outputs/t1679
echo ">>>>>>>>running test 1680"
../source/print_tokens.exe  < ../inputs/ts759 > ../outputs/t1680
echo ">>>>>>>>running test 1681"
../source/print_tokens.exe  < ../inputs/ts760 > ../outputs/t1681
echo ">>>>>>>>running test 1682"
../source/print_tokens.exe  < ../inputs/ts761 > ../outputs/t1682
echo ">>>>>>>>running test 1683"
../source/print_tokens.exe  < ../inputs/ts762 > ../outputs/t1683
echo ">>>>>>>>running test 1684"
../source/print_tokens.exe  < ../inputs/ts763 > ../outputs/t1684
echo ">>>>>>>>running test 1685"
../source/print_tokens.exe  < ../inputs/ts764 > ../outputs/t1685
echo ">>>>>>>>running test 1686"
../source/print_tokens.exe  < ../inputs/ts765 > ../outputs/t1686
echo ">>>>>>>>running test 1687"
../source/print_tokens.exe  < ../inputs/ts766 > ../outputs/t1687
echo ">>>>>>>>running test 1688"
../source/print_tokens.exe  < ../inputs/ts767 > ../outputs/t1688
echo ">>>>>>>>running test 1689"
../source/print_tokens.exe  < ../inputs/ts768 > ../outputs/t1689
echo ">>>>>>>>running test 1690"
../source/print_tokens.exe  < ../inputs/ts769 > ../outputs/t1690
echo ">>>>>>>>running test 1691"
../source/print_tokens.exe  < ../inputs/ts770 > ../outputs/t1691
echo ">>>>>>>>running test 1692"
../source/print_tokens.exe  < ../inputs/ts771 > ../outputs/t1692
echo ">>>>>>>>running test 1693"
../source/print_tokens.exe  < ../inputs/ts772 > ../outputs/t1693
echo ">>>>>>>>running test 1694"
../source/print_tokens.exe  < ../inputs/ts773 > ../outputs/t1694
echo ">>>>>>>>running test 1695"
../source/print_tokens.exe  < ../inputs/ts774 > ../outputs/t1695
echo ">>>>>>>>running test 1696"
../source/print_tokens.exe  < ../inputs/ts775 > ../outputs/t1696
echo ">>>>>>>>running test 1697"
../source/print_tokens.exe  < ../inputs/ts776 > ../outputs/t1697
echo ">>>>>>>>running test 1698"
../source/print_tokens.exe  < ../inputs/ts777 > ../outputs/t1698
echo ">>>>>>>>running test 1699"
../source/print_tokens.exe  < ../inputs/ts778 > ../outputs/t1699
echo ">>>>>>>>running test 1700"
../source/print_tokens.exe  < ../inputs/ts779 > ../outputs/t1700
echo ">>>>>>>>running test 1701"
../source/print_tokens.exe  < ../inputs/ts780 > ../outputs/t1701
echo ">>>>>>>>running test 1702"
../source/print_tokens.exe  < ../inputs/ts781 > ../outputs/t1702
echo ">>>>>>>>running test 1703"
../source/print_tokens.exe  < ../inputs/ts782 > ../outputs/t1703
echo ">>>>>>>>running test 1704"
../source/print_tokens.exe  < ../inputs/ts783 > ../outputs/t1704
echo ">>>>>>>>running test 1705"
../source/print_tokens.exe  < ../inputs/ts784 > ../outputs/t1705
echo ">>>>>>>>running test 1706"
../source/print_tokens.exe  < ../inputs/ts785 > ../outputs/t1706
echo ">>>>>>>>running test 1707"
../source/print_tokens.exe  < ../inputs/ts786 > ../outputs/t1707
echo ">>>>>>>>running test 1708"
../source/print_tokens.exe  < ../inputs/ts787 > ../outputs/t1708
echo ">>>>>>>>running test 1709"
../source/print_tokens.exe  < ../inputs/ts788 > ../outputs/t1709
echo ">>>>>>>>running test 1710"
../source/print_tokens.exe  < ../inputs/ts789 > ../outputs/t1710
echo ">>>>>>>>running test 1711"
../source/print_tokens.exe  < ../inputs/ts790 > ../outputs/t1711
echo ">>>>>>>>running test 1712"
../source/print_tokens.exe  < ../inputs/ts791 > ../outputs/t1712
echo ">>>>>>>>running test 1713"
../source/print_tokens.exe  < ../inputs/ts792 > ../outputs/t1713
echo ">>>>>>>>running test 1714"
../source/print_tokens.exe  < ../inputs/ts793 > ../outputs/t1714
echo ">>>>>>>>running test 1715"
../source/print_tokens.exe  < ../inputs/ts794 > ../outputs/t1715
echo ">>>>>>>>running test 1716"
../source/print_tokens.exe  < ../inputs/ts795 > ../outputs/t1716
echo ">>>>>>>>running test 1717"
../source/print_tokens.exe  < ../inputs/ts796 > ../outputs/t1717
echo ">>>>>>>>running test 1718"
../source/print_tokens.exe  < ../inputs/ts797 > ../outputs/t1718
echo ">>>>>>>>running test 1719"
../source/print_tokens.exe  < ../inputs/ts798 > ../outputs/t1719
echo ">>>>>>>>running test 1720"
../source/print_tokens.exe  < ../inputs/ts799 > ../outputs/t1720
echo ">>>>>>>>running test 1721"
../source/print_tokens.exe  < ../inputs/ts800 > ../outputs/t1721
echo ">>>>>>>>running test 1722"
../source/print_tokens.exe  < ../inputs/tst1 > ../outputs/t1722
echo ">>>>>>>>running test 1723"
../source/print_tokens.exe  < ../inputs/tst10 > ../outputs/t1723
echo ">>>>>>>>running test 1724"
../source/print_tokens.exe  < ../inputs/tst100 > ../outputs/t1724
echo ">>>>>>>>running test 1725"
../source/print_tokens.exe  < ../inputs/tst101 > ../outputs/t1725
echo ">>>>>>>>running test 1726"
../source/print_tokens.exe  < ../inputs/tst102 > ../outputs/t1726
echo ">>>>>>>>running test 1727"
../source/print_tokens.exe  < ../inputs/tst103 > ../outputs/t1727
echo ">>>>>>>>running test 1728"
../source/print_tokens.exe  < ../inputs/tst104 > ../outputs/t1728
echo ">>>>>>>>running test 1729"
../source/print_tokens.exe  < ../inputs/tst105 > ../outputs/t1729
echo ">>>>>>>>running test 1730"
../source/print_tokens.exe  < ../inputs/tst106 > ../outputs/t1730
echo ">>>>>>>>running test 1731"
../source/print_tokens.exe  < ../inputs/tst107 > ../outputs/t1731
echo ">>>>>>>>running test 1732"
../source/print_tokens.exe  < ../inputs/tst108 > ../outputs/t1732
echo ">>>>>>>>running test 1733"
../source/print_tokens.exe  < ../inputs/tst109 > ../outputs/t1733
echo ">>>>>>>>running test 1734"
../source/print_tokens.exe  < ../inputs/tst11 > ../outputs/t1734
echo ">>>>>>>>running test 1735"
../source/print_tokens.exe  < ../inputs/tst110 > ../outputs/t1735
echo ">>>>>>>>running test 1736"
../source/print_tokens.exe  < ../inputs/tst111 > ../outputs/t1736
echo ">>>>>>>>running test 1737"
../source/print_tokens.exe  < ../inputs/tst112 > ../outputs/t1737
echo ">>>>>>>>running test 1738"
../source/print_tokens.exe  < ../inputs/tst113 > ../outputs/t1738
echo ">>>>>>>>running test 1739"
../source/print_tokens.exe  < ../inputs/tst114 > ../outputs/t1739
echo ">>>>>>>>running test 1740"
../source/print_tokens.exe  < ../inputs/tst115 > ../outputs/t1740
echo ">>>>>>>>running test 1741"
../source/print_tokens.exe  < ../inputs/tst116 > ../outputs/t1741
echo ">>>>>>>>running test 1742"
../source/print_tokens.exe  < ../inputs/tst117 > ../outputs/t1742
echo ">>>>>>>>running test 1743"
../source/print_tokens.exe  < ../inputs/tst118 > ../outputs/t1743
echo ">>>>>>>>running test 1744"
../source/print_tokens.exe  < ../inputs/tst119 > ../outputs/t1744
echo ">>>>>>>>running test 1745"
../source/print_tokens.exe  < ../inputs/tst12 > ../outputs/t1745
echo ">>>>>>>>running test 1746"
../source/print_tokens.exe  < ../inputs/tst120 > ../outputs/t1746
echo ">>>>>>>>running test 1747"
../source/print_tokens.exe  < ../inputs/tst121 > ../outputs/t1747
echo ">>>>>>>>running test 1748"
../source/print_tokens.exe  < ../inputs/tst122 > ../outputs/t1748
echo ">>>>>>>>running test 1749"
../source/print_tokens.exe  < ../inputs/tst123 > ../outputs/t1749
echo ">>>>>>>>running test 1750"
../source/print_tokens.exe  < ../inputs/tst124 > ../outputs/t1750
echo ">>>>>>>>running test 1751"
../source/print_tokens.exe  < ../inputs/tst125 > ../outputs/t1751
echo ">>>>>>>>running test 1752"
../source/print_tokens.exe  < ../inputs/tst126 > ../outputs/t1752
echo ">>>>>>>>running test 1753"
../source/print_tokens.exe  < ../inputs/tst127 > ../outputs/t1753
echo ">>>>>>>>running test 1754"
../source/print_tokens.exe  < ../inputs/tst128 > ../outputs/t1754
echo ">>>>>>>>running test 1755"
../source/print_tokens.exe  < ../inputs/tst129 > ../outputs/t1755
echo ">>>>>>>>running test 1756"
../source/print_tokens.exe  < ../inputs/tst13 > ../outputs/t1756
echo ">>>>>>>>running test 1757"
../source/print_tokens.exe  < ../inputs/tst130 > ../outputs/t1757
echo ">>>>>>>>running test 1758"
../source/print_tokens.exe  < ../inputs/tst131 > ../outputs/t1758
echo ">>>>>>>>running test 1759"
../source/print_tokens.exe  < ../inputs/tst132 > ../outputs/t1759
echo ">>>>>>>>running test 1760"
../source/print_tokens.exe  < ../inputs/tst133 > ../outputs/t1760
echo ">>>>>>>>running test 1761"
../source/print_tokens.exe  < ../inputs/tst134 > ../outputs/t1761
echo ">>>>>>>>running test 1762"
../source/print_tokens.exe  < ../inputs/tst135 > ../outputs/t1762
echo ">>>>>>>>running test 1763"
../source/print_tokens.exe  < ../inputs/tst136 > ../outputs/t1763
echo ">>>>>>>>running test 1764"
../source/print_tokens.exe  < ../inputs/tst137 > ../outputs/t1764
echo ">>>>>>>>running test 1765"
../source/print_tokens.exe  < ../inputs/tst138 > ../outputs/t1765
echo ">>>>>>>>running test 1766"
../source/print_tokens.exe  < ../inputs/tst139 > ../outputs/t1766
echo ">>>>>>>>running test 1767"
../source/print_tokens.exe  < ../inputs/tst14 > ../outputs/t1767
echo ">>>>>>>>running test 1768"
../source/print_tokens.exe  < ../inputs/tst140 > ../outputs/t1768
echo ">>>>>>>>running test 1769"
../source/print_tokens.exe  < ../inputs/tst141 > ../outputs/t1769
echo ">>>>>>>>running test 1770"
../source/print_tokens.exe  < ../inputs/tst142 > ../outputs/t1770
echo ">>>>>>>>running test 1771"
../source/print_tokens.exe  < ../inputs/tst143 > ../outputs/t1771
echo ">>>>>>>>running test 1772"
../source/print_tokens.exe  < ../inputs/tst144 > ../outputs/t1772
echo ">>>>>>>>running test 1773"
../source/print_tokens.exe  < ../inputs/tst145 > ../outputs/t1773
echo ">>>>>>>>running test 1774"
../source/print_tokens.exe  < ../inputs/tst146 > ../outputs/t1774
echo ">>>>>>>>running test 1775"
../source/print_tokens.exe  < ../inputs/tst147 > ../outputs/t1775
echo ">>>>>>>>running test 1776"
../source/print_tokens.exe  < ../inputs/tst148 > ../outputs/t1776
echo ">>>>>>>>running test 1777"
../source/print_tokens.exe  < ../inputs/tst149 > ../outputs/t1777
echo ">>>>>>>>running test 1778"
../source/print_tokens.exe  < ../inputs/tst15 > ../outputs/t1778
echo ">>>>>>>>running test 1779"
../source/print_tokens.exe  < ../inputs/tst150 > ../outputs/t1779
echo ">>>>>>>>running test 1780"
../source/print_tokens.exe  < ../inputs/tst151 > ../outputs/t1780
echo ">>>>>>>>running test 1781"
../source/print_tokens.exe  < ../inputs/tst152 > ../outputs/t1781
echo ">>>>>>>>running test 1782"
../source/print_tokens.exe  < ../inputs/tst153 > ../outputs/t1782
echo ">>>>>>>>running test 1783"
../source/print_tokens.exe  < ../inputs/tst154 > ../outputs/t1783
echo ">>>>>>>>running test 1784"
../source/print_tokens.exe  < ../inputs/tst155 > ../outputs/t1784
echo ">>>>>>>>running test 1785"
../source/print_tokens.exe  < ../inputs/tst156 > ../outputs/t1785
echo ">>>>>>>>running test 1786"
../source/print_tokens.exe  < ../inputs/tst157 > ../outputs/t1786
echo ">>>>>>>>running test 1787"
../source/print_tokens.exe  < ../inputs/tst158 > ../outputs/t1787
echo ">>>>>>>>running test 1788"
../source/print_tokens.exe  < ../inputs/tst159 > ../outputs/t1788
echo ">>>>>>>>running test 1789"
../source/print_tokens.exe  < ../inputs/tst16 > ../outputs/t1789
echo ">>>>>>>>running test 1790"
../source/print_tokens.exe  < ../inputs/tst160 > ../outputs/t1790
echo ">>>>>>>>running test 1791"
../source/print_tokens.exe  < ../inputs/tst161 > ../outputs/t1791
echo ">>>>>>>>running test 1792"
../source/print_tokens.exe  < ../inputs/tst162 > ../outputs/t1792
echo ">>>>>>>>running test 1793"
../source/print_tokens.exe  < ../inputs/tst163 > ../outputs/t1793
echo ">>>>>>>>running test 1794"
../source/print_tokens.exe  < ../inputs/tst164 > ../outputs/t1794
echo ">>>>>>>>running test 1795"
../source/print_tokens.exe  < ../inputs/tst165 > ../outputs/t1795
echo ">>>>>>>>running test 1796"
../source/print_tokens.exe  < ../inputs/tst166 > ../outputs/t1796
echo ">>>>>>>>running test 1797"
../source/print_tokens.exe  < ../inputs/tst167 > ../outputs/t1797
echo ">>>>>>>>running test 1798"
../source/print_tokens.exe  < ../inputs/tst168 > ../outputs/t1798
echo ">>>>>>>>running test 1799"
../source/print_tokens.exe  < ../inputs/tst169 > ../outputs/t1799
echo ">>>>>>>>running test 1800"
../source/print_tokens.exe  < ../inputs/tst17 > ../outputs/t1800
echo ">>>>>>>>running test 1801"
../source/print_tokens.exe  < ../inputs/tst170 > ../outputs/t1801
echo ">>>>>>>>running test 1802"
../source/print_tokens.exe  < ../inputs/tst171 > ../outputs/t1802
echo ">>>>>>>>running test 1803"
../source/print_tokens.exe  < ../inputs/tst172 > ../outputs/t1803
echo ">>>>>>>>running test 1804"
../source/print_tokens.exe  < ../inputs/tst173 > ../outputs/t1804
echo ">>>>>>>>running test 1805"
../source/print_tokens.exe  < ../inputs/tst174 > ../outputs/t1805
echo ">>>>>>>>running test 1806"
../source/print_tokens.exe  < ../inputs/tst175 > ../outputs/t1806
echo ">>>>>>>>running test 1807"
../source/print_tokens.exe  < ../inputs/tst176 > ../outputs/t1807
echo ">>>>>>>>running test 1808"
../source/print_tokens.exe  < ../inputs/tst177 > ../outputs/t1808
echo ">>>>>>>>running test 1809"
../source/print_tokens.exe  < ../inputs/tst178 > ../outputs/t1809
echo ">>>>>>>>running test 1810"
../source/print_tokens.exe  < ../inputs/tst179 > ../outputs/t1810
echo ">>>>>>>>running test 1811"
../source/print_tokens.exe  < ../inputs/tst18 > ../outputs/t1811
echo ">>>>>>>>running test 1812"
../source/print_tokens.exe  < ../inputs/tst180 > ../outputs/t1812
echo ">>>>>>>>running test 1813"
../source/print_tokens.exe  < ../inputs/tst181 > ../outputs/t1813
echo ">>>>>>>>running test 1814"
../source/print_tokens.exe  < ../inputs/tst182 > ../outputs/t1814
echo ">>>>>>>>running test 1815"
../source/print_tokens.exe  < ../inputs/tst183 > ../outputs/t1815
echo ">>>>>>>>running test 1816"
../source/print_tokens.exe  < ../inputs/tst184 > ../outputs/t1816
echo ">>>>>>>>running test 1817"
../source/print_tokens.exe  < ../inputs/tst185 > ../outputs/t1817
echo ">>>>>>>>running test 1818"
../source/print_tokens.exe  < ../inputs/tst186 > ../outputs/t1818
echo ">>>>>>>>running test 1819"
../source/print_tokens.exe  < ../inputs/tst187 > ../outputs/t1819
echo ">>>>>>>>running test 1820"
../source/print_tokens.exe  < ../inputs/tst188 > ../outputs/t1820
echo ">>>>>>>>running test 1821"
../source/print_tokens.exe  < ../inputs/tst189 > ../outputs/t1821
echo ">>>>>>>>running test 1822"
../source/print_tokens.exe  < ../inputs/tst19 > ../outputs/t1822
echo ">>>>>>>>running test 1823"
../source/print_tokens.exe  < ../inputs/tst190 > ../outputs/t1823
echo ">>>>>>>>running test 1824"
../source/print_tokens.exe  < ../inputs/tst191 > ../outputs/t1824
echo ">>>>>>>>running test 1825"
../source/print_tokens.exe  < ../inputs/tst192 > ../outputs/t1825
echo ">>>>>>>>running test 1826"
../source/print_tokens.exe  < ../inputs/tst193 > ../outputs/t1826
echo ">>>>>>>>running test 1827"
../source/print_tokens.exe  < ../inputs/tst194 > ../outputs/t1827
echo ">>>>>>>>running test 1828"
../source/print_tokens.exe  < ../inputs/tst195 > ../outputs/t1828
echo ">>>>>>>>running test 1829"
../source/print_tokens.exe  < ../inputs/tst196 > ../outputs/t1829
echo ">>>>>>>>running test 1830"
../source/print_tokens.exe  < ../inputs/tst197 > ../outputs/t1830
echo ">>>>>>>>running test 1831"
../source/print_tokens.exe  < ../inputs/tst198 > ../outputs/t1831
echo ">>>>>>>>running test 1832"
../source/print_tokens.exe  < ../inputs/tst199 > ../outputs/t1832
echo ">>>>>>>>running test 1833"
../source/print_tokens.exe  < ../inputs/tst2 > ../outputs/t1833
echo ">>>>>>>>running test 1834"
../source/print_tokens.exe  < ../inputs/tst20 > ../outputs/t1834
echo ">>>>>>>>running test 1835"
../source/print_tokens.exe  < ../inputs/tst200 > ../outputs/t1835
echo ">>>>>>>>running test 1836"
../source/print_tokens.exe  < ../inputs/tst201 > ../outputs/t1836
echo ">>>>>>>>running test 1837"
../source/print_tokens.exe  < ../inputs/tst202 > ../outputs/t1837
echo ">>>>>>>>running test 1838"
../source/print_tokens.exe  < ../inputs/tst203 > ../outputs/t1838
echo ">>>>>>>>running test 1839"
../source/print_tokens.exe  < ../inputs/tst204 > ../outputs/t1839
echo ">>>>>>>>running test 1840"
../source/print_tokens.exe  < ../inputs/tst205 > ../outputs/t1840
echo ">>>>>>>>running test 1841"
../source/print_tokens.exe  < ../inputs/tst206 > ../outputs/t1841
echo ">>>>>>>>running test 1842"
../source/print_tokens.exe  < ../inputs/tst207 > ../outputs/t1842
echo ">>>>>>>>running test 1843"
../source/print_tokens.exe  < ../inputs/tst208 > ../outputs/t1843
echo ">>>>>>>>running test 1844"
../source/print_tokens.exe  < ../inputs/tst209 > ../outputs/t1844
echo ">>>>>>>>running test 1845"
../source/print_tokens.exe  < ../inputs/tst21 > ../outputs/t1845
echo ">>>>>>>>running test 1846"
../source/print_tokens.exe  < ../inputs/tst210 > ../outputs/t1846
echo ">>>>>>>>running test 1847"
../source/print_tokens.exe  < ../inputs/tst211 > ../outputs/t1847
echo ">>>>>>>>running test 1848"
../source/print_tokens.exe  < ../inputs/tst212 > ../outputs/t1848
echo ">>>>>>>>running test 1849"
../source/print_tokens.exe  < ../inputs/tst213 > ../outputs/t1849
echo ">>>>>>>>running test 1850"
../source/print_tokens.exe  < ../inputs/tst214 > ../outputs/t1850
echo ">>>>>>>>running test 1851"
../source/print_tokens.exe  < ../inputs/tst215 > ../outputs/t1851
echo ">>>>>>>>running test 1852"
../source/print_tokens.exe  < ../inputs/tst216 > ../outputs/t1852
echo ">>>>>>>>running test 1853"
../source/print_tokens.exe  < ../inputs/tst217 > ../outputs/t1853
echo ">>>>>>>>running test 1854"
../source/print_tokens.exe  < ../inputs/tst218 > ../outputs/t1854
echo ">>>>>>>>running test 1855"
../source/print_tokens.exe  < ../inputs/tst219 > ../outputs/t1855
echo ">>>>>>>>running test 1856"
../source/print_tokens.exe  < ../inputs/tst22 > ../outputs/t1856
echo ">>>>>>>>running test 1857"
../source/print_tokens.exe  < ../inputs/tst220 > ../outputs/t1857
echo ">>>>>>>>running test 1858"
../source/print_tokens.exe  < ../inputs/tst221 > ../outputs/t1858
echo ">>>>>>>>running test 1859"
../source/print_tokens.exe  < ../inputs/tst222 > ../outputs/t1859
echo ">>>>>>>>running test 1860"
../source/print_tokens.exe  < ../inputs/tst223 > ../outputs/t1860
echo ">>>>>>>>running test 1861"
../source/print_tokens.exe  < ../inputs/tst224 > ../outputs/t1861
echo ">>>>>>>>running test 1862"
../source/print_tokens.exe  < ../inputs/tst225 > ../outputs/t1862
echo ">>>>>>>>running test 1863"
../source/print_tokens.exe  < ../inputs/tst226 > ../outputs/t1863
echo ">>>>>>>>running test 1864"
../source/print_tokens.exe  < ../inputs/tst227 > ../outputs/t1864
echo ">>>>>>>>running test 1865"
../source/print_tokens.exe  < ../inputs/tst228 > ../outputs/t1865
echo ">>>>>>>>running test 1866"
../source/print_tokens.exe  < ../inputs/tst229 > ../outputs/t1866
echo ">>>>>>>>running test 1867"
../source/print_tokens.exe  < ../inputs/tst23 > ../outputs/t1867
echo ">>>>>>>>running test 1868"
../source/print_tokens.exe  < ../inputs/tst230 > ../outputs/t1868
echo ">>>>>>>>running test 1869"
../source/print_tokens.exe  < ../inputs/tst231 > ../outputs/t1869
echo ">>>>>>>>running test 1870"
../source/print_tokens.exe  < ../inputs/tst232 > ../outputs/t1870
echo ">>>>>>>>running test 1871"
../source/print_tokens.exe  < ../inputs/tst233 > ../outputs/t1871
echo ">>>>>>>>running test 1872"
../source/print_tokens.exe  < ../inputs/tst234 > ../outputs/t1872
echo ">>>>>>>>running test 1873"
../source/print_tokens.exe  < ../inputs/tst235 > ../outputs/t1873
echo ">>>>>>>>running test 1874"
../source/print_tokens.exe  < ../inputs/tst236 > ../outputs/t1874
echo ">>>>>>>>running test 1875"
../source/print_tokens.exe  < ../inputs/tst237 > ../outputs/t1875
echo ">>>>>>>>running test 1876"
../source/print_tokens.exe  < ../inputs/tst238 > ../outputs/t1876
echo ">>>>>>>>running test 1877"
../source/print_tokens.exe  < ../inputs/tst239 > ../outputs/t1877
echo ">>>>>>>>running test 1878"
../source/print_tokens.exe  < ../inputs/tst24 > ../outputs/t1878
echo ">>>>>>>>running test 1879"
../source/print_tokens.exe  < ../inputs/tst240 > ../outputs/t1879
echo ">>>>>>>>running test 1880"
../source/print_tokens.exe  < ../inputs/tst241 > ../outputs/t1880
echo ">>>>>>>>running test 1881"
../source/print_tokens.exe  < ../inputs/tst242 > ../outputs/t1881
echo ">>>>>>>>running test 1882"
../source/print_tokens.exe  < ../inputs/tst243 > ../outputs/t1882
echo ">>>>>>>>running test 1883"
../source/print_tokens.exe  < ../inputs/tst244 > ../outputs/t1883
echo ">>>>>>>>running test 1884"
../source/print_tokens.exe  < ../inputs/tst245 > ../outputs/t1884
echo ">>>>>>>>running test 1885"
../source/print_tokens.exe  < ../inputs/tst246 > ../outputs/t1885
echo ">>>>>>>>running test 1886"
../source/print_tokens.exe  < ../inputs/tst247 > ../outputs/t1886
echo ">>>>>>>>running test 1887"
../source/print_tokens.exe  < ../inputs/tst248 > ../outputs/t1887
echo ">>>>>>>>running test 1888"
../source/print_tokens.exe  < ../inputs/tst249 > ../outputs/t1888
echo ">>>>>>>>running test 1889"
../source/print_tokens.exe  < ../inputs/tst25 > ../outputs/t1889
echo ">>>>>>>>running test 1890"
../source/print_tokens.exe  < ../inputs/tst250 > ../outputs/t1890
echo ">>>>>>>>running test 1891"
../source/print_tokens.exe  < ../inputs/tst251 > ../outputs/t1891
echo ">>>>>>>>running test 1892"
../source/print_tokens.exe  < ../inputs/tst252 > ../outputs/t1892
echo ">>>>>>>>running test 1893"
../source/print_tokens.exe  < ../inputs/tst253 > ../outputs/t1893
echo ">>>>>>>>running test 1894"
../source/print_tokens.exe  < ../inputs/tst254 > ../outputs/t1894
echo ">>>>>>>>running test 1895"
../source/print_tokens.exe  < ../inputs/tst255 > ../outputs/t1895
echo ">>>>>>>>running test 1896"
../source/print_tokens.exe  < ../inputs/tst256 > ../outputs/t1896
echo ">>>>>>>>running test 1897"
../source/print_tokens.exe  < ../inputs/tst257 > ../outputs/t1897
echo ">>>>>>>>running test 1898"
../source/print_tokens.exe  < ../inputs/tst258 > ../outputs/t1898
echo ">>>>>>>>running test 1899"
../source/print_tokens.exe  < ../inputs/tst259 > ../outputs/t1899
echo ">>>>>>>>running test 1900"
../source/print_tokens.exe  < ../inputs/tst26 > ../outputs/t1900
echo ">>>>>>>>running test 1901"
../source/print_tokens.exe  < ../inputs/tst260 > ../outputs/t1901
echo ">>>>>>>>running test 1902"
../source/print_tokens.exe  < ../inputs/tst261 > ../outputs/t1902
echo ">>>>>>>>running test 1903"
../source/print_tokens.exe  < ../inputs/tst262 > ../outputs/t1903
echo ">>>>>>>>running test 1904"
../source/print_tokens.exe  < ../inputs/tst263 > ../outputs/t1904
echo ">>>>>>>>running test 1905"
../source/print_tokens.exe  < ../inputs/tst264 > ../outputs/t1905
echo ">>>>>>>>running test 1906"
../source/print_tokens.exe  < ../inputs/tst265 > ../outputs/t1906
echo ">>>>>>>>running test 1907"
../source/print_tokens.exe  < ../inputs/tst266 > ../outputs/t1907
echo ">>>>>>>>running test 1908"
../source/print_tokens.exe  < ../inputs/tst267 > ../outputs/t1908
echo ">>>>>>>>running test 1909"
../source/print_tokens.exe  < ../inputs/tst268 > ../outputs/t1909
echo ">>>>>>>>running test 1910"
../source/print_tokens.exe  < ../inputs/tst269 > ../outputs/t1910
echo ">>>>>>>>running test 1911"
../source/print_tokens.exe  < ../inputs/tst27 > ../outputs/t1911
echo ">>>>>>>>running test 1912"
../source/print_tokens.exe  < ../inputs/tst270 > ../outputs/t1912
echo ">>>>>>>>running test 1913"
../source/print_tokens.exe  < ../inputs/tst271 > ../outputs/t1913
echo ">>>>>>>>running test 1914"
../source/print_tokens.exe  < ../inputs/tst272 > ../outputs/t1914
echo ">>>>>>>>running test 1915"
../source/print_tokens.exe  < ../inputs/tst273 > ../outputs/t1915
echo ">>>>>>>>running test 1916"
../source/print_tokens.exe  < ../inputs/tst274 > ../outputs/t1916
echo ">>>>>>>>running test 1917"
../source/print_tokens.exe  < ../inputs/tst275 > ../outputs/t1917
echo ">>>>>>>>running test 1918"
../source/print_tokens.exe  < ../inputs/tst276 > ../outputs/t1918
echo ">>>>>>>>running test 1919"
../source/print_tokens.exe  < ../inputs/tst277 > ../outputs/t1919
echo ">>>>>>>>running test 1920"
../source/print_tokens.exe  < ../inputs/tst278 > ../outputs/t1920
echo ">>>>>>>>running test 1921"
../source/print_tokens.exe  < ../inputs/tst279 > ../outputs/t1921
echo ">>>>>>>>running test 1922"
../source/print_tokens.exe  < ../inputs/tst28 > ../outputs/t1922
echo ">>>>>>>>running test 1923"
../source/print_tokens.exe  < ../inputs/tst280 > ../outputs/t1923
echo ">>>>>>>>running test 1924"
../source/print_tokens.exe  < ../inputs/tst281 > ../outputs/t1924
echo ">>>>>>>>running test 1925"
../source/print_tokens.exe  < ../inputs/tst282 > ../outputs/t1925
echo ">>>>>>>>running test 1926"
../source/print_tokens.exe  < ../inputs/tst283 > ../outputs/t1926
echo ">>>>>>>>running test 1927"
../source/print_tokens.exe  < ../inputs/tst284 > ../outputs/t1927
echo ">>>>>>>>running test 1928"
../source/print_tokens.exe  < ../inputs/tst285 > ../outputs/t1928
echo ">>>>>>>>running test 1929"
../source/print_tokens.exe  < ../inputs/tst286 > ../outputs/t1929
echo ">>>>>>>>running test 1930"
../source/print_tokens.exe  < ../inputs/tst287 > ../outputs/t1930
echo ">>>>>>>>running test 1931"
../source/print_tokens.exe  < ../inputs/tst288 > ../outputs/t1931
echo ">>>>>>>>running test 1932"
../source/print_tokens.exe  < ../inputs/tst289 > ../outputs/t1932
echo ">>>>>>>>running test 1933"
../source/print_tokens.exe  < ../inputs/tst29 > ../outputs/t1933
echo ">>>>>>>>running test 1934"
../source/print_tokens.exe  < ../inputs/tst290 > ../outputs/t1934
echo ">>>>>>>>running test 1935"
../source/print_tokens.exe  < ../inputs/tst291 > ../outputs/t1935
echo ">>>>>>>>running test 1936"
../source/print_tokens.exe  < ../inputs/tst292 > ../outputs/t1936
echo ">>>>>>>>running test 1937"
../source/print_tokens.exe  < ../inputs/tst293 > ../outputs/t1937
echo ">>>>>>>>running test 1938"
../source/print_tokens.exe  < ../inputs/tst294 > ../outputs/t1938
echo ">>>>>>>>running test 1939"
../source/print_tokens.exe  < ../inputs/tst295 > ../outputs/t1939
echo ">>>>>>>>running test 1940"
../source/print_tokens.exe  < ../inputs/tst296 > ../outputs/t1940
echo ">>>>>>>>running test 1941"
../source/print_tokens.exe  < ../inputs/tst297 > ../outputs/t1941
echo ">>>>>>>>running test 1942"
../source/print_tokens.exe  < ../inputs/tst298 > ../outputs/t1942
echo ">>>>>>>>running test 1943"
../source/print_tokens.exe  < ../inputs/tst299 > ../outputs/t1943
echo ">>>>>>>>running test 1944"
../source/print_tokens.exe  < ../inputs/tst3 > ../outputs/t1944
echo ">>>>>>>>running test 1945"
../source/print_tokens.exe  < ../inputs/tst30 > ../outputs/t1945
echo ">>>>>>>>running test 1946"
../source/print_tokens.exe  < ../inputs/tst300 > ../outputs/t1946
echo ">>>>>>>>running test 1947"
../source/print_tokens.exe  < ../inputs/tst31 > ../outputs/t1947
echo ">>>>>>>>running test 1948"
../source/print_tokens.exe  < ../inputs/tst32 > ../outputs/t1948
echo ">>>>>>>>running test 1949"
../source/print_tokens.exe  < ../inputs/tst33 > ../outputs/t1949
echo ">>>>>>>>running test 1950"
../source/print_tokens.exe  < ../inputs/tst34 > ../outputs/t1950
echo ">>>>>>>>running test 1951"
../source/print_tokens.exe  < ../inputs/tst35 > ../outputs/t1951
echo ">>>>>>>>running test 1952"
../source/print_tokens.exe  < ../inputs/tst36 > ../outputs/t1952
echo ">>>>>>>>running test 1953"
../source/print_tokens.exe  < ../inputs/tst37 > ../outputs/t1953
echo ">>>>>>>>running test 1954"
../source/print_tokens.exe  < ../inputs/tst38 > ../outputs/t1954
echo ">>>>>>>>running test 1955"
../source/print_tokens.exe  < ../inputs/tst39 > ../outputs/t1955
echo ">>>>>>>>running test 1956"
../source/print_tokens.exe  < ../inputs/tst4 > ../outputs/t1956
echo ">>>>>>>>running test 1957"
../source/print_tokens.exe  < ../inputs/tst40 > ../outputs/t1957
echo ">>>>>>>>running test 1958"
../source/print_tokens.exe  < ../inputs/tst41 > ../outputs/t1958
echo ">>>>>>>>running test 1959"
../source/print_tokens.exe  < ../inputs/tst42 > ../outputs/t1959
echo ">>>>>>>>running test 1960"
../source/print_tokens.exe  < ../inputs/tst43 > ../outputs/t1960
echo ">>>>>>>>running test 1961"
../source/print_tokens.exe  < ../inputs/tst44 > ../outputs/t1961
echo ">>>>>>>>running test 1962"
../source/print_tokens.exe  < ../inputs/tst45 > ../outputs/t1962
echo ">>>>>>>>running test 1963"
../source/print_tokens.exe  < ../inputs/tst46 > ../outputs/t1963
echo ">>>>>>>>running test 1964"
../source/print_tokens.exe  < ../inputs/tst47 > ../outputs/t1964
echo ">>>>>>>>running test 1965"
../source/print_tokens.exe  < ../inputs/tst48 > ../outputs/t1965
echo ">>>>>>>>running test 1966"
../source/print_tokens.exe  < ../inputs/tst49 > ../outputs/t1966
echo ">>>>>>>>running test 1967"
../source/print_tokens.exe  < ../inputs/tst5 > ../outputs/t1967
echo ">>>>>>>>running test 1968"
../source/print_tokens.exe  < ../inputs/tst50 > ../outputs/t1968
echo ">>>>>>>>running test 1969"
../source/print_tokens.exe  < ../inputs/tst51 > ../outputs/t1969
echo ">>>>>>>>running test 1970"
../source/print_tokens.exe  < ../inputs/tst52 > ../outputs/t1970
echo ">>>>>>>>running test 1971"
../source/print_tokens.exe  < ../inputs/tst53 > ../outputs/t1971
echo ">>>>>>>>running test 1972"
../source/print_tokens.exe  < ../inputs/tst54 > ../outputs/t1972
echo ">>>>>>>>running test 1973"
../source/print_tokens.exe  < ../inputs/tst55 > ../outputs/t1973
echo ">>>>>>>>running test 1974"
../source/print_tokens.exe  < ../inputs/tst56 > ../outputs/t1974
echo ">>>>>>>>running test 1975"
../source/print_tokens.exe  < ../inputs/tst57 > ../outputs/t1975
echo ">>>>>>>>running test 1976"
../source/print_tokens.exe  < ../inputs/tst58 > ../outputs/t1976
echo ">>>>>>>>running test 1977"
../source/print_tokens.exe  < ../inputs/tst59 > ../outputs/t1977
echo ">>>>>>>>running test 1978"
../source/print_tokens.exe  < ../inputs/tst6 > ../outputs/t1978
echo ">>>>>>>>running test 1979"
../source/print_tokens.exe  < ../inputs/tst60 > ../outputs/t1979
echo ">>>>>>>>running test 1980"
../source/print_tokens.exe  < ../inputs/tst61 > ../outputs/t1980
echo ">>>>>>>>running test 1981"
../source/print_tokens.exe  < ../inputs/tst62 > ../outputs/t1981
echo ">>>>>>>>running test 1982"
../source/print_tokens.exe  < ../inputs/tst63 > ../outputs/t1982
echo ">>>>>>>>running test 1983"
../source/print_tokens.exe  < ../inputs/tst64 > ../outputs/t1983
echo ">>>>>>>>running test 1984"
../source/print_tokens.exe  < ../inputs/tst65 > ../outputs/t1984
echo ">>>>>>>>running test 1985"
../source/print_tokens.exe  < ../inputs/tst66 > ../outputs/t1985
echo ">>>>>>>>running test 1986"
../source/print_tokens.exe  < ../inputs/tst67 > ../outputs/t1986
echo ">>>>>>>>running test 1987"
../source/print_tokens.exe  < ../inputs/tst68 > ../outputs/t1987
echo ">>>>>>>>running test 1988"
../source/print_tokens.exe  < ../inputs/tst69 > ../outputs/t1988
echo ">>>>>>>>running test 1989"
../source/print_tokens.exe  < ../inputs/tst7 > ../outputs/t1989
echo ">>>>>>>>running test 1990"
../source/print_tokens.exe  < ../inputs/tst70 > ../outputs/t1990
echo ">>>>>>>>running test 1991"
../source/print_tokens.exe  < ../inputs/tst71 > ../outputs/t1991
echo ">>>>>>>>running test 1992"
../source/print_tokens.exe  < ../inputs/tst72 > ../outputs/t1992
echo ">>>>>>>>running test 1993"
../source/print_tokens.exe  < ../inputs/tst73 > ../outputs/t1993
echo ">>>>>>>>running test 1994"
../source/print_tokens.exe  < ../inputs/tst74 > ../outputs/t1994
echo ">>>>>>>>running test 1995"
../source/print_tokens.exe  < ../inputs/tst75 > ../outputs/t1995
echo ">>>>>>>>running test 1996"
../source/print_tokens.exe  < ../inputs/tst76 > ../outputs/t1996
echo ">>>>>>>>running test 1997"
../source/print_tokens.exe  < ../inputs/tst77 > ../outputs/t1997
echo ">>>>>>>>running test 1998"
../source/print_tokens.exe  < ../inputs/tst78 > ../outputs/t1998
echo ">>>>>>>>running test 1999"
../source/print_tokens.exe  < ../inputs/tst79 > ../outputs/t1999
echo ">>>>>>>>running test 2000"
../source/print_tokens.exe  < ../inputs/tst8 > ../outputs/t2000
echo ">>>>>>>>running test 2001"
../source/print_tokens.exe  < ../inputs/tst80 > ../outputs/t2001
echo ">>>>>>>>running test 2002"
../source/print_tokens.exe  < ../inputs/tst81 > ../outputs/t2002
echo ">>>>>>>>running test 2003"
../source/print_tokens.exe  < ../inputs/tst82 > ../outputs/t2003
echo ">>>>>>>>running test 2004"
../source/print_tokens.exe  < ../inputs/tst83 > ../outputs/t2004
echo ">>>>>>>>running test 2005"
../source/print_tokens.exe  < ../inputs/tst84 > ../outputs/t2005
echo ">>>>>>>>running test 2006"
../source/print_tokens.exe  < ../inputs/tst85 > ../outputs/t2006
echo ">>>>>>>>running test 2007"
../source/print_tokens.exe  < ../inputs/tst86 > ../outputs/t2007
echo ">>>>>>>>running test 2008"
../source/print_tokens.exe  < ../inputs/tst87 > ../outputs/t2008
echo ">>>>>>>>running test 2009"
../source/print_tokens.exe  < ../inputs/tst88 > ../outputs/t2009
echo ">>>>>>>>running test 2010"
../source/print_tokens.exe  < ../inputs/tst89 > ../outputs/t2010
echo ">>>>>>>>running test 2011"
../source/print_tokens.exe  < ../inputs/tst9 > ../outputs/t2011
echo ">>>>>>>>running test 2012"
../source/print_tokens.exe  < ../inputs/tst90 > ../outputs/t2012
echo ">>>>>>>>running test 2013"
../source/print_tokens.exe  < ../inputs/tst91 > ../outputs/t2013
echo ">>>>>>>>running test 2014"
../source/print_tokens.exe  < ../inputs/tst92 > ../outputs/t2014
echo ">>>>>>>>running test 2015"
../source/print_tokens.exe  < ../inputs/tst93 > ../outputs/t2015
echo ">>>>>>>>running test 2016"
../source/print_tokens.exe  < ../inputs/tst94 > ../outputs/t2016
echo ">>>>>>>>running test 2017"
../source/print_tokens.exe  < ../inputs/tst95 > ../outputs/t2017
echo ">>>>>>>>running test 2018"
../source/print_tokens.exe  < ../inputs/tst96 > ../outputs/t2018
echo ">>>>>>>>running test 2019"
../source/print_tokens.exe  < ../inputs/tst97 > ../outputs/t2019
echo ">>>>>>>>running test 2020"
../source/print_tokens.exe  < ../inputs/tst98 > ../outputs/t2020
echo ">>>>>>>>running test 2021"
../source/print_tokens.exe  < ../inputs/tst99 > ../outputs/t2021
echo ">>>>>>>>running test 2022"
../source/print_tokens.exe  < ../inputs/uslin.100 > ../outputs/t2022
echo ">>>>>>>>running test 2023"
../source/print_tokens.exe  < ../inputs/uslin.1002 > ../outputs/t2023
echo ">>>>>>>>running test 2024"
../source/print_tokens.exe  < ../inputs/uslin.1006 > ../outputs/t2024
echo ">>>>>>>>running test 2025"
../source/print_tokens.exe  < ../inputs/uslin.1007 > ../outputs/t2025
echo ">>>>>>>>running test 2026"
../source/print_tokens.exe  < ../inputs/uslin.101 > ../outputs/t2026
echo ">>>>>>>>running test 2027"
../source/print_tokens.exe  < ../inputs/uslin.1011 > ../outputs/t2027
echo ">>>>>>>>running test 2028"
../source/print_tokens.exe  < ../inputs/uslin.1012 > ../outputs/t2028
echo ">>>>>>>>running test 2029"
../source/print_tokens.exe  < ../inputs/uslin.1013 > ../outputs/t2029
echo ">>>>>>>>running test 2030"
../source/print_tokens.exe  < ../inputs/uslin.1016 > ../outputs/t2030
echo ">>>>>>>>running test 2031"
../source/print_tokens.exe  < ../inputs/uslin.1017 > ../outputs/t2031
echo ">>>>>>>>running test 2032"
../source/print_tokens.exe  < ../inputs/uslin.1019 > ../outputs/t2032
echo ">>>>>>>>running test 2033"
../source/print_tokens.exe  < ../inputs/uslin.102 > ../outputs/t2033
echo ">>>>>>>>running test 2034"
../source/print_tokens.exe  < ../inputs/uslin.1021 > ../outputs/t2034
echo ">>>>>>>>running test 2035"
../source/print_tokens.exe  < ../inputs/uslin.1022 > ../outputs/t2035
echo ">>>>>>>>running test 2036"
../source/print_tokens.exe  < ../inputs/uslin.1023 > ../outputs/t2036
echo ">>>>>>>>running test 2037"
../source/print_tokens.exe  < ../inputs/uslin.1026 > ../outputs/t2037
echo ">>>>>>>>running test 2038"
../source/print_tokens.exe  < ../inputs/uslin.1027 > ../outputs/t2038
echo ">>>>>>>>running test 2039"
../source/print_tokens.exe  < ../inputs/uslin.1028 > ../outputs/t2039
echo ">>>>>>>>running test 2040"
../source/print_tokens.exe  < ../inputs/uslin.1029 > ../outputs/t2040
echo ">>>>>>>>running test 2041"
../source/print_tokens.exe  < ../inputs/uslin.103 > ../outputs/t2041
echo ">>>>>>>>running test 2042"
../source/print_tokens.exe  < ../inputs/uslin.1033 > ../outputs/t2042
echo ">>>>>>>>running test 2043"
../source/print_tokens.exe  < ../inputs/uslin.1037 > ../outputs/t2043
echo ">>>>>>>>running test 2044"
../source/print_tokens.exe  < ../inputs/uslin.104 > ../outputs/t2044
echo ">>>>>>>>running test 2045"
../source/print_tokens.exe  < ../inputs/uslin.1041 > ../outputs/t2045
echo ">>>>>>>>running test 2046"
../source/print_tokens.exe  < ../inputs/uslin.1044 > ../outputs/t2046
echo ">>>>>>>>running test 2047"
../source/print_tokens.exe  < ../inputs/uslin.1051 > ../outputs/t2047
echo ">>>>>>>>running test 2048"
../source/print_tokens.exe  < ../inputs/uslin.1052 > ../outputs/t2048
echo ">>>>>>>>running test 2049"
../source/print_tokens.exe  < ../inputs/uslin.1053 > ../outputs/t2049
echo ">>>>>>>>running test 2050"
../source/print_tokens.exe  < ../inputs/uslin.1056 > ../outputs/t2050
echo ">>>>>>>>running test 2051"
../source/print_tokens.exe  < ../inputs/uslin.1058 > ../outputs/t2051
echo ">>>>>>>>running test 2052"
../source/print_tokens.exe  < ../inputs/uslin.1062 > ../outputs/t2052
echo ">>>>>>>>running test 2053"
../source/print_tokens.exe  < ../inputs/uslin.1063 > ../outputs/t2053
echo ">>>>>>>>running test 2054"
../source/print_tokens.exe  < ../inputs/uslin.1064 > ../outputs/t2054
echo ">>>>>>>>running test 2055"
../source/print_tokens.exe  < ../inputs/uslin.1066 > ../outputs/t2055
echo ">>>>>>>>running test 2056"
../source/print_tokens.exe  < ../inputs/uslin.1070 > ../outputs/t2056
echo ">>>>>>>>running test 2057"
../source/print_tokens.exe  < ../inputs/uslin.1072 > ../outputs/t2057
echo ">>>>>>>>running test 2058"
../source/print_tokens.exe  < ../inputs/uslin.1073 > ../outputs/t2058
echo ">>>>>>>>running test 2059"
../source/print_tokens.exe  < ../inputs/uslin.1079 > ../outputs/t2059
echo ">>>>>>>>running test 2060"
../source/print_tokens.exe  < ../inputs/uslin.108 > ../outputs/t2060
echo ">>>>>>>>running test 2061"
../source/print_tokens.exe  < ../inputs/uslin.1081 > ../outputs/t2061
echo ">>>>>>>>running test 2062"
../source/print_tokens.exe  < ../inputs/uslin.1083 > ../outputs/t2062
echo ">>>>>>>>running test 2063"
../source/print_tokens.exe  < ../inputs/uslin.1086 > ../outputs/t2063
echo ">>>>>>>>running test 2064"
../source/print_tokens.exe  < ../inputs/uslin.1087 > ../outputs/t2064
echo ">>>>>>>>running test 2065"
../source/print_tokens.exe  < ../inputs/uslin.1088 > ../outputs/t2065
echo ">>>>>>>>running test 2066"
../source/print_tokens.exe  < ../inputs/uslin.1089 > ../outputs/t2066
echo ">>>>>>>>running test 2067"
../source/print_tokens.exe  < ../inputs/uslin.1090 > ../outputs/t2067
echo ">>>>>>>>running test 2068"
../source/print_tokens.exe  < ../inputs/uslin.1097 > ../outputs/t2068
echo ">>>>>>>>running test 2069"
../source/print_tokens.exe  < ../inputs/uslin.1098 > ../outputs/t2069
echo ">>>>>>>>running test 2070"
../source/print_tokens.exe  < ../inputs/uslin.1099 > ../outputs/t2070
echo ">>>>>>>>running test 2071"
../source/print_tokens.exe  < ../inputs/uslin.11 > ../outputs/t2071
echo ">>>>>>>>running test 2072"
../source/print_tokens.exe  < ../inputs/uslin.110 > ../outputs/t2072
echo ">>>>>>>>running test 2073"
../source/print_tokens.exe  < ../inputs/uslin.1100 > ../outputs/t2073
echo ">>>>>>>>running test 2074"
../source/print_tokens.exe  < ../inputs/uslin.1102 > ../outputs/t2074
echo ">>>>>>>>running test 2075"
../source/print_tokens.exe  < ../inputs/uslin.1104 > ../outputs/t2075
echo ">>>>>>>>running test 2076"
../source/print_tokens.exe  < ../inputs/uslin.1106 > ../outputs/t2076
echo ">>>>>>>>running test 2077"
../source/print_tokens.exe  < ../inputs/uslin.1107 > ../outputs/t2077
echo ">>>>>>>>running test 2078"
../source/print_tokens.exe  < ../inputs/uslin.1108 > ../outputs/t2078
echo ">>>>>>>>running test 2079"
../source/print_tokens.exe  < ../inputs/uslin.1111 > ../outputs/t2079
echo ">>>>>>>>running test 2080"
../source/print_tokens.exe  < ../inputs/uslin.1116 > ../outputs/t2080
echo ">>>>>>>>running test 2081"
../source/print_tokens.exe  < ../inputs/uslin.1117 > ../outputs/t2081
echo ">>>>>>>>running test 2082"
../source/print_tokens.exe  < ../inputs/uslin.1118 > ../outputs/t2082
echo ">>>>>>>>running test 2083"
../source/print_tokens.exe  < ../inputs/uslin.112 > ../outputs/t2083
echo ">>>>>>>>running test 2084"
../source/print_tokens.exe  < ../inputs/uslin.1122 > ../outputs/t2084
echo ">>>>>>>>running test 2085"
../source/print_tokens.exe  < ../inputs/uslin.1123 > ../outputs/t2085
echo ">>>>>>>>running test 2086"
../source/print_tokens.exe  < ../inputs/uslin.1128 > ../outputs/t2086
echo ">>>>>>>>running test 2087"
../source/print_tokens.exe  < ../inputs/uslin.1129 > ../outputs/t2087
echo ">>>>>>>>running test 2088"
../source/print_tokens.exe  < ../inputs/uslin.113 > ../outputs/t2088
echo ">>>>>>>>running test 2089"
../source/print_tokens.exe  < ../inputs/uslin.1131 > ../outputs/t2089
echo ">>>>>>>>running test 2090"
../source/print_tokens.exe  < ../inputs/uslin.1132 > ../outputs/t2090
echo ">>>>>>>>running test 2091"
../source/print_tokens.exe  < ../inputs/uslin.1133 > ../outputs/t2091
echo ">>>>>>>>running test 2092"
../source/print_tokens.exe  < ../inputs/uslin.1134 > ../outputs/t2092
echo ">>>>>>>>running test 2093"
../source/print_tokens.exe  < ../inputs/uslin.1135 > ../outputs/t2093
echo ">>>>>>>>running test 2094"
../source/print_tokens.exe  < ../inputs/uslin.1136 > ../outputs/t2094
echo ">>>>>>>>running test 2095"
../source/print_tokens.exe  < ../inputs/uslin.1137 > ../outputs/t2095
echo ">>>>>>>>running test 2096"
../source/print_tokens.exe  < ../inputs/uslin.1138 > ../outputs/t2096
echo ">>>>>>>>running test 2097"
../source/print_tokens.exe  < ../inputs/uslin.1143 > ../outputs/t2097
echo ">>>>>>>>running test 2098"
../source/print_tokens.exe  < ../inputs/uslin.1145 > ../outputs/t2098
echo ">>>>>>>>running test 2099"
../source/print_tokens.exe  < ../inputs/uslin.1146 > ../outputs/t2099
echo ">>>>>>>>running test 2100"
../source/print_tokens.exe  < ../inputs/uslin.1147 > ../outputs/t2100
echo ">>>>>>>>running test 2101"
../source/print_tokens.exe  < ../inputs/uslin.1148 > ../outputs/t2101
echo ">>>>>>>>running test 2102"
../source/print_tokens.exe  < ../inputs/uslin.1149 > ../outputs/t2102
echo ">>>>>>>>running test 2103"
../source/print_tokens.exe  < ../inputs/uslin.1150 > ../outputs/t2103
echo ">>>>>>>>running test 2104"
../source/print_tokens.exe  < ../inputs/uslin.1151 > ../outputs/t2104
echo ">>>>>>>>running test 2105"
../source/print_tokens.exe  < ../inputs/uslin.1152 > ../outputs/t2105
echo ">>>>>>>>running test 2106"
../source/print_tokens.exe  < ../inputs/uslin.1153 > ../outputs/t2106
echo ">>>>>>>>running test 2107"
../source/print_tokens.exe  < ../inputs/uslin.1154 > ../outputs/t2107
echo ">>>>>>>>running test 2108"
../source/print_tokens.exe  < ../inputs/uslin.1157 > ../outputs/t2108
echo ">>>>>>>>running test 2109"
../source/print_tokens.exe  < ../inputs/uslin.1158 > ../outputs/t2109
echo ">>>>>>>>running test 2110"
../source/print_tokens.exe  < ../inputs/uslin.116 > ../outputs/t2110
echo ">>>>>>>>running test 2111"
../source/print_tokens.exe  < ../inputs/uslin.1161 > ../outputs/t2111
echo ">>>>>>>>running test 2112"
../source/print_tokens.exe  < ../inputs/uslin.1164 > ../outputs/t2112
echo ">>>>>>>>running test 2113"
../source/print_tokens.exe  < ../inputs/uslin.1168 > ../outputs/t2113
echo ">>>>>>>>running test 2114"
../source/print_tokens.exe  < ../inputs/uslin.1169 > ../outputs/t2114
echo ">>>>>>>>running test 2115"
../source/print_tokens.exe  < ../inputs/uslin.1170 > ../outputs/t2115
echo ">>>>>>>>running test 2116"
../source/print_tokens.exe  < ../inputs/uslin.1171 > ../outputs/t2116
echo ">>>>>>>>running test 2117"
../source/print_tokens.exe  < ../inputs/uslin.1172 > ../outputs/t2117
echo ">>>>>>>>running test 2118"
../source/print_tokens.exe  < ../inputs/uslin.1175 > ../outputs/t2118
echo ">>>>>>>>running test 2119"
../source/print_tokens.exe  < ../inputs/uslin.1176 > ../outputs/t2119
echo ">>>>>>>>running test 2120"
../source/print_tokens.exe  < ../inputs/uslin.1177 > ../outputs/t2120
echo ">>>>>>>>running test 2121"
../source/print_tokens.exe  < ../inputs/uslin.1178 > ../outputs/t2121
echo ">>>>>>>>running test 2122"
../source/print_tokens.exe  < ../inputs/uslin.118 > ../outputs/t2122
echo ">>>>>>>>running test 2123"
../source/print_tokens.exe  < ../inputs/uslin.1181 > ../outputs/t2123
echo ">>>>>>>>running test 2124"
../source/print_tokens.exe  < ../inputs/uslin.1183 > ../outputs/t2124
echo ">>>>>>>>running test 2125"
../source/print_tokens.exe  < ../inputs/uslin.1188 > ../outputs/t2125
echo ">>>>>>>>running test 2126"
../source/print_tokens.exe  < ../inputs/uslin.1190 > ../outputs/t2126
echo ">>>>>>>>running test 2127"
../source/print_tokens.exe  < ../inputs/uslin.1194 > ../outputs/t2127
echo ">>>>>>>>running test 2128"
../source/print_tokens.exe  < ../inputs/uslin.1195 > ../outputs/t2128
echo ">>>>>>>>running test 2129"
../source/print_tokens.exe  < ../inputs/uslin.1197 > ../outputs/t2129
echo ">>>>>>>>running test 2130"
../source/print_tokens.exe  < ../inputs/uslin.1199 > ../outputs/t2130
echo ">>>>>>>>running test 2131"
../source/print_tokens.exe  < ../inputs/uslin.12 > ../outputs/t2131
echo ">>>>>>>>running test 2132"
../source/print_tokens.exe  < ../inputs/uslin.120 > ../outputs/t2132
echo ">>>>>>>>running test 2133"
../source/print_tokens.exe  < ../inputs/uslin.1201 > ../outputs/t2133
echo ">>>>>>>>running test 2134"
../source/print_tokens.exe  < ../inputs/uslin.1203 > ../outputs/t2134
echo ">>>>>>>>running test 2135"
../source/print_tokens.exe  < ../inputs/uslin.1204 > ../outputs/t2135
echo ">>>>>>>>running test 2136"
../source/print_tokens.exe  < ../inputs/uslin.1205 > ../outputs/t2136
echo ">>>>>>>>running test 2137"
../source/print_tokens.exe  < ../inputs/uslin.1208 > ../outputs/t2137
echo ">>>>>>>>running test 2138"
../source/print_tokens.exe  < ../inputs/uslin.1210 > ../outputs/t2138
echo ">>>>>>>>running test 2139"
../source/print_tokens.exe  < ../inputs/uslin.1211 > ../outputs/t2139
echo ">>>>>>>>running test 2140"
../source/print_tokens.exe  < ../inputs/uslin.1213 > ../outputs/t2140
echo ">>>>>>>>running test 2141"
../source/print_tokens.exe  < ../inputs/uslin.1214 > ../outputs/t2141
echo ">>>>>>>>running test 2142"
../source/print_tokens.exe  < ../inputs/uslin.1215 > ../outputs/t2142
echo ">>>>>>>>running test 2143"
../source/print_tokens.exe  < ../inputs/uslin.1216 > ../outputs/t2143
echo ">>>>>>>>running test 2144"
../source/print_tokens.exe  < ../inputs/uslin.1218 > ../outputs/t2144
echo ">>>>>>>>running test 2145"
../source/print_tokens.exe  < ../inputs/uslin.122 > ../outputs/t2145
echo ">>>>>>>>running test 2146"
../source/print_tokens.exe  < ../inputs/uslin.1220 > ../outputs/t2146
echo ">>>>>>>>running test 2147"
../source/print_tokens.exe  < ../inputs/uslin.1221 > ../outputs/t2147
echo ">>>>>>>>running test 2148"
../source/print_tokens.exe  < ../inputs/uslin.1222 > ../outputs/t2148
echo ">>>>>>>>running test 2149"
../source/print_tokens.exe  < ../inputs/uslin.1225 > ../outputs/t2149
echo ">>>>>>>>running test 2150"
../source/print_tokens.exe  < ../inputs/uslin.1227 > ../outputs/t2150
echo ">>>>>>>>running test 2151"
../source/print_tokens.exe  < ../inputs/uslin.1229 > ../outputs/t2151
echo ">>>>>>>>running test 2152"
../source/print_tokens.exe  < ../inputs/uslin.123 > ../outputs/t2152
echo ">>>>>>>>running test 2153"
../source/print_tokens.exe  < ../inputs/uslin.1230 > ../outputs/t2153
echo ">>>>>>>>running test 2154"
../source/print_tokens.exe  < ../inputs/uslin.1231 > ../outputs/t2154
echo ">>>>>>>>running test 2155"
../source/print_tokens.exe  < ../inputs/uslin.1232 > ../outputs/t2155
echo ">>>>>>>>running test 2156"
../source/print_tokens.exe  < ../inputs/uslin.1236 > ../outputs/t2156
echo ">>>>>>>>running test 2157"
../source/print_tokens.exe  < ../inputs/uslin.1238 > ../outputs/t2157
echo ">>>>>>>>running test 2158"
../source/print_tokens.exe  < ../inputs/uslin.124 > ../outputs/t2158
echo ">>>>>>>>running test 2159"
../source/print_tokens.exe  < ../inputs/uslin.1240 > ../outputs/t2159
echo ">>>>>>>>running test 2160"
../source/print_tokens.exe  < ../inputs/uslin.1242 > ../outputs/t2160
echo ">>>>>>>>running test 2161"
../source/print_tokens.exe  < ../inputs/uslin.1244 > ../outputs/t2161
echo ">>>>>>>>running test 2162"
../source/print_tokens.exe  < ../inputs/uslin.1247 > ../outputs/t2162
echo ">>>>>>>>running test 2163"
../source/print_tokens.exe  < ../inputs/uslin.1248 > ../outputs/t2163
echo ">>>>>>>>running test 2164"
../source/print_tokens.exe  < ../inputs/uslin.1251 > ../outputs/t2164
echo ">>>>>>>>running test 2165"
../source/print_tokens.exe  < ../inputs/uslin.1254 > ../outputs/t2165
echo ">>>>>>>>running test 2166"
../source/print_tokens.exe  < ../inputs/uslin.1257 > ../outputs/t2166
echo ">>>>>>>>running test 2167"
../source/print_tokens.exe  < ../inputs/uslin.1259 > ../outputs/t2167
echo ">>>>>>>>running test 2168"
../source/print_tokens.exe  < ../inputs/uslin.1261 > ../outputs/t2168
echo ">>>>>>>>running test 2169"
../source/print_tokens.exe  < ../inputs/uslin.1262 > ../outputs/t2169
echo ">>>>>>>>running test 2170"
../source/print_tokens.exe  < ../inputs/uslin.1263 > ../outputs/t2170
echo ">>>>>>>>running test 2171"
../source/print_tokens.exe  < ../inputs/uslin.1269 > ../outputs/t2171
echo ">>>>>>>>running test 2172"
../source/print_tokens.exe  < ../inputs/uslin.1271 > ../outputs/t2172
echo ">>>>>>>>running test 2173"
../source/print_tokens.exe  < ../inputs/uslin.1273 > ../outputs/t2173
echo ">>>>>>>>running test 2174"
../source/print_tokens.exe  < ../inputs/uslin.1274 > ../outputs/t2174
echo ">>>>>>>>running test 2175"
../source/print_tokens.exe  < ../inputs/uslin.1275 > ../outputs/t2175
echo ">>>>>>>>running test 2176"
../source/print_tokens.exe  < ../inputs/uslin.1277 > ../outputs/t2176
echo ">>>>>>>>running test 2177"
../source/print_tokens.exe  < ../inputs/uslin.1279 > ../outputs/t2177
echo ">>>>>>>>running test 2178"
../source/print_tokens.exe  < ../inputs/uslin.1280 > ../outputs/t2178
echo ">>>>>>>>running test 2179"
../source/print_tokens.exe  < ../inputs/uslin.1282 > ../outputs/t2179
echo ">>>>>>>>running test 2180"
../source/print_tokens.exe  < ../inputs/uslin.1284 > ../outputs/t2180
echo ">>>>>>>>running test 2181"
../source/print_tokens.exe  < ../inputs/uslin.1285 > ../outputs/t2181
echo ">>>>>>>>running test 2182"
../source/print_tokens.exe  < ../inputs/uslin.1286 > ../outputs/t2182
echo ">>>>>>>>running test 2183"
../source/print_tokens.exe  < ../inputs/uslin.1288 > ../outputs/t2183
echo ">>>>>>>>running test 2184"
../source/print_tokens.exe  < ../inputs/uslin.1293 > ../outputs/t2184
echo ">>>>>>>>running test 2185"
../source/print_tokens.exe  < ../inputs/uslin.1295 > ../outputs/t2185
echo ">>>>>>>>running test 2186"
../source/print_tokens.exe  < ../inputs/uslin.1296 > ../outputs/t2186
echo ">>>>>>>>running test 2187"
../source/print_tokens.exe  < ../inputs/uslin.1297 > ../outputs/t2187
echo ">>>>>>>>running test 2188"
../source/print_tokens.exe  < ../inputs/uslin.1299 > ../outputs/t2188
echo ">>>>>>>>running test 2189"
../source/print_tokens.exe  < ../inputs/uslin.13 > ../outputs/t2189
echo ">>>>>>>>running test 2190"
../source/print_tokens.exe  < ../inputs/uslin.130 > ../outputs/t2190
echo ">>>>>>>>running test 2191"
../source/print_tokens.exe  < ../inputs/uslin.1300 > ../outputs/t2191
echo ">>>>>>>>running test 2192"
../source/print_tokens.exe  < ../inputs/uslin.1301 > ../outputs/t2192
echo ">>>>>>>>running test 2193"
../source/print_tokens.exe  < ../inputs/uslin.1304 > ../outputs/t2193
echo ">>>>>>>>running test 2194"
../source/print_tokens.exe  < ../inputs/uslin.1307 > ../outputs/t2194
echo ">>>>>>>>running test 2195"
../source/print_tokens.exe  < ../inputs/uslin.1308 > ../outputs/t2195
echo ">>>>>>>>running test 2196"
../source/print_tokens.exe  < ../inputs/uslin.1309 > ../outputs/t2196
echo ">>>>>>>>running test 2197"
../source/print_tokens.exe  < ../inputs/uslin.1310 > ../outputs/t2197
echo ">>>>>>>>running test 2198"
../source/print_tokens.exe  < ../inputs/uslin.1311 > ../outputs/t2198
echo ">>>>>>>>running test 2199"
../source/print_tokens.exe  < ../inputs/uslin.1312 > ../outputs/t2199
echo ">>>>>>>>running test 2200"
../source/print_tokens.exe  < ../inputs/uslin.1313 > ../outputs/t2200
echo ">>>>>>>>running test 2201"
../source/print_tokens.exe  < ../inputs/uslin.1314 > ../outputs/t2201
echo ">>>>>>>>running test 2202"
../source/print_tokens.exe  < ../inputs/uslin.1315 > ../outputs/t2202
echo ">>>>>>>>running test 2203"
../source/print_tokens.exe  < ../inputs/uslin.1318 > ../outputs/t2203
echo ">>>>>>>>running test 2204"
../source/print_tokens.exe  < ../inputs/uslin.1319 > ../outputs/t2204
echo ">>>>>>>>running test 2205"
../source/print_tokens.exe  < ../inputs/uslin.1320 > ../outputs/t2205
echo ">>>>>>>>running test 2206"
../source/print_tokens.exe  < ../inputs/uslin.1323 > ../outputs/t2206
echo ">>>>>>>>running test 2207"
../source/print_tokens.exe  < ../inputs/uslin.1326 > ../outputs/t2207
echo ">>>>>>>>running test 2208"
../source/print_tokens.exe  < ../inputs/uslin.1329 > ../outputs/t2208
echo ">>>>>>>>running test 2209"
../source/print_tokens.exe  < ../inputs/uslin.133 > ../outputs/t2209
echo ">>>>>>>>running test 2210"
../source/print_tokens.exe  < ../inputs/uslin.1331 > ../outputs/t2210
echo ">>>>>>>>running test 2211"
../source/print_tokens.exe  < ../inputs/uslin.1332 > ../outputs/t2211
echo ">>>>>>>>running test 2212"
../source/print_tokens.exe  < ../inputs/uslin.1336 > ../outputs/t2212
echo ">>>>>>>>running test 2213"
../source/print_tokens.exe  < ../inputs/uslin.1338 > ../outputs/t2213
echo ">>>>>>>>running test 2214"
../source/print_tokens.exe  < ../inputs/uslin.1343 > ../outputs/t2214
echo ">>>>>>>>running test 2215"
../source/print_tokens.exe  < ../inputs/uslin.1344 > ../outputs/t2215
echo ">>>>>>>>running test 2216"
../source/print_tokens.exe  < ../inputs/uslin.1345 > ../outputs/t2216
echo ">>>>>>>>running test 2217"
../source/print_tokens.exe  < ../inputs/uslin.1347 > ../outputs/t2217
echo ">>>>>>>>running test 2218"
../source/print_tokens.exe  < ../inputs/uslin.1349 > ../outputs/t2218
echo ">>>>>>>>running test 2219"
../source/print_tokens.exe  < ../inputs/uslin.135 > ../outputs/t2219
echo ">>>>>>>>running test 2220"
../source/print_tokens.exe  < ../inputs/uslin.1350 > ../outputs/t2220
echo ">>>>>>>>running test 2221"
../source/print_tokens.exe  < ../inputs/uslin.1351 > ../outputs/t2221
echo ">>>>>>>>running test 2222"
../source/print_tokens.exe  < ../inputs/uslin.1355 > ../outputs/t2222
echo ">>>>>>>>running test 2223"
../source/print_tokens.exe  < ../inputs/uslin.1356 > ../outputs/t2223
echo ">>>>>>>>running test 2224"
../source/print_tokens.exe  < ../inputs/uslin.1357 > ../outputs/t2224
echo ">>>>>>>>running test 2225"
../source/print_tokens.exe  < ../inputs/uslin.136 > ../outputs/t2225
echo ">>>>>>>>running test 2226"
../source/print_tokens.exe  < ../inputs/uslin.1360 > ../outputs/t2226
echo ">>>>>>>>running test 2227"
../source/print_tokens.exe  < ../inputs/uslin.1361 > ../outputs/t2227
echo ">>>>>>>>running test 2228"
../source/print_tokens.exe  < ../inputs/uslin.1362 > ../outputs/t2228
echo ">>>>>>>>running test 2229"
../source/print_tokens.exe  < ../inputs/uslin.1363 > ../outputs/t2229
echo ">>>>>>>>running test 2230"
../source/print_tokens.exe  < ../inputs/uslin.1366 > ../outputs/t2230
echo ">>>>>>>>running test 2231"
../source/print_tokens.exe  < ../inputs/uslin.1367 > ../outputs/t2231
echo ">>>>>>>>running test 2232"
../source/print_tokens.exe  < ../inputs/uslin.1369 > ../outputs/t2232
echo ">>>>>>>>running test 2233"
../source/print_tokens.exe  < ../inputs/uslin.1372 > ../outputs/t2233
echo ">>>>>>>>running test 2234"
../source/print_tokens.exe  < ../inputs/uslin.1377 > ../outputs/t2234
echo ">>>>>>>>running test 2235"
../source/print_tokens.exe  < ../inputs/uslin.1381 > ../outputs/t2235
echo ">>>>>>>>running test 2236"
../source/print_tokens.exe  < ../inputs/uslin.1382 > ../outputs/t2236
echo ">>>>>>>>running test 2237"
../source/print_tokens.exe  < ../inputs/uslin.1383 > ../outputs/t2237
echo ">>>>>>>>running test 2238"
../source/print_tokens.exe  < ../inputs/uslin.1387 > ../outputs/t2238
echo ">>>>>>>>running test 2239"
../source/print_tokens.exe  < ../inputs/uslin.1388 > ../outputs/t2239
echo ">>>>>>>>running test 2240"
../source/print_tokens.exe  < ../inputs/uslin.1392 > ../outputs/t2240
echo ">>>>>>>>running test 2241"
../source/print_tokens.exe  < ../inputs/uslin.1393 > ../outputs/t2241
echo ">>>>>>>>running test 2242"
../source/print_tokens.exe  < ../inputs/uslin.1396 > ../outputs/t2242
echo ">>>>>>>>running test 2243"
../source/print_tokens.exe  < ../inputs/uslin.1397 > ../outputs/t2243
echo ">>>>>>>>running test 2244"
../source/print_tokens.exe  < ../inputs/uslin.140 > ../outputs/t2244
echo ">>>>>>>>running test 2245"
../source/print_tokens.exe  < ../inputs/uslin.1404 > ../outputs/t2245
echo ">>>>>>>>running test 2246"
../source/print_tokens.exe  < ../inputs/uslin.1405 > ../outputs/t2246
echo ">>>>>>>>running test 2247"
../source/print_tokens.exe  < ../inputs/uslin.1408 > ../outputs/t2247
echo ">>>>>>>>running test 2248"
../source/print_tokens.exe  < ../inputs/uslin.1409 > ../outputs/t2248
echo ">>>>>>>>running test 2249"
../source/print_tokens.exe  < ../inputs/uslin.1410 > ../outputs/t2249
echo ">>>>>>>>running test 2250"
../source/print_tokens.exe  < ../inputs/uslin.1413 > ../outputs/t2250
echo ">>>>>>>>running test 2251"
../source/print_tokens.exe  < ../inputs/uslin.1415 > ../outputs/t2251
echo ">>>>>>>>running test 2252"
../source/print_tokens.exe  < ../inputs/uslin.142 > ../outputs/t2252
echo ">>>>>>>>running test 2253"
../source/print_tokens.exe  < ../inputs/uslin.1420 > ../outputs/t2253
echo ">>>>>>>>running test 2254"
../source/print_tokens.exe  < ../inputs/uslin.1421 > ../outputs/t2254
echo ">>>>>>>>running test 2255"
../source/print_tokens.exe  < ../inputs/uslin.1424 > ../outputs/t2255
echo ">>>>>>>>running test 2256"
../source/print_tokens.exe  < ../inputs/uslin.1425 > ../outputs/t2256
echo ">>>>>>>>running test 2257"
../source/print_tokens.exe  < ../inputs/uslin.1429 > ../outputs/t2257
echo ">>>>>>>>running test 2258"
../source/print_tokens.exe  < ../inputs/uslin.143 > ../outputs/t2258
echo ">>>>>>>>running test 2259"
../source/print_tokens.exe  < ../inputs/uslin.1430 > ../outputs/t2259
echo ">>>>>>>>running test 2260"
../source/print_tokens.exe  < ../inputs/uslin.1437 > ../outputs/t2260
echo ">>>>>>>>running test 2261"
../source/print_tokens.exe  < ../inputs/uslin.1438 > ../outputs/t2261
echo ">>>>>>>>running test 2262"
../source/print_tokens.exe  < ../inputs/uslin.1439 > ../outputs/t2262
echo ">>>>>>>>running test 2263"
../source/print_tokens.exe  < ../inputs/uslin.1441 > ../outputs/t2263
echo ">>>>>>>>running test 2264"
../source/print_tokens.exe  < ../inputs/uslin.1443 > ../outputs/t2264
echo ">>>>>>>>running test 2265"
../source/print_tokens.exe  < ../inputs/uslin.145 > ../outputs/t2265
echo ">>>>>>>>running test 2266"
../source/print_tokens.exe  < ../inputs/uslin.1455 > ../outputs/t2266
echo ">>>>>>>>running test 2267"
../source/print_tokens.exe  < ../inputs/uslin.1457 > ../outputs/t2267
echo ">>>>>>>>running test 2268"
../source/print_tokens.exe  < ../inputs/uslin.1459 > ../outputs/t2268
echo ">>>>>>>>running test 2269"
../source/print_tokens.exe  < ../inputs/uslin.1461 > ../outputs/t2269
echo ">>>>>>>>running test 2270"
../source/print_tokens.exe  < ../inputs/uslin.1468 > ../outputs/t2270
echo ">>>>>>>>running test 2271"
../source/print_tokens.exe  < ../inputs/uslin.1469 > ../outputs/t2271
echo ">>>>>>>>running test 2272"
../source/print_tokens.exe  < ../inputs/uslin.147 > ../outputs/t2272
echo ">>>>>>>>running test 2273"
../source/print_tokens.exe  < ../inputs/uslin.1470 > ../outputs/t2273
echo ">>>>>>>>running test 2274"
../source/print_tokens.exe  < ../inputs/uslin.1475 > ../outputs/t2274
echo ">>>>>>>>running test 2275"
../source/print_tokens.exe  < ../inputs/uslin.1476 > ../outputs/t2275
echo ">>>>>>>>running test 2276"
../source/print_tokens.exe  < ../inputs/uslin.1480 > ../outputs/t2276
echo ">>>>>>>>running test 2277"
../source/print_tokens.exe  < ../inputs/uslin.1483 > ../outputs/t2277
echo ">>>>>>>>running test 2278"
../source/print_tokens.exe  < ../inputs/uslin.1486 > ../outputs/t2278
echo ">>>>>>>>running test 2279"
../source/print_tokens.exe  < ../inputs/uslin.1491 > ../outputs/t2279
echo ">>>>>>>>running test 2280"
../source/print_tokens.exe  < ../inputs/uslin.1492 > ../outputs/t2280
echo ">>>>>>>>running test 2281"
../source/print_tokens.exe  < ../inputs/uslin.1493 > ../outputs/t2281
echo ">>>>>>>>running test 2282"
../source/print_tokens.exe  < ../inputs/uslin.1494 > ../outputs/t2282
echo ">>>>>>>>running test 2283"
../source/print_tokens.exe  < ../inputs/uslin.1496 > ../outputs/t2283
echo ">>>>>>>>running test 2284"
../source/print_tokens.exe  < ../inputs/uslin.1497 > ../outputs/t2284
echo ">>>>>>>>running test 2285"
../source/print_tokens.exe  < ../inputs/uslin.15 > ../outputs/t2285
echo ">>>>>>>>running test 2286"
../source/print_tokens.exe  < ../inputs/uslin.1501 > ../outputs/t2286
echo ">>>>>>>>running test 2287"
../source/print_tokens.exe  < ../inputs/uslin.1502 > ../outputs/t2287
echo ">>>>>>>>running test 2288"
../source/print_tokens.exe  < ../inputs/uslin.1504 > ../outputs/t2288
echo ">>>>>>>>running test 2289"
../source/print_tokens.exe  < ../inputs/uslin.1509 > ../outputs/t2289
echo ">>>>>>>>running test 2290"
../source/print_tokens.exe  < ../inputs/uslin.151 > ../outputs/t2290
echo ">>>>>>>>running test 2291"
../source/print_tokens.exe  < ../inputs/uslin.1510 > ../outputs/t2291
echo ">>>>>>>>running test 2292"
../source/print_tokens.exe  < ../inputs/uslin.1516 > ../outputs/t2292
echo ">>>>>>>>running test 2293"
../source/print_tokens.exe  < ../inputs/uslin.1517 > ../outputs/t2293
echo ">>>>>>>>running test 2294"
../source/print_tokens.exe  < ../inputs/uslin.1518 > ../outputs/t2294
echo ">>>>>>>>running test 2295"
../source/print_tokens.exe  < ../inputs/uslin.1519 > ../outputs/t2295
echo ">>>>>>>>running test 2296"
../source/print_tokens.exe  < ../inputs/uslin.1524 > ../outputs/t2296
echo ">>>>>>>>running test 2297"
../source/print_tokens.exe  < ../inputs/uslin.1525 > ../outputs/t2297
echo ">>>>>>>>running test 2298"
../source/print_tokens.exe  < ../inputs/uslin.1526 > ../outputs/t2298
echo ">>>>>>>>running test 2299"
../source/print_tokens.exe  < ../inputs/uslin.1527 > ../outputs/t2299
echo ">>>>>>>>running test 2300"
../source/print_tokens.exe  < ../inputs/uslin.1529 > ../outputs/t2300
echo ">>>>>>>>running test 2301"
../source/print_tokens.exe  < ../inputs/uslin.153 > ../outputs/t2301
echo ">>>>>>>>running test 2302"
../source/print_tokens.exe  < ../inputs/uslin.1530 > ../outputs/t2302
echo ">>>>>>>>running test 2303"
../source/print_tokens.exe  < ../inputs/uslin.1532 > ../outputs/t2303
echo ">>>>>>>>running test 2304"
../source/print_tokens.exe  < ../inputs/uslin.1534 > ../outputs/t2304
echo ">>>>>>>>running test 2305"
../source/print_tokens.exe  < ../inputs/uslin.1538 > ../outputs/t2305
echo ">>>>>>>>running test 2306"
../source/print_tokens.exe  < ../inputs/uslin.1539 > ../outputs/t2306
echo ">>>>>>>>running test 2307"
../source/print_tokens.exe  < ../inputs/uslin.154 > ../outputs/t2307
echo ">>>>>>>>running test 2308"
../source/print_tokens.exe  < ../inputs/uslin.1541 > ../outputs/t2308
echo ">>>>>>>>running test 2309"
../source/print_tokens.exe  < ../inputs/uslin.1542 > ../outputs/t2309
echo ">>>>>>>>running test 2310"
../source/print_tokens.exe  < ../inputs/uslin.1546 > ../outputs/t2310
echo ">>>>>>>>running test 2311"
../source/print_tokens.exe  < ../inputs/uslin.1549 > ../outputs/t2311
echo ">>>>>>>>running test 2312"
../source/print_tokens.exe  < ../inputs/uslin.155 > ../outputs/t2312
echo ">>>>>>>>running test 2313"
../source/print_tokens.exe  < ../inputs/uslin.1551 > ../outputs/t2313
echo ">>>>>>>>running test 2314"
../source/print_tokens.exe  < ../inputs/uslin.1554 > ../outputs/t2314
echo ">>>>>>>>running test 2315"
../source/print_tokens.exe  < ../inputs/uslin.1556 > ../outputs/t2315
echo ">>>>>>>>running test 2316"
../source/print_tokens.exe  < ../inputs/uslin.1557 > ../outputs/t2316
echo ">>>>>>>>running test 2317"
../source/print_tokens.exe  < ../inputs/uslin.1559 > ../outputs/t2317
echo ">>>>>>>>running test 2318"
../source/print_tokens.exe  < ../inputs/uslin.1562 > ../outputs/t2318
echo ">>>>>>>>running test 2319"
../source/print_tokens.exe  < ../inputs/uslin.1563 > ../outputs/t2319
echo ">>>>>>>>running test 2320"
../source/print_tokens.exe  < ../inputs/uslin.1565 > ../outputs/t2320
echo ">>>>>>>>running test 2321"
../source/print_tokens.exe  < ../inputs/uslin.1566 > ../outputs/t2321
echo ">>>>>>>>running test 2322"
../source/print_tokens.exe  < ../inputs/uslin.1567 > ../outputs/t2322
echo ">>>>>>>>running test 2323"
../source/print_tokens.exe  < ../inputs/uslin.1569 > ../outputs/t2323
echo ">>>>>>>>running test 2324"
../source/print_tokens.exe  < ../inputs/uslin.157 > ../outputs/t2324
echo ">>>>>>>>running test 2325"
../source/print_tokens.exe  < ../inputs/uslin.1570 > ../outputs/t2325
echo ">>>>>>>>running test 2326"
../source/print_tokens.exe  < ../inputs/uslin.1572 > ../outputs/t2326
echo ">>>>>>>>running test 2327"
../source/print_tokens.exe  < ../inputs/uslin.1576 > ../outputs/t2327
echo ">>>>>>>>running test 2328"
../source/print_tokens.exe  < ../inputs/uslin.1578 > ../outputs/t2328
echo ">>>>>>>>running test 2329"
../source/print_tokens.exe  < ../inputs/uslin.1579 > ../outputs/t2329
echo ">>>>>>>>running test 2330"
../source/print_tokens.exe  < ../inputs/uslin.1584 > ../outputs/t2330
echo ">>>>>>>>running test 2331"
../source/print_tokens.exe  < ../inputs/uslin.1587 > ../outputs/t2331
echo ">>>>>>>>running test 2332"
../source/print_tokens.exe  < ../inputs/uslin.1588 > ../outputs/t2332
echo ">>>>>>>>running test 2333"
../source/print_tokens.exe  < ../inputs/uslin.1589 > ../outputs/t2333
echo ">>>>>>>>running test 2334"
../source/print_tokens.exe  < ../inputs/uslin.1593 > ../outputs/t2334
echo ">>>>>>>>running test 2335"
../source/print_tokens.exe  < ../inputs/uslin.1596 > ../outputs/t2335
echo ">>>>>>>>running test 2336"
../source/print_tokens.exe  < ../inputs/uslin.1598 > ../outputs/t2336
echo ">>>>>>>>running test 2337"
../source/print_tokens.exe  < ../inputs/uslin.1599 > ../outputs/t2337
echo ">>>>>>>>running test 2338"
../source/print_tokens.exe  < ../inputs/uslin.16 > ../outputs/t2338
echo ">>>>>>>>running test 2339"
../source/print_tokens.exe  < ../inputs/uslin.160 > ../outputs/t2339
echo ">>>>>>>>running test 2340"
../source/print_tokens.exe  < ../inputs/uslin.1600 > ../outputs/t2340
echo ">>>>>>>>running test 2341"
../source/print_tokens.exe  < ../inputs/uslin.1604 > ../outputs/t2341
echo ">>>>>>>>running test 2342"
../source/print_tokens.exe  < ../inputs/uslin.1605 > ../outputs/t2342
echo ">>>>>>>>running test 2343"
../source/print_tokens.exe  < ../inputs/uslin.1609 > ../outputs/t2343
echo ">>>>>>>>running test 2344"
../source/print_tokens.exe  < ../inputs/uslin.161 > ../outputs/t2344
echo ">>>>>>>>running test 2345"
../source/print_tokens.exe  < ../inputs/uslin.1611 > ../outputs/t2345
echo ">>>>>>>>running test 2346"
../source/print_tokens.exe  < ../inputs/uslin.1612 > ../outputs/t2346
echo ">>>>>>>>running test 2347"
../source/print_tokens.exe  < ../inputs/uslin.1613 > ../outputs/t2347
echo ">>>>>>>>running test 2348"
../source/print_tokens.exe  < ../inputs/uslin.1615 > ../outputs/t2348
echo ">>>>>>>>running test 2349"
../source/print_tokens.exe  < ../inputs/uslin.1616 > ../outputs/t2349
echo ">>>>>>>>running test 2350"
../source/print_tokens.exe  < ../inputs/uslin.162 > ../outputs/t2350
echo ">>>>>>>>running test 2351"
../source/print_tokens.exe  < ../inputs/uslin.1621 > ../outputs/t2351
echo ">>>>>>>>running test 2352"
../source/print_tokens.exe  < ../inputs/uslin.1622 > ../outputs/t2352
echo ">>>>>>>>running test 2353"
../source/print_tokens.exe  < ../inputs/uslin.1627 > ../outputs/t2353
echo ">>>>>>>>running test 2354"
../source/print_tokens.exe  < ../inputs/uslin.1628 > ../outputs/t2354
echo ">>>>>>>>running test 2355"
../source/print_tokens.exe  < ../inputs/uslin.163 > ../outputs/t2355
echo ">>>>>>>>running test 2356"
../source/print_tokens.exe  < ../inputs/uslin.1633 > ../outputs/t2356
echo ">>>>>>>>running test 2357"
../source/print_tokens.exe  < ../inputs/uslin.1636 > ../outputs/t2357
echo ">>>>>>>>running test 2358"
../source/print_tokens.exe  < ../inputs/uslin.1639 > ../outputs/t2358
echo ">>>>>>>>running test 2359"
../source/print_tokens.exe  < ../inputs/uslin.164 > ../outputs/t2359
echo ">>>>>>>>running test 2360"
../source/print_tokens.exe  < ../inputs/uslin.1640 > ../outputs/t2360
echo ">>>>>>>>running test 2361"
../source/print_tokens.exe  < ../inputs/uslin.1642 > ../outputs/t2361
echo ">>>>>>>>running test 2362"
../source/print_tokens.exe  < ../inputs/uslin.1643 > ../outputs/t2362
echo ">>>>>>>>running test 2363"
../source/print_tokens.exe  < ../inputs/uslin.1647 > ../outputs/t2363
echo ">>>>>>>>running test 2364"
../source/print_tokens.exe  < ../inputs/uslin.1648 > ../outputs/t2364
echo ">>>>>>>>running test 2365"
../source/print_tokens.exe  < ../inputs/uslin.1649 > ../outputs/t2365
echo ">>>>>>>>running test 2366"
../source/print_tokens.exe  < ../inputs/uslin.1650 > ../outputs/t2366
echo ">>>>>>>>running test 2367"
../source/print_tokens.exe  < ../inputs/uslin.1658 > ../outputs/t2367
echo ">>>>>>>>running test 2368"
../source/print_tokens.exe  < ../inputs/uslin.1659 > ../outputs/t2368
echo ">>>>>>>>running test 2369"
../source/print_tokens.exe  < ../inputs/uslin.1660 > ../outputs/t2369
echo ">>>>>>>>running test 2370"
../source/print_tokens.exe  < ../inputs/uslin.1666 > ../outputs/t2370
echo ">>>>>>>>running test 2371"
../source/print_tokens.exe  < ../inputs/uslin.1667 > ../outputs/t2371
echo ">>>>>>>>running test 2372"
../source/print_tokens.exe  < ../inputs/uslin.1668 > ../outputs/t2372
echo ">>>>>>>>running test 2373"
../source/print_tokens.exe  < ../inputs/uslin.1669 > ../outputs/t2373
echo ">>>>>>>>running test 2374"
../source/print_tokens.exe  < ../inputs/uslin.1670 > ../outputs/t2374
echo ">>>>>>>>running test 2375"
../source/print_tokens.exe  < ../inputs/uslin.1671 > ../outputs/t2375
echo ">>>>>>>>running test 2376"
../source/print_tokens.exe  < ../inputs/uslin.1672 > ../outputs/t2376
echo ">>>>>>>>running test 2377"
../source/print_tokens.exe  < ../inputs/uslin.1675 > ../outputs/t2377
echo ">>>>>>>>running test 2378"
../source/print_tokens.exe  < ../inputs/uslin.1676 > ../outputs/t2378
echo ">>>>>>>>running test 2379"
../source/print_tokens.exe  < ../inputs/uslin.1679 > ../outputs/t2379
echo ">>>>>>>>running test 2380"
../source/print_tokens.exe  < ../inputs/uslin.1681 > ../outputs/t2380
echo ">>>>>>>>running test 2381"
../source/print_tokens.exe  < ../inputs/uslin.1686 > ../outputs/t2381
echo ">>>>>>>>running test 2382"
../source/print_tokens.exe  < ../inputs/uslin.169 > ../outputs/t2382
echo ">>>>>>>>running test 2383"
../source/print_tokens.exe  < ../inputs/uslin.1691 > ../outputs/t2383
echo ">>>>>>>>running test 2384"
../source/print_tokens.exe  < ../inputs/uslin.1694 > ../outputs/t2384
echo ">>>>>>>>running test 2385"
../source/print_tokens.exe  < ../inputs/uslin.1695 > ../outputs/t2385
echo ">>>>>>>>running test 2386"
../source/print_tokens.exe  < ../inputs/uslin.1698 > ../outputs/t2386
echo ">>>>>>>>running test 2387"
../source/print_tokens.exe  < ../inputs/uslin.17 > ../outputs/t2387
echo ">>>>>>>>running test 2388"
../source/print_tokens.exe  < ../inputs/uslin.170 > ../outputs/t2388
echo ">>>>>>>>running test 2389"
../source/print_tokens.exe  < ../inputs/uslin.1702 > ../outputs/t2389
echo ">>>>>>>>running test 2390"
../source/print_tokens.exe  < ../inputs/uslin.1707 > ../outputs/t2390
echo ">>>>>>>>running test 2391"
../source/print_tokens.exe  < ../inputs/uslin.171 > ../outputs/t2391
echo ">>>>>>>>running test 2392"
../source/print_tokens.exe  < ../inputs/uslin.1710 > ../outputs/t2392
echo ">>>>>>>>running test 2393"
../source/print_tokens.exe  < ../inputs/uslin.1711 > ../outputs/t2393
echo ">>>>>>>>running test 2394"
../source/print_tokens.exe  < ../inputs/uslin.1712 > ../outputs/t2394
echo ">>>>>>>>running test 2395"
../source/print_tokens.exe  < ../inputs/uslin.1716 > ../outputs/t2395
echo ">>>>>>>>running test 2396"
../source/print_tokens.exe  < ../inputs/uslin.1724 > ../outputs/t2396
echo ">>>>>>>>running test 2397"
../source/print_tokens.exe  < ../inputs/uslin.1730 > ../outputs/t2397
echo ">>>>>>>>running test 2398"
../source/print_tokens.exe  < ../inputs/uslin.1735 > ../outputs/t2398
echo ">>>>>>>>running test 2399"
../source/print_tokens.exe  < ../inputs/uslin.1737 > ../outputs/t2399
echo ">>>>>>>>running test 2400"
../source/print_tokens.exe  < ../inputs/uslin.1738 > ../outputs/t2400
echo ">>>>>>>>running test 2401"
../source/print_tokens.exe  < ../inputs/uslin.1740 > ../outputs/t2401
echo ">>>>>>>>running test 2402"
../source/print_tokens.exe  < ../inputs/uslin.1742 > ../outputs/t2402
echo ">>>>>>>>running test 2403"
../source/print_tokens.exe  < ../inputs/uslin.1744 > ../outputs/t2403
echo ">>>>>>>>running test 2404"
../source/print_tokens.exe  < ../inputs/uslin.175 > ../outputs/t2404
echo ">>>>>>>>running test 2405"
../source/print_tokens.exe  < ../inputs/uslin.1753 > ../outputs/t2405
echo ">>>>>>>>running test 2406"
../source/print_tokens.exe  < ../inputs/uslin.1754 > ../outputs/t2406
echo ">>>>>>>>running test 2407"
../source/print_tokens.exe  < ../inputs/uslin.1755 > ../outputs/t2407
echo ">>>>>>>>running test 2408"
../source/print_tokens.exe  < ../inputs/uslin.1756 > ../outputs/t2408
echo ">>>>>>>>running test 2409"
../source/print_tokens.exe  < ../inputs/uslin.176 > ../outputs/t2409
echo ">>>>>>>>running test 2410"
../source/print_tokens.exe  < ../inputs/uslin.1760 > ../outputs/t2410
echo ">>>>>>>>running test 2411"
../source/print_tokens.exe  < ../inputs/uslin.1762 > ../outputs/t2411
echo ">>>>>>>>running test 2412"
../source/print_tokens.exe  < ../inputs/uslin.1764 > ../outputs/t2412
echo ">>>>>>>>running test 2413"
../source/print_tokens.exe  < ../inputs/uslin.177 > ../outputs/t2413
echo ">>>>>>>>running test 2414"
../source/print_tokens.exe  < ../inputs/uslin.1771 > ../outputs/t2414
echo ">>>>>>>>running test 2415"
../source/print_tokens.exe  < ../inputs/uslin.1773 > ../outputs/t2415
echo ">>>>>>>>running test 2416"
../source/print_tokens.exe  < ../inputs/uslin.1774 > ../outputs/t2416
echo ">>>>>>>>running test 2417"
../source/print_tokens.exe  < ../inputs/uslin.1776 > ../outputs/t2417
echo ">>>>>>>>running test 2418"
../source/print_tokens.exe  < ../inputs/uslin.1778 > ../outputs/t2418
echo ">>>>>>>>running test 2419"
../source/print_tokens.exe  < ../inputs/uslin.1782 > ../outputs/t2419
echo ">>>>>>>>running test 2420"
../source/print_tokens.exe  < ../inputs/uslin.1783 > ../outputs/t2420
echo ">>>>>>>>running test 2421"
../source/print_tokens.exe  < ../inputs/uslin.1785 > ../outputs/t2421
echo ">>>>>>>>running test 2422"
../source/print_tokens.exe  < ../inputs/uslin.1787 > ../outputs/t2422
echo ">>>>>>>>running test 2423"
../source/print_tokens.exe  < ../inputs/uslin.1789 > ../outputs/t2423
echo ">>>>>>>>running test 2424"
../source/print_tokens.exe  < ../inputs/uslin.1792 > ../outputs/t2424
echo ">>>>>>>>running test 2425"
../source/print_tokens.exe  < ../inputs/uslin.1793 > ../outputs/t2425
echo ">>>>>>>>running test 2426"
../source/print_tokens.exe  < ../inputs/uslin.1794 > ../outputs/t2426
echo ">>>>>>>>running test 2427"
../source/print_tokens.exe  < ../inputs/uslin.1798 > ../outputs/t2427
echo ">>>>>>>>running test 2428"
../source/print_tokens.exe  < ../inputs/uslin.1800 > ../outputs/t2428
echo ">>>>>>>>running test 2429"
../source/print_tokens.exe  < ../inputs/uslin.1802 > ../outputs/t2429
echo ">>>>>>>>running test 2430"
../source/print_tokens.exe  < ../inputs/uslin.1806 > ../outputs/t2430
echo ">>>>>>>>running test 2431"
../source/print_tokens.exe  < ../inputs/uslin.1809 > ../outputs/t2431
echo ">>>>>>>>running test 2432"
../source/print_tokens.exe  < ../inputs/uslin.1812 > ../outputs/t2432
echo ">>>>>>>>running test 2433"
../source/print_tokens.exe  < ../inputs/uslin.1814 > ../outputs/t2433
echo ">>>>>>>>running test 2434"
../source/print_tokens.exe  < ../inputs/uslin.1816 > ../outputs/t2434
echo ">>>>>>>>running test 2435"
../source/print_tokens.exe  < ../inputs/uslin.1818 > ../outputs/t2435
echo ">>>>>>>>running test 2436"
../source/print_tokens.exe  < ../inputs/uslin.1819 > ../outputs/t2436
echo ">>>>>>>>running test 2437"
../source/print_tokens.exe  < ../inputs/uslin.182 > ../outputs/t2437
echo ">>>>>>>>running test 2438"
../source/print_tokens.exe  < ../inputs/uslin.1821 > ../outputs/t2438
echo ">>>>>>>>running test 2439"
../source/print_tokens.exe  < ../inputs/uslin.1823 > ../outputs/t2439
echo ">>>>>>>>running test 2440"
../source/print_tokens.exe  < ../inputs/uslin.1827 > ../outputs/t2440
echo ">>>>>>>>running test 2441"
../source/print_tokens.exe  < ../inputs/uslin.1829 > ../outputs/t2441
echo ">>>>>>>>running test 2442"
../source/print_tokens.exe  < ../inputs/uslin.1830 > ../outputs/t2442
echo ">>>>>>>>running test 2443"
../source/print_tokens.exe  < ../inputs/uslin.1832 > ../outputs/t2443
echo ">>>>>>>>running test 2444"
../source/print_tokens.exe  < ../inputs/uslin.1835 > ../outputs/t2444
echo ">>>>>>>>running test 2445"
../source/print_tokens.exe  < ../inputs/uslin.1836 > ../outputs/t2445
echo ">>>>>>>>running test 2446"
../source/print_tokens.exe  < ../inputs/uslin.1837 > ../outputs/t2446
echo ">>>>>>>>running test 2447"
../source/print_tokens.exe  < ../inputs/uslin.1838 > ../outputs/t2447
echo ">>>>>>>>running test 2448"
../source/print_tokens.exe  < ../inputs/uslin.1839 > ../outputs/t2448
echo ">>>>>>>>running test 2449"
../source/print_tokens.exe  < ../inputs/uslin.184 > ../outputs/t2449
echo ">>>>>>>>running test 2450"
../source/print_tokens.exe  < ../inputs/uslin.1845 > ../outputs/t2450
echo ">>>>>>>>running test 2451"
../source/print_tokens.exe  < ../inputs/uslin.1847 > ../outputs/t2451
echo ">>>>>>>>running test 2452"
../source/print_tokens.exe  < ../inputs/uslin.1848 > ../outputs/t2452
echo ">>>>>>>>running test 2453"
../source/print_tokens.exe  < ../inputs/uslin.185 > ../outputs/t2453
echo ">>>>>>>>running test 2454"
../source/print_tokens.exe  < ../inputs/uslin.1850 > ../outputs/t2454
echo ">>>>>>>>running test 2455"
../source/print_tokens.exe  < ../inputs/uslin.1855 > ../outputs/t2455
echo ">>>>>>>>running test 2456"
../source/print_tokens.exe  < ../inputs/uslin.1856 > ../outputs/t2456
echo ">>>>>>>>running test 2457"
../source/print_tokens.exe  < ../inputs/uslin.1858 > ../outputs/t2457
echo ">>>>>>>>running test 2458"
../source/print_tokens.exe  < ../inputs/uslin.1862 > ../outputs/t2458
echo ">>>>>>>>running test 2459"
../source/print_tokens.exe  < ../inputs/uslin.1863 > ../outputs/t2459
echo ">>>>>>>>running test 2460"
../source/print_tokens.exe  < ../inputs/uslin.1865 > ../outputs/t2460
echo ">>>>>>>>running test 2461"
../source/print_tokens.exe  < ../inputs/uslin.1871 > ../outputs/t2461
echo ">>>>>>>>running test 2462"
../source/print_tokens.exe  < ../inputs/uslin.1872 > ../outputs/t2462
echo ">>>>>>>>running test 2463"
../source/print_tokens.exe  < ../inputs/uslin.1873 > ../outputs/t2463
echo ">>>>>>>>running test 2464"
../source/print_tokens.exe  < ../inputs/uslin.1874 > ../outputs/t2464
echo ">>>>>>>>running test 2465"
../source/print_tokens.exe  < ../inputs/uslin.1876 > ../outputs/t2465
echo ">>>>>>>>running test 2466"
../source/print_tokens.exe  < ../inputs/uslin.1877 > ../outputs/t2466
echo ">>>>>>>>running test 2467"
../source/print_tokens.exe  < ../inputs/uslin.1878 > ../outputs/t2467
echo ">>>>>>>>running test 2468"
../source/print_tokens.exe  < ../inputs/uslin.188 > ../outputs/t2468
echo ">>>>>>>>running test 2469"
../source/print_tokens.exe  < ../inputs/uslin.1880 > ../outputs/t2469
echo ">>>>>>>>running test 2470"
../source/print_tokens.exe  < ../inputs/uslin.1881 > ../outputs/t2470
echo ">>>>>>>>running test 2471"
../source/print_tokens.exe  < ../inputs/uslin.1882 > ../outputs/t2471
echo ">>>>>>>>running test 2472"
../source/print_tokens.exe  < ../inputs/uslin.1885 > ../outputs/t2472
echo ">>>>>>>>running test 2473"
../source/print_tokens.exe  < ../inputs/uslin.1886 > ../outputs/t2473
echo ">>>>>>>>running test 2474"
../source/print_tokens.exe  < ../inputs/uslin.1887 > ../outputs/t2474
echo ">>>>>>>>running test 2475"
../source/print_tokens.exe  < ../inputs/uslin.189 > ../outputs/t2475
echo ">>>>>>>>running test 2476"
../source/print_tokens.exe  < ../inputs/uslin.1891 > ../outputs/t2476
echo ">>>>>>>>running test 2477"
../source/print_tokens.exe  < ../inputs/uslin.1892 > ../outputs/t2477
echo ">>>>>>>>running test 2478"
../source/print_tokens.exe  < ../inputs/uslin.1893 > ../outputs/t2478
echo ">>>>>>>>running test 2479"
../source/print_tokens.exe  < ../inputs/uslin.1895 > ../outputs/t2479
echo ">>>>>>>>running test 2480"
../source/print_tokens.exe  < ../inputs/uslin.1896 > ../outputs/t2480
echo ">>>>>>>>running test 2481"
../source/print_tokens.exe  < ../inputs/uslin.1897 > ../outputs/t2481
echo ">>>>>>>>running test 2482"
../source/print_tokens.exe  < ../inputs/uslin.1898 > ../outputs/t2482
echo ">>>>>>>>running test 2483"
../source/print_tokens.exe  < ../inputs/uslin.190 > ../outputs/t2483
echo ">>>>>>>>running test 2484"
../source/print_tokens.exe  < ../inputs/uslin.1903 > ../outputs/t2484
echo ">>>>>>>>running test 2485"
../source/print_tokens.exe  < ../inputs/uslin.1905 > ../outputs/t2485
echo ">>>>>>>>running test 2486"
../source/print_tokens.exe  < ../inputs/uslin.1907 > ../outputs/t2486
echo ">>>>>>>>running test 2487"
../source/print_tokens.exe  < ../inputs/uslin.1908 > ../outputs/t2487
echo ">>>>>>>>running test 2488"
../source/print_tokens.exe  < ../inputs/uslin.191 > ../outputs/t2488
echo ">>>>>>>>running test 2489"
../source/print_tokens.exe  < ../inputs/uslin.1912 > ../outputs/t2489
echo ">>>>>>>>running test 2490"
../source/print_tokens.exe  < ../inputs/uslin.1913 > ../outputs/t2490
echo ">>>>>>>>running test 2491"
../source/print_tokens.exe  < ../inputs/uslin.1914 > ../outputs/t2491
echo ">>>>>>>>running test 2492"
../source/print_tokens.exe  < ../inputs/uslin.1916 > ../outputs/t2492
echo ">>>>>>>>running test 2493"
../source/print_tokens.exe  < ../inputs/uslin.1917 > ../outputs/t2493
echo ">>>>>>>>running test 2494"
../source/print_tokens.exe  < ../inputs/uslin.1918 > ../outputs/t2494
echo ">>>>>>>>running test 2495"
../source/print_tokens.exe  < ../inputs/uslin.1920 > ../outputs/t2495
echo ">>>>>>>>running test 2496"
../source/print_tokens.exe  < ../inputs/uslin.1922 > ../outputs/t2496
echo ">>>>>>>>running test 2497"
../source/print_tokens.exe  < ../inputs/uslin.1924 > ../outputs/t2497
echo ">>>>>>>>running test 2498"
../source/print_tokens.exe  < ../inputs/uslin.1925 > ../outputs/t2498
echo ">>>>>>>>running test 2499"
../source/print_tokens.exe  < ../inputs/uslin.1926 > ../outputs/t2499
echo ">>>>>>>>running test 2500"
../source/print_tokens.exe  < ../inputs/uslin.1929 > ../outputs/t2500
echo ">>>>>>>>running test 2501"
../source/print_tokens.exe  < ../inputs/uslin.193 > ../outputs/t2501
echo ">>>>>>>>running test 2502"
../source/print_tokens.exe  < ../inputs/uslin.1931 > ../outputs/t2502
echo ">>>>>>>>running test 2503"
../source/print_tokens.exe  < ../inputs/uslin.1932 > ../outputs/t2503
echo ">>>>>>>>running test 2504"
../source/print_tokens.exe  < ../inputs/uslin.1934 > ../outputs/t2504
echo ">>>>>>>>running test 2505"
../source/print_tokens.exe  < ../inputs/uslin.1935 > ../outputs/t2505
echo ">>>>>>>>running test 2506"
../source/print_tokens.exe  < ../inputs/uslin.1936 > ../outputs/t2506
echo ">>>>>>>>running test 2507"
../source/print_tokens.exe  < ../inputs/uslin.1937 > ../outputs/t2507
echo ">>>>>>>>running test 2508"
../source/print_tokens.exe  < ../inputs/uslin.1938 > ../outputs/t2508
echo ">>>>>>>>running test 2509"
../source/print_tokens.exe  < ../inputs/uslin.1944 > ../outputs/t2509
echo ">>>>>>>>running test 2510"
../source/print_tokens.exe  < ../inputs/uslin.1945 > ../outputs/t2510
echo ">>>>>>>>running test 2511"
../source/print_tokens.exe  < ../inputs/uslin.1946 > ../outputs/t2511
echo ">>>>>>>>running test 2512"
../source/print_tokens.exe  < ../inputs/uslin.1947 > ../outputs/t2512
echo ">>>>>>>>running test 2513"
../source/print_tokens.exe  < ../inputs/uslin.1948 > ../outputs/t2513
echo ">>>>>>>>running test 2514"
../source/print_tokens.exe  < ../inputs/uslin.195 > ../outputs/t2514
echo ">>>>>>>>running test 2515"
../source/print_tokens.exe  < ../inputs/uslin.1950 > ../outputs/t2515
echo ">>>>>>>>running test 2516"
../source/print_tokens.exe  < ../inputs/uslin.1955 > ../outputs/t2516
echo ">>>>>>>>running test 2517"
../source/print_tokens.exe  < ../inputs/uslin.1958 > ../outputs/t2517
echo ">>>>>>>>running test 2518"
../source/print_tokens.exe  < ../inputs/uslin.1959 > ../outputs/t2518
echo ">>>>>>>>running test 2519"
../source/print_tokens.exe  < ../inputs/uslin.1961 > ../outputs/t2519
echo ">>>>>>>>running test 2520"
../source/print_tokens.exe  < ../inputs/uslin.1964 > ../outputs/t2520
echo ">>>>>>>>running test 2521"
../source/print_tokens.exe  < ../inputs/uslin.1970 > ../outputs/t2521
echo ">>>>>>>>running test 2522"
../source/print_tokens.exe  < ../inputs/uslin.1972 > ../outputs/t2522
echo ">>>>>>>>running test 2523"
../source/print_tokens.exe  < ../inputs/uslin.1974 > ../outputs/t2523
echo ">>>>>>>>running test 2524"
../source/print_tokens.exe  < ../inputs/uslin.1975 > ../outputs/t2524
echo ">>>>>>>>running test 2525"
../source/print_tokens.exe  < ../inputs/uslin.1979 > ../outputs/t2525
echo ">>>>>>>>running test 2526"
../source/print_tokens.exe  < ../inputs/uslin.1984 > ../outputs/t2526
echo ">>>>>>>>running test 2527"
../source/print_tokens.exe  < ../inputs/uslin.1985 > ../outputs/t2527
echo ">>>>>>>>running test 2528"
../source/print_tokens.exe  < ../inputs/uslin.1988 > ../outputs/t2528
echo ">>>>>>>>running test 2529"
../source/print_tokens.exe  < ../inputs/uslin.1989 > ../outputs/t2529
echo ">>>>>>>>running test 2530"
../source/print_tokens.exe  < ../inputs/uslin.1990 > ../outputs/t2530
echo ">>>>>>>>running test 2531"
../source/print_tokens.exe  < ../inputs/uslin.1995 > ../outputs/t2531
echo ">>>>>>>>running test 2532"
../source/print_tokens.exe  < ../inputs/uslin.1997 > ../outputs/t2532
echo ">>>>>>>>running test 2533"
../source/print_tokens.exe  < ../inputs/uslin.1998 > ../outputs/t2533
echo ">>>>>>>>running test 2534"
../source/print_tokens.exe  < ../inputs/uslin.1999 > ../outputs/t2534
echo ">>>>>>>>running test 2535"
../source/print_tokens.exe  < ../inputs/uslin.20 > ../outputs/t2535
echo ">>>>>>>>running test 2536"
../source/print_tokens.exe  < ../inputs/uslin.2000 > ../outputs/t2536
echo ">>>>>>>>running test 2537"
../source/print_tokens.exe  < ../inputs/uslin.201 > ../outputs/t2537
echo ">>>>>>>>running test 2538"
../source/print_tokens.exe  < ../inputs/uslin.204 > ../outputs/t2538
echo ">>>>>>>>running test 2539"
../source/print_tokens.exe  < ../inputs/uslin.206 > ../outputs/t2539
echo ">>>>>>>>running test 2540"
../source/print_tokens.exe  < ../inputs/uslin.207 > ../outputs/t2540
echo ">>>>>>>>running test 2541"
../source/print_tokens.exe  < ../inputs/uslin.208 > ../outputs/t2541
echo ">>>>>>>>running test 2542"
../source/print_tokens.exe  < ../inputs/uslin.209 > ../outputs/t2542
echo ">>>>>>>>running test 2543"
../source/print_tokens.exe  < ../inputs/uslin.21 > ../outputs/t2543
echo ">>>>>>>>running test 2544"
../source/print_tokens.exe  < ../inputs/uslin.210 > ../outputs/t2544
echo ">>>>>>>>running test 2545"
../source/print_tokens.exe  < ../inputs/uslin.213 > ../outputs/t2545
echo ">>>>>>>>running test 2546"
../source/print_tokens.exe  < ../inputs/uslin.214 > ../outputs/t2546
echo ">>>>>>>>running test 2547"
../source/print_tokens.exe  < ../inputs/uslin.215 > ../outputs/t2547
echo ">>>>>>>>running test 2548"
../source/print_tokens.exe  < ../inputs/uslin.22 > ../outputs/t2548
echo ">>>>>>>>running test 2549"
../source/print_tokens.exe  < ../inputs/uslin.225 > ../outputs/t2549
echo ">>>>>>>>running test 2550"
../source/print_tokens.exe  < ../inputs/uslin.226 > ../outputs/t2550
echo ">>>>>>>>running test 2551"
../source/print_tokens.exe  < ../inputs/uslin.230 > ../outputs/t2551
echo ">>>>>>>>running test 2552"
../source/print_tokens.exe  < ../inputs/uslin.233 > ../outputs/t2552
echo ">>>>>>>>running test 2553"
../source/print_tokens.exe  < ../inputs/uslin.234 > ../outputs/t2553
echo ">>>>>>>>running test 2554"
../source/print_tokens.exe  < ../inputs/uslin.237 > ../outputs/t2554
echo ">>>>>>>>running test 2555"
../source/print_tokens.exe  < ../inputs/uslin.238 > ../outputs/t2555
echo ">>>>>>>>running test 2556"
../source/print_tokens.exe  < ../inputs/uslin.239 > ../outputs/t2556
echo ">>>>>>>>running test 2557"
../source/print_tokens.exe  < ../inputs/uslin.243 > ../outputs/t2557
echo ">>>>>>>>running test 2558"
../source/print_tokens.exe  < ../inputs/uslin.244 > ../outputs/t2558
echo ">>>>>>>>running test 2559"
../source/print_tokens.exe  < ../inputs/uslin.245 > ../outputs/t2559
echo ">>>>>>>>running test 2560"
../source/print_tokens.exe  < ../inputs/uslin.246 > ../outputs/t2560
echo ">>>>>>>>running test 2561"
../source/print_tokens.exe  < ../inputs/uslin.247 > ../outputs/t2561
echo ">>>>>>>>running test 2562"
../source/print_tokens.exe  < ../inputs/uslin.248 > ../outputs/t2562
echo ">>>>>>>>running test 2563"
../source/print_tokens.exe  < ../inputs/uslin.249 > ../outputs/t2563
echo ">>>>>>>>running test 2564"
../source/print_tokens.exe  < ../inputs/uslin.25 > ../outputs/t2564
echo ">>>>>>>>running test 2565"
../source/print_tokens.exe  < ../inputs/uslin.251 > ../outputs/t2565
echo ">>>>>>>>running test 2566"
../source/print_tokens.exe  < ../inputs/uslin.252 > ../outputs/t2566
echo ">>>>>>>>running test 2567"
../source/print_tokens.exe  < ../inputs/uslin.254 > ../outputs/t2567
echo ">>>>>>>>running test 2568"
../source/print_tokens.exe  < ../inputs/uslin.256 > ../outputs/t2568
echo ">>>>>>>>running test 2569"
../source/print_tokens.exe  < ../inputs/uslin.257 > ../outputs/t2569
echo ">>>>>>>>running test 2570"
../source/print_tokens.exe  < ../inputs/uslin.258 > ../outputs/t2570
echo ">>>>>>>>running test 2571"
../source/print_tokens.exe  < ../inputs/uslin.260 > ../outputs/t2571
echo ">>>>>>>>running test 2572"
../source/print_tokens.exe  < ../inputs/uslin.264 > ../outputs/t2572
echo ">>>>>>>>running test 2573"
../source/print_tokens.exe  < ../inputs/uslin.266 > ../outputs/t2573
echo ">>>>>>>>running test 2574"
../source/print_tokens.exe  < ../inputs/uslin.267 > ../outputs/t2574
echo ">>>>>>>>running test 2575"
../source/print_tokens.exe  < ../inputs/uslin.268 > ../outputs/t2575
echo ">>>>>>>>running test 2576"
../source/print_tokens.exe  < ../inputs/uslin.27 > ../outputs/t2576
echo ">>>>>>>>running test 2577"
../source/print_tokens.exe  < ../inputs/uslin.270 > ../outputs/t2577
echo ">>>>>>>>running test 2578"
../source/print_tokens.exe  < ../inputs/uslin.271 > ../outputs/t2578
echo ">>>>>>>>running test 2579"
../source/print_tokens.exe  < ../inputs/uslin.272 > ../outputs/t2579
echo ">>>>>>>>running test 2580"
../source/print_tokens.exe  < ../inputs/uslin.275 > ../outputs/t2580
echo ">>>>>>>>running test 2581"
../source/print_tokens.exe  < ../inputs/uslin.276 > ../outputs/t2581
echo ">>>>>>>>running test 2582"
../source/print_tokens.exe  < ../inputs/uslin.277 > ../outputs/t2582
echo ">>>>>>>>running test 2583"
../source/print_tokens.exe  < ../inputs/uslin.28 > ../outputs/t2583
echo ">>>>>>>>running test 2584"
../source/print_tokens.exe  < ../inputs/uslin.280 > ../outputs/t2584
echo ">>>>>>>>running test 2585"
../source/print_tokens.exe  < ../inputs/uslin.281 > ../outputs/t2585
echo ">>>>>>>>running test 2586"
../source/print_tokens.exe  < ../inputs/uslin.282 > ../outputs/t2586
echo ">>>>>>>>running test 2587"
../source/print_tokens.exe  < ../inputs/uslin.283 > ../outputs/t2587
echo ">>>>>>>>running test 2588"
../source/print_tokens.exe  < ../inputs/uslin.286 > ../outputs/t2588
echo ">>>>>>>>running test 2589"
../source/print_tokens.exe  < ../inputs/uslin.289 > ../outputs/t2589
echo ">>>>>>>>running test 2590"
../source/print_tokens.exe  < ../inputs/uslin.294 > ../outputs/t2590
echo ">>>>>>>>running test 2591"
../source/print_tokens.exe  < ../inputs/uslin.295 > ../outputs/t2591
echo ">>>>>>>>running test 2592"
../source/print_tokens.exe  < ../inputs/uslin.296 > ../outputs/t2592
echo ">>>>>>>>running test 2593"
../source/print_tokens.exe  < ../inputs/uslin.297 > ../outputs/t2593
echo ">>>>>>>>running test 2594"
../source/print_tokens.exe  < ../inputs/uslin.298 > ../outputs/t2594
echo ">>>>>>>>running test 2595"
../source/print_tokens.exe  < ../inputs/uslin.299 > ../outputs/t2595
echo ">>>>>>>>running test 2596"
../source/print_tokens.exe  < ../inputs/uslin.30 > ../outputs/t2596
echo ">>>>>>>>running test 2597"
../source/print_tokens.exe  < ../inputs/uslin.301 > ../outputs/t2597
echo ">>>>>>>>running test 2598"
../source/print_tokens.exe  < ../inputs/uslin.302 > ../outputs/t2598
echo ">>>>>>>>running test 2599"
../source/print_tokens.exe  < ../inputs/uslin.305 > ../outputs/t2599
echo ">>>>>>>>running test 2600"
../source/print_tokens.exe  < ../inputs/uslin.306 > ../outputs/t2600
echo ">>>>>>>>running test 2601"
../source/print_tokens.exe  < ../inputs/uslin.307 > ../outputs/t2601
echo ">>>>>>>>running test 2602"
../source/print_tokens.exe  < ../inputs/uslin.31 > ../outputs/t2602
echo ">>>>>>>>running test 2603"
../source/print_tokens.exe  < ../inputs/uslin.311 > ../outputs/t2603
echo ">>>>>>>>running test 2604"
../source/print_tokens.exe  < ../inputs/uslin.318 > ../outputs/t2604
echo ">>>>>>>>running test 2605"
../source/print_tokens.exe  < ../inputs/uslin.319 > ../outputs/t2605
echo ">>>>>>>>running test 2606"
../source/print_tokens.exe  < ../inputs/uslin.320 > ../outputs/t2606
echo ">>>>>>>>running test 2607"
../source/print_tokens.exe  < ../inputs/uslin.321 > ../outputs/t2607
echo ">>>>>>>>running test 2608"
../source/print_tokens.exe  < ../inputs/uslin.322 > ../outputs/t2608
echo ">>>>>>>>running test 2609"
../source/print_tokens.exe  < ../inputs/uslin.323 > ../outputs/t2609
echo ">>>>>>>>running test 2610"
../source/print_tokens.exe  < ../inputs/uslin.325 > ../outputs/t2610
echo ">>>>>>>>running test 2611"
../source/print_tokens.exe  < ../inputs/uslin.327 > ../outputs/t2611
echo ">>>>>>>>running test 2612"
../source/print_tokens.exe  < ../inputs/uslin.329 > ../outputs/t2612
echo ">>>>>>>>running test 2613"
../source/print_tokens.exe  < ../inputs/uslin.33 > ../outputs/t2613
echo ">>>>>>>>running test 2614"
../source/print_tokens.exe  < ../inputs/uslin.330 > ../outputs/t2614
echo ">>>>>>>>running test 2615"
../source/print_tokens.exe  < ../inputs/uslin.333 > ../outputs/t2615
echo ">>>>>>>>running test 2616"
../source/print_tokens.exe  < ../inputs/uslin.335 > ../outputs/t2616
echo ">>>>>>>>running test 2617"
../source/print_tokens.exe  < ../inputs/uslin.337 > ../outputs/t2617
echo ">>>>>>>>running test 2618"
../source/print_tokens.exe  < ../inputs/uslin.339 > ../outputs/t2618
echo ">>>>>>>>running test 2619"
../source/print_tokens.exe  < ../inputs/uslin.34 > ../outputs/t2619
echo ">>>>>>>>running test 2620"
../source/print_tokens.exe  < ../inputs/uslin.340 > ../outputs/t2620
echo ">>>>>>>>running test 2621"
../source/print_tokens.exe  < ../inputs/uslin.343 > ../outputs/t2621
echo ">>>>>>>>running test 2622"
../source/print_tokens.exe  < ../inputs/uslin.344 > ../outputs/t2622
echo ">>>>>>>>running test 2623"
../source/print_tokens.exe  < ../inputs/uslin.345 > ../outputs/t2623
echo ">>>>>>>>running test 2624"
../source/print_tokens.exe  < ../inputs/uslin.348 > ../outputs/t2624
echo ">>>>>>>>running test 2625"
../source/print_tokens.exe  < ../inputs/uslin.349 > ../outputs/t2625
echo ">>>>>>>>running test 2626"
../source/print_tokens.exe  < ../inputs/uslin.350 > ../outputs/t2626
echo ">>>>>>>>running test 2627"
../source/print_tokens.exe  < ../inputs/uslin.352 > ../outputs/t2627
echo ">>>>>>>>running test 2628"
../source/print_tokens.exe  < ../inputs/uslin.353 > ../outputs/t2628
echo ">>>>>>>>running test 2629"
../source/print_tokens.exe  < ../inputs/uslin.355 > ../outputs/t2629
echo ">>>>>>>>running test 2630"
../source/print_tokens.exe  < ../inputs/uslin.36 > ../outputs/t2630
echo ">>>>>>>>running test 2631"
../source/print_tokens.exe  < ../inputs/uslin.360 > ../outputs/t2631
echo ">>>>>>>>running test 2632"
../source/print_tokens.exe  < ../inputs/uslin.362 > ../outputs/t2632
echo ">>>>>>>>running test 2633"
../source/print_tokens.exe  < ../inputs/uslin.363 > ../outputs/t2633
echo ">>>>>>>>running test 2634"
../source/print_tokens.exe  < ../inputs/uslin.367 > ../outputs/t2634
echo ">>>>>>>>running test 2635"
../source/print_tokens.exe  < ../inputs/uslin.369 > ../outputs/t2635
echo ">>>>>>>>running test 2636"
../source/print_tokens.exe  < ../inputs/uslin.37 > ../outputs/t2636
echo ">>>>>>>>running test 2637"
../source/print_tokens.exe  < ../inputs/uslin.372 > ../outputs/t2637
echo ">>>>>>>>running test 2638"
../source/print_tokens.exe  < ../inputs/uslin.377 > ../outputs/t2638
echo ">>>>>>>>running test 2639"
../source/print_tokens.exe  < ../inputs/uslin.378 > ../outputs/t2639
echo ">>>>>>>>running test 2640"
../source/print_tokens.exe  < ../inputs/uslin.379 > ../outputs/t2640
echo ">>>>>>>>running test 2641"
../source/print_tokens.exe  < ../inputs/uslin.380 > ../outputs/t2641
echo ">>>>>>>>running test 2642"
../source/print_tokens.exe  < ../inputs/uslin.383 > ../outputs/t2642
echo ">>>>>>>>running test 2643"
../source/print_tokens.exe  < ../inputs/uslin.386 > ../outputs/t2643
echo ">>>>>>>>running test 2644"
../source/print_tokens.exe  < ../inputs/uslin.387 > ../outputs/t2644
echo ">>>>>>>>running test 2645"
../source/print_tokens.exe  < ../inputs/uslin.388 > ../outputs/t2645
echo ">>>>>>>>running test 2646"
../source/print_tokens.exe  < ../inputs/uslin.392 > ../outputs/t2646
echo ">>>>>>>>running test 2647"
../source/print_tokens.exe  < ../inputs/uslin.395 > ../outputs/t2647
echo ">>>>>>>>running test 2648"
../source/print_tokens.exe  < ../inputs/uslin.396 > ../outputs/t2648
echo ">>>>>>>>running test 2649"
../source/print_tokens.exe  < ../inputs/uslin.398 > ../outputs/t2649
echo ">>>>>>>>running test 2650"
../source/print_tokens.exe  < ../inputs/uslin.4 > ../outputs/t2650
echo ">>>>>>>>running test 2651"
../source/print_tokens.exe  < ../inputs/uslin.40 > ../outputs/t2651
echo ">>>>>>>>running test 2652"
../source/print_tokens.exe  < ../inputs/uslin.402 > ../outputs/t2652
echo ">>>>>>>>running test 2653"
../source/print_tokens.exe  < ../inputs/uslin.407 > ../outputs/t2653
echo ">>>>>>>>running test 2654"
../source/print_tokens.exe  < ../inputs/uslin.41 > ../outputs/t2654
echo ">>>>>>>>running test 2655"
../source/print_tokens.exe  < ../inputs/uslin.412 > ../outputs/t2655
echo ">>>>>>>>running test 2656"
../source/print_tokens.exe  < ../inputs/uslin.413 > ../outputs/t2656
echo ">>>>>>>>running test 2657"
../source/print_tokens.exe  < ../inputs/uslin.415 > ../outputs/t2657
echo ">>>>>>>>running test 2658"
../source/print_tokens.exe  < ../inputs/uslin.418 > ../outputs/t2658
echo ">>>>>>>>running test 2659"
../source/print_tokens.exe  < ../inputs/uslin.419 > ../outputs/t2659
echo ">>>>>>>>running test 2660"
../source/print_tokens.exe  < ../inputs/uslin.42 > ../outputs/t2660
echo ">>>>>>>>running test 2661"
../source/print_tokens.exe  < ../inputs/uslin.421 > ../outputs/t2661
echo ">>>>>>>>running test 2662"
../source/print_tokens.exe  < ../inputs/uslin.423 > ../outputs/t2662
echo ">>>>>>>>running test 2663"
../source/print_tokens.exe  < ../inputs/uslin.424 > ../outputs/t2663
echo ">>>>>>>>running test 2664"
../source/print_tokens.exe  < ../inputs/uslin.425 > ../outputs/t2664
echo ">>>>>>>>running test 2665"
../source/print_tokens.exe  < ../inputs/uslin.428 > ../outputs/t2665
echo ">>>>>>>>running test 2666"
../source/print_tokens.exe  < ../inputs/uslin.430 > ../outputs/t2666
echo ">>>>>>>>running test 2667"
../source/print_tokens.exe  < ../inputs/uslin.432 > ../outputs/t2667
echo ">>>>>>>>running test 2668"
../source/print_tokens.exe  < ../inputs/uslin.433 > ../outputs/t2668
echo ">>>>>>>>running test 2669"
../source/print_tokens.exe  < ../inputs/uslin.434 > ../outputs/t2669
echo ">>>>>>>>running test 2670"
../source/print_tokens.exe  < ../inputs/uslin.435 > ../outputs/t2670
echo ">>>>>>>>running test 2671"
../source/print_tokens.exe  < ../inputs/uslin.436 > ../outputs/t2671
echo ">>>>>>>>running test 2672"
../source/print_tokens.exe  < ../inputs/uslin.438 > ../outputs/t2672
echo ">>>>>>>>running test 2673"
../source/print_tokens.exe  < ../inputs/uslin.441 > ../outputs/t2673
echo ">>>>>>>>running test 2674"
../source/print_tokens.exe  < ../inputs/uslin.442 > ../outputs/t2674
echo ">>>>>>>>running test 2675"
../source/print_tokens.exe  < ../inputs/uslin.447 > ../outputs/t2675
echo ">>>>>>>>running test 2676"
../source/print_tokens.exe  < ../inputs/uslin.448 > ../outputs/t2676
echo ">>>>>>>>running test 2677"
../source/print_tokens.exe  < ../inputs/uslin.449 > ../outputs/t2677
echo ">>>>>>>>running test 2678"
../source/print_tokens.exe  < ../inputs/uslin.450 > ../outputs/t2678
echo ">>>>>>>>running test 2679"
../source/print_tokens.exe  < ../inputs/uslin.451 > ../outputs/t2679
echo ">>>>>>>>running test 2680"
../source/print_tokens.exe  < ../inputs/uslin.455 > ../outputs/t2680
echo ">>>>>>>>running test 2681"
../source/print_tokens.exe  < ../inputs/uslin.456 > ../outputs/t2681
echo ">>>>>>>>running test 2682"
../source/print_tokens.exe  < ../inputs/uslin.457 > ../outputs/t2682
echo ">>>>>>>>running test 2683"
../source/print_tokens.exe  < ../inputs/uslin.459 > ../outputs/t2683
echo ">>>>>>>>running test 2684"
../source/print_tokens.exe  < ../inputs/uslin.462 > ../outputs/t2684
echo ">>>>>>>>running test 2685"
../source/print_tokens.exe  < ../inputs/uslin.463 > ../outputs/t2685
echo ">>>>>>>>running test 2686"
../source/print_tokens.exe  < ../inputs/uslin.467 > ../outputs/t2686
echo ">>>>>>>>running test 2687"
../source/print_tokens.exe  < ../inputs/uslin.468 > ../outputs/t2687
echo ">>>>>>>>running test 2688"
../source/print_tokens.exe  < ../inputs/uslin.469 > ../outputs/t2688
echo ">>>>>>>>running test 2689"
../source/print_tokens.exe  < ../inputs/uslin.47 > ../outputs/t2689
echo ">>>>>>>>running test 2690"
../source/print_tokens.exe  < ../inputs/uslin.475 > ../outputs/t2690
echo ">>>>>>>>running test 2691"
../source/print_tokens.exe  < ../inputs/uslin.476 > ../outputs/t2691
echo ">>>>>>>>running test 2692"
../source/print_tokens.exe  < ../inputs/uslin.477 > ../outputs/t2692
echo ">>>>>>>>running test 2693"
../source/print_tokens.exe  < ../inputs/uslin.479 > ../outputs/t2693
echo ">>>>>>>>running test 2694"
../source/print_tokens.exe  < ../inputs/uslin.48 > ../outputs/t2694
echo ">>>>>>>>running test 2695"
../source/print_tokens.exe  < ../inputs/uslin.480 > ../outputs/t2695
echo ">>>>>>>>running test 2696"
../source/print_tokens.exe  < ../inputs/uslin.483 > ../outputs/t2696
echo ">>>>>>>>running test 2697"
../source/print_tokens.exe  < ../inputs/uslin.487 > ../outputs/t2697
echo ">>>>>>>>running test 2698"
../source/print_tokens.exe  < ../inputs/uslin.489 > ../outputs/t2698
echo ">>>>>>>>running test 2699"
../source/print_tokens.exe  < ../inputs/uslin.493 > ../outputs/t2699
echo ">>>>>>>>running test 2700"
../source/print_tokens.exe  < ../inputs/uslin.494 > ../outputs/t2700
echo ">>>>>>>>running test 2701"
../source/print_tokens.exe  < ../inputs/uslin.496 > ../outputs/t2701
echo ">>>>>>>>running test 2702"
../source/print_tokens.exe  < ../inputs/uslin.50 > ../outputs/t2702
echo ">>>>>>>>running test 2703"
../source/print_tokens.exe  < ../inputs/uslin.502 > ../outputs/t2703
echo ">>>>>>>>running test 2704"
../source/print_tokens.exe  < ../inputs/uslin.504 > ../outputs/t2704
echo ">>>>>>>>running test 2705"
../source/print_tokens.exe  < ../inputs/uslin.506 > ../outputs/t2705
echo ">>>>>>>>running test 2706"
../source/print_tokens.exe  < ../inputs/uslin.507 > ../outputs/t2706
echo ">>>>>>>>running test 2707"
../source/print_tokens.exe  < ../inputs/uslin.510 > ../outputs/t2707
echo ">>>>>>>>running test 2708"
../source/print_tokens.exe  < ../inputs/uslin.511 > ../outputs/t2708
echo ">>>>>>>>running test 2709"
../source/print_tokens.exe  < ../inputs/uslin.512 > ../outputs/t2709
echo ">>>>>>>>running test 2710"
../source/print_tokens.exe  < ../inputs/uslin.513 > ../outputs/t2710
echo ">>>>>>>>running test 2711"
../source/print_tokens.exe  < ../inputs/uslin.514 > ../outputs/t2711
echo ">>>>>>>>running test 2712"
../source/print_tokens.exe  < ../inputs/uslin.515 > ../outputs/t2712
echo ">>>>>>>>running test 2713"
../source/print_tokens.exe  < ../inputs/uslin.518 > ../outputs/t2713
echo ">>>>>>>>running test 2714"
../source/print_tokens.exe  < ../inputs/uslin.519 > ../outputs/t2714
echo ">>>>>>>>running test 2715"
../source/print_tokens.exe  < ../inputs/uslin.52 > ../outputs/t2715
echo ">>>>>>>>running test 2716"
../source/print_tokens.exe  < ../inputs/uslin.520 > ../outputs/t2716
echo ">>>>>>>>running test 2717"
../source/print_tokens.exe  < ../inputs/uslin.522 > ../outputs/t2717
echo ">>>>>>>>running test 2718"
../source/print_tokens.exe  < ../inputs/uslin.525 > ../outputs/t2718
echo ">>>>>>>>running test 2719"
../source/print_tokens.exe  < ../inputs/uslin.526 > ../outputs/t2719
echo ">>>>>>>>running test 2720"
../source/print_tokens.exe  < ../inputs/uslin.527 > ../outputs/t2720
echo ">>>>>>>>running test 2721"
../source/print_tokens.exe  < ../inputs/uslin.528 > ../outputs/t2721
echo ">>>>>>>>running test 2722"
../source/print_tokens.exe  < ../inputs/uslin.533 > ../outputs/t2722
echo ">>>>>>>>running test 2723"
../source/print_tokens.exe  < ../inputs/uslin.534 > ../outputs/t2723
echo ">>>>>>>>running test 2724"
../source/print_tokens.exe  < ../inputs/uslin.537 > ../outputs/t2724
echo ">>>>>>>>running test 2725"
../source/print_tokens.exe  < ../inputs/uslin.538 > ../outputs/t2725
echo ">>>>>>>>running test 2726"
../source/print_tokens.exe  < ../inputs/uslin.539 > ../outputs/t2726
echo ">>>>>>>>running test 2727"
../source/print_tokens.exe  < ../inputs/uslin.54 > ../outputs/t2727
echo ">>>>>>>>running test 2728"
../source/print_tokens.exe  < ../inputs/uslin.540 > ../outputs/t2728
echo ">>>>>>>>running test 2729"
../source/print_tokens.exe  < ../inputs/uslin.543 > ../outputs/t2729
echo ">>>>>>>>running test 2730"
../source/print_tokens.exe  < ../inputs/uslin.544 > ../outputs/t2730
echo ">>>>>>>>running test 2731"
../source/print_tokens.exe  < ../inputs/uslin.552 > ../outputs/t2731
echo ">>>>>>>>running test 2732"
../source/print_tokens.exe  < ../inputs/uslin.553 > ../outputs/t2732
echo ">>>>>>>>running test 2733"
../source/print_tokens.exe  < ../inputs/uslin.558 > ../outputs/t2733
echo ">>>>>>>>running test 2734"
../source/print_tokens.exe  < ../inputs/uslin.562 > ../outputs/t2734
echo ">>>>>>>>running test 2735"
../source/print_tokens.exe  < ../inputs/uslin.566 > ../outputs/t2735
echo ">>>>>>>>running test 2736"
../source/print_tokens.exe  < ../inputs/uslin.568 > ../outputs/t2736
echo ">>>>>>>>running test 2737"
../source/print_tokens.exe  < ../inputs/uslin.569 > ../outputs/t2737
echo ">>>>>>>>running test 2738"
../source/print_tokens.exe  < ../inputs/uslin.570 > ../outputs/t2738
echo ">>>>>>>>running test 2739"
../source/print_tokens.exe  < ../inputs/uslin.571 > ../outputs/t2739
echo ">>>>>>>>running test 2740"
../source/print_tokens.exe  < ../inputs/uslin.572 > ../outputs/t2740
echo ">>>>>>>>running test 2741"
../source/print_tokens.exe  < ../inputs/uslin.573 > ../outputs/t2741
echo ">>>>>>>>running test 2742"
../source/print_tokens.exe  < ../inputs/uslin.574 > ../outputs/t2742
echo ">>>>>>>>running test 2743"
../source/print_tokens.exe  < ../inputs/uslin.576 > ../outputs/t2743
echo ">>>>>>>>running test 2744"
../source/print_tokens.exe  < ../inputs/uslin.577 > ../outputs/t2744
echo ">>>>>>>>running test 2745"
../source/print_tokens.exe  < ../inputs/uslin.579 > ../outputs/t2745
echo ">>>>>>>>running test 2746"
../source/print_tokens.exe  < ../inputs/uslin.58 > ../outputs/t2746
echo ">>>>>>>>running test 2747"
../source/print_tokens.exe  < ../inputs/uslin.580 > ../outputs/t2747
echo ">>>>>>>>running test 2748"
../source/print_tokens.exe  < ../inputs/uslin.581 > ../outputs/t2748
echo ">>>>>>>>running test 2749"
../source/print_tokens.exe  < ../inputs/uslin.582 > ../outputs/t2749
echo ">>>>>>>>running test 2750"
../source/print_tokens.exe  < ../inputs/uslin.583 > ../outputs/t2750
echo ">>>>>>>>running test 2751"
../source/print_tokens.exe  < ../inputs/uslin.584 > ../outputs/t2751
echo ">>>>>>>>running test 2752"
../source/print_tokens.exe  < ../inputs/uslin.585 > ../outputs/t2752
echo ">>>>>>>>running test 2753"
../source/print_tokens.exe  < ../inputs/uslin.586 > ../outputs/t2753
echo ">>>>>>>>running test 2754"
../source/print_tokens.exe  < ../inputs/uslin.592 > ../outputs/t2754
echo ">>>>>>>>running test 2755"
../source/print_tokens.exe  < ../inputs/uslin.593 > ../outputs/t2755
echo ">>>>>>>>running test 2756"
../source/print_tokens.exe  < ../inputs/uslin.594 > ../outputs/t2756
echo ">>>>>>>>running test 2757"
../source/print_tokens.exe  < ../inputs/uslin.596 > ../outputs/t2757
echo ">>>>>>>>running test 2758"
../source/print_tokens.exe  < ../inputs/uslin.597 > ../outputs/t2758
echo ">>>>>>>>running test 2759"
../source/print_tokens.exe  < ../inputs/uslin.598 > ../outputs/t2759
echo ">>>>>>>>running test 2760"
../source/print_tokens.exe  < ../inputs/uslin.60 > ../outputs/t2760
echo ">>>>>>>>running test 2761"
../source/print_tokens.exe  < ../inputs/uslin.602 > ../outputs/t2761
echo ">>>>>>>>running test 2762"
../source/print_tokens.exe  < ../inputs/uslin.605 > ../outputs/t2762
echo ">>>>>>>>running test 2763"
../source/print_tokens.exe  < ../inputs/uslin.607 > ../outputs/t2763
echo ">>>>>>>>running test 2764"
../source/print_tokens.exe  < ../inputs/uslin.611 > ../outputs/t2764
echo ">>>>>>>>running test 2765"
../source/print_tokens.exe  < ../inputs/uslin.614 > ../outputs/t2765
echo ">>>>>>>>running test 2766"
../source/print_tokens.exe  < ../inputs/uslin.615 > ../outputs/t2766
echo ">>>>>>>>running test 2767"
../source/print_tokens.exe  < ../inputs/uslin.616 > ../outputs/t2767
echo ">>>>>>>>running test 2768"
../source/print_tokens.exe  < ../inputs/uslin.617 > ../outputs/t2768
echo ">>>>>>>>running test 2769"
../source/print_tokens.exe  < ../inputs/uslin.619 > ../outputs/t2769
echo ">>>>>>>>running test 2770"
../source/print_tokens.exe  < ../inputs/uslin.62 > ../outputs/t2770
echo ">>>>>>>>running test 2771"
../source/print_tokens.exe  < ../inputs/uslin.621 > ../outputs/t2771
echo ">>>>>>>>running test 2772"
../source/print_tokens.exe  < ../inputs/uslin.623 > ../outputs/t2772
echo ">>>>>>>>running test 2773"
../source/print_tokens.exe  < ../inputs/uslin.624 > ../outputs/t2773
echo ">>>>>>>>running test 2774"
../source/print_tokens.exe  < ../inputs/uslin.625 > ../outputs/t2774
echo ">>>>>>>>running test 2775"
../source/print_tokens.exe  < ../inputs/uslin.626 > ../outputs/t2775
echo ">>>>>>>>running test 2776"
../source/print_tokens.exe  < ../inputs/uslin.627 > ../outputs/t2776
echo ">>>>>>>>running test 2777"
../source/print_tokens.exe  < ../inputs/uslin.63 > ../outputs/t2777
echo ">>>>>>>>running test 2778"
../source/print_tokens.exe  < ../inputs/uslin.630 > ../outputs/t2778
echo ">>>>>>>>running test 2779"
../source/print_tokens.exe  < ../inputs/uslin.633 > ../outputs/t2779
echo ">>>>>>>>running test 2780"
../source/print_tokens.exe  < ../inputs/uslin.636 > ../outputs/t2780
echo ">>>>>>>>running test 2781"
../source/print_tokens.exe  < ../inputs/uslin.64 > ../outputs/t2781
echo ">>>>>>>>running test 2782"
../source/print_tokens.exe  < ../inputs/uslin.640 > ../outputs/t2782
echo ">>>>>>>>running test 2783"
../source/print_tokens.exe  < ../inputs/uslin.642 > ../outputs/t2783
echo ">>>>>>>>running test 2784"
../source/print_tokens.exe  < ../inputs/uslin.647 > ../outputs/t2784
echo ">>>>>>>>running test 2785"
../source/print_tokens.exe  < ../inputs/uslin.648 > ../outputs/t2785
echo ">>>>>>>>running test 2786"
../source/print_tokens.exe  < ../inputs/uslin.650 > ../outputs/t2786
echo ">>>>>>>>running test 2787"
../source/print_tokens.exe  < ../inputs/uslin.655 > ../outputs/t2787
echo ">>>>>>>>running test 2788"
../source/print_tokens.exe  < ../inputs/uslin.656 > ../outputs/t2788
echo ">>>>>>>>running test 2789"
../source/print_tokens.exe  < ../inputs/uslin.659 > ../outputs/t2789
echo ">>>>>>>>running test 2790"
../source/print_tokens.exe  < ../inputs/uslin.662 > ../outputs/t2790
echo ">>>>>>>>running test 2791"
../source/print_tokens.exe  < ../inputs/uslin.663 > ../outputs/t2791
echo ">>>>>>>>running test 2792"
../source/print_tokens.exe  < ../inputs/uslin.665 > ../outputs/t2792
echo ">>>>>>>>running test 2793"
../source/print_tokens.exe  < ../inputs/uslin.668 > ../outputs/t2793
echo ">>>>>>>>running test 2794"
../source/print_tokens.exe  < ../inputs/uslin.669 > ../outputs/t2794
echo ">>>>>>>>running test 2795"
../source/print_tokens.exe  < ../inputs/uslin.67 > ../outputs/t2795
echo ">>>>>>>>running test 2796"
../source/print_tokens.exe  < ../inputs/uslin.670 > ../outputs/t2796
echo ">>>>>>>>running test 2797"
../source/print_tokens.exe  < ../inputs/uslin.673 > ../outputs/t2797
echo ">>>>>>>>running test 2798"
../source/print_tokens.exe  < ../inputs/uslin.674 > ../outputs/t2798
echo ">>>>>>>>running test 2799"
../source/print_tokens.exe  < ../inputs/uslin.676 > ../outputs/t2799
echo ">>>>>>>>running test 2800"
../source/print_tokens.exe  < ../inputs/uslin.677 > ../outputs/t2800
echo ">>>>>>>>running test 2801"
../source/print_tokens.exe  < ../inputs/uslin.679 > ../outputs/t2801
echo ">>>>>>>>running test 2802"
../source/print_tokens.exe  < ../inputs/uslin.68 > ../outputs/t2802
echo ">>>>>>>>running test 2803"
../source/print_tokens.exe  < ../inputs/uslin.680 > ../outputs/t2803
echo ">>>>>>>>running test 2804"
../source/print_tokens.exe  < ../inputs/uslin.682 > ../outputs/t2804
echo ">>>>>>>>running test 2805"
../source/print_tokens.exe  < ../inputs/uslin.686 > ../outputs/t2805
echo ">>>>>>>>running test 2806"
../source/print_tokens.exe  < ../inputs/uslin.691 > ../outputs/t2806
echo ">>>>>>>>running test 2807"
../source/print_tokens.exe  < ../inputs/uslin.695 > ../outputs/t2807
echo ">>>>>>>>running test 2808"
../source/print_tokens.exe  < ../inputs/uslin.70 > ../outputs/t2808
echo ">>>>>>>>running test 2809"
../source/print_tokens.exe  < ../inputs/uslin.701 > ../outputs/t2809
echo ">>>>>>>>running test 2810"
../source/print_tokens.exe  < ../inputs/uslin.704 > ../outputs/t2810
echo ">>>>>>>>running test 2811"
../source/print_tokens.exe  < ../inputs/uslin.706 > ../outputs/t2811
echo ">>>>>>>>running test 2812"
../source/print_tokens.exe  < ../inputs/uslin.708 > ../outputs/t2812
echo ">>>>>>>>running test 2813"
../source/print_tokens.exe  < ../inputs/uslin.709 > ../outputs/t2813
echo ">>>>>>>>running test 2814"
../source/print_tokens.exe  < ../inputs/uslin.71 > ../outputs/t2814
echo ">>>>>>>>running test 2815"
../source/print_tokens.exe  < ../inputs/uslin.712 > ../outputs/t2815
echo ">>>>>>>>running test 2816"
../source/print_tokens.exe  < ../inputs/uslin.713 > ../outputs/t2816
echo ">>>>>>>>running test 2817"
../source/print_tokens.exe  < ../inputs/uslin.716 > ../outputs/t2817
echo ">>>>>>>>running test 2818"
../source/print_tokens.exe  < ../inputs/uslin.717 > ../outputs/t2818
echo ">>>>>>>>running test 2819"
../source/print_tokens.exe  < ../inputs/uslin.719 > ../outputs/t2819
echo ">>>>>>>>running test 2820"
../source/print_tokens.exe  < ../inputs/uslin.72 > ../outputs/t2820
echo ">>>>>>>>running test 2821"
../source/print_tokens.exe  < ../inputs/uslin.721 > ../outputs/t2821
echo ">>>>>>>>running test 2822"
../source/print_tokens.exe  < ../inputs/uslin.723 > ../outputs/t2822
echo ">>>>>>>>running test 2823"
../source/print_tokens.exe  < ../inputs/uslin.727 > ../outputs/t2823
echo ">>>>>>>>running test 2824"
../source/print_tokens.exe  < ../inputs/uslin.728 > ../outputs/t2824
echo ">>>>>>>>running test 2825"
../source/print_tokens.exe  < ../inputs/uslin.734 > ../outputs/t2825
echo ">>>>>>>>running test 2826"
../source/print_tokens.exe  < ../inputs/uslin.736 > ../outputs/t2826
echo ">>>>>>>>running test 2827"
../source/print_tokens.exe  < ../inputs/uslin.738 > ../outputs/t2827
echo ">>>>>>>>running test 2828"
../source/print_tokens.exe  < ../inputs/uslin.74 > ../outputs/t2828
echo ">>>>>>>>running test 2829"
../source/print_tokens.exe  < ../inputs/uslin.742 > ../outputs/t2829
echo ">>>>>>>>running test 2830"
../source/print_tokens.exe  < ../inputs/uslin.744 > ../outputs/t2830
echo ">>>>>>>>running test 2831"
../source/print_tokens.exe  < ../inputs/uslin.746 > ../outputs/t2831
echo ">>>>>>>>running test 2832"
../source/print_tokens.exe  < ../inputs/uslin.747 > ../outputs/t2832
echo ">>>>>>>>running test 2833"
../source/print_tokens.exe  < ../inputs/uslin.748 > ../outputs/t2833
echo ">>>>>>>>running test 2834"
../source/print_tokens.exe  < ../inputs/uslin.75 > ../outputs/t2834
echo ">>>>>>>>running test 2835"
../source/print_tokens.exe  < ../inputs/uslin.751 > ../outputs/t2835
echo ">>>>>>>>running test 2836"
../source/print_tokens.exe  < ../inputs/uslin.752 > ../outputs/t2836
echo ">>>>>>>>running test 2837"
../source/print_tokens.exe  < ../inputs/uslin.753 > ../outputs/t2837
echo ">>>>>>>>running test 2838"
../source/print_tokens.exe  < ../inputs/uslin.756 > ../outputs/t2838
echo ">>>>>>>>running test 2839"
../source/print_tokens.exe  < ../inputs/uslin.758 > ../outputs/t2839
echo ">>>>>>>>running test 2840"
../source/print_tokens.exe  < ../inputs/uslin.76 > ../outputs/t2840
echo ">>>>>>>>running test 2841"
../source/print_tokens.exe  < ../inputs/uslin.760 > ../outputs/t2841
echo ">>>>>>>>running test 2842"
../source/print_tokens.exe  < ../inputs/uslin.761 > ../outputs/t2842
echo ">>>>>>>>running test 2843"
../source/print_tokens.exe  < ../inputs/uslin.765 > ../outputs/t2843
echo ">>>>>>>>running test 2844"
../source/print_tokens.exe  < ../inputs/uslin.766 > ../outputs/t2844
echo ">>>>>>>>running test 2845"
../source/print_tokens.exe  < ../inputs/uslin.767 > ../outputs/t2845
echo ">>>>>>>>running test 2846"
../source/print_tokens.exe  < ../inputs/uslin.768 > ../outputs/t2846
echo ">>>>>>>>running test 2847"
../source/print_tokens.exe  < ../inputs/uslin.769 > ../outputs/t2847
echo ">>>>>>>>running test 2848"
../source/print_tokens.exe  < ../inputs/uslin.77 > ../outputs/t2848
echo ">>>>>>>>running test 2849"
../source/print_tokens.exe  < ../inputs/uslin.772 > ../outputs/t2849
echo ">>>>>>>>running test 2850"
../source/print_tokens.exe  < ../inputs/uslin.773 > ../outputs/t2850
echo ">>>>>>>>running test 2851"
../source/print_tokens.exe  < ../inputs/uslin.775 > ../outputs/t2851
echo ">>>>>>>>running test 2852"
../source/print_tokens.exe  < ../inputs/uslin.776 > ../outputs/t2852
echo ">>>>>>>>running test 2853"
../source/print_tokens.exe  < ../inputs/uslin.777 > ../outputs/t2853
echo ">>>>>>>>running test 2854"
../source/print_tokens.exe  < ../inputs/uslin.778 > ../outputs/t2854
echo ">>>>>>>>running test 2855"
../source/print_tokens.exe  < ../inputs/uslin.779 > ../outputs/t2855
echo ">>>>>>>>running test 2856"
../source/print_tokens.exe  < ../inputs/uslin.78 > ../outputs/t2856
echo ">>>>>>>>running test 2857"
../source/print_tokens.exe  < ../inputs/uslin.781 > ../outputs/t2857
echo ">>>>>>>>running test 2858"
../source/print_tokens.exe  < ../inputs/uslin.784 > ../outputs/t2858
echo ">>>>>>>>running test 2859"
../source/print_tokens.exe  < ../inputs/uslin.786 > ../outputs/t2859
echo ">>>>>>>>running test 2860"
../source/print_tokens.exe  < ../inputs/uslin.787 > ../outputs/t2860
echo ">>>>>>>>running test 2861"
../source/print_tokens.exe  < ../inputs/uslin.788 > ../outputs/t2861
echo ">>>>>>>>running test 2862"
../source/print_tokens.exe  < ../inputs/uslin.789 > ../outputs/t2862
echo ">>>>>>>>running test 2863"
../source/print_tokens.exe  < ../inputs/uslin.79 > ../outputs/t2863
echo ">>>>>>>>running test 2864"
../source/print_tokens.exe  < ../inputs/uslin.790 > ../outputs/t2864
echo ">>>>>>>>running test 2865"
../source/print_tokens.exe  < ../inputs/uslin.791 > ../outputs/t2865
echo ">>>>>>>>running test 2866"
../source/print_tokens.exe  < ../inputs/uslin.793 > ../outputs/t2866
echo ">>>>>>>>running test 2867"
../source/print_tokens.exe  < ../inputs/uslin.798 > ../outputs/t2867
echo ">>>>>>>>running test 2868"
../source/print_tokens.exe  < ../inputs/uslin.80 > ../outputs/t2868
echo ">>>>>>>>running test 2869"
../source/print_tokens.exe  < ../inputs/uslin.803 > ../outputs/t2869
echo ">>>>>>>>running test 2870"
../source/print_tokens.exe  < ../inputs/uslin.807 > ../outputs/t2870
echo ">>>>>>>>running test 2871"
../source/print_tokens.exe  < ../inputs/uslin.808 > ../outputs/t2871
echo ">>>>>>>>running test 2872"
../source/print_tokens.exe  < ../inputs/uslin.811 > ../outputs/t2872
echo ">>>>>>>>running test 2873"
../source/print_tokens.exe  < ../inputs/uslin.814 > ../outputs/t2873
echo ">>>>>>>>running test 2874"
../source/print_tokens.exe  < ../inputs/uslin.816 > ../outputs/t2874
echo ">>>>>>>>running test 2875"
../source/print_tokens.exe  < ../inputs/uslin.818 > ../outputs/t2875
echo ">>>>>>>>running test 2876"
../source/print_tokens.exe  < ../inputs/uslin.82 > ../outputs/t2876
echo ">>>>>>>>running test 2877"
../source/print_tokens.exe  < ../inputs/uslin.821 > ../outputs/t2877
echo ">>>>>>>>running test 2878"
../source/print_tokens.exe  < ../inputs/uslin.823 > ../outputs/t2878
echo ">>>>>>>>running test 2879"
../source/print_tokens.exe  < ../inputs/uslin.825 > ../outputs/t2879
echo ">>>>>>>>running test 2880"
../source/print_tokens.exe  < ../inputs/uslin.828 > ../outputs/t2880
echo ">>>>>>>>running test 2881"
../source/print_tokens.exe  < ../inputs/uslin.829 > ../outputs/t2881
echo ">>>>>>>>running test 2882"
../source/print_tokens.exe  < ../inputs/uslin.83 > ../outputs/t2882
echo ">>>>>>>>running test 2883"
../source/print_tokens.exe  < ../inputs/uslin.831 > ../outputs/t2883
echo ">>>>>>>>running test 2884"
../source/print_tokens.exe  < ../inputs/uslin.832 > ../outputs/t2884
echo ">>>>>>>>running test 2885"
../source/print_tokens.exe  < ../inputs/uslin.834 > ../outputs/t2885
echo ">>>>>>>>running test 2886"
../source/print_tokens.exe  < ../inputs/uslin.836 > ../outputs/t2886
echo ">>>>>>>>running test 2887"
../source/print_tokens.exe  < ../inputs/uslin.837 > ../outputs/t2887
echo ">>>>>>>>running test 2888"
../source/print_tokens.exe  < ../inputs/uslin.840 > ../outputs/t2888
echo ">>>>>>>>running test 2889"
../source/print_tokens.exe  < ../inputs/uslin.843 > ../outputs/t2889
echo ">>>>>>>>running test 2890"
../source/print_tokens.exe  < ../inputs/uslin.85 > ../outputs/t2890
echo ">>>>>>>>running test 2891"
../source/print_tokens.exe  < ../inputs/uslin.851 > ../outputs/t2891
echo ">>>>>>>>running test 2892"
../source/print_tokens.exe  < ../inputs/uslin.855 > ../outputs/t2892
echo ">>>>>>>>running test 2893"
../source/print_tokens.exe  < ../inputs/uslin.858 > ../outputs/t2893
echo ">>>>>>>>running test 2894"
../source/print_tokens.exe  < ../inputs/uslin.860 > ../outputs/t2894
echo ">>>>>>>>running test 2895"
../source/print_tokens.exe  < ../inputs/uslin.862 > ../outputs/t2895
echo ">>>>>>>>running test 2896"
../source/print_tokens.exe  < ../inputs/uslin.864 > ../outputs/t2896
echo ">>>>>>>>running test 2897"
../source/print_tokens.exe  < ../inputs/uslin.865 > ../outputs/t2897
echo ">>>>>>>>running test 2898"
../source/print_tokens.exe  < ../inputs/uslin.866 > ../outputs/t2898
echo ">>>>>>>>running test 2899"
../source/print_tokens.exe  < ../inputs/uslin.87 > ../outputs/t2899
echo ">>>>>>>>running test 2900"
../source/print_tokens.exe  < ../inputs/uslin.871 > ../outputs/t2900
echo ">>>>>>>>running test 2901"
../source/print_tokens.exe  < ../inputs/uslin.88 > ../outputs/t2901
echo ">>>>>>>>running test 2902"
../source/print_tokens.exe  < ../inputs/uslin.880 > ../outputs/t2902
echo ">>>>>>>>running test 2903"
../source/print_tokens.exe  < ../inputs/uslin.888 > ../outputs/t2903
echo ">>>>>>>>running test 2904"
../source/print_tokens.exe  < ../inputs/uslin.89 > ../outputs/t2904
echo ">>>>>>>>running test 2905"
../source/print_tokens.exe  < ../inputs/uslin.892 > ../outputs/t2905
echo ">>>>>>>>running test 2906"
../source/print_tokens.exe  < ../inputs/uslin.895 > ../outputs/t2906
echo ">>>>>>>>running test 2907"
../source/print_tokens.exe  < ../inputs/uslin.896 > ../outputs/t2907
echo ">>>>>>>>running test 2908"
../source/print_tokens.exe  < ../inputs/uslin.898 > ../outputs/t2908
echo ">>>>>>>>running test 2909"
../source/print_tokens.exe  < ../inputs/uslin.9 > ../outputs/t2909
echo ">>>>>>>>running test 2910"
../source/print_tokens.exe  < ../inputs/uslin.903 > ../outputs/t2910
echo ">>>>>>>>running test 2911"
../source/print_tokens.exe  < ../inputs/uslin.904 > ../outputs/t2911
echo ">>>>>>>>running test 2912"
../source/print_tokens.exe  < ../inputs/uslin.905 > ../outputs/t2912
echo ">>>>>>>>running test 2913"
../source/print_tokens.exe  < ../inputs/uslin.906 > ../outputs/t2913
echo ">>>>>>>>running test 2914"
../source/print_tokens.exe  < ../inputs/uslin.910 > ../outputs/t2914
echo ">>>>>>>>running test 2915"
../source/print_tokens.exe  < ../inputs/uslin.913 > ../outputs/t2915
echo ">>>>>>>>running test 2916"
../source/print_tokens.exe  < ../inputs/uslin.914 > ../outputs/t2916
echo ">>>>>>>>running test 2917"
../source/print_tokens.exe  < ../inputs/uslin.92 > ../outputs/t2917
echo ">>>>>>>>running test 2918"
../source/print_tokens.exe  < ../inputs/uslin.920 > ../outputs/t2918
echo ">>>>>>>>running test 2919"
../source/print_tokens.exe  < ../inputs/uslin.922 > ../outputs/t2919
echo ">>>>>>>>running test 2920"
../source/print_tokens.exe  < ../inputs/uslin.923 > ../outputs/t2920
echo ">>>>>>>>running test 2921"
../source/print_tokens.exe  < ../inputs/uslin.924 > ../outputs/t2921
echo ">>>>>>>>running test 2922"
../source/print_tokens.exe  < ../inputs/uslin.926 > ../outputs/t2922
echo ">>>>>>>>running test 2923"
../source/print_tokens.exe  < ../inputs/uslin.927 > ../outputs/t2923
echo ">>>>>>>>running test 2924"
../source/print_tokens.exe  < ../inputs/uslin.93 > ../outputs/t2924
echo ">>>>>>>>running test 2925"
../source/print_tokens.exe  < ../inputs/uslin.930 > ../outputs/t2925
echo ">>>>>>>>running test 2926"
../source/print_tokens.exe  < ../inputs/uslin.933 > ../outputs/t2926
echo ">>>>>>>>running test 2927"
../source/print_tokens.exe  < ../inputs/uslin.937 > ../outputs/t2927
echo ">>>>>>>>running test 2928"
../source/print_tokens.exe  < ../inputs/uslin.94 > ../outputs/t2928
echo ">>>>>>>>running test 2929"
../source/print_tokens.exe  < ../inputs/uslin.942 > ../outputs/t2929
echo ">>>>>>>>running test 2930"
../source/print_tokens.exe  < ../inputs/uslin.944 > ../outputs/t2930
echo ">>>>>>>>running test 2931"
../source/print_tokens.exe  < ../inputs/uslin.945 > ../outputs/t2931
echo ">>>>>>>>running test 2932"
../source/print_tokens.exe  < ../inputs/uslin.949 > ../outputs/t2932
echo ">>>>>>>>running test 2933"
../source/print_tokens.exe  < ../inputs/uslin.954 > ../outputs/t2933
echo ">>>>>>>>running test 2934"
../source/print_tokens.exe  < ../inputs/uslin.955 > ../outputs/t2934
echo ">>>>>>>>running test 2935"
../source/print_tokens.exe  < ../inputs/uslin.957 > ../outputs/t2935
echo ">>>>>>>>running test 2936"
../source/print_tokens.exe  < ../inputs/uslin.958 > ../outputs/t2936
echo ">>>>>>>>running test 2937"
../source/print_tokens.exe  < ../inputs/uslin.96 > ../outputs/t2937
echo ">>>>>>>>running test 2938"
../source/print_tokens.exe  < ../inputs/uslin.960 > ../outputs/t2938
echo ">>>>>>>>running test 2939"
../source/print_tokens.exe  < ../inputs/uslin.961 > ../outputs/t2939
echo ">>>>>>>>running test 2940"
../source/print_tokens.exe  < ../inputs/uslin.962 > ../outputs/t2940
echo ">>>>>>>>running test 2941"
../source/print_tokens.exe  < ../inputs/uslin.964 > ../outputs/t2941
echo ">>>>>>>>running test 2942"
../source/print_tokens.exe  < ../inputs/uslin.966 > ../outputs/t2942
echo ">>>>>>>>running test 2943"
../source/print_tokens.exe  < ../inputs/uslin.968 > ../outputs/t2943
echo ">>>>>>>>running test 2944"
../source/print_tokens.exe  < ../inputs/uslin.969 > ../outputs/t2944
echo ">>>>>>>>running test 2945"
../source/print_tokens.exe  < ../inputs/uslin.97 > ../outputs/t2945
echo ">>>>>>>>running test 2946"
../source/print_tokens.exe  < ../inputs/uslin.971 > ../outputs/t2946
echo ">>>>>>>>running test 2947"
../source/print_tokens.exe  < ../inputs/uslin.973 > ../outputs/t2947
echo ">>>>>>>>running test 2948"
../source/print_tokens.exe  < ../inputs/uslin.974 > ../outputs/t2948
echo ">>>>>>>>running test 2949"
../source/print_tokens.exe  < ../inputs/uslin.978 > ../outputs/t2949
echo ">>>>>>>>running test 2950"
../source/print_tokens.exe  < ../inputs/uslin.98 > ../outputs/t2950
echo ">>>>>>>>running test 2951"
../source/print_tokens.exe  < ../inputs/uslin.981 > ../outputs/t2951
echo ">>>>>>>>running test 2952"
../source/print_tokens.exe  < ../inputs/uslin.982 > ../outputs/t2952
echo ">>>>>>>>running test 2953"
../source/print_tokens.exe  < ../inputs/uslin.984 > ../outputs/t2953
echo ">>>>>>>>running test 2954"
../source/print_tokens.exe  < ../inputs/uslin.987 > ../outputs/t2954
echo ">>>>>>>>running test 2955"
../source/print_tokens.exe  < ../inputs/uslin.989 > ../outputs/t2955
echo ">>>>>>>>running test 2956"
../source/print_tokens.exe  < ../inputs/uslin.99 > ../outputs/t2956
echo ">>>>>>>>running test 2957"
../source/print_tokens.exe  < ../inputs/uslin.991 > ../outputs/t2957
echo ">>>>>>>>running test 2958"
../source/print_tokens.exe  < ../inputs/uslin.992 > ../outputs/t2958
echo ">>>>>>>>running test 2959"
../source/print_tokens.exe  < ../inputs/uslin.993 > ../outputs/t2959
echo ">>>>>>>>running test 2960"
../source/print_tokens.exe  < ../inputs/uslin.994 > ../outputs/t2960
echo ">>>>>>>>running test 2961"
../source/print_tokens.exe  < ../inputs/uslin.995 > ../outputs/t2961
echo ">>>>>>>>running test 2962"
../source/print_tokens.exe  < ../inputs/uslin.996 > ../outputs/t2962
echo ">>>>>>>>running test 2963"
../source/print_tokens.exe  < ../inputs/uslin.999 > ../outputs/t2963
echo ">>>>>>>>running test 2964"
../source/print_tokens.exe ../inputs/garbage/nothing     > ../outputs/t2964
echo ">>>>>>>>running test 2965"
../source/print_tokens.exe ../inputs/jk1     > ../outputs/t2965
echo ">>>>>>>>running test 2966"
../source/print_tokens.exe ../inputs/jk10     > ../outputs/t2966
echo ">>>>>>>>running test 2967"
../source/print_tokens.exe ../inputs/jk11     > ../outputs/t2967
echo ">>>>>>>>running test 2968"
../source/print_tokens.exe ../inputs/jk12     > ../outputs/t2968
echo ">>>>>>>>running test 2969"
../source/print_tokens.exe ../inputs/jk13     > ../outputs/t2969
echo ">>>>>>>>running test 2970"
../source/print_tokens.exe ../inputs/jk14     > ../outputs/t2970
echo ">>>>>>>>running test 2971"
../source/print_tokens.exe ../inputs/jk15     > ../outputs/t2971
echo ">>>>>>>>running test 2972"
../source/print_tokens.exe ../inputs/jk16     > ../outputs/t2972
echo ">>>>>>>>running test 2973"
../source/print_tokens.exe ../inputs/jk17     > ../outputs/t2973
echo ">>>>>>>>running test 2974"
../source/print_tokens.exe ../inputs/jk18     > ../outputs/t2974
echo ">>>>>>>>running test 2975"
../source/print_tokens.exe ../inputs/jk19     > ../outputs/t2975
echo ">>>>>>>>running test 2976"
../source/print_tokens.exe ../inputs/jk2     > ../outputs/t2976
echo ">>>>>>>>running test 2977"
../source/print_tokens.exe ../inputs/jk20     > ../outputs/t2977
echo ">>>>>>>>running test 2978"
../source/print_tokens.exe ../inputs/jk21     > ../outputs/t2978
echo ">>>>>>>>running test 2979"
../source/print_tokens.exe ../inputs/jk22     > ../outputs/t2979
echo ">>>>>>>>running test 2980"
../source/print_tokens.exe ../inputs/jk23     > ../outputs/t2980
echo ">>>>>>>>running test 2981"
../source/print_tokens.exe ../inputs/jk24     > ../outputs/t2981
echo ">>>>>>>>running test 2982"
../source/print_tokens.exe ../inputs/jk25     > ../outputs/t2982
echo ">>>>>>>>running test 2983"
../source/print_tokens.exe ../inputs/jk26     > ../outputs/t2983
echo ">>>>>>>>running test 2984"
../source/print_tokens.exe ../inputs/jk27     > ../outputs/t2984
echo ">>>>>>>>running test 2985"
../source/print_tokens.exe ../inputs/jk28     > ../outputs/t2985
echo ">>>>>>>>running test 2986"
../source/print_tokens.exe ../inputs/jk29     > ../outputs/t2986
echo ">>>>>>>>running test 2987"
../source/print_tokens.exe ../inputs/jk3     > ../outputs/t2987
echo ">>>>>>>>running test 2988"
../source/print_tokens.exe ../inputs/jk30     > ../outputs/t2988
echo ">>>>>>>>running test 2989"
../source/print_tokens.exe ../inputs/jk31     > ../outputs/t2989
echo ">>>>>>>>running test 2990"
../source/print_tokens.exe ../inputs/jk32     > ../outputs/t2990
echo ">>>>>>>>running test 2991"
../source/print_tokens.exe ../inputs/jk33     > ../outputs/t2991
echo ">>>>>>>>running test 2992"
../source/print_tokens.exe ../inputs/jk34     > ../outputs/t2992
echo ">>>>>>>>running test 2993"
../source/print_tokens.exe ../inputs/jk35     > ../outputs/t2993
echo ">>>>>>>>running test 2994"
../source/print_tokens.exe ../inputs/jk36     > ../outputs/t2994
echo ">>>>>>>>running test 2995"
../source/print_tokens.exe ../inputs/jk37     > ../outputs/t2995
echo ">>>>>>>>running test 2996"
../source/print_tokens.exe ../inputs/jk38     > ../outputs/t2996
echo ">>>>>>>>running test 2997"
../source/print_tokens.exe ../inputs/jk39     > ../outputs/t2997
echo ">>>>>>>>running test 2998"
../source/print_tokens.exe ../inputs/jk4     > ../outputs/t2998
echo ">>>>>>>>running test 2999"
../source/print_tokens.exe ../inputs/jk40     > ../outputs/t2999
echo ">>>>>>>>running test 3000"
../source/print_tokens.exe ../inputs/jk41     > ../outputs/t3000
echo ">>>>>>>>running test 3001"
../source/print_tokens.exe ../inputs/jk42     > ../outputs/t3001
echo ">>>>>>>>running test 3002"
../source/print_tokens.exe ../inputs/jk43     > ../outputs/t3002
echo ">>>>>>>>running test 3003"
../source/print_tokens.exe ../inputs/jk44     > ../outputs/t3003
echo ">>>>>>>>running test 3004"
../source/print_tokens.exe ../inputs/jk45     > ../outputs/t3004
echo ">>>>>>>>running test 3005"
../source/print_tokens.exe ../inputs/jk46     > ../outputs/t3005
echo ">>>>>>>>running test 3006"
../source/print_tokens.exe ../inputs/jk47     > ../outputs/t3006
echo ">>>>>>>>running test 3007"
../source/print_tokens.exe ../inputs/jk48     > ../outputs/t3007
echo ">>>>>>>>running test 3008"
../source/print_tokens.exe ../inputs/jk49     > ../outputs/t3008
echo ">>>>>>>>running test 3009"
../source/print_tokens.exe ../inputs/jk5     > ../outputs/t3009
echo ">>>>>>>>running test 3010"
../source/print_tokens.exe ../inputs/jk50     > ../outputs/t3010
echo ">>>>>>>>running test 3011"
../source/print_tokens.exe ../inputs/jk6     > ../outputs/t3011
echo ">>>>>>>>running test 3012"
../source/print_tokens.exe ../inputs/jk7     > ../outputs/t3012
echo ">>>>>>>>running test 3013"
../source/print_tokens.exe ../inputs/jk8     > ../outputs/t3013
echo ">>>>>>>>running test 3014"
../source/print_tokens.exe ../inputs/jk9     > ../outputs/t3014
echo ">>>>>>>>running test 3015"
../source/print_tokens.exe ../inputs/newtst522.tst.noeof     > ../outputs/t3015
echo ">>>>>>>>running test 3016"
../source/print_tokens.exe ../inputs/tc240.noeof     > ../outputs/t3016
echo ">>>>>>>>running test 3017"
../source/print_tokens.exe ../inputs/test287.noeof     > ../outputs/t3017
echo ">>>>>>>>running test 3018"
../source/print_tokens.exe ../inputs/test330.noeof     > ../outputs/t3018
echo ">>>>>>>>running test 3019"
../source/print_tokens.exe ../inputs/test373.noeof     > ../outputs/t3019
echo ">>>>>>>>running test 3020"
../source/print_tokens.exe ../inputs/ts516.noeof     > ../outputs/t3020
echo ">>>>>>>>running test 3021"
../source/print_tokens.exe ../inputs/ts583.noeof     > ../outputs/t3021
echo ">>>>>>>>running test 3022"
../source/print_tokens.exe ../inputs/ts609.noeof     > ../outputs/t3022
echo ">>>>>>>>running test 3023"
../source/print_tokens.exe ../inputs/tst110.noeof     > ../outputs/t3023
echo ">>>>>>>>running test 3024"
../source/print_tokens.exe ../inputs/tst52.noeof     > ../outputs/t3024
echo ">>>>>>>>running test 3025"
../source/print_tokens.exe ../inputs/uslin.1     > ../outputs/t3025
echo ">>>>>>>>running test 3026"
../source/print_tokens.exe ../inputs/uslin.10     > ../outputs/t3026
echo ">>>>>>>>running test 3027"
../source/print_tokens.exe ../inputs/uslin.1000     > ../outputs/t3027
echo ">>>>>>>>running test 3028"
../source/print_tokens.exe ../inputs/uslin.1001     > ../outputs/t3028
echo ">>>>>>>>running test 3029"
../source/print_tokens.exe ../inputs/uslin.1003     > ../outputs/t3029
echo ">>>>>>>>running test 3030"
../source/print_tokens.exe ../inputs/uslin.1004     > ../outputs/t3030
echo ">>>>>>>>running test 3031"
../source/print_tokens.exe ../inputs/uslin.1005     > ../outputs/t3031
echo ">>>>>>>>running test 3032"
../source/print_tokens.exe ../inputs/uslin.1008     > ../outputs/t3032
echo ">>>>>>>>running test 3033"
../source/print_tokens.exe ../inputs/uslin.1009     > ../outputs/t3033
echo ">>>>>>>>running test 3034"
../source/print_tokens.exe ../inputs/uslin.1010     > ../outputs/t3034
echo ">>>>>>>>running test 3035"
../source/print_tokens.exe ../inputs/uslin.1014     > ../outputs/t3035
echo ">>>>>>>>running test 3036"
../source/print_tokens.exe ../inputs/uslin.1014.noeof     > ../outputs/t3036
echo ">>>>>>>>running test 3037"
../source/print_tokens.exe ../inputs/uslin.1015     > ../outputs/t3037
echo ">>>>>>>>running test 3038"
../source/print_tokens.exe ../inputs/uslin.1018     > ../outputs/t3038
echo ">>>>>>>>running test 3039"
../source/print_tokens.exe ../inputs/uslin.1020     > ../outputs/t3039
echo ">>>>>>>>running test 3040"
../source/print_tokens.exe ../inputs/uslin.1024     > ../outputs/t3040
echo ">>>>>>>>running test 3041"
../source/print_tokens.exe ../inputs/uslin.1025     > ../outputs/t3041
echo ">>>>>>>>running test 3042"
../source/print_tokens.exe ../inputs/uslin.1030     > ../outputs/t3042
echo ">>>>>>>>running test 3043"
../source/print_tokens.exe ../inputs/uslin.1031     > ../outputs/t3043
echo ">>>>>>>>running test 3044"
../source/print_tokens.exe ../inputs/uslin.1032     > ../outputs/t3044
echo ">>>>>>>>running test 3045"
../source/print_tokens.exe ../inputs/uslin.1034     > ../outputs/t3045
echo ">>>>>>>>running test 3046"
../source/print_tokens.exe ../inputs/uslin.1035     > ../outputs/t3046
echo ">>>>>>>>running test 3047"
../source/print_tokens.exe ../inputs/uslin.1036     > ../outputs/t3047
echo ">>>>>>>>running test 3048"
../source/print_tokens.exe ../inputs/uslin.1038     > ../outputs/t3048
echo ">>>>>>>>running test 3049"
../source/print_tokens.exe ../inputs/uslin.1038.noeof     > ../outputs/t3049
echo ">>>>>>>>running test 3050"
../source/print_tokens.exe ../inputs/uslin.1039     > ../outputs/t3050
echo ">>>>>>>>running test 3051"
../source/print_tokens.exe ../inputs/uslin.1040     > ../outputs/t3051
echo ">>>>>>>>running test 3052"
../source/print_tokens.exe ../inputs/uslin.1042     > ../outputs/t3052
echo ">>>>>>>>running test 3053"
../source/print_tokens.exe ../inputs/uslin.1043     > ../outputs/t3053
echo ">>>>>>>>running test 3054"
../source/print_tokens.exe ../inputs/uslin.1045     > ../outputs/t3054
echo ">>>>>>>>running test 3055"
../source/print_tokens.exe ../inputs/uslin.1046     > ../outputs/t3055
echo ">>>>>>>>running test 3056"
../source/print_tokens.exe ../inputs/uslin.1047     > ../outputs/t3056
echo ">>>>>>>>running test 3057"
../source/print_tokens.exe ../inputs/uslin.1048     > ../outputs/t3057
echo ">>>>>>>>running test 3058"
../source/print_tokens.exe ../inputs/uslin.1049     > ../outputs/t3058
echo ">>>>>>>>running test 3059"
../source/print_tokens.exe ../inputs/uslin.105     > ../outputs/t3059
echo ">>>>>>>>running test 3060"
../source/print_tokens.exe ../inputs/uslin.1050     > ../outputs/t3060
echo ">>>>>>>>running test 3061"
../source/print_tokens.exe ../inputs/uslin.1054     > ../outputs/t3061
echo ">>>>>>>>running test 3062"
../source/print_tokens.exe ../inputs/uslin.1057     > ../outputs/t3062
echo ">>>>>>>>running test 3063"
../source/print_tokens.exe ../inputs/uslin.1059     > ../outputs/t3063
echo ">>>>>>>>running test 3064"
../source/print_tokens.exe ../inputs/uslin.106     > ../outputs/t3064
echo ">>>>>>>>running test 3065"
../source/print_tokens.exe ../inputs/uslin.1061     > ../outputs/t3065
echo ">>>>>>>>running test 3066"
../source/print_tokens.exe ../inputs/uslin.1065     > ../outputs/t3066
echo ">>>>>>>>running test 3067"
../source/print_tokens.exe ../inputs/uslin.1067     > ../outputs/t3067
echo ">>>>>>>>running test 3068"
../source/print_tokens.exe ../inputs/uslin.1068     > ../outputs/t3068
echo ">>>>>>>>running test 3069"
../source/print_tokens.exe ../inputs/uslin.1069     > ../outputs/t3069
echo ">>>>>>>>running test 3070"
../source/print_tokens.exe ../inputs/uslin.107     > ../outputs/t3070
echo ">>>>>>>>running test 3071"
../source/print_tokens.exe ../inputs/uslin.1071     > ../outputs/t3071
echo ">>>>>>>>running test 3072"
../source/print_tokens.exe ../inputs/uslin.1074     > ../outputs/t3072
echo ">>>>>>>>running test 3073"
../source/print_tokens.exe ../inputs/uslin.1075     > ../outputs/t3073
echo ">>>>>>>>running test 3074"
../source/print_tokens.exe ../inputs/uslin.1076     > ../outputs/t3074
echo ">>>>>>>>running test 3075"
../source/print_tokens.exe ../inputs/uslin.1077     > ../outputs/t3075
echo ">>>>>>>>running test 3076"
../source/print_tokens.exe ../inputs/uslin.1078     > ../outputs/t3076
echo ">>>>>>>>running test 3077"
../source/print_tokens.exe ../inputs/uslin.1080     > ../outputs/t3077
echo ">>>>>>>>running test 3078"
../source/print_tokens.exe ../inputs/uslin.1082     > ../outputs/t3078
echo ">>>>>>>>running test 3079"
../source/print_tokens.exe ../inputs/uslin.1084     > ../outputs/t3079
echo ">>>>>>>>running test 3080"
../source/print_tokens.exe ../inputs/uslin.1085     > ../outputs/t3080
echo ">>>>>>>>running test 3081"
../source/print_tokens.exe ../inputs/uslin.109     > ../outputs/t3081
echo ">>>>>>>>running test 3082"
../source/print_tokens.exe ../inputs/uslin.1091     > ../outputs/t3082
echo ">>>>>>>>running test 3083"
../source/print_tokens.exe ../inputs/uslin.1092     > ../outputs/t3083
echo ">>>>>>>>running test 3084"
../source/print_tokens.exe ../inputs/uslin.1093     > ../outputs/t3084
echo ">>>>>>>>running test 3085"
../source/print_tokens.exe ../inputs/uslin.1094     > ../outputs/t3085
echo ">>>>>>>>running test 3086"
../source/print_tokens.exe ../inputs/uslin.1095     > ../outputs/t3086
echo ">>>>>>>>running test 3087"
../source/print_tokens.exe ../inputs/uslin.1096     > ../outputs/t3087
echo ">>>>>>>>running test 3088"
../source/print_tokens.exe ../inputs/uslin.1101     > ../outputs/t3088
echo ">>>>>>>>running test 3089"
../source/print_tokens.exe ../inputs/uslin.1103     > ../outputs/t3089
echo ">>>>>>>>running test 3090"
../source/print_tokens.exe ../inputs/uslin.1105     > ../outputs/t3090
echo ">>>>>>>>running test 3091"
../source/print_tokens.exe ../inputs/uslin.1109      > ../outputs/t3091
echo ">>>>>>>>running test 3092"
../source/print_tokens.exe ../inputs/uslin.111     > ../outputs/t3092
echo ">>>>>>>>running test 3093"
../source/print_tokens.exe ../inputs/uslin.1112     > ../outputs/t3093
echo ">>>>>>>>running test 3094"
../source/print_tokens.exe ../inputs/uslin.1113     > ../outputs/t3094
echo ">>>>>>>>running test 3095"
../source/print_tokens.exe ../inputs/uslin.1114     > ../outputs/t3095
echo ">>>>>>>>running test 3096"
../source/print_tokens.exe ../inputs/uslin.1115     > ../outputs/t3096
echo ">>>>>>>>running test 3097"
../source/print_tokens.exe ../inputs/uslin.1119     > ../outputs/t3097
echo ">>>>>>>>running test 3098"
../source/print_tokens.exe ../inputs/uslin.1120     > ../outputs/t3098
echo ">>>>>>>>running test 3099"
../source/print_tokens.exe ../inputs/uslin.1121     > ../outputs/t3099
echo ">>>>>>>>running test 3100"
../source/print_tokens.exe ../inputs/uslin.1124      > ../outputs/t3100
echo ">>>>>>>>running test 3101"
../source/print_tokens.exe ../inputs/uslin.1125     > ../outputs/t3101
echo ">>>>>>>>running test 3102"
../source/print_tokens.exe ../inputs/uslin.1126     > ../outputs/t3102
echo ">>>>>>>>running test 3103"
../source/print_tokens.exe ../inputs/uslin.1127     > ../outputs/t3103
echo ">>>>>>>>running test 3104"
../source/print_tokens.exe ../inputs/uslin.1130     > ../outputs/t3104
echo ">>>>>>>>running test 3105"
../source/print_tokens.exe ../inputs/uslin.1139     > ../outputs/t3105
echo ">>>>>>>>running test 3106"
../source/print_tokens.exe ../inputs/uslin.114     > ../outputs/t3106
echo ">>>>>>>>running test 3107"
../source/print_tokens.exe ../inputs/uslin.1140     > ../outputs/t3107
echo ">>>>>>>>running test 3108"
../source/print_tokens.exe ../inputs/uslin.1141     > ../outputs/t3108
echo ">>>>>>>>running test 3109"
../source/print_tokens.exe ../inputs/uslin.1142     > ../outputs/t3109
echo ">>>>>>>>running test 3110"
../source/print_tokens.exe ../inputs/uslin.1144     > ../outputs/t3110
echo ">>>>>>>>running test 3111"
../source/print_tokens.exe ../inputs/uslin.115     > ../outputs/t3111
echo ">>>>>>>>running test 3112"
../source/print_tokens.exe ../inputs/uslin.1155     > ../outputs/t3112
echo ">>>>>>>>running test 3113"
../source/print_tokens.exe ../inputs/uslin.1156      > ../outputs/t3113
echo ">>>>>>>>running test 3114"
../source/print_tokens.exe ../inputs/uslin.1159     > ../outputs/t3114
echo ">>>>>>>>running test 3115"
../source/print_tokens.exe ../inputs/uslin.1160     > ../outputs/t3115
echo ">>>>>>>>running test 3116"
../source/print_tokens.exe ../inputs/uslin.1162     > ../outputs/t3116
echo ">>>>>>>>running test 3117"
../source/print_tokens.exe ../inputs/uslin.1163     > ../outputs/t3117
echo ">>>>>>>>running test 3118"
../source/print_tokens.exe ../inputs/uslin.1165     > ../outputs/t3118
echo ">>>>>>>>running test 3119"
../source/print_tokens.exe ../inputs/uslin.1166     > ../outputs/t3119
echo ">>>>>>>>running test 3120"
../source/print_tokens.exe ../inputs/uslin.1167     > ../outputs/t3120
echo ">>>>>>>>running test 3121"
../source/print_tokens.exe ../inputs/uslin.117     > ../outputs/t3121
echo ">>>>>>>>running test 3122"
../source/print_tokens.exe ../inputs/uslin.1173     > ../outputs/t3122
echo ">>>>>>>>running test 3123"
../source/print_tokens.exe ../inputs/uslin.1174     > ../outputs/t3123
echo ">>>>>>>>running test 3124"
../source/print_tokens.exe ../inputs/uslin.1179     > ../outputs/t3124
echo ">>>>>>>>running test 3125"
../source/print_tokens.exe ../inputs/uslin.1180     > ../outputs/t3125
echo ">>>>>>>>running test 3126"
../source/print_tokens.exe ../inputs/uslin.1182     > ../outputs/t3126
echo ">>>>>>>>running test 3127"
../source/print_tokens.exe ../inputs/uslin.1184     > ../outputs/t3127
echo ">>>>>>>>running test 3128"
../source/print_tokens.exe ../inputs/uslin.1185     > ../outputs/t3128
echo ">>>>>>>>running test 3129"
../source/print_tokens.exe ../inputs/uslin.1186     > ../outputs/t3129
echo ">>>>>>>>running test 3130"
../source/print_tokens.exe ../inputs/uslin.1187     > ../outputs/t3130
echo ">>>>>>>>running test 3131"
../source/print_tokens.exe ../inputs/uslin.1189     > ../outputs/t3131
echo ">>>>>>>>running test 3132"
../source/print_tokens.exe ../inputs/uslin.119     > ../outputs/t3132
echo ">>>>>>>>running test 3133"
../source/print_tokens.exe ../inputs/uslin.1191     > ../outputs/t3133
echo ">>>>>>>>running test 3134"
../source/print_tokens.exe ../inputs/uslin.1192     > ../outputs/t3134
echo ">>>>>>>>running test 3135"
../source/print_tokens.exe ../inputs/uslin.1193     > ../outputs/t3135
echo ">>>>>>>>running test 3136"
../source/print_tokens.exe ../inputs/uslin.1196     > ../outputs/t3136
echo ">>>>>>>>running test 3137"
../source/print_tokens.exe ../inputs/uslin.1198     > ../outputs/t3137
echo ">>>>>>>>running test 3138"
../source/print_tokens.exe ../inputs/uslin.1200     > ../outputs/t3138
echo ">>>>>>>>running test 3139"
../source/print_tokens.exe ../inputs/uslin.1202     > ../outputs/t3139
echo ">>>>>>>>running test 3140"
../source/print_tokens.exe ../inputs/uslin.1206     > ../outputs/t3140
echo ">>>>>>>>running test 3141"
../source/print_tokens.exe ../inputs/uslin.1207     > ../outputs/t3141
echo ">>>>>>>>running test 3142"
../source/print_tokens.exe ../inputs/uslin.1209     > ../outputs/t3142
echo ">>>>>>>>running test 3143"
../source/print_tokens.exe ../inputs/uslin.121     > ../outputs/t3143
echo ">>>>>>>>running test 3144"
../source/print_tokens.exe ../inputs/uslin.1212     > ../outputs/t3144
echo ">>>>>>>>running test 3145"
../source/print_tokens.exe ../inputs/uslin.1217     > ../outputs/t3145
echo ">>>>>>>>running test 3146"
../source/print_tokens.exe ../inputs/uslin.1219     > ../outputs/t3146
echo ">>>>>>>>running test 3147"
../source/print_tokens.exe ../inputs/uslin.1224     > ../outputs/t3147
echo ">>>>>>>>running test 3148"
../source/print_tokens.exe ../inputs/uslin.1226     > ../outputs/t3148
echo ">>>>>>>>running test 3149"
../source/print_tokens.exe ../inputs/uslin.1233     > ../outputs/t3149
echo ">>>>>>>>running test 3150"
../source/print_tokens.exe ../inputs/uslin.1234     > ../outputs/t3150
echo ">>>>>>>>running test 3151"
../source/print_tokens.exe ../inputs/uslin.1235     > ../outputs/t3151
echo ">>>>>>>>running test 3152"
../source/print_tokens.exe ../inputs/uslin.1237     > ../outputs/t3152
echo ">>>>>>>>running test 3153"
../source/print_tokens.exe ../inputs/uslin.1239     > ../outputs/t3153
echo ">>>>>>>>running test 3154"
../source/print_tokens.exe ../inputs/uslin.1241     > ../outputs/t3154
echo ">>>>>>>>running test 3155"
../source/print_tokens.exe ../inputs/uslin.1243     > ../outputs/t3155
echo ">>>>>>>>running test 3156"
../source/print_tokens.exe ../inputs/uslin.1245     > ../outputs/t3156
echo ">>>>>>>>running test 3157"
../source/print_tokens.exe ../inputs/uslin.1246     > ../outputs/t3157
echo ">>>>>>>>running test 3158"
../source/print_tokens.exe ../inputs/uslin.1249     > ../outputs/t3158
echo ">>>>>>>>running test 3159"
../source/print_tokens.exe ../inputs/uslin.125     > ../outputs/t3159
echo ">>>>>>>>running test 3160"
../source/print_tokens.exe ../inputs/uslin.1250     > ../outputs/t3160
echo ">>>>>>>>running test 3161"
../source/print_tokens.exe ../inputs/uslin.1252     > ../outputs/t3161
echo ">>>>>>>>running test 3162"
../source/print_tokens.exe ../inputs/uslin.1253     > ../outputs/t3162
echo ">>>>>>>>running test 3163"
../source/print_tokens.exe ../inputs/uslin.1255      > ../outputs/t3163
echo ">>>>>>>>running test 3164"
../source/print_tokens.exe ../inputs/uslin.1256     > ../outputs/t3164
echo ">>>>>>>>running test 3165"
../source/print_tokens.exe ../inputs/uslin.1258     > ../outputs/t3165
echo ">>>>>>>>running test 3166"
../source/print_tokens.exe ../inputs/uslin.126     > ../outputs/t3166
echo ">>>>>>>>running test 3167"
../source/print_tokens.exe ../inputs/uslin.1260      > ../outputs/t3167
echo ">>>>>>>>running test 3168"
../source/print_tokens.exe ../inputs/uslin.1264     > ../outputs/t3168
echo ">>>>>>>>running test 3169"
../source/print_tokens.exe ../inputs/uslin.1265     > ../outputs/t3169
echo ">>>>>>>>running test 3170"
../source/print_tokens.exe ../inputs/uslin.1266     > ../outputs/t3170
echo ">>>>>>>>running test 3171"
../source/print_tokens.exe ../inputs/uslin.1267     > ../outputs/t3171
echo ">>>>>>>>running test 3172"
../source/print_tokens.exe ../inputs/uslin.1268     > ../outputs/t3172
echo ">>>>>>>>running test 3173"
../source/print_tokens.exe ../inputs/uslin.127     > ../outputs/t3173
echo ">>>>>>>>running test 3174"
../source/print_tokens.exe ../inputs/uslin.1270     > ../outputs/t3174
echo ">>>>>>>>running test 3175"
../source/print_tokens.exe ../inputs/uslin.1272     > ../outputs/t3175
echo ">>>>>>>>running test 3176"
../source/print_tokens.exe ../inputs/uslin.1276     > ../outputs/t3176
echo ">>>>>>>>running test 3177"
../source/print_tokens.exe ../inputs/uslin.1278     > ../outputs/t3177
echo ">>>>>>>>running test 3178"
../source/print_tokens.exe ../inputs/uslin.128     > ../outputs/t3178
echo ">>>>>>>>running test 3179"
../source/print_tokens.exe ../inputs/uslin.1281     > ../outputs/t3179
echo ">>>>>>>>running test 3180"
../source/print_tokens.exe ../inputs/uslin.1283     > ../outputs/t3180
echo ">>>>>>>>running test 3181"
../source/print_tokens.exe ../inputs/uslin.1287     > ../outputs/t3181
echo ">>>>>>>>running test 3182"
../source/print_tokens.exe ../inputs/uslin.1289     > ../outputs/t3182
echo ">>>>>>>>running test 3183"
../source/print_tokens.exe ../inputs/uslin.129     > ../outputs/t3183
echo ">>>>>>>>running test 3184"
../source/print_tokens.exe ../inputs/uslin.1290     > ../outputs/t3184
echo ">>>>>>>>running test 3185"
../source/print_tokens.exe ../inputs/uslin.1291     > ../outputs/t3185
echo ">>>>>>>>running test 3186"
../source/print_tokens.exe ../inputs/uslin.1292     > ../outputs/t3186
echo ">>>>>>>>running test 3187"
../source/print_tokens.exe ../inputs/uslin.1294     > ../outputs/t3187
echo ">>>>>>>>running test 3188"
../source/print_tokens.exe ../inputs/uslin.1298     > ../outputs/t3188
echo ">>>>>>>>running test 3189"
../source/print_tokens.exe ../inputs/uslin.1302     > ../outputs/t3189
echo ">>>>>>>>running test 3190"
../source/print_tokens.exe ../inputs/uslin.1303     > ../outputs/t3190
echo ">>>>>>>>running test 3191"
../source/print_tokens.exe ../inputs/uslin.1305     > ../outputs/t3191
echo ">>>>>>>>running test 3192"
../source/print_tokens.exe ../inputs/uslin.1306     > ../outputs/t3192
echo ">>>>>>>>running test 3193"
../source/print_tokens.exe ../inputs/uslin.131     > ../outputs/t3193
echo ">>>>>>>>running test 3194"
../source/print_tokens.exe ../inputs/uslin.1316     > ../outputs/t3194
echo ">>>>>>>>running test 3195"
../source/print_tokens.exe ../inputs/uslin.1317     > ../outputs/t3195
echo ">>>>>>>>running test 3196"
../source/print_tokens.exe ../inputs/uslin.132     > ../outputs/t3196
echo ">>>>>>>>running test 3197"
../source/print_tokens.exe ../inputs/uslin.1321     > ../outputs/t3197
echo ">>>>>>>>running test 3198"
../source/print_tokens.exe ../inputs/uslin.1322     > ../outputs/t3198
echo ">>>>>>>>running test 3199"
../source/print_tokens.exe ../inputs/uslin.1324     > ../outputs/t3199
echo ">>>>>>>>running test 3200"
../source/print_tokens.exe ../inputs/uslin.1325     > ../outputs/t3200
echo ">>>>>>>>running test 3201"
../source/print_tokens.exe ../inputs/uslin.1327     > ../outputs/t3201
echo ">>>>>>>>running test 3202"
../source/print_tokens.exe ../inputs/uslin.1328     > ../outputs/t3202
echo ">>>>>>>>running test 3203"
../source/print_tokens.exe ../inputs/uslin.1330     > ../outputs/t3203
echo ">>>>>>>>running test 3204"
../source/print_tokens.exe ../inputs/uslin.1333     > ../outputs/t3204
echo ">>>>>>>>running test 3205"
../source/print_tokens.exe ../inputs/uslin.1334     > ../outputs/t3205
echo ">>>>>>>>running test 3206"
../source/print_tokens.exe ../inputs/uslin.1335     > ../outputs/t3206
echo ">>>>>>>>running test 3207"
../source/print_tokens.exe ../inputs/uslin.1337     > ../outputs/t3207
echo ">>>>>>>>running test 3208"
../source/print_tokens.exe ../inputs/uslin.1339     > ../outputs/t3208
echo ">>>>>>>>running test 3209"
../source/print_tokens.exe ../inputs/uslin.134     > ../outputs/t3209
echo ">>>>>>>>running test 3210"
../source/print_tokens.exe ../inputs/uslin.1340     > ../outputs/t3210
echo ">>>>>>>>running test 3211"
../source/print_tokens.exe ../inputs/uslin.1341     > ../outputs/t3211
echo ">>>>>>>>running test 3212"
../source/print_tokens.exe ../inputs/uslin.1342     > ../outputs/t3212
echo ">>>>>>>>running test 3213"
../source/print_tokens.exe ../inputs/uslin.1346     > ../outputs/t3213
echo ">>>>>>>>running test 3214"
../source/print_tokens.exe ../inputs/uslin.1348     > ../outputs/t3214
echo ">>>>>>>>running test 3215"
../source/print_tokens.exe ../inputs/uslin.1352     > ../outputs/t3215
echo ">>>>>>>>running test 3216"
../source/print_tokens.exe ../inputs/uslin.1353     > ../outputs/t3216
echo ">>>>>>>>running test 3217"
../source/print_tokens.exe ../inputs/uslin.1354     > ../outputs/t3217
echo ">>>>>>>>running test 3218"
../source/print_tokens.exe ../inputs/uslin.1358     > ../outputs/t3218
echo ">>>>>>>>running test 3219"
../source/print_tokens.exe ../inputs/uslin.1359     > ../outputs/t3219
echo ">>>>>>>>running test 3220"
../source/print_tokens.exe ../inputs/uslin.1364     > ../outputs/t3220
echo ">>>>>>>>running test 3221"
../source/print_tokens.exe ../inputs/uslin.1368     > ../outputs/t3221
echo ">>>>>>>>running test 3222"
../source/print_tokens.exe ../inputs/uslin.137     > ../outputs/t3222
echo ">>>>>>>>running test 3223"
../source/print_tokens.exe ../inputs/uslin.1370     > ../outputs/t3223
echo ">>>>>>>>running test 3224"
../source/print_tokens.exe ../inputs/uslin.1371     > ../outputs/t3224
echo ">>>>>>>>running test 3225"
../source/print_tokens.exe ../inputs/uslin.1373     > ../outputs/t3225
echo ">>>>>>>>running test 3226"
../source/print_tokens.exe ../inputs/uslin.1374     > ../outputs/t3226
echo ">>>>>>>>running test 3227"
../source/print_tokens.exe ../inputs/uslin.1375     > ../outputs/t3227
echo ">>>>>>>>running test 3228"
../source/print_tokens.exe ../inputs/uslin.1376     > ../outputs/t3228
echo ">>>>>>>>running test 3229"
../source/print_tokens.exe ../inputs/uslin.1378     > ../outputs/t3229
echo ">>>>>>>>running test 3230"
../source/print_tokens.exe ../inputs/uslin.1379     > ../outputs/t3230
echo ">>>>>>>>running test 3231"
../source/print_tokens.exe ../inputs/uslin.138     > ../outputs/t3231
echo ">>>>>>>>running test 3232"
../source/print_tokens.exe ../inputs/uslin.1380     > ../outputs/t3232
echo ">>>>>>>>running test 3233"
../source/print_tokens.exe ../inputs/uslin.1384     > ../outputs/t3233
echo ">>>>>>>>running test 3234"
../source/print_tokens.exe ../inputs/uslin.1385     > ../outputs/t3234
echo ">>>>>>>>running test 3235"
../source/print_tokens.exe ../inputs/uslin.1386     > ../outputs/t3235
echo ">>>>>>>>running test 3236"
../source/print_tokens.exe ../inputs/uslin.1389     > ../outputs/t3236
echo ">>>>>>>>running test 3237"
../source/print_tokens.exe ../inputs/uslin.139     > ../outputs/t3237
echo ">>>>>>>>running test 3238"
../source/print_tokens.exe ../inputs/uslin.1390     > ../outputs/t3238
echo ">>>>>>>>running test 3239"
../source/print_tokens.exe ../inputs/uslin.1391     > ../outputs/t3239
echo ">>>>>>>>running test 3240"
../source/print_tokens.exe ../inputs/uslin.1394     > ../outputs/t3240
echo ">>>>>>>>running test 3241"
../source/print_tokens.exe ../inputs/uslin.1395     > ../outputs/t3241
echo ">>>>>>>>running test 3242"
../source/print_tokens.exe ../inputs/uslin.1398     > ../outputs/t3242
echo ">>>>>>>>running test 3243"
../source/print_tokens.exe ../inputs/uslin.1399     > ../outputs/t3243
echo ">>>>>>>>running test 3244"
../source/print_tokens.exe ../inputs/uslin.14     > ../outputs/t3244
echo ">>>>>>>>running test 3245"
../source/print_tokens.exe ../inputs/uslin.1401     > ../outputs/t3245
echo ">>>>>>>>running test 3246"
../source/print_tokens.exe ../inputs/uslin.1402     > ../outputs/t3246
echo ">>>>>>>>running test 3247"
../source/print_tokens.exe ../inputs/uslin.1403     > ../outputs/t3247
echo ">>>>>>>>running test 3248"
../source/print_tokens.exe ../inputs/uslin.1406     > ../outputs/t3248
echo ">>>>>>>>running test 3249"
../source/print_tokens.exe ../inputs/uslin.1407     > ../outputs/t3249
echo ">>>>>>>>running test 3250"
../source/print_tokens.exe ../inputs/uslin.141     > ../outputs/t3250
echo ">>>>>>>>running test 3251"
../source/print_tokens.exe ../inputs/uslin.1411     > ../outputs/t3251
echo ">>>>>>>>running test 3252"
../source/print_tokens.exe ../inputs/uslin.1412     > ../outputs/t3252
echo ">>>>>>>>running test 3253"
../source/print_tokens.exe ../inputs/uslin.1414     > ../outputs/t3253
echo ">>>>>>>>running test 3254"
../source/print_tokens.exe ../inputs/uslin.1416     > ../outputs/t3254
echo ">>>>>>>>running test 3255"
../source/print_tokens.exe ../inputs/uslin.1417     > ../outputs/t3255
echo ">>>>>>>>running test 3256"
../source/print_tokens.exe ../inputs/uslin.1418      > ../outputs/t3256
echo ">>>>>>>>running test 3257"
../source/print_tokens.exe ../inputs/uslin.1419     > ../outputs/t3257
echo ">>>>>>>>running test 3258"
../source/print_tokens.exe ../inputs/uslin.1422     > ../outputs/t3258
echo ">>>>>>>>running test 3259"
../source/print_tokens.exe ../inputs/uslin.1423     > ../outputs/t3259
echo ">>>>>>>>running test 3260"
../source/print_tokens.exe ../inputs/uslin.1426     > ../outputs/t3260
echo ">>>>>>>>running test 3261"
../source/print_tokens.exe ../inputs/uslin.1427     > ../outputs/t3261
echo ">>>>>>>>running test 3262"
../source/print_tokens.exe ../inputs/uslin.1428     > ../outputs/t3262
echo ">>>>>>>>running test 3263"
../source/print_tokens.exe ../inputs/uslin.1431     > ../outputs/t3263
echo ">>>>>>>>running test 3264"
../source/print_tokens.exe ../inputs/uslin.1432     > ../outputs/t3264
echo ">>>>>>>>running test 3265"
../source/print_tokens.exe ../inputs/uslin.1433     > ../outputs/t3265
echo ">>>>>>>>running test 3266"
../source/print_tokens.exe ../inputs/uslin.1434     > ../outputs/t3266
echo ">>>>>>>>running test 3267"
../source/print_tokens.exe ../inputs/uslin.1435     > ../outputs/t3267
echo ">>>>>>>>running test 3268"
../source/print_tokens.exe ../inputs/uslin.1436     > ../outputs/t3268
echo ">>>>>>>>running test 3269"
../source/print_tokens.exe ../inputs/uslin.144     > ../outputs/t3269
echo ">>>>>>>>running test 3270"
../source/print_tokens.exe ../inputs/uslin.1440     > ../outputs/t3270
echo ">>>>>>>>running test 3271"
../source/print_tokens.exe ../inputs/uslin.1444     > ../outputs/t3271
echo ">>>>>>>>running test 3272"
../source/print_tokens.exe ../inputs/uslin.1445     > ../outputs/t3272
echo ">>>>>>>>running test 3273"
../source/print_tokens.exe ../inputs/uslin.1446     > ../outputs/t3273
echo ">>>>>>>>running test 3274"
../source/print_tokens.exe ../inputs/uslin.1447     > ../outputs/t3274
echo ">>>>>>>>running test 3275"
../source/print_tokens.exe ../inputs/uslin.1448     > ../outputs/t3275
echo ">>>>>>>>running test 3276"
../source/print_tokens.exe ../inputs/uslin.1449     > ../outputs/t3276
echo ">>>>>>>>running test 3277"
../source/print_tokens.exe ../inputs/uslin.1450     > ../outputs/t3277
echo ">>>>>>>>running test 3278"
../source/print_tokens.exe ../inputs/uslin.1451     > ../outputs/t3278
echo ">>>>>>>>running test 3279"
../source/print_tokens.exe ../inputs/uslin.1452     > ../outputs/t3279
echo ">>>>>>>>running test 3280"
../source/print_tokens.exe ../inputs/uslin.1453     > ../outputs/t3280
echo ">>>>>>>>running test 3281"
../source/print_tokens.exe ../inputs/uslin.1454     > ../outputs/t3281
echo ">>>>>>>>running test 3282"
../source/print_tokens.exe ../inputs/uslin.1456     > ../outputs/t3282
echo ">>>>>>>>running test 3283"
../source/print_tokens.exe ../inputs/uslin.1458     > ../outputs/t3283
echo ">>>>>>>>running test 3284"
../source/print_tokens.exe ../inputs/uslin.146     > ../outputs/t3284
echo ">>>>>>>>running test 3285"
../source/print_tokens.exe ../inputs/uslin.1460     > ../outputs/t3285
echo ">>>>>>>>running test 3286"
../source/print_tokens.exe ../inputs/uslin.1462     > ../outputs/t3286
echo ">>>>>>>>running test 3287"
../source/print_tokens.exe ../inputs/uslin.1463     > ../outputs/t3287
echo ">>>>>>>>running test 3288"
../source/print_tokens.exe ../inputs/uslin.1464     > ../outputs/t3288
echo ">>>>>>>>running test 3289"
../source/print_tokens.exe ../inputs/uslin.1465     > ../outputs/t3289
echo ">>>>>>>>running test 3290"
../source/print_tokens.exe ../inputs/uslin.1466     > ../outputs/t3290
echo ">>>>>>>>running test 3291"
../source/print_tokens.exe ../inputs/uslin.1467     > ../outputs/t3291
echo ">>>>>>>>running test 3292"
../source/print_tokens.exe ../inputs/uslin.1471     > ../outputs/t3292
echo ">>>>>>>>running test 3293"
../source/print_tokens.exe ../inputs/uslin.1472     > ../outputs/t3293
echo ">>>>>>>>running test 3294"
../source/print_tokens.exe ../inputs/uslin.1473     > ../outputs/t3294
echo ">>>>>>>>running test 3295"
../source/print_tokens.exe ../inputs/uslin.1474     > ../outputs/t3295
echo ">>>>>>>>running test 3296"
../source/print_tokens.exe ../inputs/uslin.1477     > ../outputs/t3296
echo ">>>>>>>>running test 3297"
../source/print_tokens.exe ../inputs/uslin.1478     > ../outputs/t3297
echo ">>>>>>>>running test 3298"
../source/print_tokens.exe ../inputs/uslin.1479     > ../outputs/t3298
echo ">>>>>>>>running test 3299"
../source/print_tokens.exe ../inputs/uslin.148     > ../outputs/t3299
echo ">>>>>>>>running test 3300"
../source/print_tokens.exe ../inputs/uslin.1481     > ../outputs/t3300
echo ">>>>>>>>running test 3301"
../source/print_tokens.exe ../inputs/uslin.1482     > ../outputs/t3301
echo ">>>>>>>>running test 3302"
../source/print_tokens.exe ../inputs/uslin.1484     > ../outputs/t3302
echo ">>>>>>>>running test 3303"
../source/print_tokens.exe ../inputs/uslin.1485     > ../outputs/t3303
echo ">>>>>>>>running test 3304"
../source/print_tokens.exe ../inputs/uslin.1487     > ../outputs/t3304
echo ">>>>>>>>running test 3305"
../source/print_tokens.exe ../inputs/uslin.1488     > ../outputs/t3305
echo ">>>>>>>>running test 3306"
../source/print_tokens.exe ../inputs/uslin.1489     > ../outputs/t3306
echo ">>>>>>>>running test 3307"
../source/print_tokens.exe ../inputs/uslin.149     > ../outputs/t3307
echo ">>>>>>>>running test 3308"
../source/print_tokens.exe ../inputs/uslin.1495     > ../outputs/t3308
echo ">>>>>>>>running test 3309"
../source/print_tokens.exe ../inputs/uslin.1498     > ../outputs/t3309
echo ">>>>>>>>running test 3310"
../source/print_tokens.exe ../inputs/uslin.1499     > ../outputs/t3310
echo ">>>>>>>>running test 3311"
../source/print_tokens.exe ../inputs/uslin.150     > ../outputs/t3311
echo ">>>>>>>>running test 3312"
../source/print_tokens.exe ../inputs/uslin.1500     > ../outputs/t3312
echo ">>>>>>>>running test 3313"
../source/print_tokens.exe ../inputs/uslin.1503     > ../outputs/t3313
echo ">>>>>>>>running test 3314"
../source/print_tokens.exe ../inputs/uslin.1505     > ../outputs/t3314
echo ">>>>>>>>running test 3315"
../source/print_tokens.exe ../inputs/uslin.1506     > ../outputs/t3315
echo ">>>>>>>>running test 3316"
../source/print_tokens.exe ../inputs/uslin.1507     > ../outputs/t3316
echo ">>>>>>>>running test 3317"
../source/print_tokens.exe ../inputs/uslin.1508     > ../outputs/t3317
echo ">>>>>>>>running test 3318"
../source/print_tokens.exe ../inputs/uslin.1511     > ../outputs/t3318
echo ">>>>>>>>running test 3319"
../source/print_tokens.exe ../inputs/uslin.1512     > ../outputs/t3319
echo ">>>>>>>>running test 3320"
../source/print_tokens.exe ../inputs/uslin.1513     > ../outputs/t3320
echo ">>>>>>>>running test 3321"
../source/print_tokens.exe ../inputs/uslin.1514     > ../outputs/t3321
echo ">>>>>>>>running test 3322"
../source/print_tokens.exe ../inputs/uslin.1515     > ../outputs/t3322
echo ">>>>>>>>running test 3323"
../source/print_tokens.exe ../inputs/uslin.152      > ../outputs/t3323
echo ">>>>>>>>running test 3324"
../source/print_tokens.exe ../inputs/uslin.1520     > ../outputs/t3324
echo ">>>>>>>>running test 3325"
../source/print_tokens.exe ../inputs/uslin.1521     > ../outputs/t3325
echo ">>>>>>>>running test 3326"
../source/print_tokens.exe ../inputs/uslin.1522      > ../outputs/t3326
echo ">>>>>>>>running test 3327"
../source/print_tokens.exe ../inputs/uslin.1523     > ../outputs/t3327
echo ">>>>>>>>running test 3328"
../source/print_tokens.exe ../inputs/uslin.1528     > ../outputs/t3328
echo ">>>>>>>>running test 3329"
../source/print_tokens.exe ../inputs/uslin.1531     > ../outputs/t3329
echo ">>>>>>>>running test 3330"
../source/print_tokens.exe ../inputs/uslin.1533     > ../outputs/t3330
echo ">>>>>>>>running test 3331"
../source/print_tokens.exe ../inputs/uslin.1535     > ../outputs/t3331
echo ">>>>>>>>running test 3332"
../source/print_tokens.exe ../inputs/uslin.1536     > ../outputs/t3332
echo ">>>>>>>>running test 3333"
../source/print_tokens.exe ../inputs/uslin.1537     > ../outputs/t3333
echo ">>>>>>>>running test 3334"
../source/print_tokens.exe ../inputs/uslin.1540     > ../outputs/t3334
echo ">>>>>>>>running test 3335"
../source/print_tokens.exe ../inputs/uslin.1543     > ../outputs/t3335
echo ">>>>>>>>running test 3336"
../source/print_tokens.exe ../inputs/uslin.1544     > ../outputs/t3336
echo ">>>>>>>>running test 3337"
../source/print_tokens.exe ../inputs/uslin.1545     > ../outputs/t3337
echo ">>>>>>>>running test 3338"
../source/print_tokens.exe ../inputs/uslin.1547      > ../outputs/t3338
echo ">>>>>>>>running test 3339"
../source/print_tokens.exe ../inputs/uslin.1548     > ../outputs/t3339
echo ">>>>>>>>running test 3340"
../source/print_tokens.exe ../inputs/uslin.1550     > ../outputs/t3340
echo ">>>>>>>>running test 3341"
../source/print_tokens.exe ../inputs/uslin.1552     > ../outputs/t3341
echo ">>>>>>>>running test 3342"
../source/print_tokens.exe ../inputs/uslin.1553     > ../outputs/t3342
echo ">>>>>>>>running test 3343"
../source/print_tokens.exe ../inputs/uslin.1555     > ../outputs/t3343
echo ">>>>>>>>running test 3344"
../source/print_tokens.exe ../inputs/uslin.1558     > ../outputs/t3344
echo ">>>>>>>>running test 3345"
../source/print_tokens.exe ../inputs/uslin.156     > ../outputs/t3345
echo ">>>>>>>>running test 3346"
../source/print_tokens.exe ../inputs/uslin.1560     > ../outputs/t3346
echo ">>>>>>>>running test 3347"
../source/print_tokens.exe ../inputs/uslin.1561     > ../outputs/t3347
echo ">>>>>>>>running test 3348"
../source/print_tokens.exe ../inputs/uslin.1564     > ../outputs/t3348
echo ">>>>>>>>running test 3349"
../source/print_tokens.exe ../inputs/uslin.1568     > ../outputs/t3349
echo ">>>>>>>>running test 3350"
../source/print_tokens.exe ../inputs/uslin.1571     > ../outputs/t3350
echo ">>>>>>>>running test 3351"
../source/print_tokens.exe ../inputs/uslin.1573     > ../outputs/t3351
echo ">>>>>>>>running test 3352"
../source/print_tokens.exe ../inputs/uslin.1574     > ../outputs/t3352
echo ">>>>>>>>running test 3353"
../source/print_tokens.exe ../inputs/uslin.1575      > ../outputs/t3353
echo ">>>>>>>>running test 3354"
../source/print_tokens.exe ../inputs/uslin.1577     > ../outputs/t3354
echo ">>>>>>>>running test 3355"
../source/print_tokens.exe ../inputs/uslin.158     > ../outputs/t3355
echo ">>>>>>>>running test 3356"
../source/print_tokens.exe ../inputs/uslin.1580     > ../outputs/t3356
echo ">>>>>>>>running test 3357"
../source/print_tokens.exe ../inputs/uslin.1581     > ../outputs/t3357
echo ">>>>>>>>running test 3358"
../source/print_tokens.exe ../inputs/uslin.1582     > ../outputs/t3358
echo ">>>>>>>>running test 3359"
../source/print_tokens.exe ../inputs/uslin.1583      > ../outputs/t3359
echo ">>>>>>>>running test 3360"
../source/print_tokens.exe ../inputs/uslin.1585     > ../outputs/t3360
echo ">>>>>>>>running test 3361"
../source/print_tokens.exe ../inputs/uslin.1586      > ../outputs/t3361
echo ">>>>>>>>running test 3362"
../source/print_tokens.exe ../inputs/uslin.159     > ../outputs/t3362
echo ">>>>>>>>running test 3363"
../source/print_tokens.exe ../inputs/uslin.1590     > ../outputs/t3363
echo ">>>>>>>>running test 3364"
../source/print_tokens.exe ../inputs/uslin.1591     > ../outputs/t3364
echo ">>>>>>>>running test 3365"
../source/print_tokens.exe ../inputs/uslin.1592     > ../outputs/t3365
echo ">>>>>>>>running test 3366"
../source/print_tokens.exe ../inputs/uslin.1594     > ../outputs/t3366
echo ">>>>>>>>running test 3367"
../source/print_tokens.exe ../inputs/uslin.1595      > ../outputs/t3367
echo ">>>>>>>>running test 3368"
../source/print_tokens.exe ../inputs/uslin.1597     > ../outputs/t3368
echo ">>>>>>>>running test 3369"
../source/print_tokens.exe ../inputs/uslin.1601     > ../outputs/t3369
echo ">>>>>>>>running test 3370"
../source/print_tokens.exe ../inputs/uslin.1602     > ../outputs/t3370
echo ">>>>>>>>running test 3371"
../source/print_tokens.exe ../inputs/uslin.1603     > ../outputs/t3371
echo ">>>>>>>>running test 3372"
../source/print_tokens.exe ../inputs/uslin.1606     > ../outputs/t3372
echo ">>>>>>>>running test 3373"
../source/print_tokens.exe ../inputs/uslin.1607     > ../outputs/t3373
echo ">>>>>>>>running test 3374"
../source/print_tokens.exe ../inputs/uslin.1608     > ../outputs/t3374
echo ">>>>>>>>running test 3375"
../source/print_tokens.exe ../inputs/uslin.1610      > ../outputs/t3375
echo ">>>>>>>>running test 3376"
../source/print_tokens.exe ../inputs/uslin.1614     > ../outputs/t3376
echo ">>>>>>>>running test 3377"
../source/print_tokens.exe ../inputs/uslin.1617     > ../outputs/t3377
echo ">>>>>>>>running test 3378"
../source/print_tokens.exe ../inputs/uslin.1618     > ../outputs/t3378
echo ">>>>>>>>running test 3379"
../source/print_tokens.exe ../inputs/uslin.1619     > ../outputs/t3379
echo ">>>>>>>>running test 3380"
../source/print_tokens.exe ../inputs/uslin.1620     > ../outputs/t3380
echo ">>>>>>>>running test 3381"
../source/print_tokens.exe ../inputs/uslin.1623     > ../outputs/t3381
echo ">>>>>>>>running test 3382"
../source/print_tokens.exe ../inputs/uslin.1624     > ../outputs/t3382
echo ">>>>>>>>running test 3383"
../source/print_tokens.exe ../inputs/uslin.1625     > ../outputs/t3383
echo ">>>>>>>>running test 3384"
../source/print_tokens.exe ../inputs/uslin.1626      > ../outputs/t3384
echo ">>>>>>>>running test 3385"
../source/print_tokens.exe ../inputs/uslin.1629     > ../outputs/t3385
echo ">>>>>>>>running test 3386"
../source/print_tokens.exe ../inputs/uslin.1630     > ../outputs/t3386
echo ">>>>>>>>running test 3387"
../source/print_tokens.exe ../inputs/uslin.1631     > ../outputs/t3387
echo ">>>>>>>>running test 3388"
../source/print_tokens.exe ../inputs/uslin.1632     > ../outputs/t3388
echo ">>>>>>>>running test 3389"
../source/print_tokens.exe ../inputs/uslin.1634     > ../outputs/t3389
echo ">>>>>>>>running test 3390"
../source/print_tokens.exe ../inputs/uslin.1635     > ../outputs/t3390
echo ">>>>>>>>running test 3391"
../source/print_tokens.exe ../inputs/uslin.1637     > ../outputs/t3391
echo ">>>>>>>>running test 3392"
../source/print_tokens.exe ../inputs/uslin.1638     > ../outputs/t3392
echo ">>>>>>>>running test 3393"
../source/print_tokens.exe ../inputs/uslin.1641     > ../outputs/t3393
echo ">>>>>>>>running test 3394"
../source/print_tokens.exe ../inputs/uslin.1644     > ../outputs/t3394
echo ">>>>>>>>running test 3395"
../source/print_tokens.exe ../inputs/uslin.1645     > ../outputs/t3395
echo ">>>>>>>>running test 3396"
../source/print_tokens.exe ../inputs/uslin.1646     > ../outputs/t3396
echo ">>>>>>>>running test 3397"
../source/print_tokens.exe ../inputs/uslin.165     > ../outputs/t3397
echo ">>>>>>>>running test 3398"
../source/print_tokens.exe ../inputs/uslin.1651     > ../outputs/t3398
echo ">>>>>>>>running test 3399"
../source/print_tokens.exe ../inputs/uslin.1652     > ../outputs/t3399
echo ">>>>>>>>running test 3400"
../source/print_tokens.exe ../inputs/uslin.1653     > ../outputs/t3400
echo ">>>>>>>>running test 3401"
../source/print_tokens.exe ../inputs/uslin.1654     > ../outputs/t3401
echo ">>>>>>>>running test 3402"
../source/print_tokens.exe ../inputs/uslin.1655     > ../outputs/t3402
echo ">>>>>>>>running test 3403"
../source/print_tokens.exe ../inputs/uslin.1656     > ../outputs/t3403
echo ">>>>>>>>running test 3404"
../source/print_tokens.exe ../inputs/uslin.1657     > ../outputs/t3404
echo ">>>>>>>>running test 3405"
../source/print_tokens.exe ../inputs/uslin.166     > ../outputs/t3405
echo ">>>>>>>>running test 3406"
../source/print_tokens.exe ../inputs/uslin.1661     > ../outputs/t3406
echo ">>>>>>>>running test 3407"
../source/print_tokens.exe ../inputs/uslin.1662     > ../outputs/t3407
echo ">>>>>>>>running test 3408"
../source/print_tokens.exe ../inputs/uslin.1663     > ../outputs/t3408
echo ">>>>>>>>running test 3409"
../source/print_tokens.exe ../inputs/uslin.1664     > ../outputs/t3409
echo ">>>>>>>>running test 3410"
../source/print_tokens.exe ../inputs/uslin.1665     > ../outputs/t3410
echo ">>>>>>>>running test 3411"
../source/print_tokens.exe ../inputs/uslin.167     > ../outputs/t3411
echo ">>>>>>>>running test 3412"
../source/print_tokens.exe ../inputs/uslin.1673     > ../outputs/t3412
echo ">>>>>>>>running test 3413"
../source/print_tokens.exe ../inputs/uslin.1674     > ../outputs/t3413
echo ">>>>>>>>running test 3414"
../source/print_tokens.exe ../inputs/uslin.1677      > ../outputs/t3414
echo ">>>>>>>>running test 3415"
../source/print_tokens.exe ../inputs/uslin.1678     > ../outputs/t3415
echo ">>>>>>>>running test 3416"
../source/print_tokens.exe ../inputs/uslin.168     > ../outputs/t3416
echo ">>>>>>>>running test 3417"
../source/print_tokens.exe ../inputs/uslin.1680     > ../outputs/t3417
echo ">>>>>>>>running test 3418"
../source/print_tokens.exe ../inputs/uslin.1682     > ../outputs/t3418
echo ">>>>>>>>running test 3419"
../source/print_tokens.exe ../inputs/uslin.1683     > ../outputs/t3419
echo ">>>>>>>>running test 3420"
../source/print_tokens.exe ../inputs/uslin.1684     > ../outputs/t3420
echo ">>>>>>>>running test 3421"
../source/print_tokens.exe ../inputs/uslin.1685     > ../outputs/t3421
echo ">>>>>>>>running test 3422"
../source/print_tokens.exe ../inputs/uslin.1687     > ../outputs/t3422
echo ">>>>>>>>running test 3423"
../source/print_tokens.exe ../inputs/uslin.1688     > ../outputs/t3423
echo ">>>>>>>>running test 3424"
../source/print_tokens.exe ../inputs/uslin.1689     > ../outputs/t3424
echo ">>>>>>>>running test 3425"
../source/print_tokens.exe ../inputs/uslin.1690     > ../outputs/t3425
echo ">>>>>>>>running test 3426"
../source/print_tokens.exe ../inputs/uslin.1692     > ../outputs/t3426
echo ">>>>>>>>running test 3427"
../source/print_tokens.exe ../inputs/uslin.1693     > ../outputs/t3427
echo ">>>>>>>>running test 3428"
../source/print_tokens.exe ../inputs/uslin.1696     > ../outputs/t3428
echo ">>>>>>>>running test 3429"
../source/print_tokens.exe ../inputs/uslin.1697     > ../outputs/t3429
echo ">>>>>>>>running test 3430"
../source/print_tokens.exe ../inputs/uslin.1699     > ../outputs/t3430
echo ">>>>>>>>running test 3431"
../source/print_tokens.exe ../inputs/uslin.1700     > ../outputs/t3431
echo ">>>>>>>>running test 3432"
../source/print_tokens.exe ../inputs/uslin.1701     > ../outputs/t3432
echo ">>>>>>>>running test 3433"
../source/print_tokens.exe ../inputs/uslin.1703     > ../outputs/t3433
echo ">>>>>>>>running test 3434"
../source/print_tokens.exe ../inputs/uslin.1704     > ../outputs/t3434
echo ">>>>>>>>running test 3435"
../source/print_tokens.exe ../inputs/uslin.1705     > ../outputs/t3435
echo ">>>>>>>>running test 3436"
../source/print_tokens.exe ../inputs/uslin.1706     > ../outputs/t3436
echo ">>>>>>>>running test 3437"
../source/print_tokens.exe ../inputs/uslin.1708     > ../outputs/t3437
echo ">>>>>>>>running test 3438"
../source/print_tokens.exe ../inputs/uslin.1709     > ../outputs/t3438
echo ">>>>>>>>running test 3439"
../source/print_tokens.exe ../inputs/uslin.1713     > ../outputs/t3439
echo ">>>>>>>>running test 3440"
../source/print_tokens.exe ../inputs/uslin.1714     > ../outputs/t3440
echo ">>>>>>>>running test 3441"
../source/print_tokens.exe ../inputs/uslin.1715     > ../outputs/t3441
echo ">>>>>>>>running test 3442"
../source/print_tokens.exe ../inputs/uslin.1717     > ../outputs/t3442
echo ">>>>>>>>running test 3443"
../source/print_tokens.exe ../inputs/uslin.1718     > ../outputs/t3443
echo ">>>>>>>>running test 3444"
../source/print_tokens.exe ../inputs/uslin.1719     > ../outputs/t3444
echo ">>>>>>>>running test 3445"
../source/print_tokens.exe ../inputs/uslin.172     > ../outputs/t3445
echo ">>>>>>>>running test 3446"
../source/print_tokens.exe ../inputs/uslin.1720     > ../outputs/t3446
echo ">>>>>>>>running test 3447"
../source/print_tokens.exe ../inputs/uslin.1721     > ../outputs/t3447
echo ">>>>>>>>running test 3448"
../source/print_tokens.exe ../inputs/uslin.1722     > ../outputs/t3448
echo ">>>>>>>>running test 3449"
../source/print_tokens.exe ../inputs/uslin.1723     > ../outputs/t3449
echo ">>>>>>>>running test 3450"
../source/print_tokens.exe ../inputs/uslin.1725     > ../outputs/t3450
echo ">>>>>>>>running test 3451"
../source/print_tokens.exe ../inputs/uslin.1726     > ../outputs/t3451
echo ">>>>>>>>running test 3452"
../source/print_tokens.exe ../inputs/uslin.1727     > ../outputs/t3452
echo ">>>>>>>>running test 3453"
../source/print_tokens.exe ../inputs/uslin.1729     > ../outputs/t3453
echo ">>>>>>>>running test 3454"
../source/print_tokens.exe ../inputs/uslin.173     > ../outputs/t3454
echo ">>>>>>>>running test 3455"
../source/print_tokens.exe ../inputs/uslin.1731     > ../outputs/t3455
echo ">>>>>>>>running test 3456"
../source/print_tokens.exe ../inputs/uslin.1732     > ../outputs/t3456
echo ">>>>>>>>running test 3457"
../source/print_tokens.exe ../inputs/uslin.1733     > ../outputs/t3457
echo ">>>>>>>>running test 3458"
../source/print_tokens.exe ../inputs/uslin.1734     > ../outputs/t3458
echo ">>>>>>>>running test 3459"
../source/print_tokens.exe ../inputs/uslin.1736     > ../outputs/t3459
echo ">>>>>>>>running test 3460"
../source/print_tokens.exe ../inputs/uslin.1739     > ../outputs/t3460
echo ">>>>>>>>running test 3461"
../source/print_tokens.exe ../inputs/uslin.174     > ../outputs/t3461
echo ">>>>>>>>running test 3462"
../source/print_tokens.exe ../inputs/uslin.1741     > ../outputs/t3462
echo ">>>>>>>>running test 3463"
../source/print_tokens.exe ../inputs/uslin.1743     > ../outputs/t3463
echo ">>>>>>>>running test 3464"
../source/print_tokens.exe ../inputs/uslin.1745     > ../outputs/t3464
echo ">>>>>>>>running test 3465"
../source/print_tokens.exe ../inputs/uslin.1746     > ../outputs/t3465
echo ">>>>>>>>running test 3466"
../source/print_tokens.exe ../inputs/uslin.1747     > ../outputs/t3466
echo ">>>>>>>>running test 3467"
../source/print_tokens.exe ../inputs/uslin.1748     > ../outputs/t3467
echo ">>>>>>>>running test 3468"
../source/print_tokens.exe ../inputs/uslin.1749     > ../outputs/t3468
echo ">>>>>>>>running test 3469"
../source/print_tokens.exe ../inputs/uslin.1750     > ../outputs/t3469
echo ">>>>>>>>running test 3470"
../source/print_tokens.exe ../inputs/uslin.1751     > ../outputs/t3470
echo ">>>>>>>>running test 3471"
../source/print_tokens.exe ../inputs/uslin.1752     > ../outputs/t3471
echo ">>>>>>>>running test 3472"
../source/print_tokens.exe ../inputs/uslin.1757     > ../outputs/t3472
echo ">>>>>>>>running test 3473"
../source/print_tokens.exe ../inputs/uslin.1758     > ../outputs/t3473
echo ">>>>>>>>running test 3474"
../source/print_tokens.exe ../inputs/uslin.1759     > ../outputs/t3474
echo ">>>>>>>>running test 3475"
../source/print_tokens.exe ../inputs/uslin.1761     > ../outputs/t3475
echo ">>>>>>>>running test 3476"
../source/print_tokens.exe ../inputs/uslin.1763     > ../outputs/t3476
echo ">>>>>>>>running test 3477"
../source/print_tokens.exe ../inputs/uslin.1765     > ../outputs/t3477
echo ">>>>>>>>running test 3478"
../source/print_tokens.exe ../inputs/uslin.1766     > ../outputs/t3478
echo ">>>>>>>>running test 3479"
../source/print_tokens.exe ../inputs/uslin.1767     > ../outputs/t3479
echo ">>>>>>>>running test 3480"
../source/print_tokens.exe ../inputs/uslin.1768     > ../outputs/t3480
echo ">>>>>>>>running test 3481"
../source/print_tokens.exe ../inputs/uslin.1769     > ../outputs/t3481
echo ">>>>>>>>running test 3482"
../source/print_tokens.exe ../inputs/uslin.1770     > ../outputs/t3482
echo ">>>>>>>>running test 3483"
../source/print_tokens.exe ../inputs/uslin.1772     > ../outputs/t3483
echo ">>>>>>>>running test 3484"
../source/print_tokens.exe ../inputs/uslin.1775     > ../outputs/t3484
echo ">>>>>>>>running test 3485"
../source/print_tokens.exe ../inputs/uslin.1777     > ../outputs/t3485
echo ">>>>>>>>running test 3486"
../source/print_tokens.exe ../inputs/uslin.1779     > ../outputs/t3486
echo ">>>>>>>>running test 3487"
../source/print_tokens.exe ../inputs/uslin.178     > ../outputs/t3487
echo ">>>>>>>>running test 3488"
../source/print_tokens.exe ../inputs/uslin.1780     > ../outputs/t3488
echo ">>>>>>>>running test 3489"
../source/print_tokens.exe ../inputs/uslin.1781     > ../outputs/t3489
echo ">>>>>>>>running test 3490"
../source/print_tokens.exe ../inputs/uslin.1784     > ../outputs/t3490
echo ">>>>>>>>running test 3491"
../source/print_tokens.exe ../inputs/uslin.1786     > ../outputs/t3491
echo ">>>>>>>>running test 3492"
../source/print_tokens.exe ../inputs/uslin.1788      > ../outputs/t3492
echo ">>>>>>>>running test 3493"
../source/print_tokens.exe ../inputs/uslin.179     > ../outputs/t3493
echo ">>>>>>>>running test 3494"
../source/print_tokens.exe ../inputs/uslin.1790     > ../outputs/t3494
echo ">>>>>>>>running test 3495"
../source/print_tokens.exe ../inputs/uslin.1791     > ../outputs/t3495
echo ">>>>>>>>running test 3496"
../source/print_tokens.exe ../inputs/uslin.1795      > ../outputs/t3496
echo ">>>>>>>>running test 3497"
../source/print_tokens.exe ../inputs/uslin.1796     > ../outputs/t3497
echo ">>>>>>>>running test 3498"
../source/print_tokens.exe ../inputs/uslin.1797     > ../outputs/t3498
echo ">>>>>>>>running test 3499"
../source/print_tokens.exe ../inputs/uslin.1799     > ../outputs/t3499
echo ">>>>>>>>running test 3500"
../source/print_tokens.exe ../inputs/uslin.18     > ../outputs/t3500
echo ">>>>>>>>running test 3501"
../source/print_tokens.exe ../inputs/uslin.180     > ../outputs/t3501
echo ">>>>>>>>running test 3502"
../source/print_tokens.exe ../inputs/uslin.1801     > ../outputs/t3502
echo ">>>>>>>>running test 3503"
../source/print_tokens.exe ../inputs/uslin.1803     > ../outputs/t3503
echo ">>>>>>>>running test 3504"
../source/print_tokens.exe ../inputs/uslin.1804     > ../outputs/t3504
echo ">>>>>>>>running test 3505"
../source/print_tokens.exe ../inputs/uslin.1805     > ../outputs/t3505
echo ">>>>>>>>running test 3506"
../source/print_tokens.exe ../inputs/uslin.1807     > ../outputs/t3506
echo ">>>>>>>>running test 3507"
../source/print_tokens.exe ../inputs/uslin.1808     > ../outputs/t3507
echo ">>>>>>>>running test 3508"
../source/print_tokens.exe ../inputs/uslin.1810     > ../outputs/t3508
echo ">>>>>>>>running test 3509"
../source/print_tokens.exe ../inputs/uslin.1811     > ../outputs/t3509
echo ">>>>>>>>running test 3510"
../source/print_tokens.exe ../inputs/uslin.1813     > ../outputs/t3510
echo ">>>>>>>>running test 3511"
../source/print_tokens.exe ../inputs/uslin.1815     > ../outputs/t3511
echo ">>>>>>>>running test 3512"
../source/print_tokens.exe ../inputs/uslin.1817     > ../outputs/t3512
echo ">>>>>>>>running test 3513"
../source/print_tokens.exe ../inputs/uslin.1820     > ../outputs/t3513
echo ">>>>>>>>running test 3514"
../source/print_tokens.exe ../inputs/uslin.1822     > ../outputs/t3514
echo ">>>>>>>>running test 3515"
../source/print_tokens.exe ../inputs/uslin.1824     > ../outputs/t3515
echo ">>>>>>>>running test 3516"
../source/print_tokens.exe ../inputs/uslin.1825     > ../outputs/t3516
echo ">>>>>>>>running test 3517"
../source/print_tokens.exe ../inputs/uslin.1826     > ../outputs/t3517
echo ">>>>>>>>running test 3518"
../source/print_tokens.exe ../inputs/uslin.1828     > ../outputs/t3518
echo ">>>>>>>>running test 3519"
../source/print_tokens.exe ../inputs/uslin.183     > ../outputs/t3519
echo ">>>>>>>>running test 3520"
../source/print_tokens.exe ../inputs/uslin.1831     > ../outputs/t3520
echo ">>>>>>>>running test 3521"
../source/print_tokens.exe ../inputs/uslin.1833     > ../outputs/t3521
echo ">>>>>>>>running test 3522"
../source/print_tokens.exe ../inputs/uslin.1834     > ../outputs/t3522
echo ">>>>>>>>running test 3523"
../source/print_tokens.exe ../inputs/uslin.1840     > ../outputs/t3523
echo ">>>>>>>>running test 3524"
../source/print_tokens.exe ../inputs/uslin.1841     > ../outputs/t3524
echo ">>>>>>>>running test 3525"
../source/print_tokens.exe ../inputs/uslin.1842     > ../outputs/t3525
echo ">>>>>>>>running test 3526"
../source/print_tokens.exe ../inputs/uslin.1843     > ../outputs/t3526
echo ">>>>>>>>running test 3527"
../source/print_tokens.exe ../inputs/uslin.1844     > ../outputs/t3527
echo ">>>>>>>>running test 3528"
../source/print_tokens.exe ../inputs/uslin.1846     > ../outputs/t3528
echo ">>>>>>>>running test 3529"
../source/print_tokens.exe ../inputs/uslin.1849     > ../outputs/t3529
echo ">>>>>>>>running test 3530"
../source/print_tokens.exe ../inputs/uslin.1851     > ../outputs/t3530
echo ">>>>>>>>running test 3531"
../source/print_tokens.exe ../inputs/uslin.1852     > ../outputs/t3531
echo ">>>>>>>>running test 3532"
../source/print_tokens.exe ../inputs/uslin.1853      > ../outputs/t3532
echo ">>>>>>>>running test 3533"
../source/print_tokens.exe ../inputs/uslin.1854      > ../outputs/t3533
echo ">>>>>>>>running test 3534"
../source/print_tokens.exe ../inputs/uslin.1857     > ../outputs/t3534
echo ">>>>>>>>running test 3535"
../source/print_tokens.exe ../inputs/uslin.1857.noeof     > ../outputs/t3535
echo ">>>>>>>>running test 3536"
../source/print_tokens.exe ../inputs/uslin.1859     > ../outputs/t3536
echo ">>>>>>>>running test 3537"
../source/print_tokens.exe ../inputs/uslin.186     > ../outputs/t3537
echo ">>>>>>>>running test 3538"
../source/print_tokens.exe ../inputs/uslin.1860     > ../outputs/t3538
echo ">>>>>>>>running test 3539"
../source/print_tokens.exe ../inputs/uslin.1861     > ../outputs/t3539
echo ">>>>>>>>running test 3540"
../source/print_tokens.exe ../inputs/uslin.1864     > ../outputs/t3540
echo ">>>>>>>>running test 3541"
../source/print_tokens.exe ../inputs/uslin.1866     > ../outputs/t3541
echo ">>>>>>>>running test 3542"
../source/print_tokens.exe ../inputs/uslin.1867     > ../outputs/t3542
echo ">>>>>>>>running test 3543"
../source/print_tokens.exe ../inputs/uslin.1868     > ../outputs/t3543
echo ">>>>>>>>running test 3544"
../source/print_tokens.exe ../inputs/uslin.1869     > ../outputs/t3544
echo ">>>>>>>>running test 3545"
../source/print_tokens.exe ../inputs/uslin.187     > ../outputs/t3545
echo ">>>>>>>>running test 3546"
../source/print_tokens.exe ../inputs/uslin.1870     > ../outputs/t3546
echo ">>>>>>>>running test 3547"
../source/print_tokens.exe ../inputs/uslin.1875     > ../outputs/t3547
echo ">>>>>>>>running test 3548"
../source/print_tokens.exe ../inputs/uslin.1879     > ../outputs/t3548
echo ">>>>>>>>running test 3549"
../source/print_tokens.exe ../inputs/uslin.1883     > ../outputs/t3549
echo ">>>>>>>>running test 3550"
../source/print_tokens.exe ../inputs/uslin.1884     > ../outputs/t3550
echo ">>>>>>>>running test 3551"
../source/print_tokens.exe ../inputs/uslin.1888     > ../outputs/t3551
echo ">>>>>>>>running test 3552"
../source/print_tokens.exe ../inputs/uslin.1889     > ../outputs/t3552
echo ">>>>>>>>running test 3553"
../source/print_tokens.exe ../inputs/uslin.1890     > ../outputs/t3553
echo ">>>>>>>>running test 3554"
../source/print_tokens.exe ../inputs/uslin.1894     > ../outputs/t3554
echo ">>>>>>>>running test 3555"
../source/print_tokens.exe ../inputs/uslin.1899     > ../outputs/t3555
echo ">>>>>>>>running test 3556"
../source/print_tokens.exe ../inputs/uslin.19     > ../outputs/t3556
echo ">>>>>>>>running test 3557"
../source/print_tokens.exe ../inputs/uslin.1900     > ../outputs/t3557
echo ">>>>>>>>running test 3558"
../source/print_tokens.exe ../inputs/uslin.1901     > ../outputs/t3558
echo ">>>>>>>>running test 3559"
../source/print_tokens.exe ../inputs/uslin.1902     > ../outputs/t3559
echo ">>>>>>>>running test 3560"
../source/print_tokens.exe ../inputs/uslin.1904     > ../outputs/t3560
echo ">>>>>>>>running test 3561"
../source/print_tokens.exe ../inputs/uslin.1906     > ../outputs/t3561
echo ">>>>>>>>running test 3562"
../source/print_tokens.exe ../inputs/uslin.1909     > ../outputs/t3562
echo ">>>>>>>>running test 3563"
../source/print_tokens.exe ../inputs/uslin.1910     > ../outputs/t3563
echo ">>>>>>>>running test 3564"
../source/print_tokens.exe ../inputs/uslin.1911     > ../outputs/t3564
echo ">>>>>>>>running test 3565"
../source/print_tokens.exe ../inputs/uslin.1915     > ../outputs/t3565
echo ">>>>>>>>running test 3566"
../source/print_tokens.exe ../inputs/uslin.1919     > ../outputs/t3566
echo ">>>>>>>>running test 3567"
../source/print_tokens.exe ../inputs/uslin.192     > ../outputs/t3567
echo ">>>>>>>>running test 3568"
../source/print_tokens.exe ../inputs/uslin.1921     > ../outputs/t3568
echo ">>>>>>>>running test 3569"
../source/print_tokens.exe ../inputs/uslin.1923     > ../outputs/t3569
echo ">>>>>>>>running test 3570"
../source/print_tokens.exe ../inputs/uslin.1927     > ../outputs/t3570
echo ">>>>>>>>running test 3571"
../source/print_tokens.exe ../inputs/uslin.1928      > ../outputs/t3571
echo ">>>>>>>>running test 3572"
../source/print_tokens.exe ../inputs/uslin.1930     > ../outputs/t3572
echo ">>>>>>>>running test 3573"
../source/print_tokens.exe ../inputs/uslin.1939     > ../outputs/t3573
echo ">>>>>>>>running test 3574"
../source/print_tokens.exe ../inputs/uslin.194     > ../outputs/t3574
echo ">>>>>>>>running test 3575"
../source/print_tokens.exe ../inputs/uslin.1940     > ../outputs/t3575
echo ">>>>>>>>running test 3576"
../source/print_tokens.exe ../inputs/uslin.1941     > ../outputs/t3576
echo ">>>>>>>>running test 3577"
../source/print_tokens.exe ../inputs/uslin.1942     > ../outputs/t3577
echo ">>>>>>>>running test 3578"
../source/print_tokens.exe ../inputs/uslin.1943     > ../outputs/t3578
echo ">>>>>>>>running test 3579"
../source/print_tokens.exe ../inputs/uslin.1949     > ../outputs/t3579
echo ">>>>>>>>running test 3580"
../source/print_tokens.exe ../inputs/uslin.1951     > ../outputs/t3580
echo ">>>>>>>>running test 3581"
../source/print_tokens.exe ../inputs/uslin.1952     > ../outputs/t3581
echo ">>>>>>>>running test 3582"
../source/print_tokens.exe ../inputs/uslin.1953     > ../outputs/t3582
echo ">>>>>>>>running test 3583"
../source/print_tokens.exe ../inputs/uslin.1954     > ../outputs/t3583
echo ">>>>>>>>running test 3584"
../source/print_tokens.exe ../inputs/uslin.1956     > ../outputs/t3584
echo ">>>>>>>>running test 3585"
../source/print_tokens.exe ../inputs/uslin.1957     > ../outputs/t3585
echo ">>>>>>>>running test 3586"
../source/print_tokens.exe ../inputs/uslin.196     > ../outputs/t3586
echo ">>>>>>>>running test 3587"
../source/print_tokens.exe ../inputs/uslin.1960     > ../outputs/t3587
echo ">>>>>>>>running test 3588"
../source/print_tokens.exe ../inputs/uslin.1962     > ../outputs/t3588
echo ">>>>>>>>running test 3589"
../source/print_tokens.exe ../inputs/uslin.1963     > ../outputs/t3589
echo ">>>>>>>>running test 3590"
../source/print_tokens.exe ../inputs/uslin.1965     > ../outputs/t3590
echo ">>>>>>>>running test 3591"
../source/print_tokens.exe ../inputs/uslin.1966     > ../outputs/t3591
echo ">>>>>>>>running test 3592"
../source/print_tokens.exe ../inputs/uslin.1967     > ../outputs/t3592
echo ">>>>>>>>running test 3593"
../source/print_tokens.exe ../inputs/uslin.1968     > ../outputs/t3593
echo ">>>>>>>>running test 3594"
../source/print_tokens.exe ../inputs/uslin.1969     > ../outputs/t3594
echo ">>>>>>>>running test 3595"
../source/print_tokens.exe ../inputs/uslin.197      > ../outputs/t3595
echo ">>>>>>>>running test 3596"
../source/print_tokens.exe ../inputs/uslin.1973     > ../outputs/t3596
echo ">>>>>>>>running test 3597"
../source/print_tokens.exe ../inputs/uslin.1976     > ../outputs/t3597
echo ">>>>>>>>running test 3598"
../source/print_tokens.exe ../inputs/uslin.1977     > ../outputs/t3598
echo ">>>>>>>>running test 3599"
../source/print_tokens.exe ../inputs/uslin.1978     > ../outputs/t3599
echo ">>>>>>>>running test 3600"
../source/print_tokens.exe ../inputs/uslin.198     > ../outputs/t3600
echo ">>>>>>>>running test 3601"
../source/print_tokens.exe ../inputs/uslin.1980     > ../outputs/t3601
echo ">>>>>>>>running test 3602"
../source/print_tokens.exe ../inputs/uslin.1981     > ../outputs/t3602
echo ">>>>>>>>running test 3603"
../source/print_tokens.exe ../inputs/uslin.1982     > ../outputs/t3603
echo ">>>>>>>>running test 3604"
../source/print_tokens.exe ../inputs/uslin.1983     > ../outputs/t3604
echo ">>>>>>>>running test 3605"
../source/print_tokens.exe ../inputs/uslin.1984.noeof     > ../outputs/t3605
echo ">>>>>>>>running test 3606"
../source/print_tokens.exe ../inputs/uslin.1986     > ../outputs/t3606
echo ">>>>>>>>running test 3607"
../source/print_tokens.exe ../inputs/uslin.1987     > ../outputs/t3607
echo ">>>>>>>>running test 3608"
../source/print_tokens.exe ../inputs/uslin.199     > ../outputs/t3608
echo ">>>>>>>>running test 3609"
../source/print_tokens.exe ../inputs/uslin.1991     > ../outputs/t3609
echo ">>>>>>>>running test 3610"
../source/print_tokens.exe ../inputs/uslin.1992      > ../outputs/t3610
echo ">>>>>>>>running test 3611"
../source/print_tokens.exe ../inputs/uslin.1993     > ../outputs/t3611
echo ">>>>>>>>running test 3612"
../source/print_tokens.exe ../inputs/uslin.1994     > ../outputs/t3612
echo ">>>>>>>>running test 3613"
../source/print_tokens.exe ../inputs/uslin.1996     > ../outputs/t3613
echo ">>>>>>>>running test 3614"
../source/print_tokens.exe ../inputs/uslin.200     > ../outputs/t3614
echo ">>>>>>>>running test 3615"
../source/print_tokens.exe ../inputs/uslin.202     > ../outputs/t3615
echo ">>>>>>>>running test 3616"
../source/print_tokens.exe ../inputs/uslin.203     > ../outputs/t3616
echo ">>>>>>>>running test 3617"
../source/print_tokens.exe ../inputs/uslin.205     > ../outputs/t3617
echo ">>>>>>>>running test 3618"
../source/print_tokens.exe ../inputs/uslin.211     > ../outputs/t3618
echo ">>>>>>>>running test 3619"
../source/print_tokens.exe ../inputs/uslin.212     > ../outputs/t3619
echo ">>>>>>>>running test 3620"
../source/print_tokens.exe ../inputs/uslin.216     > ../outputs/t3620
echo ">>>>>>>>running test 3621"
../source/print_tokens.exe ../inputs/uslin.217     > ../outputs/t3621
echo ">>>>>>>>running test 3622"
../source/print_tokens.exe ../inputs/uslin.218     > ../outputs/t3622
echo ">>>>>>>>running test 3623"
../source/print_tokens.exe ../inputs/uslin.219     > ../outputs/t3623
echo ">>>>>>>>running test 3624"
../source/print_tokens.exe ../inputs/uslin.220     > ../outputs/t3624
echo ">>>>>>>>running test 3625"
../source/print_tokens.exe ../inputs/uslin.221     > ../outputs/t3625
echo ">>>>>>>>running test 3626"
../source/print_tokens.exe ../inputs/uslin.222     > ../outputs/t3626
echo ">>>>>>>>running test 3627"
../source/print_tokens.exe ../inputs/uslin.223     > ../outputs/t3627
echo ">>>>>>>>running test 3628"
../source/print_tokens.exe ../inputs/uslin.224     > ../outputs/t3628
echo ">>>>>>>>running test 3629"
../source/print_tokens.exe ../inputs/uslin.227     > ../outputs/t3629
echo ">>>>>>>>running test 3630"
../source/print_tokens.exe ../inputs/uslin.228     > ../outputs/t3630
echo ">>>>>>>>running test 3631"
../source/print_tokens.exe ../inputs/uslin.229     > ../outputs/t3631
echo ">>>>>>>>running test 3632"
../source/print_tokens.exe ../inputs/uslin.23     > ../outputs/t3632
echo ">>>>>>>>running test 3633"
../source/print_tokens.exe ../inputs/uslin.231     > ../outputs/t3633
echo ">>>>>>>>running test 3634"
../source/print_tokens.exe ../inputs/uslin.232     > ../outputs/t3634
echo ">>>>>>>>running test 3635"
../source/print_tokens.exe ../inputs/uslin.235     > ../outputs/t3635
echo ">>>>>>>>running test 3636"
../source/print_tokens.exe ../inputs/uslin.236     > ../outputs/t3636
echo ">>>>>>>>running test 3637"
../source/print_tokens.exe ../inputs/uslin.24     > ../outputs/t3637
echo ">>>>>>>>running test 3638"
../source/print_tokens.exe ../inputs/uslin.240     > ../outputs/t3638
echo ">>>>>>>>running test 3639"
../source/print_tokens.exe ../inputs/uslin.241     > ../outputs/t3639
echo ">>>>>>>>running test 3640"
../source/print_tokens.exe ../inputs/uslin.242     > ../outputs/t3640
echo ">>>>>>>>running test 3641"
../source/print_tokens.exe ../inputs/uslin.250     > ../outputs/t3641
echo ">>>>>>>>running test 3642"
../source/print_tokens.exe ../inputs/uslin.253     > ../outputs/t3642
echo ">>>>>>>>running test 3643"
../source/print_tokens.exe ../inputs/uslin.255     > ../outputs/t3643
echo ">>>>>>>>running test 3644"
../source/print_tokens.exe ../inputs/uslin.259     > ../outputs/t3644
echo ">>>>>>>>running test 3645"
../source/print_tokens.exe ../inputs/uslin.26     > ../outputs/t3645
echo ">>>>>>>>running test 3646"
../source/print_tokens.exe ../inputs/uslin.261     > ../outputs/t3646
echo ">>>>>>>>running test 3647"
../source/print_tokens.exe ../inputs/uslin.262     > ../outputs/t3647
echo ">>>>>>>>running test 3648"
../source/print_tokens.exe ../inputs/uslin.263     > ../outputs/t3648
echo ">>>>>>>>running test 3649"
../source/print_tokens.exe ../inputs/uslin.265      > ../outputs/t3649
echo ">>>>>>>>running test 3650"
../source/print_tokens.exe ../inputs/uslin.269     > ../outputs/t3650
echo ">>>>>>>>running test 3651"
../source/print_tokens.exe ../inputs/uslin.273     > ../outputs/t3651
echo ">>>>>>>>running test 3652"
../source/print_tokens.exe ../inputs/uslin.274     > ../outputs/t3652
echo ">>>>>>>>running test 3653"
../source/print_tokens.exe ../inputs/uslin.278     > ../outputs/t3653
echo ">>>>>>>>running test 3654"
../source/print_tokens.exe ../inputs/uslin.279     > ../outputs/t3654
echo ">>>>>>>>running test 3655"
../source/print_tokens.exe ../inputs/uslin.284     > ../outputs/t3655
echo ">>>>>>>>running test 3656"
../source/print_tokens.exe ../inputs/uslin.285     > ../outputs/t3656
echo ">>>>>>>>running test 3657"
../source/print_tokens.exe ../inputs/uslin.288     > ../outputs/t3657
echo ">>>>>>>>running test 3658"
../source/print_tokens.exe ../inputs/uslin.29     > ../outputs/t3658
echo ">>>>>>>>running test 3659"
../source/print_tokens.exe ../inputs/uslin.290     > ../outputs/t3659
echo ">>>>>>>>running test 3660"
../source/print_tokens.exe ../inputs/uslin.291     > ../outputs/t3660
echo ">>>>>>>>running test 3661"
../source/print_tokens.exe ../inputs/uslin.292     > ../outputs/t3661
echo ">>>>>>>>running test 3662"
../source/print_tokens.exe ../inputs/uslin.293     > ../outputs/t3662
echo ">>>>>>>>running test 3663"
../source/print_tokens.exe ../inputs/uslin.3      > ../outputs/t3663
echo ">>>>>>>>running test 3664"
../source/print_tokens.exe ../inputs/uslin.300     > ../outputs/t3664
echo ">>>>>>>>running test 3665"
../source/print_tokens.exe ../inputs/uslin.303      > ../outputs/t3665
echo ">>>>>>>>running test 3666"
../source/print_tokens.exe ../inputs/uslin.304     > ../outputs/t3666
echo ">>>>>>>>running test 3667"
../source/print_tokens.exe ../inputs/uslin.308      > ../outputs/t3667
echo ">>>>>>>>running test 3668"
../source/print_tokens.exe ../inputs/uslin.309     > ../outputs/t3668
echo ">>>>>>>>running test 3669"
../source/print_tokens.exe ../inputs/uslin.310     > ../outputs/t3669
echo ">>>>>>>>running test 3670"
../source/print_tokens.exe ../inputs/uslin.312     > ../outputs/t3670
echo ">>>>>>>>running test 3671"
../source/print_tokens.exe ../inputs/uslin.313     > ../outputs/t3671
echo ">>>>>>>>running test 3672"
../source/print_tokens.exe ../inputs/uslin.314     > ../outputs/t3672
echo ">>>>>>>>running test 3673"
../source/print_tokens.exe ../inputs/uslin.315     > ../outputs/t3673
echo ">>>>>>>>running test 3674"
../source/print_tokens.exe ../inputs/uslin.316     > ../outputs/t3674
echo ">>>>>>>>running test 3675"
../source/print_tokens.exe ../inputs/uslin.317     > ../outputs/t3675
echo ">>>>>>>>running test 3676"
../source/print_tokens.exe ../inputs/uslin.32     > ../outputs/t3676
echo ">>>>>>>>running test 3677"
../source/print_tokens.exe ../inputs/uslin.324     > ../outputs/t3677
echo ">>>>>>>>running test 3678"
../source/print_tokens.exe ../inputs/uslin.326     > ../outputs/t3678
echo ">>>>>>>>running test 3679"
../source/print_tokens.exe ../inputs/uslin.328     > ../outputs/t3679
echo ">>>>>>>>running test 3680"
../source/print_tokens.exe ../inputs/uslin.331     > ../outputs/t3680
echo ">>>>>>>>running test 3681"
../source/print_tokens.exe ../inputs/uslin.332     > ../outputs/t3681
echo ">>>>>>>>running test 3682"
../source/print_tokens.exe ../inputs/uslin.336     > ../outputs/t3682
echo ">>>>>>>>running test 3683"
../source/print_tokens.exe ../inputs/uslin.338     > ../outputs/t3683
echo ">>>>>>>>running test 3684"
../source/print_tokens.exe ../inputs/uslin.341     > ../outputs/t3684
echo ">>>>>>>>running test 3685"
../source/print_tokens.exe ../inputs/uslin.342     > ../outputs/t3685
echo ">>>>>>>>running test 3686"
../source/print_tokens.exe ../inputs/uslin.346     > ../outputs/t3686
echo ">>>>>>>>running test 3687"
../source/print_tokens.exe ../inputs/uslin.347     > ../outputs/t3687
echo ">>>>>>>>running test 3688"
../source/print_tokens.exe ../inputs/uslin.35     > ../outputs/t3688
echo ">>>>>>>>running test 3689"
../source/print_tokens.exe ../inputs/uslin.351     > ../outputs/t3689
echo ">>>>>>>>running test 3690"
../source/print_tokens.exe ../inputs/uslin.354     > ../outputs/t3690
echo ">>>>>>>>running test 3691"
../source/print_tokens.exe ../inputs/uslin.356     > ../outputs/t3691
echo ">>>>>>>>running test 3692"
../source/print_tokens.exe ../inputs/uslin.357     > ../outputs/t3692
echo ">>>>>>>>running test 3693"
../source/print_tokens.exe ../inputs/uslin.358     > ../outputs/t3693
echo ">>>>>>>>running test 3694"
../source/print_tokens.exe ../inputs/uslin.359     > ../outputs/t3694
echo ">>>>>>>>running test 3695"
../source/print_tokens.exe ../inputs/uslin.361     > ../outputs/t3695
echo ">>>>>>>>running test 3696"
../source/print_tokens.exe ../inputs/uslin.364     > ../outputs/t3696
echo ">>>>>>>>running test 3697"
../source/print_tokens.exe ../inputs/uslin.365     > ../outputs/t3697
echo ">>>>>>>>running test 3698"
../source/print_tokens.exe ../inputs/uslin.366     > ../outputs/t3698
echo ">>>>>>>>running test 3699"
../source/print_tokens.exe ../inputs/uslin.368     > ../outputs/t3699
echo ">>>>>>>>running test 3700"
../source/print_tokens.exe ../inputs/uslin.370     > ../outputs/t3700
echo ">>>>>>>>running test 3701"
../source/print_tokens.exe ../inputs/uslin.371     > ../outputs/t3701
echo ">>>>>>>>running test 3702"
../source/print_tokens.exe ../inputs/uslin.373     > ../outputs/t3702
echo ">>>>>>>>running test 3703"
../source/print_tokens.exe ../inputs/uslin.374     > ../outputs/t3703
echo ">>>>>>>>running test 3704"
../source/print_tokens.exe ../inputs/uslin.375     > ../outputs/t3704
echo ">>>>>>>>running test 3705"
../source/print_tokens.exe ../inputs/uslin.376     > ../outputs/t3705
echo ">>>>>>>>running test 3706"
../source/print_tokens.exe ../inputs/uslin.38     > ../outputs/t3706
echo ">>>>>>>>running test 3707"
../source/print_tokens.exe ../inputs/uslin.381     > ../outputs/t3707
echo ">>>>>>>>running test 3708"
../source/print_tokens.exe ../inputs/uslin.382     > ../outputs/t3708
echo ">>>>>>>>running test 3709"
../source/print_tokens.exe ../inputs/uslin.384     > ../outputs/t3709
echo ">>>>>>>>running test 3710"
../source/print_tokens.exe ../inputs/uslin.385     > ../outputs/t3710
echo ">>>>>>>>running test 3711"
../source/print_tokens.exe ../inputs/uslin.389     > ../outputs/t3711
echo ">>>>>>>>running test 3712"
../source/print_tokens.exe ../inputs/uslin.39     > ../outputs/t3712
echo ">>>>>>>>running test 3713"
../source/print_tokens.exe ../inputs/uslin.390     > ../outputs/t3713
echo ">>>>>>>>running test 3714"
../source/print_tokens.exe ../inputs/uslin.391     > ../outputs/t3714
echo ">>>>>>>>running test 3715"
../source/print_tokens.exe ../inputs/uslin.393     > ../outputs/t3715
echo ">>>>>>>>running test 3716"
../source/print_tokens.exe ../inputs/uslin.394     > ../outputs/t3716
echo ">>>>>>>>running test 3717"
../source/print_tokens.exe ../inputs/uslin.396.noeof     > ../outputs/t3717
echo ">>>>>>>>running test 3718"
../source/print_tokens.exe ../inputs/uslin.397     > ../outputs/t3718
echo ">>>>>>>>running test 3719"
../source/print_tokens.exe ../inputs/uslin.399     > ../outputs/t3719
echo ">>>>>>>>running test 3720"
../source/print_tokens.exe ../inputs/uslin.400     > ../outputs/t3720
echo ">>>>>>>>running test 3721"
../source/print_tokens.exe ../inputs/uslin.401     > ../outputs/t3721
echo ">>>>>>>>running test 3722"
../source/print_tokens.exe ../inputs/uslin.403     > ../outputs/t3722
echo ">>>>>>>>running test 3723"
../source/print_tokens.exe ../inputs/uslin.404     > ../outputs/t3723
echo ">>>>>>>>running test 3724"
../source/print_tokens.exe ../inputs/uslin.405     > ../outputs/t3724
echo ">>>>>>>>running test 3725"
../source/print_tokens.exe ../inputs/uslin.406     > ../outputs/t3725
echo ">>>>>>>>running test 3726"
../source/print_tokens.exe ../inputs/uslin.408     > ../outputs/t3726
echo ">>>>>>>>running test 3727"
../source/print_tokens.exe ../inputs/uslin.409     > ../outputs/t3727
echo ">>>>>>>>running test 3728"
../source/print_tokens.exe ../inputs/uslin.410     > ../outputs/t3728
echo ">>>>>>>>running test 3729"
../source/print_tokens.exe ../inputs/uslin.411      > ../outputs/t3729
echo ">>>>>>>>running test 3730"
../source/print_tokens.exe ../inputs/uslin.414     > ../outputs/t3730
echo ">>>>>>>>running test 3731"
../source/print_tokens.exe ../inputs/uslin.416     > ../outputs/t3731
echo ">>>>>>>>running test 3732"
../source/print_tokens.exe ../inputs/uslin.416.noeof     > ../outputs/t3732
echo ">>>>>>>>running test 3733"
../source/print_tokens.exe ../inputs/uslin.417     > ../outputs/t3733
echo ">>>>>>>>running test 3734"
../source/print_tokens.exe ../inputs/uslin.420     > ../outputs/t3734
echo ">>>>>>>>running test 3735"
../source/print_tokens.exe ../inputs/uslin.422     > ../outputs/t3735
echo ">>>>>>>>running test 3736"
../source/print_tokens.exe ../inputs/uslin.426     > ../outputs/t3736
echo ">>>>>>>>running test 3737"
../source/print_tokens.exe ../inputs/uslin.427     > ../outputs/t3737
echo ">>>>>>>>running test 3738"
../source/print_tokens.exe ../inputs/uslin.429     > ../outputs/t3738
echo ">>>>>>>>running test 3739"
../source/print_tokens.exe ../inputs/uslin.43     > ../outputs/t3739
echo ">>>>>>>>running test 3740"
../source/print_tokens.exe ../inputs/uslin.431     > ../outputs/t3740
echo ">>>>>>>>running test 3741"
../source/print_tokens.exe ../inputs/uslin.437     > ../outputs/t3741
echo ">>>>>>>>running test 3742"
../source/print_tokens.exe ../inputs/uslin.439     > ../outputs/t3742
echo ">>>>>>>>running test 3743"
../source/print_tokens.exe ../inputs/uslin.44     > ../outputs/t3743
echo ">>>>>>>>running test 3744"
../source/print_tokens.exe ../inputs/uslin.440     > ../outputs/t3744
echo ">>>>>>>>running test 3745"
../source/print_tokens.exe ../inputs/uslin.441.noeof     > ../outputs/t3745
echo ">>>>>>>>running test 3746"
../source/print_tokens.exe ../inputs/uslin.443     > ../outputs/t3746
echo ">>>>>>>>running test 3747"
../source/print_tokens.exe ../inputs/uslin.444     > ../outputs/t3747
echo ">>>>>>>>running test 3748"
../source/print_tokens.exe ../inputs/uslin.445     > ../outputs/t3748
echo ">>>>>>>>running test 3749"
../source/print_tokens.exe ../inputs/uslin.446     > ../outputs/t3749
echo ">>>>>>>>running test 3750"
../source/print_tokens.exe ../inputs/uslin.45     > ../outputs/t3750
echo ">>>>>>>>running test 3751"
../source/print_tokens.exe ../inputs/uslin.452     > ../outputs/t3751
echo ">>>>>>>>running test 3752"
../source/print_tokens.exe ../inputs/uslin.453     > ../outputs/t3752
echo ">>>>>>>>running test 3753"
../source/print_tokens.exe ../inputs/uslin.454     > ../outputs/t3753
echo ">>>>>>>>running test 3754"
../source/print_tokens.exe ../inputs/uslin.458     > ../outputs/t3754
echo ">>>>>>>>running test 3755"
../source/print_tokens.exe ../inputs/uslin.46     > ../outputs/t3755
echo ">>>>>>>>running test 3756"
../source/print_tokens.exe ../inputs/uslin.460     > ../outputs/t3756
echo ">>>>>>>>running test 3757"
../source/print_tokens.exe ../inputs/uslin.461     > ../outputs/t3757
echo ">>>>>>>>running test 3758"
../source/print_tokens.exe ../inputs/uslin.464     > ../outputs/t3758
echo ">>>>>>>>running test 3759"
../source/print_tokens.exe ../inputs/uslin.465     > ../outputs/t3759
echo ">>>>>>>>running test 3760"
../source/print_tokens.exe ../inputs/uslin.466     > ../outputs/t3760
echo ">>>>>>>>running test 3761"
../source/print_tokens.exe ../inputs/uslin.470     > ../outputs/t3761
echo ">>>>>>>>running test 3762"
../source/print_tokens.exe ../inputs/uslin.471     > ../outputs/t3762
echo ">>>>>>>>running test 3763"
../source/print_tokens.exe ../inputs/uslin.472     > ../outputs/t3763
echo ">>>>>>>>running test 3764"
../source/print_tokens.exe ../inputs/uslin.473     > ../outputs/t3764
echo ">>>>>>>>running test 3765"
../source/print_tokens.exe ../inputs/uslin.474     > ../outputs/t3765
echo ">>>>>>>>running test 3766"
../source/print_tokens.exe ../inputs/uslin.478     > ../outputs/t3766
echo ">>>>>>>>running test 3767"
../source/print_tokens.exe ../inputs/uslin.481     > ../outputs/t3767
echo ">>>>>>>>running test 3768"
../source/print_tokens.exe ../inputs/uslin.482     > ../outputs/t3768
echo ">>>>>>>>running test 3769"
../source/print_tokens.exe ../inputs/uslin.484     > ../outputs/t3769
echo ">>>>>>>>running test 3770"
../source/print_tokens.exe ../inputs/uslin.485     > ../outputs/t3770
echo ">>>>>>>>running test 3771"
../source/print_tokens.exe ../inputs/uslin.486     > ../outputs/t3771
echo ">>>>>>>>running test 3772"
../source/print_tokens.exe ../inputs/uslin.488     > ../outputs/t3772
echo ">>>>>>>>running test 3773"
../source/print_tokens.exe ../inputs/uslin.49     > ../outputs/t3773
echo ">>>>>>>>running test 3774"
../source/print_tokens.exe ../inputs/uslin.490     > ../outputs/t3774
echo ">>>>>>>>running test 3775"
../source/print_tokens.exe ../inputs/uslin.491     > ../outputs/t3775
echo ">>>>>>>>running test 3776"
../source/print_tokens.exe ../inputs/uslin.492     > ../outputs/t3776
echo ">>>>>>>>running test 3777"
../source/print_tokens.exe ../inputs/uslin.495     > ../outputs/t3777
echo ">>>>>>>>running test 3778"
../source/print_tokens.exe ../inputs/uslin.497     > ../outputs/t3778
echo ">>>>>>>>running test 3779"
../source/print_tokens.exe ../inputs/uslin.498     > ../outputs/t3779
echo ">>>>>>>>running test 3780"
../source/print_tokens.exe ../inputs/uslin.499     > ../outputs/t3780
echo ">>>>>>>>running test 3781"
../source/print_tokens.exe ../inputs/uslin.5      > ../outputs/t3781
echo ">>>>>>>>running test 3782"
../source/print_tokens.exe ../inputs/uslin.5.noeof     > ../outputs/t3782
echo ">>>>>>>>running test 3783"
../source/print_tokens.exe ../inputs/uslin.500     > ../outputs/t3783
echo ">>>>>>>>running test 3784"
../source/print_tokens.exe ../inputs/uslin.501     > ../outputs/t3784
echo ">>>>>>>>running test 3785"
../source/print_tokens.exe ../inputs/uslin.503     > ../outputs/t3785
echo ">>>>>>>>running test 3786"
../source/print_tokens.exe ../inputs/uslin.505     > ../outputs/t3786
echo ">>>>>>>>running test 3787"
../source/print_tokens.exe ../inputs/uslin.508     > ../outputs/t3787
echo ">>>>>>>>running test 3788"
../source/print_tokens.exe ../inputs/uslin.509     > ../outputs/t3788
echo ">>>>>>>>running test 3789"
../source/print_tokens.exe ../inputs/uslin.51     > ../outputs/t3789
echo ">>>>>>>>running test 3790"
../source/print_tokens.exe ../inputs/uslin.516     > ../outputs/t3790
echo ">>>>>>>>running test 3791"
../source/print_tokens.exe ../inputs/uslin.517     > ../outputs/t3791
echo ">>>>>>>>running test 3792"
../source/print_tokens.exe ../inputs/uslin.521     > ../outputs/t3792
echo ">>>>>>>>running test 3793"
../source/print_tokens.exe ../inputs/uslin.523     > ../outputs/t3793
echo ">>>>>>>>running test 3794"
../source/print_tokens.exe ../inputs/uslin.524     > ../outputs/t3794
echo ">>>>>>>>running test 3795"
../source/print_tokens.exe ../inputs/uslin.529     > ../outputs/t3795
echo ">>>>>>>>running test 3796"
../source/print_tokens.exe ../inputs/uslin.53     > ../outputs/t3796
echo ">>>>>>>>running test 3797"
../source/print_tokens.exe ../inputs/uslin.530     > ../outputs/t3797
echo ">>>>>>>>running test 3798"
../source/print_tokens.exe ../inputs/uslin.531     > ../outputs/t3798
echo ">>>>>>>>running test 3799"
../source/print_tokens.exe ../inputs/uslin.532     > ../outputs/t3799
echo ">>>>>>>>running test 3800"
../source/print_tokens.exe ../inputs/uslin.535     > ../outputs/t3800
echo ">>>>>>>>running test 3801"
../source/print_tokens.exe ../inputs/uslin.536     > ../outputs/t3801
echo ">>>>>>>>running test 3802"
../source/print_tokens.exe ../inputs/uslin.541     > ../outputs/t3802
echo ">>>>>>>>running test 3803"
../source/print_tokens.exe ../inputs/uslin.542     > ../outputs/t3803
echo ">>>>>>>>running test 3804"
../source/print_tokens.exe ../inputs/uslin.545     > ../outputs/t3804
echo ">>>>>>>>running test 3805"
../source/print_tokens.exe ../inputs/uslin.546     > ../outputs/t3805
echo ">>>>>>>>running test 3806"
../source/print_tokens.exe ../inputs/uslin.547     > ../outputs/t3806
echo ">>>>>>>>running test 3807"
../source/print_tokens.exe ../inputs/uslin.548     > ../outputs/t3807
echo ">>>>>>>>running test 3808"
../source/print_tokens.exe ../inputs/uslin.549     > ../outputs/t3808
echo ">>>>>>>>running test 3809"
../source/print_tokens.exe ../inputs/uslin.55     > ../outputs/t3809
echo ">>>>>>>>running test 3810"
../source/print_tokens.exe ../inputs/uslin.550      > ../outputs/t3810
echo ">>>>>>>>running test 3811"
../source/print_tokens.exe ../inputs/uslin.551     > ../outputs/t3811
echo ">>>>>>>>running test 3812"
../source/print_tokens.exe ../inputs/uslin.554     > ../outputs/t3812
echo ">>>>>>>>running test 3813"
../source/print_tokens.exe ../inputs/uslin.555     > ../outputs/t3813
echo ">>>>>>>>running test 3814"
../source/print_tokens.exe ../inputs/uslin.556     > ../outputs/t3814
echo ">>>>>>>>running test 3815"
../source/print_tokens.exe ../inputs/uslin.559     > ../outputs/t3815
echo ">>>>>>>>running test 3816"
../source/print_tokens.exe ../inputs/uslin.56     > ../outputs/t3816
echo ">>>>>>>>running test 3817"
../source/print_tokens.exe ../inputs/uslin.560     > ../outputs/t3817
echo ">>>>>>>>running test 3818"
../source/print_tokens.exe ../inputs/uslin.561     > ../outputs/t3818
echo ">>>>>>>>running test 3819"
../source/print_tokens.exe ../inputs/uslin.563     > ../outputs/t3819
echo ">>>>>>>>running test 3820"
../source/print_tokens.exe ../inputs/uslin.564     > ../outputs/t3820
echo ">>>>>>>>running test 3821"
../source/print_tokens.exe ../inputs/uslin.565     > ../outputs/t3821
echo ">>>>>>>>running test 3822"
../source/print_tokens.exe ../inputs/uslin.567     > ../outputs/t3822
echo ">>>>>>>>running test 3823"
../source/print_tokens.exe ../inputs/uslin.57     > ../outputs/t3823
echo ">>>>>>>>running test 3824"
../source/print_tokens.exe ../inputs/uslin.575     > ../outputs/t3824
echo ">>>>>>>>running test 3825"
../source/print_tokens.exe ../inputs/uslin.578     > ../outputs/t3825
echo ">>>>>>>>running test 3826"
../source/print_tokens.exe ../inputs/uslin.587     > ../outputs/t3826
echo ">>>>>>>>running test 3827"
../source/print_tokens.exe ../inputs/uslin.588     > ../outputs/t3827
echo ">>>>>>>>running test 3828"
../source/print_tokens.exe ../inputs/uslin.589     > ../outputs/t3828
echo ">>>>>>>>running test 3829"
../source/print_tokens.exe ../inputs/uslin.59     > ../outputs/t3829
echo ">>>>>>>>running test 3830"
../source/print_tokens.exe ../inputs/uslin.590     > ../outputs/t3830
echo ">>>>>>>>running test 3831"
../source/print_tokens.exe ../inputs/uslin.591     > ../outputs/t3831
echo ">>>>>>>>running test 3832"
../source/print_tokens.exe ../inputs/uslin.595     > ../outputs/t3832
echo ">>>>>>>>running test 3833"
../source/print_tokens.exe ../inputs/uslin.599     > ../outputs/t3833
echo ">>>>>>>>running test 3834"
../source/print_tokens.exe ../inputs/uslin.6     > ../outputs/t3834
echo ">>>>>>>>running test 3835"
../source/print_tokens.exe ../inputs/uslin.600     > ../outputs/t3835
echo ">>>>>>>>running test 3836"
../source/print_tokens.exe ../inputs/uslin.601     > ../outputs/t3836
echo ">>>>>>>>running test 3837"
../source/print_tokens.exe ../inputs/uslin.603     > ../outputs/t3837
echo ">>>>>>>>running test 3838"
../source/print_tokens.exe ../inputs/uslin.604     > ../outputs/t3838
echo ">>>>>>>>running test 3839"
../source/print_tokens.exe ../inputs/uslin.606     > ../outputs/t3839
echo ">>>>>>>>running test 3840"
../source/print_tokens.exe ../inputs/uslin.608     > ../outputs/t3840
echo ">>>>>>>>running test 3841"
../source/print_tokens.exe ../inputs/uslin.609      > ../outputs/t3841
echo ">>>>>>>>running test 3842"
../source/print_tokens.exe ../inputs/uslin.61     > ../outputs/t3842
echo ">>>>>>>>running test 3843"
../source/print_tokens.exe ../inputs/uslin.610     > ../outputs/t3843
echo ">>>>>>>>running test 3844"
../source/print_tokens.exe ../inputs/uslin.612     > ../outputs/t3844
echo ">>>>>>>>running test 3845"
../source/print_tokens.exe ../inputs/uslin.613     > ../outputs/t3845
echo ">>>>>>>>running test 3846"
../source/print_tokens.exe ../inputs/uslin.618     > ../outputs/t3846
echo ">>>>>>>>running test 3847"
../source/print_tokens.exe ../inputs/uslin.620     > ../outputs/t3847
echo ">>>>>>>>running test 3848"
../source/print_tokens.exe ../inputs/uslin.622     > ../outputs/t3848
echo ">>>>>>>>running test 3849"
../source/print_tokens.exe ../inputs/uslin.628     > ../outputs/t3849
echo ">>>>>>>>running test 3850"
../source/print_tokens.exe ../inputs/uslin.629      > ../outputs/t3850
echo ">>>>>>>>running test 3851"
../source/print_tokens.exe ../inputs/uslin.631     > ../outputs/t3851
echo ">>>>>>>>running test 3852"
../source/print_tokens.exe ../inputs/uslin.632     > ../outputs/t3852
echo ">>>>>>>>running test 3853"
../source/print_tokens.exe ../inputs/uslin.634     > ../outputs/t3853
echo ">>>>>>>>running test 3854"
../source/print_tokens.exe ../inputs/uslin.635     > ../outputs/t3854
echo ">>>>>>>>running test 3855"
../source/print_tokens.exe ../inputs/uslin.637     > ../outputs/t3855
echo ">>>>>>>>running test 3856"
../source/print_tokens.exe ../inputs/uslin.637.noeof     > ../outputs/t3856
echo ">>>>>>>>running test 3857"
../source/print_tokens.exe ../inputs/uslin.638     > ../outputs/t3857
echo ">>>>>>>>running test 3858"
../source/print_tokens.exe ../inputs/uslin.639     > ../outputs/t3858
echo ">>>>>>>>running test 3859"
../source/print_tokens.exe ../inputs/uslin.639.noeof     > ../outputs/t3859
echo ">>>>>>>>running test 3860"
../source/print_tokens.exe ../inputs/uslin.641     > ../outputs/t3860
echo ">>>>>>>>running test 3861"
../source/print_tokens.exe ../inputs/uslin.643     > ../outputs/t3861
echo ">>>>>>>>running test 3862"
../source/print_tokens.exe ../inputs/uslin.644     > ../outputs/t3862
echo ">>>>>>>>running test 3863"
../source/print_tokens.exe ../inputs/uslin.645     > ../outputs/t3863
echo ">>>>>>>>running test 3864"
../source/print_tokens.exe ../inputs/uslin.646     > ../outputs/t3864
echo ">>>>>>>>running test 3865"
../source/print_tokens.exe ../inputs/uslin.649     > ../outputs/t3865
echo ">>>>>>>>running test 3866"
../source/print_tokens.exe ../inputs/uslin.65     > ../outputs/t3866
echo ">>>>>>>>running test 3867"
../source/print_tokens.exe ../inputs/uslin.651     > ../outputs/t3867
echo ">>>>>>>>running test 3868"
../source/print_tokens.exe ../inputs/uslin.652     > ../outputs/t3868
echo ">>>>>>>>running test 3869"
../source/print_tokens.exe ../inputs/uslin.653     > ../outputs/t3869
echo ">>>>>>>>running test 3870"
../source/print_tokens.exe ../inputs/uslin.654     > ../outputs/t3870
echo ">>>>>>>>running test 3871"
../source/print_tokens.exe ../inputs/uslin.657     > ../outputs/t3871
echo ">>>>>>>>running test 3872"
../source/print_tokens.exe ../inputs/uslin.658     > ../outputs/t3872
echo ">>>>>>>>running test 3873"
../source/print_tokens.exe ../inputs/uslin.66      > ../outputs/t3873
echo ">>>>>>>>running test 3874"
../source/print_tokens.exe ../inputs/uslin.660     > ../outputs/t3874
echo ">>>>>>>>running test 3875"
../source/print_tokens.exe ../inputs/uslin.661     > ../outputs/t3875
echo ">>>>>>>>running test 3876"
../source/print_tokens.exe ../inputs/uslin.664     > ../outputs/t3876
echo ">>>>>>>>running test 3877"
../source/print_tokens.exe ../inputs/uslin.666     > ../outputs/t3877
echo ">>>>>>>>running test 3878"
../source/print_tokens.exe ../inputs/uslin.667     > ../outputs/t3878
echo ">>>>>>>>running test 3879"
../source/print_tokens.exe ../inputs/uslin.671     > ../outputs/t3879
echo ">>>>>>>>running test 3880"
../source/print_tokens.exe ../inputs/uslin.672     > ../outputs/t3880
echo ">>>>>>>>running test 3881"
../source/print_tokens.exe ../inputs/uslin.675     > ../outputs/t3881
echo ">>>>>>>>running test 3882"
../source/print_tokens.exe ../inputs/uslin.678     > ../outputs/t3882
echo ">>>>>>>>running test 3883"
../source/print_tokens.exe ../inputs/uslin.681     > ../outputs/t3883
echo ">>>>>>>>running test 3884"
../source/print_tokens.exe ../inputs/uslin.683     > ../outputs/t3884
echo ">>>>>>>>running test 3885"
../source/print_tokens.exe ../inputs/uslin.684     > ../outputs/t3885
echo ">>>>>>>>running test 3886"
../source/print_tokens.exe ../inputs/uslin.685     > ../outputs/t3886
echo ">>>>>>>>running test 3887"
../source/print_tokens.exe ../inputs/uslin.687     > ../outputs/t3887
echo ">>>>>>>>running test 3888"
../source/print_tokens.exe ../inputs/uslin.688     > ../outputs/t3888
echo ">>>>>>>>running test 3889"
../source/print_tokens.exe ../inputs/uslin.689     > ../outputs/t3889
echo ">>>>>>>>running test 3890"
../source/print_tokens.exe ../inputs/uslin.69     > ../outputs/t3890
echo ">>>>>>>>running test 3891"
../source/print_tokens.exe ../inputs/uslin.690     > ../outputs/t3891
echo ">>>>>>>>running test 3892"
../source/print_tokens.exe ../inputs/uslin.692     > ../outputs/t3892
echo ">>>>>>>>running test 3893"
../source/print_tokens.exe ../inputs/uslin.693     > ../outputs/t3893
echo ">>>>>>>>running test 3894"
../source/print_tokens.exe ../inputs/uslin.694     > ../outputs/t3894
echo ">>>>>>>>running test 3895"
../source/print_tokens.exe ../inputs/uslin.696     > ../outputs/t3895
echo ">>>>>>>>running test 3896"
../source/print_tokens.exe ../inputs/uslin.697     > ../outputs/t3896
echo ">>>>>>>>running test 3897"
../source/print_tokens.exe ../inputs/uslin.698     > ../outputs/t3897
echo ">>>>>>>>running test 3898"
../source/print_tokens.exe ../inputs/uslin.699     > ../outputs/t3898
echo ">>>>>>>>running test 3899"
../source/print_tokens.exe ../inputs/uslin.700     > ../outputs/t3899
echo ">>>>>>>>running test 3900"
../source/print_tokens.exe ../inputs/uslin.702     > ../outputs/t3900
echo ">>>>>>>>running test 3901"
../source/print_tokens.exe ../inputs/uslin.703     > ../outputs/t3901
echo ">>>>>>>>running test 3902"
../source/print_tokens.exe ../inputs/uslin.705     > ../outputs/t3902
echo ">>>>>>>>running test 3903"
../source/print_tokens.exe ../inputs/uslin.707     > ../outputs/t3903
echo ">>>>>>>>running test 3904"
../source/print_tokens.exe ../inputs/uslin.710     > ../outputs/t3904
echo ">>>>>>>>running test 3905"
../source/print_tokens.exe ../inputs/uslin.714     > ../outputs/t3905
echo ">>>>>>>>running test 3906"
../source/print_tokens.exe ../inputs/uslin.715     > ../outputs/t3906
echo ">>>>>>>>running test 3907"
../source/print_tokens.exe ../inputs/uslin.718     > ../outputs/t3907
echo ">>>>>>>>running test 3908"
../source/print_tokens.exe ../inputs/uslin.720     > ../outputs/t3908
echo ">>>>>>>>running test 3909"
../source/print_tokens.exe ../inputs/uslin.722     > ../outputs/t3909
echo ">>>>>>>>running test 3910"
../source/print_tokens.exe ../inputs/uslin.724     > ../outputs/t3910
echo ">>>>>>>>running test 3911"
../source/print_tokens.exe ../inputs/uslin.724.noeof     > ../outputs/t3911
echo ">>>>>>>>running test 3912"
../source/print_tokens.exe ../inputs/uslin.725     > ../outputs/t3912
echo ">>>>>>>>running test 3913"
../source/print_tokens.exe ../inputs/uslin.726     > ../outputs/t3913
echo ">>>>>>>>running test 3914"
../source/print_tokens.exe ../inputs/uslin.729     > ../outputs/t3914
echo ">>>>>>>>running test 3915"
../source/print_tokens.exe ../inputs/uslin.73     > ../outputs/t3915
echo ">>>>>>>>running test 3916"
../source/print_tokens.exe ../inputs/uslin.730     > ../outputs/t3916
echo ">>>>>>>>running test 3917"
../source/print_tokens.exe ../inputs/uslin.731     > ../outputs/t3917
echo ">>>>>>>>running test 3918"
../source/print_tokens.exe ../inputs/uslin.732     > ../outputs/t3918
echo ">>>>>>>>running test 3919"
../source/print_tokens.exe ../inputs/uslin.733     > ../outputs/t3919
echo ">>>>>>>>running test 3920"
../source/print_tokens.exe ../inputs/uslin.735     > ../outputs/t3920
echo ">>>>>>>>running test 3921"
../source/print_tokens.exe ../inputs/uslin.737     > ../outputs/t3921
echo ">>>>>>>>running test 3922"
../source/print_tokens.exe ../inputs/uslin.739     > ../outputs/t3922
echo ">>>>>>>>running test 3923"
../source/print_tokens.exe ../inputs/uslin.740     > ../outputs/t3923
echo ">>>>>>>>running test 3924"
../source/print_tokens.exe ../inputs/uslin.741     > ../outputs/t3924
echo ">>>>>>>>running test 3925"
../source/print_tokens.exe ../inputs/uslin.743     > ../outputs/t3925
echo ">>>>>>>>running test 3926"
../source/print_tokens.exe ../inputs/uslin.745      > ../outputs/t3926
echo ">>>>>>>>running test 3927"
../source/print_tokens.exe ../inputs/uslin.749     > ../outputs/t3927
echo ">>>>>>>>running test 3928"
../source/print_tokens.exe ../inputs/uslin.750     > ../outputs/t3928
echo ">>>>>>>>running test 3929"
../source/print_tokens.exe ../inputs/uslin.754     > ../outputs/t3929
echo ">>>>>>>>running test 3930"
../source/print_tokens.exe ../inputs/uslin.755     > ../outputs/t3930
echo ">>>>>>>>running test 3931"
../source/print_tokens.exe ../inputs/uslin.757     > ../outputs/t3931
echo ">>>>>>>>running test 3932"
../source/print_tokens.exe ../inputs/uslin.759     > ../outputs/t3932
echo ">>>>>>>>running test 3933"
../source/print_tokens.exe ../inputs/uslin.762     > ../outputs/t3933
echo ">>>>>>>>running test 3934"
../source/print_tokens.exe ../inputs/uslin.763     > ../outputs/t3934
echo ">>>>>>>>running test 3935"
../source/print_tokens.exe ../inputs/uslin.764     > ../outputs/t3935
echo ">>>>>>>>running test 3936"
../source/print_tokens.exe ../inputs/uslin.77.noeof     > ../outputs/t3936
echo ">>>>>>>>running test 3937"
../source/print_tokens.exe ../inputs/uslin.770     > ../outputs/t3937
echo ">>>>>>>>running test 3938"
../source/print_tokens.exe ../inputs/uslin.771     > ../outputs/t3938
echo ">>>>>>>>running test 3939"
../source/print_tokens.exe ../inputs/uslin.774     > ../outputs/t3939
echo ">>>>>>>>running test 3940"
../source/print_tokens.exe ../inputs/uslin.780     > ../outputs/t3940
echo ">>>>>>>>running test 3941"
../source/print_tokens.exe ../inputs/uslin.782     > ../outputs/t3941
echo ">>>>>>>>running test 3942"
../source/print_tokens.exe ../inputs/uslin.783     > ../outputs/t3942
echo ">>>>>>>>running test 3943"
../source/print_tokens.exe ../inputs/uslin.785     > ../outputs/t3943
echo ">>>>>>>>running test 3944"
../source/print_tokens.exe ../inputs/uslin.792     > ../outputs/t3944
echo ">>>>>>>>running test 3945"
../source/print_tokens.exe ../inputs/uslin.794     > ../outputs/t3945
echo ">>>>>>>>running test 3946"
../source/print_tokens.exe ../inputs/uslin.795     > ../outputs/t3946
echo ">>>>>>>>running test 3947"
../source/print_tokens.exe ../inputs/uslin.796     > ../outputs/t3947
echo ">>>>>>>>running test 3948"
../source/print_tokens.exe ../inputs/uslin.797      > ../outputs/t3948
echo ">>>>>>>>running test 3949"
../source/print_tokens.exe ../inputs/uslin.799     > ../outputs/t3949
echo ">>>>>>>>running test 3950"
../source/print_tokens.exe ../inputs/uslin.800     > ../outputs/t3950
echo ">>>>>>>>running test 3951"
../source/print_tokens.exe ../inputs/uslin.801     > ../outputs/t3951
echo ">>>>>>>>running test 3952"
../source/print_tokens.exe ../inputs/uslin.802     > ../outputs/t3952
echo ">>>>>>>>running test 3953"
../source/print_tokens.exe ../inputs/uslin.804     > ../outputs/t3953
echo ">>>>>>>>running test 3954"
../source/print_tokens.exe ../inputs/uslin.805     > ../outputs/t3954
echo ">>>>>>>>running test 3955"
../source/print_tokens.exe ../inputs/uslin.806     > ../outputs/t3955
echo ">>>>>>>>running test 3956"
../source/print_tokens.exe ../inputs/uslin.809     > ../outputs/t3956
echo ">>>>>>>>running test 3957"
../source/print_tokens.exe ../inputs/uslin.81     > ../outputs/t3957
echo ">>>>>>>>running test 3958"
../source/print_tokens.exe ../inputs/uslin.810     > ../outputs/t3958
echo ">>>>>>>>running test 3959"
../source/print_tokens.exe ../inputs/uslin.812     > ../outputs/t3959
echo ">>>>>>>>running test 3960"
../source/print_tokens.exe ../inputs/uslin.813     > ../outputs/t3960
echo ">>>>>>>>running test 3961"
../source/print_tokens.exe ../inputs/uslin.815      > ../outputs/t3961
echo ">>>>>>>>running test 3962"
../source/print_tokens.exe ../inputs/uslin.817     > ../outputs/t3962
echo ">>>>>>>>running test 3963"
../source/print_tokens.exe ../inputs/uslin.819     > ../outputs/t3963
echo ">>>>>>>>running test 3964"
../source/print_tokens.exe ../inputs/uslin.820     > ../outputs/t3964
echo ">>>>>>>>running test 3965"
../source/print_tokens.exe ../inputs/uslin.822     > ../outputs/t3965
echo ">>>>>>>>running test 3966"
../source/print_tokens.exe ../inputs/uslin.824     > ../outputs/t3966
echo ">>>>>>>>running test 3967"
../source/print_tokens.exe ../inputs/uslin.826     > ../outputs/t3967
echo ">>>>>>>>running test 3968"
../source/print_tokens.exe ../inputs/uslin.827      > ../outputs/t3968
echo ">>>>>>>>running test 3969"
../source/print_tokens.exe ../inputs/uslin.830     > ../outputs/t3969
echo ">>>>>>>>running test 3970"
../source/print_tokens.exe ../inputs/uslin.833     > ../outputs/t3970
echo ">>>>>>>>running test 3971"
../source/print_tokens.exe ../inputs/uslin.835     > ../outputs/t3971
echo ">>>>>>>>running test 3972"
../source/print_tokens.exe ../inputs/uslin.838     > ../outputs/t3972
echo ">>>>>>>>running test 3973"
../source/print_tokens.exe ../inputs/uslin.839     > ../outputs/t3973
echo ">>>>>>>>running test 3974"
../source/print_tokens.exe ../inputs/uslin.84     > ../outputs/t3974
echo ">>>>>>>>running test 3975"
../source/print_tokens.exe ../inputs/uslin.841     > ../outputs/t3975
echo ">>>>>>>>running test 3976"
../source/print_tokens.exe ../inputs/uslin.842     > ../outputs/t3976
echo ">>>>>>>>running test 3977"
../source/print_tokens.exe ../inputs/uslin.844     > ../outputs/t3977
echo ">>>>>>>>running test 3978"
../source/print_tokens.exe ../inputs/uslin.845     > ../outputs/t3978
echo ">>>>>>>>running test 3979"
../source/print_tokens.exe ../inputs/uslin.846     > ../outputs/t3979
echo ">>>>>>>>running test 3980"
../source/print_tokens.exe ../inputs/uslin.847     > ../outputs/t3980
echo ">>>>>>>>running test 3981"
../source/print_tokens.exe ../inputs/uslin.848     > ../outputs/t3981
echo ">>>>>>>>running test 3982"
../source/print_tokens.exe ../inputs/uslin.849      > ../outputs/t3982
echo ">>>>>>>>running test 3983"
../source/print_tokens.exe ../inputs/uslin.850     > ../outputs/t3983
echo ">>>>>>>>running test 3984"
../source/print_tokens.exe ../inputs/uslin.852     > ../outputs/t3984
echo ">>>>>>>>running test 3985"
../source/print_tokens.exe ../inputs/uslin.853     > ../outputs/t3985
echo ">>>>>>>>running test 3986"
../source/print_tokens.exe ../inputs/uslin.854     > ../outputs/t3986
echo ">>>>>>>>running test 3987"
../source/print_tokens.exe ../inputs/uslin.856     > ../outputs/t3987
echo ">>>>>>>>running test 3988"
../source/print_tokens.exe ../inputs/uslin.857     > ../outputs/t3988
echo ">>>>>>>>running test 3989"
../source/print_tokens.exe ../inputs/uslin.859     > ../outputs/t3989
echo ">>>>>>>>running test 3990"
../source/print_tokens.exe ../inputs/uslin.86     > ../outputs/t3990
echo ">>>>>>>>running test 3991"
../source/print_tokens.exe ../inputs/uslin.861     > ../outputs/t3991
echo ">>>>>>>>running test 3992"
../source/print_tokens.exe ../inputs/uslin.863     > ../outputs/t3992
echo ">>>>>>>>running test 3993"
../source/print_tokens.exe ../inputs/uslin.867     > ../outputs/t3993
echo ">>>>>>>>running test 3994"
../source/print_tokens.exe ../inputs/uslin.868     > ../outputs/t3994
echo ">>>>>>>>running test 3995"
../source/print_tokens.exe ../inputs/uslin.869     > ../outputs/t3995
echo ">>>>>>>>running test 3996"
../source/print_tokens.exe ../inputs/uslin.870     > ../outputs/t3996
echo ">>>>>>>>running test 3997"
../source/print_tokens.exe ../inputs/uslin.870.noeof     > ../outputs/t3997
echo ">>>>>>>>running test 3998"
../source/print_tokens.exe ../inputs/uslin.873     > ../outputs/t3998
echo ">>>>>>>>running test 3999"
../source/print_tokens.exe ../inputs/uslin.874     > ../outputs/t3999
echo ">>>>>>>>running test 4000"
../source/print_tokens.exe ../inputs/uslin.877      > ../outputs/t4000
echo ">>>>>>>>running test 4001"
../source/print_tokens.exe ../inputs/uslin.878     > ../outputs/t4001
echo ">>>>>>>>running test 4002"
../source/print_tokens.exe ../inputs/uslin.879     > ../outputs/t4002
echo ">>>>>>>>running test 4003"
../source/print_tokens.exe ../inputs/uslin.881     > ../outputs/t4003
echo ">>>>>>>>running test 4004"
../source/print_tokens.exe ../inputs/uslin.882     > ../outputs/t4004
echo ">>>>>>>>running test 4005"
../source/print_tokens.exe ../inputs/uslin.883     > ../outputs/t4005
echo ">>>>>>>>running test 4006"
../source/print_tokens.exe ../inputs/uslin.884     > ../outputs/t4006
echo ">>>>>>>>running test 4007"
../source/print_tokens.exe ../inputs/uslin.885     > ../outputs/t4007
echo ">>>>>>>>running test 4008"
../source/print_tokens.exe ../inputs/uslin.885.noeof     > ../outputs/t4008
echo ">>>>>>>>running test 4009"
../source/print_tokens.exe ../inputs/uslin.886     > ../outputs/t4009
echo ">>>>>>>>running test 4010"
../source/print_tokens.exe ../inputs/uslin.887     > ../outputs/t4010
echo ">>>>>>>>running test 4011"
../source/print_tokens.exe ../inputs/uslin.889     > ../outputs/t4011
echo ">>>>>>>>running test 4012"
../source/print_tokens.exe ../inputs/uslin.890     > ../outputs/t4012
echo ">>>>>>>>running test 4013"
../source/print_tokens.exe ../inputs/uslin.891     > ../outputs/t4013
echo ">>>>>>>>running test 4014"
../source/print_tokens.exe ../inputs/uslin.893     > ../outputs/t4014
echo ">>>>>>>>running test 4015"
../source/print_tokens.exe ../inputs/uslin.894     > ../outputs/t4015
echo ">>>>>>>>running test 4016"
../source/print_tokens.exe ../inputs/uslin.897     > ../outputs/t4016
echo ">>>>>>>>running test 4017"
../source/print_tokens.exe ../inputs/uslin.899     > ../outputs/t4017
echo ">>>>>>>>running test 4018"
../source/print_tokens.exe ../inputs/uslin.90     > ../outputs/t4018
echo ">>>>>>>>running test 4019"
../source/print_tokens.exe ../inputs/uslin.900     > ../outputs/t4019
echo ">>>>>>>>running test 4020"
../source/print_tokens.exe ../inputs/uslin.901     > ../outputs/t4020
echo ">>>>>>>>running test 4021"
../source/print_tokens.exe ../inputs/uslin.902     > ../outputs/t4021
echo ">>>>>>>>running test 4022"
../source/print_tokens.exe ../inputs/uslin.907     > ../outputs/t4022
echo ">>>>>>>>running test 4023"
../source/print_tokens.exe ../inputs/uslin.908     > ../outputs/t4023
echo ">>>>>>>>running test 4024"
../source/print_tokens.exe ../inputs/uslin.909     > ../outputs/t4024
echo ">>>>>>>>running test 4025"
../source/print_tokens.exe ../inputs/uslin.91     > ../outputs/t4025
echo ">>>>>>>>running test 4026"
../source/print_tokens.exe ../inputs/uslin.911     > ../outputs/t4026
echo ">>>>>>>>running test 4027"
../source/print_tokens.exe ../inputs/uslin.912     > ../outputs/t4027
echo ">>>>>>>>running test 4028"
../source/print_tokens.exe ../inputs/uslin.916     > ../outputs/t4028
echo ">>>>>>>>running test 4029"
../source/print_tokens.exe ../inputs/uslin.917     > ../outputs/t4029
echo ">>>>>>>>running test 4030"
../source/print_tokens.exe ../inputs/uslin.918     > ../outputs/t4030
echo ">>>>>>>>running test 4031"
../source/print_tokens.exe ../inputs/uslin.919     > ../outputs/t4031
echo ">>>>>>>>running test 4032"
../source/print_tokens.exe ../inputs/uslin.921     > ../outputs/t4032
echo ">>>>>>>>running test 4033"
../source/print_tokens.exe ../inputs/uslin.925      > ../outputs/t4033
echo ">>>>>>>>running test 4034"
../source/print_tokens.exe ../inputs/uslin.928     > ../outputs/t4034
echo ">>>>>>>>running test 4035"
../source/print_tokens.exe ../inputs/uslin.929     > ../outputs/t4035
echo ">>>>>>>>running test 4036"
../source/print_tokens.exe ../inputs/uslin.931     > ../outputs/t4036
echo ">>>>>>>>running test 4037"
../source/print_tokens.exe ../inputs/uslin.932     > ../outputs/t4037
echo ">>>>>>>>running test 4038"
../source/print_tokens.exe ../inputs/uslin.934     > ../outputs/t4038
echo ">>>>>>>>running test 4039"
../source/print_tokens.exe ../inputs/uslin.935     > ../outputs/t4039
echo ">>>>>>>>running test 4040"
../source/print_tokens.exe ../inputs/uslin.936     > ../outputs/t4040
echo ">>>>>>>>running test 4041"
../source/print_tokens.exe ../inputs/uslin.938     > ../outputs/t4041
echo ">>>>>>>>running test 4042"
../source/print_tokens.exe ../inputs/uslin.939     > ../outputs/t4042
echo ">>>>>>>>running test 4043"
../source/print_tokens.exe ../inputs/uslin.940     > ../outputs/t4043
echo ">>>>>>>>running test 4044"
../source/print_tokens.exe ../inputs/uslin.941     > ../outputs/t4044
echo ">>>>>>>>running test 4045"
../source/print_tokens.exe ../inputs/uslin.943     > ../outputs/t4045
echo ">>>>>>>>running test 4046"
../source/print_tokens.exe ../inputs/uslin.946     > ../outputs/t4046
echo ">>>>>>>>running test 4047"
../source/print_tokens.exe ../inputs/uslin.947     > ../outputs/t4047
echo ">>>>>>>>running test 4048"
../source/print_tokens.exe ../inputs/uslin.948     > ../outputs/t4048
echo ">>>>>>>>running test 4049"
../source/print_tokens.exe ../inputs/uslin.95     > ../outputs/t4049
echo ">>>>>>>>running test 4050"
../source/print_tokens.exe ../inputs/uslin.950     > ../outputs/t4050
echo ">>>>>>>>running test 4051"
../source/print_tokens.exe ../inputs/uslin.951     > ../outputs/t4051
echo ">>>>>>>>running test 4052"
../source/print_tokens.exe ../inputs/uslin.952     > ../outputs/t4052
echo ">>>>>>>>running test 4053"
../source/print_tokens.exe ../inputs/uslin.956     > ../outputs/t4053
echo ">>>>>>>>running test 4054"
../source/print_tokens.exe ../inputs/uslin.959     > ../outputs/t4054
echo ">>>>>>>>running test 4055"
../source/print_tokens.exe ../inputs/uslin.963     > ../outputs/t4055
echo ">>>>>>>>running test 4056"
../source/print_tokens.exe ../inputs/uslin.965     > ../outputs/t4056
echo ">>>>>>>>running test 4057"
../source/print_tokens.exe ../inputs/uslin.967     > ../outputs/t4057
echo ">>>>>>>>running test 4058"
../source/print_tokens.exe ../inputs/uslin.970     > ../outputs/t4058
echo ">>>>>>>>running test 4059"
../source/print_tokens.exe ../inputs/uslin.972     > ../outputs/t4059
echo ">>>>>>>>running test 4060"
../source/print_tokens.exe ../inputs/uslin.975     > ../outputs/t4060
echo ">>>>>>>>running test 4061"
../source/print_tokens.exe ../inputs/uslin.976     > ../outputs/t4061
echo ">>>>>>>>running test 4062"
../source/print_tokens.exe ../inputs/uslin.977     > ../outputs/t4062
echo ">>>>>>>>running test 4063"
../source/print_tokens.exe ../inputs/uslin.979     > ../outputs/t4063
echo ">>>>>>>>running test 4064"
../source/print_tokens.exe ../inputs/uslin.980     > ../outputs/t4064
echo ">>>>>>>>running test 4065"
../source/print_tokens.exe ../inputs/uslin.983     > ../outputs/t4065
echo ">>>>>>>>running test 4066"
../source/print_tokens.exe ../inputs/uslin.985     > ../outputs/t4066
echo ">>>>>>>>running test 4067"
../source/print_tokens.exe ../inputs/uslin.986     > ../outputs/t4067
echo ">>>>>>>>running test 4068"
../source/print_tokens.exe ../inputs/uslin.988     > ../outputs/t4068
echo ">>>>>>>>running test 4069"
../source/print_tokens.exe ../inputs/uslin.990     > ../outputs/t4069
echo ">>>>>>>>running test 4070"
../source/print_tokens.exe ../inputs/uslin.997     > ../outputs/t4070
echo ">>>>>>>>running test 4071"
../source/print_tokens.exe ../inputs/uslin.998     > ../outputs/t4071
echo ">>>>>>>>running test 4072"
../source/print_tokens.exe ../inputs/garbage/nothing     > ../outputs/t4072
echo ">>>>>>>>running test 4073"
../source/print_tokens.exe ../inputs/garbage/nothing     > ../outputs/t4073
echo ">>>>>>>>running test 4074"
../source/print_tokens.exe ../inputs/garbage/nothing     > ../outputs/t4074
echo ">>>>>>>>running test 4075"
../source/print_tokens.exe ../inputs/garbage/nothing     > ../outputs/t4075
echo ">>>>>>>>running test 4076"
../source/print_tokens.exe ../inputs/garbage/nothing     > ../outputs/t4076
echo ">>>>>>>>running test 4077"
../source/print_tokens.exe ../inputs/garbage/nothing     > ../outputs/t4077
echo ">>>>>>>>running test 4078"
../source/print_tokens.exe ../inputs/garbage/nothing     > ../outputs/t4078
echo ">>>>>>>>running test 4079"
../source/print_tokens.exe ../inputs/garbage/nothing     > ../outputs/t4079
echo ">>>>>>>>running test 4080"
../source/print_tokens.exe ../inputs/garbage/nothing     > ../outputs/t4080
echo ">>>>>>>>running test 4081"
../source/print_tokens.exe ../inputs/garbage/nothing     > ../outputs/t4081
echo ">>>>>>>>running test 4082"
../source/print_tokens.exe ../inputs/garbage/nothing     > ../outputs/t4082
echo ">>>>>>>>running test 4083"
../source/print_tokens.exe ../inputs/garbage/nothing     > ../outputs/t4083
echo ">>>>>>>>running test 4084"
../source/print_tokens.exe ../inputs/garbage/nothing     > ../outputs/t4084
echo ">>>>>>>>running test 4085"
../source/print_tokens.exe ../inputs/garbage/nothing     > ../outputs/t4085
echo ">>>>>>>>running test 4086"
../source/print_tokens.exe ../inputs/garbage/nothing     > ../outputs/t4086
echo ">>>>>>>>running test 4087"
../source/print_tokens.exe ../inputs/garbage/nothing     > ../outputs/t4087
echo ">>>>>>>>running test 4088"
../source/print_tokens.exe ../inputs/garbage/nothing     > ../outputs/t4088
echo ">>>>>>>>running test 4089"
../source/print_tokens.exe ../inputs/garbage/nothing     > ../outputs/t4089
echo ">>>>>>>>running test 4090"
../source/print_tokens.exe ../inputs/garbage/nothing     > ../outputs/t4090
echo ">>>>>>>>running test 4091"
../source/print_tokens.exe ../inputs/garbage/nothing     > ../outputs/t4091
echo ">>>>>>>>running test 4092"
../source/print_tokens.exe ../inputs/garbage/nothing     > ../outputs/t4092
echo ">>>>>>>>running test 4093"
../source/print_tokens.exe ../inputs/garbage/nothing     > ../outputs/t4093
echo ">>>>>>>>running test 4094"
../source/print_tokens.exe ../inputs/garbage/nothing     > ../outputs/t4094
echo ">>>>>>>>running test 4095"
../source/print_tokens.exe ../inputs/garbage/nothing     > ../outputs/t4095
echo ">>>>>>>>running test 4096"
../source/print_tokens.exe ../inputs/garbage/nothing     > ../outputs/t4096
echo ">>>>>>>>running test 4097"
../source/print_tokens.exe ../inputs/garbage/nothing     > ../outputs/t4097
echo ">>>>>>>>running test 4098"
../source/print_tokens.exe ../inputs/garbage/nothing     > ../outputs/t4098
echo ">>>>>>>>running test 4099"
../source/print_tokens.exe ../inputs/garbage/nothing     > ../outputs/t4099
echo ">>>>>>>>running test 4100"
../source/print_tokens.exe ../inputs/garbage/nothing     > ../outputs/t4100
echo ">>>>>>>>running test 4101"
../source/print_tokens.exe one doesntliketwo     > ../outputs/t4101
echo ">>>>>>>>running test 4102"
../source/print_tokens.exe one doesntliketwo     > ../outputs/t4102
echo ">>>>>>>>running test 4103"
../source/print_tokens.exe one doesntliketwo     > ../outputs/t4103
echo ">>>>>>>>running test 4104"
../source/print_tokens.exe one doesntliketwo     > ../outputs/t4104
echo ">>>>>>>>running test 4105"
../source/print_tokens.exe one doesntliketwo     > ../outputs/t4105
echo ">>>>>>>>running test 4106"
../source/print_tokens.exe one doesntliketwo     > ../outputs/t4106
echo ">>>>>>>>running test 4107"
../source/print_tokens.exe one doesntliketwo     > ../outputs/t4107
echo ">>>>>>>>running test 4108"
../source/print_tokens.exe one doesntliketwo     > ../outputs/t4108
echo ">>>>>>>>running test 4109"
../source/print_tokens.exe one doesntliketwo     > ../outputs/t4109
echo ">>>>>>>>running test 4110"
../source/print_tokens.exe one doesntliketwo     > ../outputs/t4110
echo ">>>>>>>>running test 4111"
../source/print_tokens.exe one doesntliketwo     > ../outputs/t4111
echo ">>>>>>>>running test 4112"
../source/print_tokens.exe one doesntliketwo     > ../outputs/t4112
echo ">>>>>>>>running test 4113"
../source/print_tokens.exe one doesntliketwo     > ../outputs/t4113
echo ">>>>>>>>running test 4114"
../source/print_tokens.exe one doesntliketwo     > ../outputs/t4114
echo ">>>>>>>>running test 4115"
../source/print_tokens.exe one doesntliketwo     > ../outputs/t4115
echo ">>>>>>>>running test 4116"
../source/print_tokens.exe one doesntliketwo     > ../outputs/t4116
echo ">>>>>>>>running test 4117"
../source/print_tokens.exe one doesntliketwo     > ../outputs/t4117
echo ">>>>>>>>running test 4118"
../source/print_tokens.exe one doesntliketwo     > ../outputs/t4118
echo ">>>>>>>>running test 4119"
../source/print_tokens.exe one doesntliketwo     > ../outputs/t4119
echo ">>>>>>>>running test 4120"
../source/print_tokens.exe one doesntliketwo     > ../outputs/t4120
echo ">>>>>>>>running test 4121"
../source/print_tokens.exe one doesntliketwo     > ../outputs/t4121
echo ">>>>>>>>running test 4122"
../source/print_tokens.exe one doesntliketwo     > ../outputs/t4122
echo ">>>>>>>>running test 4123"
../source/print_tokens.exe one doesntliketwo     > ../outputs/t4123
echo ">>>>>>>>running test 4124"
../source/print_tokens.exe one doesntliketwo     > ../outputs/t4124
echo ">>>>>>>>running test 4125"
../source/print_tokens.exe one doesntliketwo     > ../outputs/t4125
echo ">>>>>>>>running test 4126"
../source/print_tokens.exe one doesntliketwo     > ../outputs/t4126
echo ">>>>>>>>running test 4127"
../source/print_tokens.exe one doesntliketwo     > ../outputs/t4127
echo ">>>>>>>>running test 4128"
../source/print_tokens.exe one doesntliketwo     > ../outputs/t4128
echo ">>>>>>>>running test 4129"
../source/print_tokens.exe one doesntliketwo     > ../outputs/t4129
echo ">>>>>>>>running test 4130"
../source/print_tokens.exe one doesntliketwo     > ../outputs/t4130
