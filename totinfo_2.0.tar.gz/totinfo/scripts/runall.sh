echo script type: R
echo ">>>>>>>>running test 1"
../source/tot_info.exe  < ../inputs/universe/tst88 > ../outputs/t1
echo ">>>>>>>>running test 2"
../source/tot_info.exe  < ../inputs/universe/tst34 > ../outputs/t2
echo ">>>>>>>>running test 3"
../source/tot_info.exe  < ../inputs/universe/tst16 > ../outputs/t3
echo ">>>>>>>>running test 4"
../source/tot_info.exe  < ../inputs/universe/jkADr.mat > ../outputs/t4
echo ">>>>>>>>running test 5"
../source/tot_info.exe  < ../inputs/universe/tst6 > ../outputs/t5
echo ">>>>>>>>running test 6"
../source/tot_info.exe  < ../inputs/universe/tst13 > ../outputs/t6
echo ">>>>>>>>running test 7"
../source/tot_info.exe  < ../inputs/universe/tst108 > ../outputs/t7
echo ">>>>>>>>running test 8"
../source/tot_info.exe  < ../inputs/universe/tst17 > ../outputs/t8
echo ">>>>>>>>running test 9"
../source/tot_info.exe  < ../inputs/universe/tst29 > ../outputs/t9
echo ">>>>>>>>running test 10"
../source/tot_info.exe  < ../inputs/universe/tst89 > ../outputs/t10
echo ">>>>>>>>running test 11"
../source/tot_info.exe  < ../inputs/universe/tst8 > ../outputs/t11
echo ">>>>>>>>running test 12"
../source/tot_info.exe  < ../inputs/universe/tst9 > ../outputs/t12
echo ">>>>>>>>running test 13"
../source/tot_info.exe  < ../inputs/universe/tst55 > ../outputs/t13
echo ">>>>>>>>running test 14"
../source/tot_info.exe  < ../inputs/universe/tst76 > ../outputs/t14
echo ">>>>>>>>running test 15"
../source/tot_info.exe  < ../inputs/universe/tst109 > ../outputs/t15
echo ">>>>>>>>running test 16"
../source/tot_info.exe  < ../inputs/universe/tst10 > ../outputs/t16
echo ">>>>>>>>running test 17"
../source/tot_info.exe  < ../inputs/universe/tst15 > ../outputs/t17
echo ">>>>>>>>running test 18"
../source/tot_info.exe  < ../inputs/universe/tst19 > ../outputs/t18
echo ">>>>>>>>running test 19"
../source/tot_info.exe  < ../inputs/universe/tst90 > ../outputs/t19
echo ">>>>>>>>running test 20"
../source/tot_info.exe  < ../inputs/universe/tst20 > ../outputs/t20
echo ">>>>>>>>running test 21"
../source/tot_info.exe  < ../inputs/universe/tst56 > ../outputs/t21
echo ">>>>>>>>running test 22"
../source/tot_info.exe  < ../inputs/universe/tst24 > ../outputs/t22
echo ">>>>>>>>running test 23"
../source/tot_info.exe  < ../inputs/universe/tst3 > ../outputs/t23
echo ">>>>>>>>running test 24"
../source/tot_info.exe  < ../inputs/universe/tst25 > ../outputs/t24
echo ">>>>>>>>running test 25"
../source/tot_info.exe  < ../inputs/universe/tst50 > ../outputs/t25
echo ">>>>>>>>running test 26"
../source/tot_info.exe  < ../inputs/universe/tst87 > ../outputs/t26
echo ">>>>>>>>running test 27"
../source/tot_info.exe  < ../inputs/universe/tst91 > ../outputs/t27
echo ">>>>>>>>running test 28"
../source/tot_info.exe  < ../inputs/universe/tst107 > ../outputs/t28
echo ">>>>>>>>running test 29"
../source/tot_info.exe  < ../inputs/universe/tst27 > ../outputs/t29
echo ">>>>>>>>running test 30"
../source/tot_info.exe  < ../inputs/universe/tst77 > ../outputs/t30
echo ">>>>>>>>running test 31"
../source/tot_info.exe  < ../inputs/universe/tst98 > ../outputs/t31
echo ">>>>>>>>running test 32"
../source/tot_info.exe  < ../inputs/universe/tst18 > ../outputs/t32
echo ">>>>>>>>running test 33"
../source/tot_info.exe  < ../inputs/universe/tst28 > ../outputs/t33
echo ">>>>>>>>running test 34"
../source/tot_info.exe  < ../inputs/universe/tst7 > ../outputs/t34
echo ">>>>>>>>running test 35"
../source/tot_info.exe  < ../inputs/universe/tst30 > ../outputs/t35
echo ">>>>>>>>running test 36"
../source/tot_info.exe  < ../inputs/universe/tst107 > ../outputs/t36
echo ">>>>>>>>running test 37"
../source/tot_info.exe  < ../inputs/universe/tst32 > ../outputs/t37
echo ">>>>>>>>running test 38"
../source/tot_info.exe  < ../inputs/universe/tst33 > ../outputs/t38
echo ">>>>>>>>running test 39"
../source/tot_info.exe  < ../inputs/universe/tst2 > ../outputs/t39
echo ">>>>>>>>running test 40"
../source/tot_info.exe  < ../inputs/universe/tst5 > ../outputs/t40
echo ">>>>>>>>running test 41"
../source/tot_info.exe  < ../inputs/universe/tst92 > ../outputs/t41
echo ">>>>>>>>running test 42"
../source/tot_info.exe  < ../inputs/universe/tst97 > ../outputs/t42
echo ">>>>>>>>running test 43"
../source/tot_info.exe  < ../inputs/universe/tst31 > ../outputs/t43
echo ">>>>>>>>running test 44"
../source/tot_info.exe  < ../inputs/universe/tst35 > ../outputs/t44
echo ">>>>>>>>running test 45"
../source/tot_info.exe  < ../inputs/universe/tst21 > ../outputs/t45
echo ">>>>>>>>running test 46"
../source/tot_info.exe  < ../inputs/universe/tst39 > ../outputs/t46
echo ">>>>>>>>running test 47"
../source/tot_info.exe  < ../inputs/universe/tst12 > ../outputs/t47
echo ">>>>>>>>running test 48"
../source/tot_info.exe  < ../inputs/universe/tst86 > ../outputs/t48
echo ">>>>>>>>running test 49"
../source/tot_info.exe  < ../inputs/universe/tst106 > ../outputs/t49
echo ">>>>>>>>running test 50"
../source/tot_info.exe  < ../inputs/universe/tst41 > ../outputs/t50
echo ">>>>>>>>running test 51"
../source/tot_info.exe  < ../inputs/universe/tst43 > ../outputs/t51
echo ">>>>>>>>running test 52"
../source/tot_info.exe  < ../inputs/universe/tst23 > ../outputs/t52
echo ">>>>>>>>running test 53"
../source/tot_info.exe  < ../inputs/universe/tst115 > ../outputs/t53
echo ">>>>>>>>running test 54"
../source/tot_info.exe  < ../inputs/universe/tst44 > ../outputs/t54
echo ">>>>>>>>running test 55"
../source/tot_info.exe  < ../inputs/universe/tst68 > ../outputs/t55
echo ">>>>>>>>running test 56"
../source/tot_info.exe  < ../inputs/universe/tst45 > ../outputs/t56
echo ">>>>>>>>running test 57"
../source/tot_info.exe  < ../inputs/universe/tst4 > ../outputs/t57
echo ">>>>>>>>running test 58"
../source/tot_info.exe  < ../inputs/universe/tst116 > ../outputs/t58
echo ">>>>>>>>running test 59"
../source/tot_info.exe  < ../inputs/universe/tst85 > ../outputs/t59
echo ">>>>>>>>running test 60"
../source/tot_info.exe  < ../inputs/universe/tst46 > ../outputs/t60
echo ">>>>>>>>running test 61"
../source/tot_info.exe  < ../inputs/universe/tst47 > ../outputs/t61
echo ">>>>>>>>running test 62"
../source/tot_info.exe  < ../inputs/universe/tst96 > ../outputs/t62
echo ">>>>>>>>running test 63"
../source/tot_info.exe  < ../inputs/universe/tst73 > ../outputs/t63
echo ">>>>>>>>running test 64"
../source/tot_info.exe  < ../inputs/universe/tst48 > ../outputs/t64
echo ">>>>>>>>running test 65"
../source/tot_info.exe  < ../inputs/universe/tst101 > ../outputs/t65
echo ">>>>>>>>running test 66"
../source/tot_info.exe  < ../inputs/universe/tst64 > ../outputs/t66
echo ">>>>>>>>running test 67"
../source/tot_info.exe  < ../inputs/universe/tst84 > ../outputs/t67
echo ">>>>>>>>running test 68"
../source/tot_info.exe  < ../inputs/universe/tst49 > ../outputs/t68
echo ">>>>>>>>running test 69"
../source/tot_info.exe  < ../inputs/universe/tst95 > ../outputs/t69
echo ">>>>>>>>running test 70"
../source/tot_info.exe  < ../inputs/universe/tst14 > ../outputs/t70
echo ">>>>>>>>running test 71"
../source/tot_info.exe  < ../inputs/universe/tst51 > ../outputs/t71
echo ">>>>>>>>running test 72"
../source/tot_info.exe  < ../inputs/universe/tst115 > ../outputs/t72
echo ">>>>>>>>running test 73"
../source/tot_info.exe  < ../inputs/universe/tst72 > ../outputs/t73
echo ">>>>>>>>running test 74"
../source/tot_info.exe  < ../inputs/universe/tst60 > ../outputs/t74
echo ">>>>>>>>running test 75"
../source/tot_info.exe  < ../inputs/universe/tst83 > ../outputs/t75
echo ">>>>>>>>running test 76"
../source/tot_info.exe  < ../inputs/universe/tst38 > ../outputs/t76
echo ">>>>>>>>running test 77"
../source/tot_info.exe  < ../inputs/universe/tst52 > ../outputs/t77
echo ">>>>>>>>running test 78"
../source/tot_info.exe  < ../inputs/universe/tst95 > ../outputs/t78
echo ">>>>>>>>running test 79"
../source/tot_info.exe  < ../inputs/universe/tst82 > ../outputs/t79
echo ">>>>>>>>running test 80"
../source/tot_info.exe  < ../inputs/universe/tst114 > ../outputs/t80
echo ">>>>>>>>running test 81"
../source/tot_info.exe  < ../inputs/universe/tst75 > ../outputs/t81
echo ">>>>>>>>running test 82"
../source/tot_info.exe  < ../inputs/universe/tst36 > ../outputs/t82
echo ">>>>>>>>running test 83"
../source/tot_info.exe  < ../inputs/universe/tst54 > ../outputs/t83
echo ">>>>>>>>running test 84"
../source/tot_info.exe  < ../inputs/universe/tst57 > ../outputs/t84
echo ">>>>>>>>running test 85"
../source/tot_info.exe  < ../inputs/universe/tst79 > ../outputs/t85
echo ">>>>>>>>running test 86"
../source/tot_info.exe  < ../inputs/universe/tst58 > ../outputs/t86
echo ">>>>>>>>running test 87"
../source/tot_info.exe  < ../inputs/universe/tst94 > ../outputs/t87
echo ">>>>>>>>running test 88"
../source/tot_info.exe  < ../inputs/universe/tst59 > ../outputs/t88
echo ">>>>>>>>running test 89"
../source/tot_info.exe  < ../inputs/universe/tst11 > ../outputs/t89
echo ">>>>>>>>running test 90"
../source/tot_info.exe  < ../inputs/universe/tst116 > ../outputs/t90
echo ">>>>>>>>running test 91"
../source/tot_info.exe  < ../inputs/universe/tst40 > ../outputs/t91
echo ">>>>>>>>running test 92"
../source/tot_info.exe  < ../inputs/universe/tst93 > ../outputs/t92
echo ">>>>>>>>running test 93"
../source/tot_info.exe  < ../inputs/universe/tst61 > ../outputs/t93
echo ">>>>>>>>running test 94"
../source/tot_info.exe  < ../inputs/universe/tst22 > ../outputs/t94
echo ">>>>>>>>running test 95"
../source/tot_info.exe  < ../inputs/universe/tst42 > ../outputs/t95
echo ">>>>>>>>running test 96"
../source/tot_info.exe  < ../inputs/universe/tst62 > ../outputs/t96
echo ">>>>>>>>running test 97"
../source/tot_info.exe  < ../inputs/universe/tst104 > ../outputs/t97
echo ">>>>>>>>running test 98"
../source/tot_info.exe  < ../inputs/universe/tst37 > ../outputs/t98
echo ">>>>>>>>running test 99"
../source/tot_info.exe  < ../inputs/universe/tst81 > ../outputs/t99
echo ">>>>>>>>running test 100"
../source/tot_info.exe  < ../inputs/universe/tst63 > ../outputs/t100
echo ">>>>>>>>running test 101"
../source/tot_info.exe  < ../inputs/universe/tst113 > ../outputs/t101
echo ">>>>>>>>running test 102"
../source/tot_info.exe  < ../inputs/universe/tst112 > ../outputs/t102
echo ">>>>>>>>running test 103"
../source/tot_info.exe  < ../inputs/universe/tst26 > ../outputs/t103
echo ">>>>>>>>running test 104"
../source/tot_info.exe  < ../inputs/universe/tst65 > ../outputs/t104
echo ">>>>>>>>running test 105"
../source/tot_info.exe  < ../inputs/universe/tst71 > ../outputs/t105
echo ">>>>>>>>running test 106"
../source/tot_info.exe  < ../inputs/universe/tst111 > ../outputs/t106
echo ">>>>>>>>running test 107"
../source/tot_info.exe  < ../inputs/universe/tst74 > ../outputs/t107
echo ">>>>>>>>running test 108"
../source/tot_info.exe  < ../inputs/universe/tst102 > ../outputs/t108
echo ">>>>>>>>running test 109"
../source/tot_info.exe  < ../inputs/universe/tst66 > ../outputs/t109
echo ">>>>>>>>running test 110"
../source/tot_info.exe  < ../inputs/universe/tst117 > ../outputs/t110
echo ">>>>>>>>running test 111"
../source/tot_info.exe  < ../inputs/universe/tst67 > ../outputs/t111
echo ">>>>>>>>running test 112"
../source/tot_info.exe  < ../inputs/universe/tst69 > ../outputs/t112
echo ">>>>>>>>running test 113"
../source/tot_info.exe  < ../inputs/universe/tst70 > ../outputs/t113
echo ">>>>>>>>running test 114"
../source/tot_info.exe  < ../inputs/universe/tst1 > ../outputs/t114
echo ">>>>>>>>running test 115"
../source/tot_info.exe  < ../inputs/universe/tst103 > ../outputs/t115
echo ">>>>>>>>running test 116"
../source/tot_info.exe  < ../inputs/universe/tst80 > ../outputs/t116
echo ">>>>>>>>running test 117"
../source/tot_info.exe  < ../inputs/universe/test3 > ../outputs/t117
echo ">>>>>>>>running test 118"
../source/tot_info.exe  < ../inputs/universe/test5 > ../outputs/t118
echo ">>>>>>>>running test 119"
../source/tot_info.exe  < ../inputs/universe/test32 > ../outputs/t119
echo ">>>>>>>>running test 120"
../source/tot_info.exe  < ../inputs/universe/test7 > ../outputs/t120
echo ">>>>>>>>running test 121"
../source/tot_info.exe  < ../inputs/universe/test8 > ../outputs/t121
echo ">>>>>>>>running test 122"
../source/tot_info.exe  < ../inputs/universe/test9 > ../outputs/t122
echo ">>>>>>>>running test 123"
../source/tot_info.exe  < ../inputs/universe/test10 > ../outputs/t123
echo ">>>>>>>>running test 124"
../source/tot_info.exe  < ../inputs/universe/test19 > ../outputs/t124
echo ">>>>>>>>running test 125"
../source/tot_info.exe  < ../inputs/universe/test31 > ../outputs/t125
echo ">>>>>>>>running test 126"
../source/tot_info.exe  < ../inputs/universe/test1 > ../outputs/t126
echo ">>>>>>>>running test 127"
../source/tot_info.exe  < ../inputs/universe/test4 > ../outputs/t127
echo ">>>>>>>>running test 128"
../source/tot_info.exe  < ../inputs/universe/test39 > ../outputs/t128
echo ">>>>>>>>running test 129"
../source/tot_info.exe  < ../inputs/universe/test11 > ../outputs/t129
echo ">>>>>>>>running test 130"
../source/tot_info.exe  < ../inputs/universe/test30 > ../outputs/t130
echo ">>>>>>>>running test 131"
../source/tot_info.exe  < ../inputs/universe/test14 > ../outputs/t131
echo ">>>>>>>>running test 132"
../source/tot_info.exe  < ../inputs/universe/test13 > ../outputs/t132
echo ">>>>>>>>running test 133"
../source/tot_info.exe  < ../inputs/universe/test15 > ../outputs/t133
echo ">>>>>>>>running test 134"
../source/tot_info.exe  < ../inputs/universe/test16 > ../outputs/t134
echo ">>>>>>>>running test 135"
../source/tot_info.exe  < ../inputs/universe/test17 > ../outputs/t135
echo ">>>>>>>>running test 136"
../source/tot_info.exe  < ../inputs/universe/test6 > ../outputs/t136
echo ">>>>>>>>running test 137"
../source/tot_info.exe  < ../inputs/universe/test33 > ../outputs/t137
echo ">>>>>>>>running test 138"
../source/tot_info.exe  < ../inputs/universe/test34 > ../outputs/t138
echo ">>>>>>>>running test 139"
../source/tot_info.exe  < ../inputs/universe/test35 > ../outputs/t139
echo ">>>>>>>>running test 140"
../source/tot_info.exe  < ../inputs/universe/test36 > ../outputs/t140
echo ">>>>>>>>running test 141"
../source/tot_info.exe  < ../inputs/universe/test18 > ../outputs/t141
echo ">>>>>>>>running test 142"
../source/tot_info.exe  < ../inputs/universe/test37 > ../outputs/t142
echo ">>>>>>>>running test 143"
../source/tot_info.exe  < ../inputs/universe/test40 > ../outputs/t143
echo ">>>>>>>>running test 144"
../source/tot_info.exe  < ../inputs/universe/test38 > ../outputs/t144
echo ">>>>>>>>running test 145"
../source/tot_info.exe  < ../inputs/universe/tstt1.mat > ../outputs/t145
echo ">>>>>>>>running test 146"
../source/tot_info.exe  < ../inputs/universe/jk2AAZ.mat > ../outputs/t146
echo ">>>>>>>>running test 147"
../source/tot_info.exe  < ../inputs/universe/jk2ABS.mat > ../outputs/t147
echo ">>>>>>>>running test 148"
../source/tot_info.exe  < ../inputs/universe/jk2ABk.mat > ../outputs/t148
echo ">>>>>>>>running test 149"
../source/tot_info.exe  < ../inputs/universe/jk1AA_.mat > ../outputs/t149
echo ">>>>>>>>running test 150"
../source/tot_info.exe  < ../inputs/universe/tst29.mat > ../outputs/t150
echo ">>>>>>>>running test 151"
../source/tot_info.exe  < ../inputs/universe/jk1AAS.mat > ../outputs/t151
echo ">>>>>>>>running test 152"
../source/tot_info.exe  < ../inputs/universe/jkAAY.mat > ../outputs/t152
echo ">>>>>>>>running test 153"
../source/tot_info.exe  < ../inputs/universe/jk2AAy.mat > ../outputs/t153
echo ">>>>>>>>running test 154"
../source/tot_info.exe  < ../inputs/universe/jkAAQ.mat > ../outputs/t154
echo ">>>>>>>>running test 155"
../source/tot_info.exe  < ../inputs/universe/tst21.mat > ../outputs/t155
echo ">>>>>>>>running test 156"
../source/tot_info.exe  < ../inputs/universe/jkAAZ.mat > ../outputs/t156
echo ">>>>>>>>running test 157"
../source/tot_info.exe  < ../inputs/universe/jk2ABq.mat > ../outputs/t157
echo ">>>>>>>>running test 158"
../source/tot_info.exe  < ../inputs/universe/jk1ABq.mat > ../outputs/t158
echo ">>>>>>>>running test 159"
../source/tot_info.exe  < ../inputs/universe/jk2AAX.mat > ../outputs/t159
echo ">>>>>>>>running test 160"
../source/tot_info.exe  < ../inputs/universe/jkADr.mat > ../outputs/t160
echo ">>>>>>>>running test 161"
../source/tot_info.exe  < ../inputs/universe/jkAFi.mat > ../outputs/t161
echo ">>>>>>>>running test 162"
../source/tot_info.exe  < ../inputs/universe/jk2AAS.mat > ../outputs/t162
echo ">>>>>>>>running test 163"
../source/tot_info.exe  < ../inputs/universe/tst2f.mat > ../outputs/t163
echo ">>>>>>>>running test 164"
../source/tot_info.exe  < ../inputs/universe/tst23.mat > ../outputs/t164
echo ">>>>>>>>running test 165"
../source/tot_info.exe  < ../inputs/universe/tst2E.mat > ../outputs/t165
echo ">>>>>>>>running test 166"
../source/tot_info.exe  < ../inputs/universe/test72 > ../outputs/t166
echo ">>>>>>>>running test 167"
../source/tot_info.exe  < ../inputs/universe/test77 > ../outputs/t167
echo ">>>>>>>>running test 168"
../source/tot_info.exe  < ../inputs/universe/test80 > ../outputs/t168
echo ">>>>>>>>running test 169"
../source/tot_info.exe  < ../inputs/universe/test51 > ../outputs/t169
echo ">>>>>>>>running test 170"
../source/tot_info.exe  < ../inputs/universe/test52 > ../outputs/t170
echo ">>>>>>>>running test 171"
../source/tot_info.exe  < ../inputs/universe/test53 > ../outputs/t171
echo ">>>>>>>>running test 172"
../source/tot_info.exe  < ../inputs/universe/test54 > ../outputs/t172
echo ">>>>>>>>running test 173"
../source/tot_info.exe  < ../inputs/universe/test56 > ../outputs/t173
echo ">>>>>>>>running test 174"
../source/tot_info.exe  < ../inputs/universe/test57 > ../outputs/t174
echo ">>>>>>>>running test 175"
../source/tot_info.exe  < ../inputs/universe/test60 > ../outputs/t175
echo ">>>>>>>>running test 176"
../source/tot_info.exe  < ../inputs/universe/test42 > ../outputs/t176
echo ">>>>>>>>running test 177"
../source/tot_info.exe  < ../inputs/universe/test75 > ../outputs/t177
echo ">>>>>>>>running test 178"
../source/tot_info.exe  < ../inputs/universe/test73 > ../outputs/t178
echo ">>>>>>>>running test 179"
../source/tot_info.exe  < ../inputs/universe/test99 > ../outputs/t179
echo ">>>>>>>>running test 180"
../source/tot_info.exe  < ../inputs/universe/test43 > ../outputs/t180
echo ">>>>>>>>running test 181"
../source/tot_info.exe  < ../inputs/universe/test90 > ../outputs/t181
echo ">>>>>>>>running test 182"
../source/tot_info.exe  < ../inputs/universe/test45 > ../outputs/t182
echo ">>>>>>>>running test 183"
../source/tot_info.exe  < ../inputs/universe/test46 > ../outputs/t183
echo ">>>>>>>>running test 184"
../source/tot_info.exe  < ../inputs/universe/test78 > ../outputs/t184
echo ">>>>>>>>running test 185"
../source/tot_info.exe  < ../inputs/universe/test83 > ../outputs/t185
echo ">>>>>>>>running test 186"
../source/tot_info.exe  < ../inputs/universe/test59 > ../outputs/t186
echo ">>>>>>>>running test 187"
../source/tot_info.exe  < ../inputs/universe/test49 > ../outputs/t187
echo ">>>>>>>>running test 188"
../source/tot_info.exe  < ../inputs/universe/test50 > ../outputs/t188
echo ">>>>>>>>running test 189"
../source/tot_info.exe  < ../inputs/universe/test61 > ../outputs/t189
echo ">>>>>>>>running test 190"
../source/tot_info.exe  < ../inputs/universe/test63 > ../outputs/t190
echo ">>>>>>>>running test 191"
../source/tot_info.exe  < ../inputs/universe/test74 > ../outputs/t191
echo ">>>>>>>>running test 192"
../source/tot_info.exe  < ../inputs/universe/test64 > ../outputs/t192
echo ">>>>>>>>running test 193"
../source/tot_info.exe  < ../inputs/universe/test79 > ../outputs/t193
echo ">>>>>>>>running test 194"
../source/tot_info.exe  < ../inputs/universe/test87 > ../outputs/t194
echo ">>>>>>>>running test 195"
../source/tot_info.exe  < ../inputs/universe/test66 > ../outputs/t195
echo ">>>>>>>>running test 196"
../source/tot_info.exe  < ../inputs/universe/test67 > ../outputs/t196
echo ">>>>>>>>running test 197"
../source/tot_info.exe  < ../inputs/universe/test48 > ../outputs/t197
echo ">>>>>>>>running test 198"
../source/tot_info.exe  < ../inputs/universe/test100 > ../outputs/t198
echo ">>>>>>>>running test 199"
../source/tot_info.exe  < ../inputs/universe/test92 > ../outputs/t199
echo ">>>>>>>>running test 200"
../source/tot_info.exe  < ../inputs/universe/test68 > ../outputs/t200
echo ">>>>>>>>running test 201"
../source/tot_info.exe  < ../inputs/universe/test76 > ../outputs/t201
echo ">>>>>>>>running test 202"
../source/tot_info.exe  < ../inputs/universe/test69 > ../outputs/t202
echo ">>>>>>>>running test 203"
../source/tot_info.exe  < ../inputs/universe/test44 > ../outputs/t203
echo ">>>>>>>>running test 204"
../source/tot_info.exe  < ../inputs/universe/test47 > ../outputs/t204
echo ">>>>>>>>running test 205"
../source/tot_info.exe  < ../inputs/universe/test81 > ../outputs/t205
echo ">>>>>>>>running test 206"
../source/tot_info.exe  < ../inputs/universe/test84 > ../outputs/t206
echo ">>>>>>>>running test 207"
../source/tot_info.exe  < ../inputs/universe/test98 > ../outputs/t207
echo ">>>>>>>>running test 208"
../source/tot_info.exe  < ../inputs/universe/test58 > ../outputs/t208
echo ">>>>>>>>running test 209"
../source/tot_info.exe  < ../inputs/universe/test88 > ../outputs/t209
echo ">>>>>>>>running test 210"
../source/tot_info.exe  < ../inputs/universe/test89 > ../outputs/t210
echo ">>>>>>>>running test 211"
../source/tot_info.exe  < ../inputs/universe/test91 > ../outputs/t211
echo ">>>>>>>>running test 212"
../source/tot_info.exe  < ../inputs/universe/test70 > ../outputs/t212
echo ">>>>>>>>running test 213"
../source/tot_info.exe  < ../inputs/universe/test82 > ../outputs/t213
echo ">>>>>>>>running test 214"
../source/tot_info.exe  < ../inputs/universe/test93 > ../outputs/t214
echo ">>>>>>>>running test 215"
../source/tot_info.exe  < ../inputs/universe/test94 > ../outputs/t215
echo ">>>>>>>>running test 216"
../source/tot_info.exe  < ../inputs/universe/test65 > ../outputs/t216
echo ">>>>>>>>running test 217"
../source/tot_info.exe  < ../inputs/universe/test71 > ../outputs/t217
echo ">>>>>>>>running test 218"
../source/tot_info.exe  < ../inputs/universe/test85 > ../outputs/t218
echo ">>>>>>>>running test 219"
../source/tot_info.exe  < ../inputs/universe/test101 > ../outputs/t219
echo ">>>>>>>>running test 220"
../source/tot_info.exe  < ../inputs/universe/test102 > ../outputs/t220
echo ">>>>>>>>running test 221"
../source/tot_info.exe  < ../inputs/universe/test103 > ../outputs/t221
echo ">>>>>>>>running test 222"
../source/tot_info.exe  < ../inputs/universe/test104 > ../outputs/t222
echo ">>>>>>>>running test 223"
../source/tot_info.exe  < ../inputs/universe/test105 > ../outputs/t223
echo ">>>>>>>>running test 224"
../source/tot_info.exe  < ../inputs/universe/test106 > ../outputs/t224
echo ">>>>>>>>running test 225"
../source/tot_info.exe  < ../inputs/universe/test107 > ../outputs/t225
echo ">>>>>>>>running test 226"
../source/tot_info.exe  < ../inputs/universe/test108 > ../outputs/t226
echo ">>>>>>>>running test 227"
../source/tot_info.exe  < ../inputs/universe/test1.inc > ../outputs/t227
echo ">>>>>>>>running test 228"
../source/tot_info.exe  < ../inputs/universe/test3.inc > ../outputs/t228
echo ">>>>>>>>running test 229"
../source/tot_info.exe  < ../inputs/universe/test4.inc > ../outputs/t229
echo ">>>>>>>>running test 230"
../source/tot_info.exe  < ../inputs/universe/test5.inc > ../outputs/t230
echo ">>>>>>>>running test 231"
../source/tot_info.exe  < ../inputs/universe/test6.inc > ../outputs/t231
echo ">>>>>>>>running test 232"
../source/tot_info.exe  < ../inputs/universe/test7.inc > ../outputs/t232
echo ">>>>>>>>running test 233"
../source/tot_info.exe  < ../inputs/universe/test8.inc > ../outputs/t233
echo ">>>>>>>>running test 234"
../source/tot_info.exe  < ../inputs/universe/test9.inc > ../outputs/t234
echo ">>>>>>>>running test 235"
../source/tot_info.exe  < ../inputs/universe/test10.inc > ../outputs/t235
echo ">>>>>>>>running test 236"
../source/tot_info.exe  < ../inputs/universe/test11.inc > ../outputs/t236
echo ">>>>>>>>running test 237"
../source/tot_info.exe  < ../inputs/universe/test13.inc > ../outputs/t237
echo ">>>>>>>>running test 238"
../source/tot_info.exe  < ../inputs/universe/test14.inc > ../outputs/t238
echo ">>>>>>>>running test 239"
../source/tot_info.exe  < ../inputs/universe/test15.inc > ../outputs/t239
echo ">>>>>>>>running test 240"
../source/tot_info.exe  < ../inputs/universe/test16.inc > ../outputs/t240
echo ">>>>>>>>running test 241"
../source/tot_info.exe  < ../inputs/universe/test17.inc > ../outputs/t241
echo ">>>>>>>>running test 242"
../source/tot_info.exe  < ../inputs/universe/test18.inc > ../outputs/t242
echo ">>>>>>>>running test 243"
../source/tot_info.exe  < ../inputs/universe/test19.inc > ../outputs/t243
echo ">>>>>>>>running test 244"
../source/tot_info.exe  < ../inputs/universe/test20.inc > ../outputs/t244
echo ">>>>>>>>running test 245"
../source/tot_info.exe  < ../inputs/universe/test21.inc > ../outputs/t245
echo ">>>>>>>>running test 246"
../source/tot_info.exe  < ../inputs/universe/test22.inc > ../outputs/t246
echo ">>>>>>>>running test 247"
../source/tot_info.exe  < ../inputs/universe/test23.inc > ../outputs/t247
echo ">>>>>>>>running test 248"
../source/tot_info.exe  < ../inputs/universe/test24.inc > ../outputs/t248
echo ">>>>>>>>running test 249"
../source/tot_info.exe  < ../inputs/universe/test25.inc > ../outputs/t249
echo ">>>>>>>>running test 250"
../source/tot_info.exe  < ../inputs/universe/test26.inc > ../outputs/t250
echo ">>>>>>>>running test 251"
../source/tot_info.exe  < ../inputs/universe/test27.inc > ../outputs/t251
echo ">>>>>>>>running test 252"
../source/tot_info.exe  < ../inputs/universe/test28.inc > ../outputs/t252
echo ">>>>>>>>running test 253"
../source/tot_info.exe  < ../inputs/universe/test29.inc > ../outputs/t253
echo ">>>>>>>>running test 254"
../source/tot_info.exe  < ../inputs/universe/test30.inc > ../outputs/t254
echo ">>>>>>>>running test 255"
../source/tot_info.exe  < ../inputs/universe/test31.inc > ../outputs/t255
echo ">>>>>>>>running test 256"
../source/tot_info.exe  < ../inputs/universe/test32.inc > ../outputs/t256
echo ">>>>>>>>running test 257"
../source/tot_info.exe  < ../inputs/universe/test33.inc > ../outputs/t257
echo ">>>>>>>>running test 258"
../source/tot_info.exe  < ../inputs/universe/test34.inc > ../outputs/t258
echo ">>>>>>>>running test 259"
../source/tot_info.exe  < ../inputs/universe/test35.inc > ../outputs/t259
echo ">>>>>>>>running test 260"
../source/tot_info.exe  < ../inputs/universe/test36.inc > ../outputs/t260
echo ">>>>>>>>running test 261"
../source/tot_info.exe  < ../inputs/universe/test37.inc > ../outputs/t261
echo ">>>>>>>>running test 262"
../source/tot_info.exe  < ../inputs/universe/test38.inc > ../outputs/t262
echo ">>>>>>>>running test 263"
../source/tot_info.exe  < ../inputs/universe/test39.inc > ../outputs/t263
echo ">>>>>>>>running test 264"
../source/tot_info.exe  < ../inputs/universe/test40.inc > ../outputs/t264
echo ">>>>>>>>running test 265"
../source/tot_info.exe  < ../inputs/universe/test41.inc > ../outputs/t265
echo ">>>>>>>>running test 266"
../source/tot_info.exe  < ../inputs/universe/test42.inc > ../outputs/t266
echo ">>>>>>>>running test 267"
../source/tot_info.exe  < ../inputs/universe/test43.inc > ../outputs/t267
echo ">>>>>>>>running test 268"
../source/tot_info.exe  < ../inputs/universe/test44.inc > ../outputs/t268
echo ">>>>>>>>running test 269"
../source/tot_info.exe  < ../inputs/universe/test45.inc > ../outputs/t269
echo ">>>>>>>>running test 270"
../source/tot_info.exe  < ../inputs/universe/test46.inc > ../outputs/t270
echo ">>>>>>>>running test 271"
../source/tot_info.exe  < ../inputs/universe/test47.inc > ../outputs/t271
echo ">>>>>>>>running test 272"
../source/tot_info.exe  < ../inputs/universe/test48.inc > ../outputs/t272
echo ">>>>>>>>running test 273"
../source/tot_info.exe  < ../inputs/universe/test49.inc > ../outputs/t273
echo ">>>>>>>>running test 274"
../source/tot_info.exe  < ../inputs/universe/test50.inc > ../outputs/t274
echo ">>>>>>>>running test 275"
../source/tot_info.exe  < ../inputs/universe/test51.inc > ../outputs/t275
echo ">>>>>>>>running test 276"
../source/tot_info.exe  < ../inputs/universe/test52.inc > ../outputs/t276
echo ">>>>>>>>running test 277"
../source/tot_info.exe  < ../inputs/universe/test53.inc > ../outputs/t277
echo ">>>>>>>>running test 278"
../source/tot_info.exe  < ../inputs/universe/test54.inc > ../outputs/t278
echo ">>>>>>>>running test 279"
../source/tot_info.exe  < ../inputs/universe/test55.inc > ../outputs/t279
echo ">>>>>>>>running test 280"
../source/tot_info.exe  < ../inputs/universe/test56.inc > ../outputs/t280
echo ">>>>>>>>running test 281"
../source/tot_info.exe  < ../inputs/universe/test57.inc > ../outputs/t281
echo ">>>>>>>>running test 282"
../source/tot_info.exe  < ../inputs/universe/test58.inc > ../outputs/t282
echo ">>>>>>>>running test 283"
../source/tot_info.exe  < ../inputs/universe/test59.inc > ../outputs/t283
echo ">>>>>>>>running test 284"
../source/tot_info.exe  < ../inputs/universe/test60.inc > ../outputs/t284
echo ">>>>>>>>running test 285"
../source/tot_info.exe  < ../inputs/universe/test61.inc > ../outputs/t285
echo ">>>>>>>>running test 286"
../source/tot_info.exe  < ../inputs/universe/test62.inc > ../outputs/t286
echo ">>>>>>>>running test 287"
../source/tot_info.exe  < ../inputs/universe/test63.inc > ../outputs/t287
echo ">>>>>>>>running test 288"
../source/tot_info.exe  < ../inputs/universe/test64.inc > ../outputs/t288
echo ">>>>>>>>running test 289"
../source/tot_info.exe  < ../inputs/universe/test65.inc > ../outputs/t289
echo ">>>>>>>>running test 290"
../source/tot_info.exe  < ../inputs/universe/test66.inc > ../outputs/t290
echo ">>>>>>>>running test 291"
../source/tot_info.exe  < ../inputs/universe/test67.inc > ../outputs/t291
echo ">>>>>>>>running test 292"
../source/tot_info.exe  < ../inputs/universe/test68.inc > ../outputs/t292
echo ">>>>>>>>running test 293"
../source/tot_info.exe  < ../inputs/universe/test69.inc > ../outputs/t293
echo ">>>>>>>>running test 294"
../source/tot_info.exe  < ../inputs/universe/test70.inc > ../outputs/t294
echo ">>>>>>>>running test 295"
../source/tot_info.exe  < ../inputs/universe/test71.inc > ../outputs/t295
echo ">>>>>>>>running test 296"
../source/tot_info.exe  < ../inputs/universe/test72.inc > ../outputs/t296
echo ">>>>>>>>running test 297"
../source/tot_info.exe  < ../inputs/universe/test73.inc > ../outputs/t297
echo ">>>>>>>>running test 298"
../source/tot_info.exe  < ../inputs/universe/test74.inc > ../outputs/t298
echo ">>>>>>>>running test 299"
../source/tot_info.exe  < ../inputs/universe/test75.inc > ../outputs/t299
echo ">>>>>>>>running test 300"
../source/tot_info.exe  < ../inputs/universe/test76.inc > ../outputs/t300
echo ">>>>>>>>running test 301"
../source/tot_info.exe  < ../inputs/universe/test77.inc > ../outputs/t301
echo ">>>>>>>>running test 302"
../source/tot_info.exe  < ../inputs/universe/test78.inc > ../outputs/t302
echo ">>>>>>>>running test 303"
../source/tot_info.exe  < ../inputs/universe/test79.inc > ../outputs/t303
echo ">>>>>>>>running test 304"
../source/tot_info.exe  < ../inputs/universe/test80.inc > ../outputs/t304
echo ">>>>>>>>running test 305"
../source/tot_info.exe  < ../inputs/universe/test81.inc > ../outputs/t305
echo ">>>>>>>>running test 306"
../source/tot_info.exe  < ../inputs/universe/test82.inc > ../outputs/t306
echo ">>>>>>>>running test 307"
../source/tot_info.exe  < ../inputs/universe/test83.inc > ../outputs/t307
echo ">>>>>>>>running test 308"
../source/tot_info.exe  < ../inputs/universe/test84.inc > ../outputs/t308
echo ">>>>>>>>running test 309"
../source/tot_info.exe  < ../inputs/universe/test85.inc > ../outputs/t309
echo ">>>>>>>>running test 310"
../source/tot_info.exe  < ../inputs/universe/test86.inc > ../outputs/t310
echo ">>>>>>>>running test 311"
../source/tot_info.exe  < ../inputs/universe/test87.inc > ../outputs/t311
echo ">>>>>>>>running test 312"
../source/tot_info.exe  < ../inputs/universe/test88.inc > ../outputs/t312
echo ">>>>>>>>running test 313"
../source/tot_info.exe  < ../inputs/universe/test89.inc > ../outputs/t313
echo ">>>>>>>>running test 314"
../source/tot_info.exe  < ../inputs/universe/test90.inc > ../outputs/t314
echo ">>>>>>>>running test 315"
../source/tot_info.exe  < ../inputs/universe/test91.inc > ../outputs/t315
echo ">>>>>>>>running test 316"
../source/tot_info.exe  < ../inputs/universe/test92.inc > ../outputs/t316
echo ">>>>>>>>running test 317"
../source/tot_info.exe  < ../inputs/universe/test93.inc > ../outputs/t317
echo ">>>>>>>>running test 318"
../source/tot_info.exe  < ../inputs/universe/test94.inc > ../outputs/t318
echo ">>>>>>>>running test 319"
../source/tot_info.exe  < ../inputs/universe/test95.inc > ../outputs/t319
echo ">>>>>>>>running test 320"
../source/tot_info.exe  < ../inputs/universe/test96.inc > ../outputs/t320
echo ">>>>>>>>running test 321"
../source/tot_info.exe  < ../inputs/universe/test97.inc > ../outputs/t321
echo ">>>>>>>>running test 322"
../source/tot_info.exe  < ../inputs/universe/test98.inc > ../outputs/t322
echo ">>>>>>>>running test 323"
../source/tot_info.exe  < ../inputs/universe/test99.inc > ../outputs/t323
echo ">>>>>>>>running test 324"
../source/tot_info.exe  < ../inputs/universe/test100.inc > ../outputs/t324
echo ">>>>>>>>running test 325"
../source/tot_info.exe  < ../inputs/universe/test101.inc > ../outputs/t325
echo ">>>>>>>>running test 326"
../source/tot_info.exe  < ../inputs/universe/test102.inc > ../outputs/t326
echo ">>>>>>>>running test 327"
../source/tot_info.exe  < ../inputs/universe/test103.inc > ../outputs/t327
echo ">>>>>>>>running test 328"
../source/tot_info.exe  < ../inputs/universe/test104.inc > ../outputs/t328
echo ">>>>>>>>running test 329"
../source/tot_info.exe  < ../inputs/universe/test106.inc > ../outputs/t329
echo ">>>>>>>>running test 330"
../source/tot_info.exe  < ../inputs/universe/test107.inc > ../outputs/t330
echo ">>>>>>>>running test 331"
../source/tot_info.exe  < ../inputs/universe/test108.inc > ../outputs/t331
echo ">>>>>>>>running test 332"
../source/tot_info.exe  < ../inputs/universe/test109.inc > ../outputs/t332
echo ">>>>>>>>running test 333"
../source/tot_info.exe  < ../inputs/universe/test110.inc > ../outputs/t333
echo ">>>>>>>>running test 334"
../source/tot_info.exe  < ../inputs/universe/test111.inc > ../outputs/t334
echo ">>>>>>>>running test 335"
../source/tot_info.exe  < ../inputs/universe/test112.inc > ../outputs/t335
echo ">>>>>>>>running test 336"
../source/tot_info.exe  < ../inputs/universe/test113.inc > ../outputs/t336
echo ">>>>>>>>running test 337"
../source/tot_info.exe  < ../inputs/universe/test114.inc > ../outputs/t337
echo ">>>>>>>>running test 338"
../source/tot_info.exe  < ../inputs/universe/test115.inc > ../outputs/t338
echo ">>>>>>>>running test 339"
../source/tot_info.exe  < ../inputs/universe/test116.inc > ../outputs/t339
echo ">>>>>>>>running test 340"
../source/tot_info.exe  < ../inputs/universe/test117.inc > ../outputs/t340
echo ">>>>>>>>running test 341"
../source/tot_info.exe  < ../inputs/universe/test118.inc > ../outputs/t341
echo ">>>>>>>>running test 342"
../source/tot_info.exe  < ../inputs/universe/test119.inc > ../outputs/t342
echo ">>>>>>>>running test 343"
../source/tot_info.exe  < ../inputs/universe/test120.inc > ../outputs/t343
echo ">>>>>>>>running test 344"
../source/tot_info.exe  < ../inputs/universe/test121.inc > ../outputs/t344
echo ">>>>>>>>running test 345"
../source/tot_info.exe  < ../inputs/universe/test122.inc > ../outputs/t345
echo ">>>>>>>>running test 346"
../source/tot_info.exe  < ../inputs/universe/test123.inc > ../outputs/t346
echo ">>>>>>>>running test 347"
../source/tot_info.exe  < ../inputs/universe/test124.inc > ../outputs/t347
echo ">>>>>>>>running test 348"
../source/tot_info.exe  < ../inputs/universe/test125.inc > ../outputs/t348
echo ">>>>>>>>running test 349"
../source/tot_info.exe  < ../inputs/universe/test126.inc > ../outputs/t349
echo ">>>>>>>>running test 350"
../source/tot_info.exe  < ../inputs/universe/test127.inc > ../outputs/t350
echo ">>>>>>>>running test 351"
../source/tot_info.exe  < ../inputs/universe/test128.inc > ../outputs/t351
echo ">>>>>>>>running test 352"
../source/tot_info.exe  < ../inputs/universe/test129.inc > ../outputs/t352
echo ">>>>>>>>running test 353"
../source/tot_info.exe  < ../inputs/universe/test130.inc > ../outputs/t353
echo ">>>>>>>>running test 354"
../source/tot_info.exe  < ../inputs/universe/test131.inc > ../outputs/t354
echo ">>>>>>>>running test 355"
../source/tot_info.exe  < ../inputs/universe/test132.inc > ../outputs/t355
echo ">>>>>>>>running test 356"
../source/tot_info.exe  < ../inputs/universe/test133.inc > ../outputs/t356
echo ">>>>>>>>running test 357"
../source/tot_info.exe  < ../inputs/universe/test134.inc > ../outputs/t357
echo ">>>>>>>>running test 358"
../source/tot_info.exe  < ../inputs/universe/test135.inc > ../outputs/t358
echo ">>>>>>>>running test 359"
../source/tot_info.exe  < ../inputs/universe/test136.inc > ../outputs/t359
echo ">>>>>>>>running test 360"
../source/tot_info.exe  < ../inputs/universe/test137.inc > ../outputs/t360
echo ">>>>>>>>running test 361"
../source/tot_info.exe  < ../inputs/universe/test138.inc > ../outputs/t361
echo ">>>>>>>>running test 362"
../source/tot_info.exe  < ../inputs/universe/test139.inc > ../outputs/t362
echo ">>>>>>>>running test 363"
../source/tot_info.exe  < ../inputs/universe/test140.inc	 > ../outputs/t363
echo ">>>>>>>>running test 364"
../source/tot_info.exe  < ../inputs/universe/test141.inc > ../outputs/t364
echo ">>>>>>>>running test 365"
../source/tot_info.exe  < ../inputs/universe/test142.inc > ../outputs/t365
echo ">>>>>>>>running test 366"
../source/tot_info.exe  < ../inputs/universe/test143.inc > ../outputs/t366
echo ">>>>>>>>running test 367"
../source/tot_info.exe  < ../inputs/universe/test144.inc > ../outputs/t367
echo ">>>>>>>>running test 368"
../source/tot_info.exe  < ../inputs/universe/test145.inc > ../outputs/t368
echo ">>>>>>>>running test 369"
../source/tot_info.exe  < ../inputs/universe/test146.inc > ../outputs/t369
echo ">>>>>>>>running test 370"
../source/tot_info.exe  < ../inputs/universe/test147.inc > ../outputs/t370
echo ">>>>>>>>running test 371"
../source/tot_info.exe  < ../inputs/universe/test148.inc > ../outputs/t371
echo ">>>>>>>>running test 372"
../source/tot_info.exe  < ../inputs/universe/test149.inc > ../outputs/t372
echo ">>>>>>>>running test 373"
../source/tot_info.exe  < ../inputs/universe/test151.inc > ../outputs/t373
echo ">>>>>>>>running test 374"
../source/tot_info.exe  < ../inputs/universe/test152.inc > ../outputs/t374
echo ">>>>>>>>running test 375"
../source/tot_info.exe  < ../inputs/universe/test153.inc > ../outputs/t375
echo ">>>>>>>>running test 376"
../source/tot_info.exe  < ../inputs/universe/test154.inc > ../outputs/t376
echo ">>>>>>>>running test 377"
../source/tot_info.exe  < ../inputs/universe/test155.inc > ../outputs/t377
echo ">>>>>>>>running test 378"
../source/tot_info.exe  < ../inputs/universe/test156.inc > ../outputs/t378
echo ">>>>>>>>running test 379"
../source/tot_info.exe  < ../inputs/universe/test157.inc > ../outputs/t379
echo ">>>>>>>>running test 380"
../source/tot_info.exe  < ../inputs/universe/test158.inc > ../outputs/t380
echo ">>>>>>>>running test 381"
../source/tot_info.exe  < ../inputs/universe/test159.inc > ../outputs/t381
echo ">>>>>>>>running test 382"
../source/tot_info.exe  < ../inputs/universe/test160.inc > ../outputs/t382
echo ">>>>>>>>running test 383"
../source/tot_info.exe  < ../inputs/universe/test161.inc > ../outputs/t383
echo ">>>>>>>>running test 384"
../source/tot_info.exe  < ../inputs/universe/test162.inc > ../outputs/t384
echo ">>>>>>>>running test 385"
../source/tot_info.exe  < ../inputs/universe/test163.inc > ../outputs/t385
echo ">>>>>>>>running test 386"
../source/tot_info.exe  < ../inputs/universe/test164.inc > ../outputs/t386
echo ">>>>>>>>running test 387"
../source/tot_info.exe  < ../inputs/universe/test165.inc > ../outputs/t387
echo ">>>>>>>>running test 388"
../source/tot_info.exe  < ../inputs/universe/test166.inc > ../outputs/t388
echo ">>>>>>>>running test 389"
../source/tot_info.exe  < ../inputs/universe/test167.inc > ../outputs/t389
echo ">>>>>>>>running test 390"
../source/tot_info.exe  < ../inputs/universe/test168.inc > ../outputs/t390
echo ">>>>>>>>running test 391"
../source/tot_info.exe  < ../inputs/universe/test169.inc > ../outputs/t391
echo ">>>>>>>>running test 392"
../source/tot_info.exe  < ../inputs/universe/test170.inc > ../outputs/t392
echo ">>>>>>>>running test 393"
../source/tot_info.exe  < ../inputs/universe/test171.inc > ../outputs/t393
echo ">>>>>>>>running test 394"
../source/tot_info.exe  < ../inputs/universe/test172.inc > ../outputs/t394
echo ">>>>>>>>running test 395"
../source/tot_info.exe  < ../inputs/universe/test173.inc > ../outputs/t395
echo ">>>>>>>>running test 396"
../source/tot_info.exe  < ../inputs/universe/test174.inc > ../outputs/t396
echo ">>>>>>>>running test 397"
../source/tot_info.exe  < ../inputs/universe/test175.inc > ../outputs/t397
echo ">>>>>>>>running test 398"
../source/tot_info.exe  < ../inputs/universe/test176.inc > ../outputs/t398
echo ">>>>>>>>running test 399"
../source/tot_info.exe  < ../inputs/universe/test177.inc > ../outputs/t399
echo ">>>>>>>>running test 400"
../source/tot_info.exe  < ../inputs/universe/test178.inc > ../outputs/t400
echo ">>>>>>>>running test 401"
../source/tot_info.exe  < ../inputs/universe/test179.inc > ../outputs/t401
echo ">>>>>>>>running test 402"
../source/tot_info.exe  < ../inputs/universe/test180.inc > ../outputs/t402
echo ">>>>>>>>running test 403"
../source/tot_info.exe  < ../inputs/universe/test181.inc > ../outputs/t403
echo ">>>>>>>>running test 404"
../source/tot_info.exe  < ../inputs/universe/test182.inc > ../outputs/t404
echo ">>>>>>>>running test 405"
../source/tot_info.exe  < ../inputs/universe/test183.inc > ../outputs/t405
echo ">>>>>>>>running test 406"
../source/tot_info.exe  < ../inputs/universe/test184.inc > ../outputs/t406
echo ">>>>>>>>running test 407"
../source/tot_info.exe  < ../inputs/universe/test185.inc > ../outputs/t407
echo ">>>>>>>>running test 408"
../source/tot_info.exe  < ../inputs/universe/test186.inc > ../outputs/t408
echo ">>>>>>>>running test 409"
../source/tot_info.exe  < ../inputs/universe/test187.inc > ../outputs/t409
echo ">>>>>>>>running test 410"
../source/tot_info.exe  < ../inputs/universe/test188.inc > ../outputs/t410
echo ">>>>>>>>running test 411"
../source/tot_info.exe  < ../inputs/universe/test189.inc > ../outputs/t411
echo ">>>>>>>>running test 412"
../source/tot_info.exe  < ../inputs/universe/test190.inc > ../outputs/t412
echo ">>>>>>>>running test 413"
../source/tot_info.exe  < ../inputs/universe/test191.inc > ../outputs/t413
echo ">>>>>>>>running test 414"
../source/tot_info.exe  < ../inputs/universe/test192.inc > ../outputs/t414
echo ">>>>>>>>running test 415"
../source/tot_info.exe  < ../inputs/universe/test193.inc > ../outputs/t415
echo ">>>>>>>>running test 416"
../source/tot_info.exe  < ../inputs/universe/test194.inc > ../outputs/t416
echo ">>>>>>>>running test 417"
../source/tot_info.exe  < ../inputs/universe/test195.inc > ../outputs/t417
echo ">>>>>>>>running test 418"
../source/tot_info.exe  < ../inputs/universe/test196.inc > ../outputs/t418
echo ">>>>>>>>running test 419"
../source/tot_info.exe  < ../inputs/universe/test197.inc > ../outputs/t419
echo ">>>>>>>>running test 420"
../source/tot_info.exe  < ../inputs/universe/test198.inc > ../outputs/t420
echo ">>>>>>>>running test 421"
../source/tot_info.exe  < ../inputs/universe/test199.inc > ../outputs/t421
echo ">>>>>>>>running test 422"
../source/tot_info.exe  < ../inputs/universe/test300.inc > ../outputs/t422
echo ">>>>>>>>running test 423"
../source/tot_info.exe  < ../inputs/universe/test301.inc > ../outputs/t423
echo ">>>>>>>>running test 424"
../source/tot_info.exe  < ../inputs/universe/test302.inc > ../outputs/t424
echo ">>>>>>>>running test 425"
../source/tot_info.exe  < ../inputs/universe/test303.inc > ../outputs/t425
echo ">>>>>>>>running test 426"
../source/tot_info.exe  < ../inputs/universe/test304.inc > ../outputs/t426
echo ">>>>>>>>running test 427"
../source/tot_info.exe  < ../inputs/universe/test305.inc > ../outputs/t427
echo ">>>>>>>>running test 428"
../source/tot_info.exe  < ../inputs/universe/test306.inc > ../outputs/t428
echo ">>>>>>>>running test 429"
../source/tot_info.exe  < ../inputs/universe/test307.inc > ../outputs/t429
echo ">>>>>>>>running test 430"
../source/tot_info.exe  < ../inputs/universe/test308.inc > ../outputs/t430
echo ">>>>>>>>running test 431"
../source/tot_info.exe  < ../inputs/universe/test309.inc > ../outputs/t431
echo ">>>>>>>>running test 432"
../source/tot_info.exe  < ../inputs/universe/test310.inc > ../outputs/t432
echo ">>>>>>>>running test 433"
../source/tot_info.exe  < ../inputs/universe/test311.inc > ../outputs/t433
echo ">>>>>>>>running test 434"
../source/tot_info.exe  < ../inputs/universe/test312.inc > ../outputs/t434
echo ">>>>>>>>running test 435"
../source/tot_info.exe  < ../inputs/universe/test313.inc > ../outputs/t435
echo ">>>>>>>>running test 436"
../source/tot_info.exe  < ../inputs/universe/test314.inc > ../outputs/t436
echo ">>>>>>>>running test 437"
../source/tot_info.exe  < ../inputs/universe/test315.inc > ../outputs/t437
echo ">>>>>>>>running test 438"
../source/tot_info.exe  < ../inputs/universe/test316.inc > ../outputs/t438
echo ">>>>>>>>running test 439"
../source/tot_info.exe  < ../inputs/universe/test317.inc > ../outputs/t439
echo ">>>>>>>>running test 440"
../source/tot_info.exe  < ../inputs/universe/test318.inc > ../outputs/t440
echo ">>>>>>>>running test 441"
../source/tot_info.exe  < ../inputs/universe/test319.inc > ../outputs/t441
echo ">>>>>>>>running test 442"
../source/tot_info.exe  < ../inputs/universe/test320.inc > ../outputs/t442
echo ">>>>>>>>running test 443"
../source/tot_info.exe  < ../inputs/universe/test321.inc > ../outputs/t443
echo ">>>>>>>>running test 444"
../source/tot_info.exe  < ../inputs/universe/test322.inc > ../outputs/t444
echo ">>>>>>>>running test 445"
../source/tot_info.exe  < ../inputs/universe/test323.inc > ../outputs/t445
echo ">>>>>>>>running test 446"
../source/tot_info.exe  < ../inputs/universe/test324.inc > ../outputs/t446
echo ">>>>>>>>running test 447"
../source/tot_info.exe  < ../inputs/universe/test325.inc > ../outputs/t447
echo ">>>>>>>>running test 448"
../source/tot_info.exe  < ../inputs/universe/test326.inc > ../outputs/t448
echo ">>>>>>>>running test 449"
../source/tot_info.exe  < ../inputs/universe/test327.inc > ../outputs/t449
echo ">>>>>>>>running test 450"
../source/tot_info.exe  < ../inputs/universe/test328.inc > ../outputs/t450
echo ">>>>>>>>running test 451"
../source/tot_info.exe  < ../inputs/universe/test329.inc > ../outputs/t451
echo ">>>>>>>>running test 452"
../source/tot_info.exe  < ../inputs/universe/test331.inc > ../outputs/t452
echo ">>>>>>>>running test 453"
../source/tot_info.exe  < ../inputs/universe/test332.inc > ../outputs/t453
echo ">>>>>>>>running test 454"
../source/tot_info.exe  < ../inputs/universe/test333.inc > ../outputs/t454
echo ">>>>>>>>running test 455"
../source/tot_info.exe  < ../inputs/universe/test334.inc > ../outputs/t455
echo ">>>>>>>>running test 456"
../source/tot_info.exe  < ../inputs/universe/test335.inc > ../outputs/t456
echo ">>>>>>>>running test 457"
../source/tot_info.exe  < ../inputs/universe/test336.inc > ../outputs/t457
echo ">>>>>>>>running test 458"
../source/tot_info.exe  < ../inputs/universe/test337.inc > ../outputs/t458
echo ">>>>>>>>running test 459"
../source/tot_info.exe  < ../inputs/universe/test338.inc > ../outputs/t459
echo ">>>>>>>>running test 460"
../source/tot_info.exe  < ../inputs/universe/test339.inc > ../outputs/t460
echo ">>>>>>>>running test 461"
../source/tot_info.exe  < ../inputs/universe/test340.inc > ../outputs/t461
echo ">>>>>>>>running test 462"
../source/tot_info.exe  < ../inputs/universe/test341.inc > ../outputs/t462
echo ">>>>>>>>running test 463"
../source/tot_info.exe  < ../inputs/universe/test342.inc > ../outputs/t463
echo ">>>>>>>>running test 464"
../source/tot_info.exe  < ../inputs/universe/test343.inc > ../outputs/t464
echo ">>>>>>>>running test 465"
../source/tot_info.exe  < ../inputs/universe/test344.inc > ../outputs/t465
echo ">>>>>>>>running test 466"
../source/tot_info.exe  < ../inputs/universe/test345.inc > ../outputs/t466
echo ">>>>>>>>running test 467"
../source/tot_info.exe  < ../inputs/universe/test346.inc > ../outputs/t467
echo ">>>>>>>>running test 468"
../source/tot_info.exe  < ../inputs/universe/test347.inc > ../outputs/t468
echo ">>>>>>>>running test 469"
../source/tot_info.exe  < ../inputs/universe/test348.inc > ../outputs/t469
echo ">>>>>>>>running test 470"
../source/tot_info.exe  < ../inputs/universe/test349.inc > ../outputs/t470
echo ">>>>>>>>running test 471"
../source/tot_info.exe  < ../inputs/universe/test350.inc > ../outputs/t471
echo ">>>>>>>>running test 472"
../source/tot_info.exe  < ../inputs/universe/test351.inc > ../outputs/t472
echo ">>>>>>>>running test 473"
../source/tot_info.exe  < ../inputs/universe/test352.inc > ../outputs/t473
echo ">>>>>>>>running test 474"
../source/tot_info.exe  < ../inputs/universe/test353.inc > ../outputs/t474
echo ">>>>>>>>running test 475"
../source/tot_info.exe  < ../inputs/universe/test354.inc > ../outputs/t475
echo ">>>>>>>>running test 476"
../source/tot_info.exe  < ../inputs/universe/test355.inc > ../outputs/t476
echo ">>>>>>>>running test 477"
../source/tot_info.exe  < ../inputs/universe/test356.inc > ../outputs/t477
echo ">>>>>>>>running test 478"
../source/tot_info.exe  < ../inputs/universe/test357.inc > ../outputs/t478
echo ">>>>>>>>running test 479"
../source/tot_info.exe  < ../inputs/universe/test358.inc > ../outputs/t479
echo ">>>>>>>>running test 480"
../source/tot_info.exe  < ../inputs/universe/test359.inc > ../outputs/t480
echo ">>>>>>>>running test 481"
../source/tot_info.exe  < ../inputs/universe/test361.inc > ../outputs/t481
echo ">>>>>>>>running test 482"
../source/tot_info.exe  < ../inputs/universe/test362.inc > ../outputs/t482
echo ">>>>>>>>running test 483"
../source/tot_info.exe  < ../inputs/universe/test363.inc > ../outputs/t483
echo ">>>>>>>>running test 484"
../source/tot_info.exe  < ../inputs/universe/test364.inc > ../outputs/t484
echo ">>>>>>>>running test 485"
../source/tot_info.exe  < ../inputs/universe/test365.inc > ../outputs/t485
echo ">>>>>>>>running test 486"
../source/tot_info.exe  < ../inputs/universe/test366.inc > ../outputs/t486
echo ">>>>>>>>running test 487"
../source/tot_info.exe  < ../inputs/universe/test367.inc > ../outputs/t487
echo ">>>>>>>>running test 488"
../source/tot_info.exe  < ../inputs/universe/test368.inc > ../outputs/t488
echo ">>>>>>>>running test 489"
../source/tot_info.exe  < ../inputs/universe/test369.inc > ../outputs/t489
echo ">>>>>>>>running test 490"
../source/tot_info.exe  < ../inputs/universe/test370.inc > ../outputs/t490
echo ">>>>>>>>running test 491"
../source/tot_info.exe  < ../inputs/universe/test371.inc > ../outputs/t491
echo ">>>>>>>>running test 492"
../source/tot_info.exe  < ../inputs/universe/test372.inc > ../outputs/t492
echo ">>>>>>>>running test 493"
../source/tot_info.exe  < ../inputs/universe/test373.inc > ../outputs/t493
echo ">>>>>>>>running test 494"
../source/tot_info.exe  < ../inputs/universe/test374.inc > ../outputs/t494
echo ">>>>>>>>running test 495"
../source/tot_info.exe  < ../inputs/universe/test375.inc > ../outputs/t495
echo ">>>>>>>>running test 496"
../source/tot_info.exe  < ../inputs/universe/test376.inc > ../outputs/t496
echo ">>>>>>>>running test 497"
../source/tot_info.exe  < ../inputs/universe/test377.inc > ../outputs/t497
echo ">>>>>>>>running test 498"
../source/tot_info.exe  < ../inputs/universe/test378.inc > ../outputs/t498
echo ">>>>>>>>running test 499"
../source/tot_info.exe  < ../inputs/universe/test379.inc > ../outputs/t499
echo ">>>>>>>>running test 500"
../source/tot_info.exe  < ../inputs/universe/test380.inc > ../outputs/t500
echo ">>>>>>>>running test 501"
../source/tot_info.exe  < ../inputs/universe/test381.inc > ../outputs/t501
echo ">>>>>>>>running test 502"
../source/tot_info.exe  < ../inputs/universe/test382.inc > ../outputs/t502
echo ">>>>>>>>running test 503"
../source/tot_info.exe  < ../inputs/universe/test383.inc > ../outputs/t503
echo ">>>>>>>>running test 504"
../source/tot_info.exe  < ../inputs/universe/test384.inc > ../outputs/t504
echo ">>>>>>>>running test 505"
../source/tot_info.exe  < ../inputs/universe/test385.inc > ../outputs/t505
echo ">>>>>>>>running test 506"
../source/tot_info.exe  < ../inputs/universe/test386.inc > ../outputs/t506
echo ">>>>>>>>running test 507"
../source/tot_info.exe  < ../inputs/universe/test387.inc > ../outputs/t507
echo ">>>>>>>>running test 508"
../source/tot_info.exe  < ../inputs/universe/test388.inc > ../outputs/t508
echo ">>>>>>>>running test 509"
../source/tot_info.exe  < ../inputs/universe/test390.inc > ../outputs/t509
echo ">>>>>>>>running test 510"
../source/tot_info.exe  < ../inputs/universe/test391.inc > ../outputs/t510
echo ">>>>>>>>running test 511"
../source/tot_info.exe  < ../inputs/universe/test392.inc > ../outputs/t511
echo ">>>>>>>>running test 512"
../source/tot_info.exe  < ../inputs/universe/test393.inc > ../outputs/t512
echo ">>>>>>>>running test 513"
../source/tot_info.exe  < ../inputs/universe/test394.inc > ../outputs/t513
echo ">>>>>>>>running test 514"
../source/tot_info.exe  < ../inputs/universe/test395.inc > ../outputs/t514
echo ">>>>>>>>running test 515"
../source/tot_info.exe  < ../inputs/universe/test396.inc > ../outputs/t515
echo ">>>>>>>>running test 516"
../source/tot_info.exe  < ../inputs/universe/test397.inc > ../outputs/t516
echo ">>>>>>>>running test 517"
../source/tot_info.exe  < ../inputs/universe/test398.inc > ../outputs/t517
echo ">>>>>>>>running test 518"
../source/tot_info.exe  < ../inputs/universe/test399.inc > ../outputs/t518
echo ">>>>>>>>running test 519"
../source/tot_info.exe  < ../inputs/universe/test400.inc > ../outputs/t519
echo ">>>>>>>>running test 520"
../source/tot_info.exe  < ../inputs/universe/test401.inc > ../outputs/t520
echo ">>>>>>>>running test 521"
../source/tot_info.exe  < ../inputs/universe/test402.inc > ../outputs/t521
echo ">>>>>>>>running test 522"
../source/tot_info.exe  < ../inputs/universe/test403.inc > ../outputs/t522
echo ">>>>>>>>running test 523"
../source/tot_info.exe  < ../inputs/universe/test404.inc > ../outputs/t523
echo ">>>>>>>>running test 524"
../source/tot_info.exe  < ../inputs/universe/test405.inc > ../outputs/t524
echo ">>>>>>>>running test 525"
../source/tot_info.exe  < ../inputs/universe/test406.inc > ../outputs/t525
echo ">>>>>>>>running test 526"
../source/tot_info.exe  < ../inputs/universe/test407.inc > ../outputs/t526
echo ">>>>>>>>running test 527"
../source/tot_info.exe  < ../inputs/universe/test408.inc > ../outputs/t527
echo ">>>>>>>>running test 528"
../source/tot_info.exe  < ../inputs/universe/test409.inc > ../outputs/t528
echo ">>>>>>>>running test 529"
../source/tot_info.exe  < ../inputs/universe/test410.inc > ../outputs/t529
echo ">>>>>>>>running test 530"
../source/tot_info.exe  < ../inputs/universe/tst21.mat > ../outputs/t530
echo ">>>>>>>>running test 531"
../source/tot_info.exe  < ../inputs/universe/tst22.mat > ../outputs/t531
echo ">>>>>>>>running test 532"
../source/tot_info.exe  < ../inputs/universe/tst23.mat > ../outputs/t532
echo ">>>>>>>>running test 533"
../source/tot_info.exe  < ../inputs/universe/tst24.mat > ../outputs/t533
echo ">>>>>>>>running test 534"
../source/tot_info.exe  < ../inputs/universe/tst25.mat > ../outputs/t534
echo ">>>>>>>>running test 535"
../source/tot_info.exe  < ../inputs/universe/tst26.mat > ../outputs/t535
echo ">>>>>>>>running test 536"
../source/tot_info.exe  < ../inputs/universe/tst27.mat > ../outputs/t536
echo ">>>>>>>>running test 537"
../source/tot_info.exe  < ../inputs/universe/tst28.mat > ../outputs/t537
echo ">>>>>>>>running test 538"
../source/tot_info.exe  < ../inputs/universe/tst2question.mat > ../outputs/t538
echo ">>>>>>>>running test 539"
../source/tot_info.exe  < ../inputs/universe/tst2rtangle.mat > ../outputs/t539
echo ">>>>>>>>running test 540"
../source/tot_info.exe  < ../inputs/universe/tst2=.mat > ../outputs/t540
echo ">>>>>>>>running test 541"
../source/tot_info.exe  < ../inputs/universe/tst2:.mat > ../outputs/t541
echo ">>>>>>>>running test 542"
../source/tot_info.exe  < ../inputs/universe/tst2g.mat > ../outputs/t542
echo ">>>>>>>>running test 543"
../source/tot_info.exe  < ../inputs/universe/tst2@.mat > ../outputs/t543
echo ">>>>>>>>running test 544"
../source/tot_info.exe  < ../inputs/universe/tst2A.mat > ../outputs/t544
echo ">>>>>>>>running test 545"
../source/tot_info.exe  < ../inputs/universe/tst2B.mat > ../outputs/t545
echo ">>>>>>>>running test 546"
../source/tot_info.exe  < ../inputs/universe/tst2D.mat > ../outputs/t546
echo ">>>>>>>>running test 547"
../source/tot_info.exe  < ../inputs/universe/tst2E.mat > ../outputs/t547
echo ">>>>>>>>running test 548"
../source/tot_info.exe  < ../inputs/universe/tst2f.mat > ../outputs/t548
echo ">>>>>>>>running test 549"
../source/tot_info.exe  < ../inputs/universe/tst2D.mat > ../outputs/t549
echo ">>>>>>>>running test 550"
../source/tot_info.exe  < ../inputs/universe/jkAAA.mat > ../outputs/t550
echo ">>>>>>>>running test 551"
../source/tot_info.exe  < ../inputs/universe/jkAAB.mat > ../outputs/t551
echo ">>>>>>>>running test 552"
../source/tot_info.exe  < ../inputs/universe/jkAAC.mat > ../outputs/t552
echo ">>>>>>>>running test 553"
../source/tot_info.exe  < ../inputs/universe/jkAAD.mat > ../outputs/t553
echo ">>>>>>>>running test 554"
../source/tot_info.exe  < ../inputs/universe/jkAAE.mat > ../outputs/t554
echo ">>>>>>>>running test 555"
../source/tot_info.exe  < ../inputs/universe/jkAAF.mat > ../outputs/t555
echo ">>>>>>>>running test 556"
../source/tot_info.exe  < ../inputs/universe/jkAAG.mat > ../outputs/t556
echo ">>>>>>>>running test 557"
../source/tot_info.exe  < ../inputs/universe/jkAAH.mat > ../outputs/t557
echo ">>>>>>>>running test 558"
../source/tot_info.exe  < ../inputs/universe/jkAAI.mat > ../outputs/t558
echo ">>>>>>>>running test 559"
../source/tot_info.exe  < ../inputs/universe/jkAAJ.mat > ../outputs/t559
echo ">>>>>>>>running test 560"
../source/tot_info.exe  < ../inputs/universe/jkAFa.mat > ../outputs/t560
echo ">>>>>>>>running test 561"
../source/tot_info.exe  < ../inputs/universe/jkAFb.mat > ../outputs/t561
echo ">>>>>>>>running test 562"
../source/tot_info.exe  < ../inputs/universe/jkAFc.mat > ../outputs/t562
echo ">>>>>>>>running test 563"
../source/tot_info.exe  < ../inputs/universe/jkAFd.mat > ../outputs/t563
echo ">>>>>>>>running test 564"
../source/tot_info.exe  < ../inputs/universe/jkAFe.mat > ../outputs/t564
echo ">>>>>>>>running test 565"
../source/tot_info.exe  < ../inputs/universe/jkAFf.mat > ../outputs/t565
echo ">>>>>>>>running test 566"
../source/tot_info.exe  < ../inputs/universe/jkAFg.mat > ../outputs/t566
echo ">>>>>>>>running test 567"
../source/tot_info.exe  < ../inputs/universe/jkAFh.mat > ../outputs/t567
echo ">>>>>>>>running test 568"
../source/tot_info.exe  < ../inputs/universe/jkAFi.mat > ../outputs/t568
echo ">>>>>>>>running test 569"
../source/tot_info.exe  < ../inputs/universe/jkAEI.mat > ../outputs/t569
echo ">>>>>>>>running test 570"
../source/tot_info.exe  < ../inputs/universe/jkAEJ.mat > ../outputs/t570
echo ">>>>>>>>running test 571"
../source/tot_info.exe  < ../inputs/universe/jkAEK.mat > ../outputs/t571
echo ">>>>>>>>running test 572"
../source/tot_info.exe  < ../inputs/universe/jkAEL.mat > ../outputs/t572
echo ">>>>>>>>running test 573"
../source/tot_info.exe  < ../inputs/universe/jkAEM.mat > ../outputs/t573
echo ">>>>>>>>running test 574"
../source/tot_info.exe  < ../inputs/universe/jkAEN.mat > ../outputs/t574
echo ">>>>>>>>running test 575"
../source/tot_info.exe  < ../inputs/universe/jkAEO.mat > ../outputs/t575
echo ">>>>>>>>running test 576"
../source/tot_info.exe  < ../inputs/universe/jkAEP.mat > ../outputs/t576
echo ">>>>>>>>running test 577"
../source/tot_info.exe  < ../inputs/universe/jkAEQ.mat > ../outputs/t577
echo ">>>>>>>>running test 578"
../source/tot_info.exe  < ../inputs/universe/jkAER.mat > ../outputs/t578
echo ">>>>>>>>running test 579"
../source/tot_info.exe  < ../inputs/universe/jkAES.mat > ../outputs/t579
echo ">>>>>>>>running test 580"
../source/tot_info.exe  < ../inputs/universe/jkAET.mat > ../outputs/t580
echo ">>>>>>>>running test 581"
../source/tot_info.exe  < ../inputs/universe/jkAEU.mat > ../outputs/t581
echo ">>>>>>>>running test 582"
../source/tot_info.exe  < ../inputs/universe/jkAEV.mat > ../outputs/t582
echo ">>>>>>>>running test 583"
../source/tot_info.exe  < ../inputs/universe/jkAEW.mat > ../outputs/t583
echo ">>>>>>>>running test 584"
../source/tot_info.exe  < ../inputs/universe/jkAEX.mat > ../outputs/t584
echo ">>>>>>>>running test 585"
../source/tot_info.exe  < ../inputs/universe/jkAEY.mat > ../outputs/t585
echo ">>>>>>>>running test 586"
../source/tot_info.exe  < ../inputs/universe/jkAEZ.mat > ../outputs/t586
echo ">>>>>>>>running test 587"
../source/tot_info.exe  < ../inputs/universe/jkAE[.mat > ../outputs/t587
echo ">>>>>>>>running test 588"
../source/tot_info.exe  < ../inputs/universe/jkAE].mat > ../outputs/t588
echo ">>>>>>>>running test 589"
../source/tot_info.exe  < ../inputs/universe/jkAE_.mat > ../outputs/t589
echo ">>>>>>>>running test 590"
../source/tot_info.exe  < ../inputs/universe/jkAEa.mat > ../outputs/t590
echo ">>>>>>>>running test 591"
../source/tot_info.exe  < ../inputs/universe/jkAEb.mat > ../outputs/t591
echo ">>>>>>>>running test 592"
../source/tot_info.exe  < ../inputs/universe/jkAEc.mat > ../outputs/t592
echo ">>>>>>>>running test 593"
../source/tot_info.exe  < ../inputs/universe/jkAEd.mat > ../outputs/t593
echo ">>>>>>>>running test 594"
../source/tot_info.exe  < ../inputs/universe/jkAEe.mat > ../outputs/t594
echo ">>>>>>>>running test 595"
../source/tot_info.exe  < ../inputs/universe/jkAEf.mat > ../outputs/t595
echo ">>>>>>>>running test 596"
../source/tot_info.exe  < ../inputs/universe/jkAEg.mat > ../outputs/t596
echo ">>>>>>>>running test 597"
../source/tot_info.exe  < ../inputs/universe/jkAEh.mat > ../outputs/t597
echo ">>>>>>>>running test 598"
../source/tot_info.exe  < ../inputs/universe/jkAEi.mat > ../outputs/t598
echo ">>>>>>>>running test 599"
../source/tot_info.exe  < ../inputs/universe/jkAEj.mat > ../outputs/t599
echo ">>>>>>>>running test 600"
../source/tot_info.exe  < ../inputs/universe/jkAEk.mat > ../outputs/t600
echo ">>>>>>>>running test 601"
../source/tot_info.exe  < ../inputs/universe/jkAEl.mat > ../outputs/t601
echo ">>>>>>>>running test 602"
../source/tot_info.exe  < ../inputs/universe/jkAEm.mat > ../outputs/t602
echo ">>>>>>>>running test 603"
../source/tot_info.exe  < ../inputs/universe/jkAEn.mat > ../outputs/t603
echo ">>>>>>>>running test 604"
../source/tot_info.exe  < ../inputs/universe/jkAEo.mat > ../outputs/t604
echo ">>>>>>>>running test 605"
../source/tot_info.exe  < ../inputs/universe/jkAEp.mat > ../outputs/t605
echo ">>>>>>>>running test 606"
../source/tot_info.exe  < ../inputs/universe/jkAEq.mat > ../outputs/t606
echo ">>>>>>>>running test 607"
../source/tot_info.exe  < ../inputs/universe/jkAEr.mat > ../outputs/t607
echo ">>>>>>>>running test 608"
../source/tot_info.exe  < ../inputs/universe/jkAEs.mat > ../outputs/t608
echo ">>>>>>>>running test 609"
../source/tot_info.exe  < ../inputs/universe/jkAEt.mat > ../outputs/t609
echo ">>>>>>>>running test 610"
../source/tot_info.exe  < ../inputs/universe/jkAEu.mat > ../outputs/t610
echo ">>>>>>>>running test 611"
../source/tot_info.exe  < ../inputs/universe/jkAEv.mat > ../outputs/t611
echo ">>>>>>>>running test 612"
../source/tot_info.exe  < ../inputs/universe/jkAEw.mat > ../outputs/t612
echo ">>>>>>>>running test 613"
../source/tot_info.exe  < ../inputs/universe/jkAEx.mat > ../outputs/t613
echo ">>>>>>>>running test 614"
../source/tot_info.exe  < ../inputs/universe/jkAEy.mat > ../outputs/t614
echo ">>>>>>>>running test 615"
../source/tot_info.exe  < ../inputs/universe/jkAFA.mat > ../outputs/t615
echo ">>>>>>>>running test 616"
../source/tot_info.exe  < ../inputs/universe/jkAFB.mat > ../outputs/t616
echo ">>>>>>>>running test 617"
../source/tot_info.exe  < ../inputs/universe/jkAFC.mat > ../outputs/t617
echo ">>>>>>>>running test 618"
../source/tot_info.exe  < ../inputs/universe/jkAFD.mat > ../outputs/t618
echo ">>>>>>>>running test 619"
../source/tot_info.exe  < ../inputs/universe/jkAFE.mat > ../outputs/t619
echo ">>>>>>>>running test 620"
../source/tot_info.exe  < ../inputs/universe/jkAFF.mat > ../outputs/t620
echo ">>>>>>>>running test 621"
../source/tot_info.exe  < ../inputs/universe/jkAFG.mat > ../outputs/t621
echo ">>>>>>>>running test 622"
../source/tot_info.exe  < ../inputs/universe/jkAFH.mat > ../outputs/t622
echo ">>>>>>>>running test 623"
../source/tot_info.exe  < ../inputs/universe/jkAFI.mat > ../outputs/t623
echo ">>>>>>>>running test 624"
../source/tot_info.exe  < ../inputs/universe/jkAFJ.mat > ../outputs/t624
echo ">>>>>>>>running test 625"
../source/tot_info.exe  < ../inputs/universe/jkAFK.mat > ../outputs/t625
echo ">>>>>>>>running test 626"
../source/tot_info.exe  < ../inputs/universe/jkAFL.mat > ../outputs/t626
echo ">>>>>>>>running test 627"
../source/tot_info.exe  < ../inputs/universe/jkAFM.mat > ../outputs/t627
echo ">>>>>>>>running test 628"
../source/tot_info.exe  < ../inputs/universe/jkAFN.mat > ../outputs/t628
echo ">>>>>>>>running test 629"
../source/tot_info.exe  < ../inputs/universe/jkAFO.mat > ../outputs/t629
echo ">>>>>>>>running test 630"
../source/tot_info.exe  < ../inputs/universe/jkAFP.mat > ../outputs/t630
echo ">>>>>>>>running test 631"
../source/tot_info.exe  < ../inputs/universe/jkAFQ.mat > ../outputs/t631
echo ">>>>>>>>running test 632"
../source/tot_info.exe  < ../inputs/universe/jkAFR.mat > ../outputs/t632
echo ">>>>>>>>running test 633"
../source/tot_info.exe  < ../inputs/universe/jkAFS.mat > ../outputs/t633
echo ">>>>>>>>running test 634"
../source/tot_info.exe  < ../inputs/universe/jkAFT.mat > ../outputs/t634
echo ">>>>>>>>running test 635"
../source/tot_info.exe  < ../inputs/universe/jkAFU.mat > ../outputs/t635
echo ">>>>>>>>running test 636"
../source/tot_info.exe  < ../inputs/universe/jkAFV.mat > ../outputs/t636
echo ">>>>>>>>running test 637"
../source/tot_info.exe  < ../inputs/universe/jkAFW.mat > ../outputs/t637
echo ">>>>>>>>running test 638"
../source/tot_info.exe  < ../inputs/universe/jkAFX.mat > ../outputs/t638
echo ">>>>>>>>running test 639"
../source/tot_info.exe  < ../inputs/universe/jkAFY.mat > ../outputs/t639
echo ">>>>>>>>running test 640"
../source/tot_info.exe  < ../inputs/universe/jkAFZ.mat > ../outputs/t640
echo ">>>>>>>>running test 641"
../source/tot_info.exe  < ../inputs/universe/jkAF[.mat > ../outputs/t641
echo ">>>>>>>>running test 642"
../source/tot_info.exe  < ../inputs/universe/jkAF].mat > ../outputs/t642
echo ">>>>>>>>running test 643"
../source/tot_info.exe  < ../inputs/universe/jkAFhh.mat > ../outputs/t643
echo ">>>>>>>>running test 644"
../source/tot_info.exe  < ../inputs/universe/jkAF_.mat > ../outputs/t644
echo ">>>>>>>>running test 645"
../source/tot_info.exe  < ../inputs/universe/jkACk.mat > ../outputs/t645
echo ">>>>>>>>running test 646"
../source/tot_info.exe  < ../inputs/universe/jkACl.mat > ../outputs/t646
echo ">>>>>>>>running test 647"
../source/tot_info.exe  < ../inputs/universe/jkACm.mat > ../outputs/t647
echo ">>>>>>>>running test 648"
../source/tot_info.exe  < ../inputs/universe/jkACn.mat > ../outputs/t648
echo ">>>>>>>>running test 649"
../source/tot_info.exe  < ../inputs/universe/jkACo.mat > ../outputs/t649
echo ">>>>>>>>running test 650"
../source/tot_info.exe  < ../inputs/universe/jkACp.mat > ../outputs/t650
echo ">>>>>>>>running test 651"
../source/tot_info.exe  < ../inputs/universe/jkACq.mat > ../outputs/t651
echo ">>>>>>>>running test 652"
../source/tot_info.exe  < ../inputs/universe/jkACr.mat > ../outputs/t652
echo ">>>>>>>>running test 653"
../source/tot_info.exe  < ../inputs/universe/jkACs.mat > ../outputs/t653
echo ">>>>>>>>running test 654"
../source/tot_info.exe  < ../inputs/universe/jkACt.mat > ../outputs/t654
echo ">>>>>>>>running test 655"
../source/tot_info.exe  < ../inputs/universe/jkACu.mat > ../outputs/t655
echo ">>>>>>>>running test 656"
../source/tot_info.exe  < ../inputs/universe/jkACv.mat > ../outputs/t656
echo ">>>>>>>>running test 657"
../source/tot_info.exe  < ../inputs/universe/jkACw.mat > ../outputs/t657
echo ">>>>>>>>running test 658"
../source/tot_info.exe  < ../inputs/universe/jkACx.mat > ../outputs/t658
echo ">>>>>>>>running test 659"
../source/tot_info.exe  < ../inputs/universe/jkACy.mat > ../outputs/t659
echo ">>>>>>>>running test 660"
../source/tot_info.exe  < ../inputs/universe/jkADA.mat > ../outputs/t660
echo ">>>>>>>>running test 661"
../source/tot_info.exe  < ../inputs/universe/jkADB.mat > ../outputs/t661
echo ">>>>>>>>running test 662"
../source/tot_info.exe  < ../inputs/universe/jkADC.mat > ../outputs/t662
echo ">>>>>>>>running test 663"
../source/tot_info.exe  < ../inputs/universe/jkADD.mat > ../outputs/t663
echo ">>>>>>>>running test 664"
../source/tot_info.exe  < ../inputs/universe/jkADE.mat > ../outputs/t664
echo ">>>>>>>>running test 665"
../source/tot_info.exe  < ../inputs/universe/jkADF.mat > ../outputs/t665
echo ">>>>>>>>running test 666"
../source/tot_info.exe  < ../inputs/universe/jkADG.mat > ../outputs/t666
echo ">>>>>>>>running test 667"
../source/tot_info.exe  < ../inputs/universe/jkADH.mat > ../outputs/t667
echo ">>>>>>>>running test 668"
../source/tot_info.exe  < ../inputs/universe/jkADI.mat > ../outputs/t668
echo ">>>>>>>>running test 669"
../source/tot_info.exe  < ../inputs/universe/jkADJ.mat > ../outputs/t669
echo ">>>>>>>>running test 670"
../source/tot_info.exe  < ../inputs/universe/jkADK.mat > ../outputs/t670
echo ">>>>>>>>running test 671"
../source/tot_info.exe  < ../inputs/universe/jkADL.mat > ../outputs/t671
echo ">>>>>>>>running test 672"
../source/tot_info.exe  < ../inputs/universe/jkADM.mat > ../outputs/t672
echo ">>>>>>>>running test 673"
../source/tot_info.exe  < ../inputs/universe/jkADN.mat > ../outputs/t673
echo ">>>>>>>>running test 674"
../source/tot_info.exe  < ../inputs/universe/jkADO.mat > ../outputs/t674
echo ">>>>>>>>running test 675"
../source/tot_info.exe  < ../inputs/universe/jkADP.mat > ../outputs/t675
echo ">>>>>>>>running test 676"
../source/tot_info.exe  < ../inputs/universe/jkADQ.mat > ../outputs/t676
echo ">>>>>>>>running test 677"
../source/tot_info.exe  < ../inputs/universe/jkADR.mat > ../outputs/t677
echo ">>>>>>>>running test 678"
../source/tot_info.exe  < ../inputs/universe/jkADS.mat > ../outputs/t678
echo ">>>>>>>>running test 679"
../source/tot_info.exe  < ../inputs/universe/jkADT.mat > ../outputs/t679
echo ">>>>>>>>running test 680"
../source/tot_info.exe  < ../inputs/universe/jkADU.mat > ../outputs/t680
echo ">>>>>>>>running test 681"
../source/tot_info.exe  < ../inputs/universe/jkADV.mat > ../outputs/t681
echo ">>>>>>>>running test 682"
../source/tot_info.exe  < ../inputs/universe/jkADW.mat > ../outputs/t682
echo ">>>>>>>>running test 683"
../source/tot_info.exe  < ../inputs/universe/jkADX.mat > ../outputs/t683
echo ">>>>>>>>running test 684"
../source/tot_info.exe  < ../inputs/universe/jkADY.mat > ../outputs/t684
echo ">>>>>>>>running test 685"
../source/tot_info.exe  < ../inputs/universe/jkADZ.mat > ../outputs/t685
echo ">>>>>>>>running test 686"
../source/tot_info.exe  < ../inputs/universe/jkAD[.mat > ../outputs/t686
echo ">>>>>>>>running test 687"
../source/tot_info.exe  < ../inputs/universe/jkAD].mat > ../outputs/t687
echo ">>>>>>>>running test 688"
../source/tot_info.exe  < ../inputs/universe/jkADhh.mat > ../outputs/t688
echo ">>>>>>>>running test 689"
../source/tot_info.exe  < ../inputs/universe/jkAD_.mat > ../outputs/t689
echo ">>>>>>>>running test 690"
../source/tot_info.exe  < ../inputs/universe/jkADa.mat > ../outputs/t690
echo ">>>>>>>>running test 691"
../source/tot_info.exe  < ../inputs/universe/jkADb.mat > ../outputs/t691
echo ">>>>>>>>running test 692"
../source/tot_info.exe  < ../inputs/universe/jkAFi.mat > ../outputs/t692
echo ">>>>>>>>running test 693"
../source/tot_info.exe  < ../inputs/universe/jkADd.mat > ../outputs/t693
echo ">>>>>>>>running test 694"
../source/tot_info.exe  < ../inputs/universe/jkADe.mat > ../outputs/t694
echo ">>>>>>>>running test 695"
../source/tot_info.exe  < ../inputs/universe/jkADf.mat > ../outputs/t695
echo ">>>>>>>>running test 696"
../source/tot_info.exe  < ../inputs/universe/jkADg.mat > ../outputs/t696
echo ">>>>>>>>running test 697"
../source/tot_info.exe  < ../inputs/universe/jkADh.mat > ../outputs/t697
echo ">>>>>>>>running test 698"
../source/tot_info.exe  < ../inputs/universe/jkADi.mat > ../outputs/t698
echo ">>>>>>>>running test 699"
../source/tot_info.exe  < ../inputs/universe/jkADj.mat > ../outputs/t699
echo ">>>>>>>>running test 700"
../source/tot_info.exe  < ../inputs/universe/jkADk.mat > ../outputs/t700
echo ">>>>>>>>running test 701"
../source/tot_info.exe  < ../inputs/universe/jkADl.mat > ../outputs/t701
echo ">>>>>>>>running test 702"
../source/tot_info.exe  < ../inputs/universe/jkADm.mat > ../outputs/t702
echo ">>>>>>>>running test 703"
../source/tot_info.exe  < ../inputs/universe/jkADn.mat > ../outputs/t703
echo ">>>>>>>>running test 704"
../source/tot_info.exe  < ../inputs/universe/jkADo.mat > ../outputs/t704
echo ">>>>>>>>running test 705"
../source/tot_info.exe  < ../inputs/universe/jkADp.mat > ../outputs/t705
echo ">>>>>>>>running test 706"
../source/tot_info.exe  < ../inputs/universe/jkADq.mat > ../outputs/t706
echo ">>>>>>>>running test 707"
../source/tot_info.exe  < ../inputs/universe/jkADr.mat > ../outputs/t707
echo ">>>>>>>>running test 708"
../source/tot_info.exe  < ../inputs/universe/jkADs.mat > ../outputs/t708
echo ">>>>>>>>running test 709"
../source/tot_info.exe  < ../inputs/universe/jkADt.mat > ../outputs/t709
echo ">>>>>>>>running test 710"
../source/tot_info.exe  < ../inputs/universe/jkADu.mat > ../outputs/t710
echo ">>>>>>>>running test 711"
../source/tot_info.exe  < ../inputs/universe/jkADv.mat > ../outputs/t711
echo ">>>>>>>>running test 712"
../source/tot_info.exe  < ../inputs/universe/jkADw.mat > ../outputs/t712
echo ">>>>>>>>running test 713"
../source/tot_info.exe  < ../inputs/universe/jkADx.mat > ../outputs/t713
echo ">>>>>>>>running test 714"
../source/tot_info.exe  < ../inputs/universe/jkADy.mat > ../outputs/t714
echo ">>>>>>>>running test 715"
../source/tot_info.exe  < ../inputs/universe/jkAEA.mat > ../outputs/t715
echo ">>>>>>>>running test 716"
../source/tot_info.exe  < ../inputs/universe/jkAEB.mat > ../outputs/t716
echo ">>>>>>>>running test 717"
../source/tot_info.exe  < ../inputs/universe/jkAEC.mat > ../outputs/t717
echo ">>>>>>>>running test 718"
../source/tot_info.exe  < ../inputs/universe/jkAED.mat > ../outputs/t718
echo ">>>>>>>>running test 719"
../source/tot_info.exe  < ../inputs/universe/jkAEE.mat > ../outputs/t719
echo ">>>>>>>>running test 720"
../source/tot_info.exe  < ../inputs/universe/jkAEF.mat > ../outputs/t720
echo ">>>>>>>>running test 721"
../source/tot_info.exe  < ../inputs/universe/jkAEG.mat > ../outputs/t721
echo ">>>>>>>>running test 722"
../source/tot_info.exe  < ../inputs/universe/jkAEH.mat > ../outputs/t722
echo ">>>>>>>>running test 723"
../source/tot_info.exe  < ../inputs/universe/jkABT.mat > ../outputs/t723
echo ">>>>>>>>running test 724"
../source/tot_info.exe  < ../inputs/universe/jkABU.mat > ../outputs/t724
echo ">>>>>>>>running test 725"
../source/tot_info.exe  < ../inputs/universe/jkABV.mat > ../outputs/t725
echo ">>>>>>>>running test 726"
../source/tot_info.exe  < ../inputs/universe/jkABW.mat > ../outputs/t726
echo ">>>>>>>>running test 727"
../source/tot_info.exe  < ../inputs/universe/jkABX.mat > ../outputs/t727
echo ">>>>>>>>running test 728"
../source/tot_info.exe  < ../inputs/universe/jkABY.mat > ../outputs/t728
echo ">>>>>>>>running test 729"
../source/tot_info.exe  < ../inputs/universe/jkABZ.mat > ../outputs/t729
echo ">>>>>>>>running test 730"
../source/tot_info.exe  < ../inputs/universe/jkAB[.mat > ../outputs/t730
echo ">>>>>>>>running test 731"
../source/tot_info.exe  < ../inputs/universe/jkAB].mat > ../outputs/t731
echo ">>>>>>>>running test 732"
../source/tot_info.exe  < ../inputs/universe/jkAB_.mat > ../outputs/t732
echo ">>>>>>>>running test 733"
../source/tot_info.exe  < ../inputs/universe/jkABa.mat > ../outputs/t733
echo ">>>>>>>>running test 734"
../source/tot_info.exe  < ../inputs/universe/jkABb.mat > ../outputs/t734
echo ">>>>>>>>running test 735"
../source/tot_info.exe  < ../inputs/universe/jkABc.mat > ../outputs/t735
echo ">>>>>>>>running test 736"
../source/tot_info.exe  < ../inputs/universe/jkABd.mat > ../outputs/t736
echo ">>>>>>>>running test 737"
../source/tot_info.exe  < ../inputs/universe/jkABe.mat > ../outputs/t737
echo ">>>>>>>>running test 738"
../source/tot_info.exe  < ../inputs/universe/jkABf.mat > ../outputs/t738
echo ">>>>>>>>running test 739"
../source/tot_info.exe  < ../inputs/universe/jkABg.mat > ../outputs/t739
echo ">>>>>>>>running test 740"
../source/tot_info.exe  < ../inputs/universe/jkAB_.mat > ../outputs/t740
echo ">>>>>>>>running test 741"
../source/tot_info.exe  < ../inputs/universe/jkABa.mat > ../outputs/t741
echo ">>>>>>>>running test 742"
../source/tot_info.exe  < ../inputs/universe/jkABb.mat > ../outputs/t742
echo ">>>>>>>>running test 743"
../source/tot_info.exe  < ../inputs/universe/jkABc.mat > ../outputs/t743
echo ">>>>>>>>running test 744"
../source/tot_info.exe  < ../inputs/universe/jkABd.mat > ../outputs/t744
echo ">>>>>>>>running test 745"
../source/tot_info.exe  < ../inputs/universe/jkABe.mat > ../outputs/t745
echo ">>>>>>>>running test 746"
../source/tot_info.exe  < ../inputs/universe/jkABf.mat > ../outputs/t746
echo ">>>>>>>>running test 747"
../source/tot_info.exe  < ../inputs/universe/jkABg.mat > ../outputs/t747
echo ">>>>>>>>running test 748"
../source/tot_info.exe  < ../inputs/universe/jkABh.mat > ../outputs/t748
echo ">>>>>>>>running test 749"
../source/tot_info.exe  < ../inputs/universe/jkABi.mat > ../outputs/t749
echo ">>>>>>>>running test 750"
../source/tot_info.exe  < ../inputs/universe/jkABj.mat > ../outputs/t750
echo ">>>>>>>>running test 751"
../source/tot_info.exe  < ../inputs/universe/jkABk.mat > ../outputs/t751
echo ">>>>>>>>running test 752"
../source/tot_info.exe  < ../inputs/universe/jkABl.mat > ../outputs/t752
echo ">>>>>>>>running test 753"
../source/tot_info.exe  < ../inputs/universe/jkABm.mat > ../outputs/t753
echo ">>>>>>>>running test 754"
../source/tot_info.exe  < ../inputs/universe/jkABn.mat > ../outputs/t754
echo ">>>>>>>>running test 755"
../source/tot_info.exe  < ../inputs/universe/jkABo.mat > ../outputs/t755
echo ">>>>>>>>running test 756"
../source/tot_info.exe  < ../inputs/universe/jkABp.mat > ../outputs/t756
echo ">>>>>>>>running test 757"
../source/tot_info.exe  < ../inputs/universe/jkAFi.mat > ../outputs/t757
echo ">>>>>>>>running test 758"
../source/tot_info.exe  < ../inputs/universe/jkACC.mat > ../outputs/t758
echo ">>>>>>>>running test 759"
../source/tot_info.exe  < ../inputs/universe/jkACD.mat > ../outputs/t759
echo ">>>>>>>>running test 760"
../source/tot_info.exe  < ../inputs/universe/jkACE.mat > ../outputs/t760
echo ">>>>>>>>running test 761"
../source/tot_info.exe  < ../inputs/universe/jkACF.mat > ../outputs/t761
echo ">>>>>>>>running test 762"
../source/tot_info.exe  < ../inputs/universe/jkACG.mat > ../outputs/t762
echo ">>>>>>>>running test 763"
../source/tot_info.exe  < ../inputs/universe/jkACH.mat > ../outputs/t763
echo ">>>>>>>>running test 764"
../source/tot_info.exe  < ../inputs/universe/jkACI.mat > ../outputs/t764
echo ">>>>>>>>running test 765"
../source/tot_info.exe  < ../inputs/universe/jkACJ.mat > ../outputs/t765
echo ">>>>>>>>running test 766"
../source/tot_info.exe  < ../inputs/universe/jkACK.mat > ../outputs/t766
echo ">>>>>>>>running test 767"
../source/tot_info.exe  < ../inputs/universe/jkACL.mat > ../outputs/t767
echo ">>>>>>>>running test 768"
../source/tot_info.exe  < ../inputs/universe/jkACM.mat > ../outputs/t768
echo ">>>>>>>>running test 769"
../source/tot_info.exe  < ../inputs/universe/jkACN.mat > ../outputs/t769
echo ">>>>>>>>running test 770"
../source/tot_info.exe  < ../inputs/universe/jkACO.mat > ../outputs/t770
echo ">>>>>>>>running test 771"
../source/tot_info.exe  < ../inputs/universe/jkACP.mat > ../outputs/t771
echo ">>>>>>>>running test 772"
../source/tot_info.exe  < ../inputs/universe/jkACQ.mat > ../outputs/t772
echo ">>>>>>>>running test 773"
../source/tot_info.exe  < ../inputs/universe/jkACR.mat > ../outputs/t773
echo ">>>>>>>>running test 774"
../source/tot_info.exe  < ../inputs/universe/jkACS.mat > ../outputs/t774
echo ">>>>>>>>running test 775"
../source/tot_info.exe  < ../inputs/universe/jkACT.mat > ../outputs/t775
echo ">>>>>>>>running test 776"
../source/tot_info.exe  < ../inputs/universe/jkACU.mat > ../outputs/t776
echo ">>>>>>>>running test 777"
../source/tot_info.exe  < ../inputs/universe/jkACV.mat > ../outputs/t777
echo ">>>>>>>>running test 778"
../source/tot_info.exe  < ../inputs/universe/jkACW.mat > ../outputs/t778
echo ">>>>>>>>running test 779"
../source/tot_info.exe  < ../inputs/universe/jkACX.mat > ../outputs/t779
echo ">>>>>>>>running test 780"
../source/tot_info.exe  < ../inputs/universe/jkACY.mat > ../outputs/t780
echo ">>>>>>>>running test 781"
../source/tot_info.exe  < ../inputs/universe/jkACZ.mat > ../outputs/t781
echo ">>>>>>>>running test 782"
../source/tot_info.exe  < ../inputs/universe/jkAC[.mat > ../outputs/t782
echo ">>>>>>>>running test 783"
../source/tot_info.exe  < ../inputs/universe/jkAC].mat > ../outputs/t783
echo ">>>>>>>>running test 784"
../source/tot_info.exe  < ../inputs/universe/jkAC_.mat > ../outputs/t784
echo ">>>>>>>>running test 785"
../source/tot_info.exe  < ../inputs/universe/jkACa.mat > ../outputs/t785
echo ">>>>>>>>running test 786"
../source/tot_info.exe  < ../inputs/universe/jkACb.mat > ../outputs/t786
echo ">>>>>>>>running test 787"
../source/tot_info.exe  < ../inputs/universe/jkACc.mat > ../outputs/t787
echo ">>>>>>>>running test 788"
../source/tot_info.exe  < ../inputs/universe/jkACd.mat > ../outputs/t788
echo ">>>>>>>>running test 789"
../source/tot_info.exe  < ../inputs/universe/jkACe.mat > ../outputs/t789
echo ">>>>>>>>running test 790"
../source/tot_info.exe  < ../inputs/universe/jkACf.mat > ../outputs/t790
echo ">>>>>>>>running test 791"
../source/tot_info.exe  < ../inputs/universe/jkACg.mat > ../outputs/t791
echo ">>>>>>>>running test 792"
../source/tot_info.exe  < ../inputs/universe/jkACh.mat > ../outputs/t792
echo ">>>>>>>>running test 793"
../source/tot_info.exe  < ../inputs/universe/jkACi.mat > ../outputs/t793
echo ">>>>>>>>running test 794"
../source/tot_info.exe  < ../inputs/universe/jkACj.mat > ../outputs/t794
echo ">>>>>>>>running test 795"
../source/tot_info.exe  < ../inputs/universe/jkAAK.mat > ../outputs/t795
echo ">>>>>>>>running test 796"
../source/tot_info.exe  < ../inputs/universe/jkAAL.mat > ../outputs/t796
echo ">>>>>>>>running test 797"
../source/tot_info.exe  < ../inputs/universe/jkAAM.mat > ../outputs/t797
echo ">>>>>>>>running test 798"
../source/tot_info.exe  < ../inputs/universe/jkAAN.mat > ../outputs/t798
echo ">>>>>>>>running test 799"
../source/tot_info.exe  < ../inputs/universe/jkAAO.mat > ../outputs/t799
echo ">>>>>>>>running test 800"
../source/tot_info.exe  < ../inputs/universe/jkAAP.mat > ../outputs/t800
echo ">>>>>>>>running test 801"
../source/tot_info.exe  < ../inputs/universe/jkAAQ.mat > ../outputs/t801
echo ">>>>>>>>running test 802"
../source/tot_info.exe  < ../inputs/universe/jkAAR.mat > ../outputs/t802
echo ">>>>>>>>running test 803"
../source/tot_info.exe  < ../inputs/universe/jkAAS.mat > ../outputs/t803
echo ">>>>>>>>running test 804"
../source/tot_info.exe  < ../inputs/universe/jkAAT.mat > ../outputs/t804
echo ">>>>>>>>running test 805"
../source/tot_info.exe  < ../inputs/universe/jkAAU.mat > ../outputs/t805
echo ">>>>>>>>running test 806"
../source/tot_info.exe  < ../inputs/universe/jkAAV.mat > ../outputs/t806
echo ">>>>>>>>running test 807"
../source/tot_info.exe  < ../inputs/universe/jkAAW.mat > ../outputs/t807
echo ">>>>>>>>running test 808"
../source/tot_info.exe  < ../inputs/universe/jkAAX.mat > ../outputs/t808
echo ">>>>>>>>running test 809"
../source/tot_info.exe  < ../inputs/universe/jkAAY.mat > ../outputs/t809
echo ">>>>>>>>running test 810"
../source/tot_info.exe  < ../inputs/universe/jkAAZ.mat > ../outputs/t810
echo ">>>>>>>>running test 811"
../source/tot_info.exe  < ../inputs/universe/jkAA[.mat > ../outputs/t811
echo ">>>>>>>>running test 812"
../source/tot_info.exe  < ../inputs/universe/jkAA].mat > ../outputs/t812
echo ">>>>>>>>running test 813"
../source/tot_info.exe  < ../inputs/universe/jkAA_.mat > ../outputs/t813
echo ">>>>>>>>running test 814"
../source/tot_info.exe  < ../inputs/universe/jkAAa.mat > ../outputs/t814
echo ">>>>>>>>running test 815"
../source/tot_info.exe  < ../inputs/universe/jkAAb.mat > ../outputs/t815
echo ">>>>>>>>running test 816"
../source/tot_info.exe  < ../inputs/universe/jkAAc.mat > ../outputs/t816
echo ">>>>>>>>running test 817"
../source/tot_info.exe  < ../inputs/universe/jkAAd.mat > ../outputs/t817
echo ">>>>>>>>running test 818"
../source/tot_info.exe  < ../inputs/universe/jkAAe.mat > ../outputs/t818
echo ">>>>>>>>running test 819"
../source/tot_info.exe  < ../inputs/universe/jkAAf.mat > ../outputs/t819
echo ">>>>>>>>running test 820"
../source/tot_info.exe  < ../inputs/universe/jkAAg.mat > ../outputs/t820
echo ">>>>>>>>running test 821"
../source/tot_info.exe  < ../inputs/universe/jkAAh.mat > ../outputs/t821
echo ">>>>>>>>running test 822"
../source/tot_info.exe  < ../inputs/universe/jkAAi.mat > ../outputs/t822
echo ">>>>>>>>running test 823"
../source/tot_info.exe  < ../inputs/universe/jkAAj.mat > ../outputs/t823
echo ">>>>>>>>running test 824"
../source/tot_info.exe  < ../inputs/universe/jkAAk.mat > ../outputs/t824
echo ">>>>>>>>running test 825"
../source/tot_info.exe  < ../inputs/universe/jkAAl.mat > ../outputs/t825
echo ">>>>>>>>running test 826"
../source/tot_info.exe  < ../inputs/universe/jkAAm.mat > ../outputs/t826
echo ">>>>>>>>running test 827"
../source/tot_info.exe  < ../inputs/universe/jkAAn.mat > ../outputs/t827
echo ">>>>>>>>running test 828"
../source/tot_info.exe  < ../inputs/universe/jkAAo.mat > ../outputs/t828
echo ">>>>>>>>running test 829"
../source/tot_info.exe  < ../inputs/universe/jkAAp.mat > ../outputs/t829
echo ">>>>>>>>running test 830"
../source/tot_info.exe  < ../inputs/universe/jkAAq.mat > ../outputs/t830
echo ">>>>>>>>running test 831"
../source/tot_info.exe  < ../inputs/universe/jkAAr.mat > ../outputs/t831
echo ">>>>>>>>running test 832"
../source/tot_info.exe  < ../inputs/universe/jkAAs.mat > ../outputs/t832
echo ">>>>>>>>running test 833"
../source/tot_info.exe  < ../inputs/universe/jkAAt.mat > ../outputs/t833
echo ">>>>>>>>running test 834"
../source/tot_info.exe  < ../inputs/universe/jkAAu.mat > ../outputs/t834
echo ">>>>>>>>running test 835"
../source/tot_info.exe  < ../inputs/universe/jkAAv.mat > ../outputs/t835
echo ">>>>>>>>running test 836"
../source/tot_info.exe  < ../inputs/universe/jkAAw.mat > ../outputs/t836
echo ">>>>>>>>running test 837"
../source/tot_info.exe  < ../inputs/universe/jkAAx.mat > ../outputs/t837
echo ">>>>>>>>running test 838"
../source/tot_info.exe  < ../inputs/universe/jkAAy.mat > ../outputs/t838
echo ">>>>>>>>running test 839"
../source/tot_info.exe  < ../inputs/universe/jkABA.mat > ../outputs/t839
echo ">>>>>>>>running test 840"
../source/tot_info.exe  < ../inputs/universe/jkABB.mat > ../outputs/t840
echo ">>>>>>>>running test 841"
../source/tot_info.exe  < ../inputs/universe/jkABC.mat > ../outputs/t841
echo ">>>>>>>>running test 842"
../source/tot_info.exe  < ../inputs/universe/jkABD.mat > ../outputs/t842
echo ">>>>>>>>running test 843"
../source/tot_info.exe  < ../inputs/universe/jkABE.mat > ../outputs/t843
echo ">>>>>>>>running test 844"
../source/tot_info.exe  < ../inputs/universe/jkABF.mat > ../outputs/t844
echo ">>>>>>>>running test 845"
../source/tot_info.exe  < ../inputs/universe/jkABG.mat > ../outputs/t845
echo ">>>>>>>>running test 846"
../source/tot_info.exe  < ../inputs/universe/jkABH.mat > ../outputs/t846
echo ">>>>>>>>running test 847"
../source/tot_info.exe  < ../inputs/universe/jkABI.mat > ../outputs/t847
echo ">>>>>>>>running test 848"
../source/tot_info.exe  < ../inputs/universe/jkABJ.mat > ../outputs/t848
echo ">>>>>>>>running test 849"
../source/tot_info.exe  < ../inputs/universe/jkABK.mat > ../outputs/t849
echo ">>>>>>>>running test 850"
../source/tot_info.exe  < ../inputs/universe/jkABL.mat > ../outputs/t850
echo ">>>>>>>>running test 851"
../source/tot_info.exe  < ../inputs/universe/jkABM.mat > ../outputs/t851
echo ">>>>>>>>running test 852"
../source/tot_info.exe  < ../inputs/universe/jkABN.mat > ../outputs/t852
echo ">>>>>>>>running test 853"
../source/tot_info.exe  < ../inputs/universe/jkABO.mat > ../outputs/t853
echo ">>>>>>>>running test 854"
../source/tot_info.exe  < ../inputs/universe/jkABP.mat > ../outputs/t854
echo ">>>>>>>>running test 855"
../source/tot_info.exe  < ../inputs/universe/jkABQ.mat > ../outputs/t855
echo ">>>>>>>>running test 856"
../source/tot_info.exe  < ../inputs/universe/jkABR.mat > ../outputs/t856
echo ">>>>>>>>running test 857"
../source/tot_info.exe  < ../inputs/universe/jkABS.mat > ../outputs/t857
echo ">>>>>>>>running test 858"
../source/tot_info.exe  < ../inputs/universe/new1 > ../outputs/t858
echo ">>>>>>>>running test 859"
../source/tot_info.exe  < ../inputs/universe/new10 > ../outputs/t859
echo ">>>>>>>>running test 860"
../source/tot_info.exe  < ../inputs/universe/new11 > ../outputs/t860
echo ">>>>>>>>running test 861"
../source/tot_info.exe  < ../inputs/universe/new12 > ../outputs/t861
echo ">>>>>>>>running test 862"
../source/tot_info.exe  < ../inputs/universe/new13 > ../outputs/t862
echo ">>>>>>>>running test 863"
../source/tot_info.exe  < ../inputs/universe/new14 > ../outputs/t863
echo ">>>>>>>>running test 864"
../source/tot_info.exe  < ../inputs/universe/new15 > ../outputs/t864
echo ">>>>>>>>running test 865"
../source/tot_info.exe  < ../inputs/universe/new16 > ../outputs/t865
echo ">>>>>>>>running test 866"
../source/tot_info.exe  < ../inputs/universe/new17 > ../outputs/t866
echo ">>>>>>>>running test 867"
../source/tot_info.exe  < ../inputs/universe/new18 > ../outputs/t867
echo ">>>>>>>>running test 868"
../source/tot_info.exe  < ../inputs/universe/new19 > ../outputs/t868
echo ">>>>>>>>running test 869"
../source/tot_info.exe  < ../inputs/universe/new2 > ../outputs/t869
echo ">>>>>>>>running test 870"
../source/tot_info.exe  < ../inputs/universe/new20 > ../outputs/t870
echo ">>>>>>>>running test 871"
../source/tot_info.exe  < ../inputs/universe/new21 > ../outputs/t871
echo ">>>>>>>>running test 872"
../source/tot_info.exe  < ../inputs/universe/new22 > ../outputs/t872
echo ">>>>>>>>running test 873"
../source/tot_info.exe  < ../inputs/universe/new23 > ../outputs/t873
echo ">>>>>>>>running test 874"
../source/tot_info.exe  < ../inputs/universe/new24 > ../outputs/t874
echo ">>>>>>>>running test 875"
../source/tot_info.exe  < ../inputs/universe/new25 > ../outputs/t875
echo ">>>>>>>>running test 876"
../source/tot_info.exe  < ../inputs/universe/new26 > ../outputs/t876
echo ">>>>>>>>running test 877"
../source/tot_info.exe  < ../inputs/universe/new27 > ../outputs/t877
echo ">>>>>>>>running test 878"
../source/tot_info.exe  < ../inputs/universe/new28 > ../outputs/t878
echo ">>>>>>>>running test 879"
../source/tot_info.exe  < ../inputs/universe/new29 > ../outputs/t879
echo ">>>>>>>>running test 880"
../source/tot_info.exe  < ../inputs/universe/new3 > ../outputs/t880
echo ">>>>>>>>running test 881"
../source/tot_info.exe  < ../inputs/universe/new30 > ../outputs/t881
echo ">>>>>>>>running test 882"
../source/tot_info.exe  < ../inputs/universe/new31 > ../outputs/t882
echo ">>>>>>>>running test 883"
../source/tot_info.exe  < ../inputs/universe/new32 > ../outputs/t883
echo ">>>>>>>>running test 884"
../source/tot_info.exe  < ../inputs/universe/new33 > ../outputs/t884
echo ">>>>>>>>running test 885"
../source/tot_info.exe  < ../inputs/universe/new34 > ../outputs/t885
echo ">>>>>>>>running test 886"
../source/tot_info.exe  < ../inputs/universe/new35 > ../outputs/t886
echo ">>>>>>>>running test 887"
../source/tot_info.exe  < ../inputs/universe/new36 > ../outputs/t887
echo ">>>>>>>>running test 888"
../source/tot_info.exe  < ../inputs/universe/new37 > ../outputs/t888
echo ">>>>>>>>running test 889"
../source/tot_info.exe  < ../inputs/universe/new38 > ../outputs/t889
echo ">>>>>>>>running test 890"
../source/tot_info.exe  < ../inputs/universe/new39 > ../outputs/t890
echo ">>>>>>>>running test 891"
../source/tot_info.exe  < ../inputs/universe/new4 > ../outputs/t891
echo ">>>>>>>>running test 892"
../source/tot_info.exe  < ../inputs/universe/new40 > ../outputs/t892
echo ">>>>>>>>running test 893"
../source/tot_info.exe  < ../inputs/universe/new5 > ../outputs/t893
echo ">>>>>>>>running test 894"
../source/tot_info.exe  < ../inputs/universe/new6 > ../outputs/t894
echo ">>>>>>>>running test 895"
../source/tot_info.exe  < ../inputs/universe/new7 > ../outputs/t895
echo ">>>>>>>>running test 896"
../source/tot_info.exe  < ../inputs/universe/new8 > ../outputs/t896
echo ">>>>>>>>running test 897"
../source/tot_info.exe  < ../inputs/universe/new9 > ../outputs/t897
echo ">>>>>>>>running test 898"
../source/tot_info.exe  < ../inputs/universe/ntest12 > ../outputs/t898
echo ">>>>>>>>running test 899"
../source/tot_info.exe  < ../inputs/universe/ntest13 > ../outputs/t899
echo ">>>>>>>>running test 900"
../source/tot_info.exe  < ../inputs/universe/ntest14 > ../outputs/t900
echo ">>>>>>>>running test 901"
../source/tot_info.exe  < ../inputs/universe/ntest15 > ../outputs/t901
echo ">>>>>>>>running test 902"
../source/tot_info.exe  < ../inputs/universe/ntest16 > ../outputs/t902
echo ">>>>>>>>running test 903"
../source/tot_info.exe  < ../inputs/universe/ntest17 > ../outputs/t903
echo ">>>>>>>>running test 904"
../source/tot_info.exe  < ../inputs/universe/ntest18 > ../outputs/t904
echo ">>>>>>>>running test 905"
../source/tot_info.exe  < ../inputs/universe/ntest19 > ../outputs/t905
echo ">>>>>>>>running test 906"
../source/tot_info.exe  < ../inputs/universe/ntest2 > ../outputs/t906
echo ">>>>>>>>running test 907"
../source/tot_info.exe  < ../inputs/universe/ntest20 > ../outputs/t907
echo ">>>>>>>>running test 908"
../source/tot_info.exe  < ../inputs/universe/ntest21 > ../outputs/t908
echo ">>>>>>>>running test 909"
../source/tot_info.exe  < ../inputs/universe/ntest22 > ../outputs/t909
echo ">>>>>>>>running test 910"
../source/tot_info.exe  < ../inputs/universe/ntest23 > ../outputs/t910
echo ">>>>>>>>running test 911"
../source/tot_info.exe  < ../inputs/universe/ntest24 > ../outputs/t911
echo ">>>>>>>>running test 912"
../source/tot_info.exe  < ../inputs/universe/ntest25 > ../outputs/t912
echo ">>>>>>>>running test 913"
../source/tot_info.exe  < ../inputs/universe/ntest26 > ../outputs/t913
echo ">>>>>>>>running test 914"
../source/tot_info.exe  < ../inputs/universe/ntest27 > ../outputs/t914
echo ">>>>>>>>running test 915"
../source/tot_info.exe  < ../inputs/universe/ntest28 > ../outputs/t915
echo ">>>>>>>>running test 916"
../source/tot_info.exe  < ../inputs/universe/ntest29 > ../outputs/t916
echo ">>>>>>>>running test 917"
../source/tot_info.exe  < ../inputs/universe/ntest3 > ../outputs/t917
echo ">>>>>>>>running test 918"
../source/tot_info.exe  < ../inputs/universe/ntest30 > ../outputs/t918
echo ">>>>>>>>running test 919"
../source/tot_info.exe  < ../inputs/universe/ntest31 > ../outputs/t919
echo ">>>>>>>>running test 920"
../source/tot_info.exe  < ../inputs/universe/ntest32 > ../outputs/t920
echo ">>>>>>>>running test 921"
../source/tot_info.exe  < ../inputs/universe/ntest33 > ../outputs/t921
echo ">>>>>>>>running test 922"
../source/tot_info.exe  < ../inputs/universe/ntest35 > ../outputs/t922
echo ">>>>>>>>running test 923"
../source/tot_info.exe  < ../inputs/universe/ntest36 > ../outputs/t923
echo ">>>>>>>>running test 924"
../source/tot_info.exe  < ../inputs/universe/ntest37 > ../outputs/t924
echo ">>>>>>>>running test 925"
../source/tot_info.exe  < ../inputs/universe/ntest38 > ../outputs/t925
echo ">>>>>>>>running test 926"
../source/tot_info.exe  < ../inputs/universe/ntest39 > ../outputs/t926
echo ">>>>>>>>running test 927"
../source/tot_info.exe  < ../inputs/universe/ntest4 > ../outputs/t927
echo ">>>>>>>>running test 928"
../source/tot_info.exe  < ../inputs/universe/ntest40 > ../outputs/t928
echo ">>>>>>>>running test 929"
../source/tot_info.exe  < ../inputs/universe/ntest41 > ../outputs/t929
echo ">>>>>>>>running test 930"
../source/tot_info.exe  < ../inputs/universe/ntest42 > ../outputs/t930
echo ">>>>>>>>running test 931"
../source/tot_info.exe  < ../inputs/universe/ntest43 > ../outputs/t931
echo ">>>>>>>>running test 932"
../source/tot_info.exe  < ../inputs/universe/ntest44 > ../outputs/t932
echo ">>>>>>>>running test 933"
../source/tot_info.exe  < ../inputs/universe/ntest45 > ../outputs/t933
echo ">>>>>>>>running test 934"
../source/tot_info.exe  < ../inputs/universe/ntest46 > ../outputs/t934
echo ">>>>>>>>running test 935"
../source/tot_info.exe  < ../inputs/universe/ntest48 > ../outputs/t935
echo ">>>>>>>>running test 936"
../source/tot_info.exe  < ../inputs/universe/ntest49 > ../outputs/t936
echo ">>>>>>>>running test 937"
../source/tot_info.exe  < ../inputs/universe/ntest5 > ../outputs/t937
echo ">>>>>>>>running test 938"
../source/tot_info.exe  < ../inputs/universe/ntest50 > ../outputs/t938
echo ">>>>>>>>running test 939"
../source/tot_info.exe  < ../inputs/universe/ntest51 > ../outputs/t939
echo ">>>>>>>>running test 940"
../source/tot_info.exe  < ../inputs/universe/ntest52 > ../outputs/t940
echo ">>>>>>>>running test 941"
../source/tot_info.exe  < ../inputs/universe/ntest53 > ../outputs/t941
echo ">>>>>>>>running test 942"
../source/tot_info.exe  < ../inputs/universe/ntest54 > ../outputs/t942
echo ">>>>>>>>running test 943"
../source/tot_info.exe  < ../inputs/universe/ntest55 > ../outputs/t943
echo ">>>>>>>>running test 944"
../source/tot_info.exe  < ../inputs/universe/ntest56 > ../outputs/t944
echo ">>>>>>>>running test 945"
../source/tot_info.exe  < ../inputs/universe/ntest57 > ../outputs/t945
echo ">>>>>>>>running test 946"
../source/tot_info.exe  < ../inputs/universe/ntest6 > ../outputs/t946
echo ">>>>>>>>running test 947"
../source/tot_info.exe  < ../inputs/universe/ntest7 > ../outputs/t947
echo ">>>>>>>>running test 948"
../source/tot_info.exe  < ../inputs/universe/ntest9 > ../outputs/t948
echo ">>>>>>>>running test 949"
../source/tot_info.exe  < ../inputs/universe/bnew1 > ../outputs/t949
echo ">>>>>>>>running test 950"
../source/tot_info.exe  < ../inputs/universe/bnew10 > ../outputs/t950
echo ">>>>>>>>running test 951"
../source/tot_info.exe  < ../inputs/universe/bnew11 > ../outputs/t951
echo ">>>>>>>>running test 952"
../source/tot_info.exe  < ../inputs/universe/bnew12 > ../outputs/t952
echo ">>>>>>>>running test 953"
../source/tot_info.exe  < ../inputs/universe/bnew13 > ../outputs/t953
echo ">>>>>>>>running test 954"
../source/tot_info.exe  < ../inputs/universe/bnew14 > ../outputs/t954
echo ">>>>>>>>running test 955"
../source/tot_info.exe  < ../inputs/universe/bnew15 > ../outputs/t955
echo ">>>>>>>>running test 956"
../source/tot_info.exe  < ../inputs/universe/bnew16 > ../outputs/t956
echo ">>>>>>>>running test 957"
../source/tot_info.exe  < ../inputs/universe/bnew17 > ../outputs/t957
echo ">>>>>>>>running test 958"
../source/tot_info.exe  < ../inputs/universe/bnew18 > ../outputs/t958
echo ">>>>>>>>running test 959"
../source/tot_info.exe  < ../inputs/universe/bnew19 > ../outputs/t959
echo ">>>>>>>>running test 960"
../source/tot_info.exe  < ../inputs/universe/bnew2 > ../outputs/t960
echo ">>>>>>>>running test 961"
../source/tot_info.exe  < ../inputs/universe/bnew20 > ../outputs/t961
echo ">>>>>>>>running test 962"
../source/tot_info.exe  < ../inputs/universe/bnew21 > ../outputs/t962
echo ">>>>>>>>running test 963"
../source/tot_info.exe  < ../inputs/universe/bnew22 > ../outputs/t963
echo ">>>>>>>>running test 964"
../source/tot_info.exe  < ../inputs/universe/bnew23 > ../outputs/t964
echo ">>>>>>>>running test 965"
../source/tot_info.exe  < ../inputs/universe/bnew24 > ../outputs/t965
echo ">>>>>>>>running test 966"
../source/tot_info.exe  < ../inputs/universe/bnew25 > ../outputs/t966
echo ">>>>>>>>running test 967"
../source/tot_info.exe  < ../inputs/universe/bnew26 > ../outputs/t967
echo ">>>>>>>>running test 968"
../source/tot_info.exe  < ../inputs/universe/bnew27 > ../outputs/t968
echo ">>>>>>>>running test 969"
../source/tot_info.exe  < ../inputs/universe/bnew3 > ../outputs/t969
echo ">>>>>>>>running test 970"
../source/tot_info.exe  < ../inputs/universe/bnew4 > ../outputs/t970
echo ">>>>>>>>running test 971"
../source/tot_info.exe  < ../inputs/universe/bnew5 > ../outputs/t971
echo ">>>>>>>>running test 972"
../source/tot_info.exe  < ../inputs/universe/bnew6 > ../outputs/t972
echo ">>>>>>>>running test 973"
../source/tot_info.exe  < ../inputs/universe/bnew7 > ../outputs/t973
echo ">>>>>>>>running test 974"
../source/tot_info.exe  < ../inputs/universe/bnew8 > ../outputs/t974
echo ">>>>>>>>running test 975"
../source/tot_info.exe  < ../inputs/universe/bnew9 > ../outputs/t975
echo ">>>>>>>>running test 976"
../source/tot_info.exe  < ../inputs/universe/bnewt1 > ../outputs/t976
echo ">>>>>>>>running test 977"
../source/tot_info.exe  < ../inputs/universe/bnewt10 > ../outputs/t977
echo ">>>>>>>>running test 978"
../source/tot_info.exe  < ../inputs/universe/bnewt11 > ../outputs/t978
echo ">>>>>>>>running test 979"
../source/tot_info.exe  < ../inputs/universe/bnewt12 > ../outputs/t979
echo ">>>>>>>>running test 980"
../source/tot_info.exe  < ../inputs/universe/bnewt13 > ../outputs/t980
echo ">>>>>>>>running test 981"
../source/tot_info.exe  < ../inputs/universe/bnewt14 > ../outputs/t981
echo ">>>>>>>>running test 982"
../source/tot_info.exe  < ../inputs/universe/bnewt15 > ../outputs/t982
echo ">>>>>>>>running test 983"
../source/tot_info.exe  < ../inputs/universe/bnewt16 > ../outputs/t983
echo ">>>>>>>>running test 984"
../source/tot_info.exe  < ../inputs/universe/bnewt2 > ../outputs/t984
echo ">>>>>>>>running test 985"
../source/tot_info.exe  < ../inputs/universe/bnewt3 > ../outputs/t985
echo ">>>>>>>>running test 986"
../source/tot_info.exe  < ../inputs/universe/bnewt4 > ../outputs/t986
echo ">>>>>>>>running test 987"
../source/tot_info.exe  < ../inputs/universe/bnewt5 > ../outputs/t987
echo ">>>>>>>>running test 988"
../source/tot_info.exe  < ../inputs/universe/bnewt6 > ../outputs/t988
echo ">>>>>>>>running test 989"
../source/tot_info.exe  < ../inputs/universe/bnewt7 > ../outputs/t989
echo ">>>>>>>>running test 990"
../source/tot_info.exe  < ../inputs/universe/bnewt8 > ../outputs/t990
echo ">>>>>>>>running test 991"
../source/tot_info.exe  < ../inputs/universe/bnewt9 > ../outputs/t991
echo ">>>>>>>>running test 992"
../source/tot_info.exe  < ../inputs/universe/12new1 > ../outputs/t992
echo ">>>>>>>>running test 993"
../source/tot_info.exe  < ../inputs/universe/12new10 > ../outputs/t993
echo ">>>>>>>>running test 994"
../source/tot_info.exe  < ../inputs/universe/12new11 > ../outputs/t994
echo ">>>>>>>>running test 995"
../source/tot_info.exe  < ../inputs/universe/12new12 > ../outputs/t995
echo ">>>>>>>>running test 996"
../source/tot_info.exe  < ../inputs/universe/12new13 > ../outputs/t996
echo ">>>>>>>>running test 997"
../source/tot_info.exe  < ../inputs/universe/12new14 > ../outputs/t997
echo ">>>>>>>>running test 998"
../source/tot_info.exe  < ../inputs/universe/12new15 > ../outputs/t998
echo ">>>>>>>>running test 999"
../source/tot_info.exe  < ../inputs/universe/12new16 > ../outputs/t999
echo ">>>>>>>>running test 1000"
../source/tot_info.exe  < ../inputs/universe/12new17 > ../outputs/t1000
echo ">>>>>>>>running test 1001"
../source/tot_info.exe  < ../inputs/universe/12new18 > ../outputs/t1001
echo ">>>>>>>>running test 1002"
../source/tot_info.exe  < ../inputs/universe/12new19 > ../outputs/t1002
echo ">>>>>>>>running test 1003"
../source/tot_info.exe  < ../inputs/universe/12new2 > ../outputs/t1003
echo ">>>>>>>>running test 1004"
../source/tot_info.exe  < ../inputs/universe/12new20 > ../outputs/t1004
echo ">>>>>>>>running test 1005"
../source/tot_info.exe  < ../inputs/universe/12new21 > ../outputs/t1005
echo ">>>>>>>>running test 1006"
../source/tot_info.exe  < ../inputs/universe/12new22 > ../outputs/t1006
echo ">>>>>>>>running test 1007"
../source/tot_info.exe  < ../inputs/universe/12new23 > ../outputs/t1007
echo ">>>>>>>>running test 1008"
../source/tot_info.exe  < ../inputs/universe/12new24 > ../outputs/t1008
echo ">>>>>>>>running test 1009"
../source/tot_info.exe  < ../inputs/universe/12new25 > ../outputs/t1009
echo ">>>>>>>>running test 1010"
../source/tot_info.exe  < ../inputs/universe/12new26 > ../outputs/t1010
echo ">>>>>>>>running test 1011"
../source/tot_info.exe  < ../inputs/universe/12new27 > ../outputs/t1011
echo ">>>>>>>>running test 1012"
../source/tot_info.exe  < ../inputs/universe/12new28 > ../outputs/t1012
echo ">>>>>>>>running test 1013"
../source/tot_info.exe  < ../inputs/universe/12new29 > ../outputs/t1013
echo ">>>>>>>>running test 1014"
../source/tot_info.exe  < ../inputs/universe/12new3 > ../outputs/t1014
echo ">>>>>>>>running test 1015"
../source/tot_info.exe  < ../inputs/universe/12new30 > ../outputs/t1015
echo ">>>>>>>>running test 1016"
../source/tot_info.exe  < ../inputs/universe/12new31 > ../outputs/t1016
echo ">>>>>>>>running test 1017"
../source/tot_info.exe  < ../inputs/universe/12new32 > ../outputs/t1017
echo ">>>>>>>>running test 1018"
../source/tot_info.exe  < ../inputs/universe/12new33 > ../outputs/t1018
echo ">>>>>>>>running test 1019"
../source/tot_info.exe  < ../inputs/universe/12new34 > ../outputs/t1019
echo ">>>>>>>>running test 1020"
../source/tot_info.exe  < ../inputs/universe/12new35 > ../outputs/t1020
echo ">>>>>>>>running test 1021"
../source/tot_info.exe  < ../inputs/universe/12new36 > ../outputs/t1021
echo ">>>>>>>>running test 1022"
../source/tot_info.exe  < ../inputs/universe/12new37 > ../outputs/t1022
echo ">>>>>>>>running test 1023"
../source/tot_info.exe  < ../inputs/universe/12new38 > ../outputs/t1023
echo ">>>>>>>>running test 1024"
../source/tot_info.exe  < ../inputs/universe/12new39 > ../outputs/t1024
echo ">>>>>>>>running test 1025"
../source/tot_info.exe  < ../inputs/universe/12new4 > ../outputs/t1025
echo ">>>>>>>>running test 1026"
../source/tot_info.exe  < ../inputs/universe/12new40 > ../outputs/t1026
echo ">>>>>>>>running test 1027"
../source/tot_info.exe  < ../inputs/universe/12new5 > ../outputs/t1027
echo ">>>>>>>>running test 1028"
../source/tot_info.exe  < ../inputs/universe/12new6 > ../outputs/t1028
echo ">>>>>>>>running test 1029"
../source/tot_info.exe  < ../inputs/universe/12new7 > ../outputs/t1029
echo ">>>>>>>>running test 1030"
../source/tot_info.exe  < ../inputs/universe/12new8 > ../outputs/t1030
echo ">>>>>>>>running test 1031"
../source/tot_info.exe  < ../inputs/universe/12new9 > ../outputs/t1031
echo ">>>>>>>>running test 1032"
../source/tot_info.exe  < ../inputs/universe/12new40 > ../outputs/t1032
echo ">>>>>>>>running test 1033"
../source/tot_info.exe  < ../inputs/universe/12new41 > ../outputs/t1033
echo ">>>>>>>>running test 1034"
../source/tot_info.exe  < ../inputs/universe/12new42 > ../outputs/t1034
echo ">>>>>>>>running test 1035"
../source/tot_info.exe  < ../inputs/universe/12new43 > ../outputs/t1035
echo ">>>>>>>>running test 1036"
../source/tot_info.exe  < ../inputs/universe/12new44 > ../outputs/t1036
echo ">>>>>>>>running test 1037"
../source/tot_info.exe  < ../inputs/universe/12new45 > ../outputs/t1037
echo ">>>>>>>>running test 1038"
../source/tot_info.exe  < ../inputs/universe/12new46 > ../outputs/t1038
echo ">>>>>>>>running test 1039"
../source/tot_info.exe  < ../inputs/universe/12new47 > ../outputs/t1039
echo ">>>>>>>>running test 1040"
../source/tot_info.exe  < ../inputs/universe/12new48 > ../outputs/t1040
echo ">>>>>>>>running test 1041"
../source/tot_info.exe  < ../inputs/universe/12new49 > ../outputs/t1041
echo ">>>>>>>>running test 1042"
../source/tot_info.exe  < ../inputs/universe/12new50 > ../outputs/t1042
echo ">>>>>>>>running test 1043"
../source/tot_info.exe  < ../inputs/universe/12new51 > ../outputs/t1043
echo ">>>>>>>>running test 1044"
../source/tot_info.exe  < ../inputs/universe/12new52 > ../outputs/t1044
echo ">>>>>>>>running test 1045"
../source/tot_info.exe  < ../inputs/universe/12new53 > ../outputs/t1045
echo ">>>>>>>>running test 1046"
../source/tot_info.exe  < ../inputs/universe/12new54 > ../outputs/t1046
echo ">>>>>>>>running test 1047"
../source/tot_info.exe  < ../inputs/universe/12new55 > ../outputs/t1047
echo ">>>>>>>>running test 1048"
../source/tot_info.exe  < ../inputs/universe/12new56 > ../outputs/t1048
echo ">>>>>>>>running test 1049"
../source/tot_info.exe  < ../inputs/universe/12new57 > ../outputs/t1049
echo ">>>>>>>>running test 1050"
../source/tot_info.exe  < ../inputs/universe/12new58 > ../outputs/t1050
echo ">>>>>>>>running test 1051"
../source/tot_info.exe  < ../inputs/universe/12new59 > ../outputs/t1051
echo ">>>>>>>>running test 1052"
../source/tot_info.exe  < ../inputs/universe/12new60 > ../outputs/t1052
