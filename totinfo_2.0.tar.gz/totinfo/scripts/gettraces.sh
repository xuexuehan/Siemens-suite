echo script type: T
echo ">>>>>>>>running test 1"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst88 > ../newoutputs/t1
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/0.tr
echo ">>>>>>>>running test 2"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst34 > ../newoutputs/t2
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/1.tr
echo ">>>>>>>>running test 3"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst16 > ../newoutputs/t3
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/2.tr
echo ">>>>>>>>running test 4"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkADr.mat > ../newoutputs/t4
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/3.tr
echo ">>>>>>>>running test 5"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst6 > ../newoutputs/t5
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/4.tr
echo ">>>>>>>>running test 6"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst13 > ../newoutputs/t6
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/5.tr
echo ">>>>>>>>running test 7"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst108 > ../newoutputs/t7
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/6.tr
echo ">>>>>>>>running test 8"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst17 > ../newoutputs/t8
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/7.tr
echo ">>>>>>>>running test 9"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst29 > ../newoutputs/t9
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/8.tr
echo ">>>>>>>>running test 10"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst89 > ../newoutputs/t10
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/9.tr
echo ">>>>>>>>running test 11"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst8 > ../newoutputs/t11
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/10.tr
echo ">>>>>>>>running test 12"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst9 > ../newoutputs/t12
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/11.tr
echo ">>>>>>>>running test 13"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst55 > ../newoutputs/t13
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/12.tr
echo ">>>>>>>>running test 14"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst76 > ../newoutputs/t14
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/13.tr
echo ">>>>>>>>running test 15"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst109 > ../newoutputs/t15
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/14.tr
echo ">>>>>>>>running test 16"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst10 > ../newoutputs/t16
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/15.tr
echo ">>>>>>>>running test 17"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst15 > ../newoutputs/t17
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/16.tr
echo ">>>>>>>>running test 18"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst19 > ../newoutputs/t18
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/17.tr
echo ">>>>>>>>running test 19"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst90 > ../newoutputs/t19
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/18.tr
echo ">>>>>>>>running test 20"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst20 > ../newoutputs/t20
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/19.tr
echo ">>>>>>>>running test 21"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst56 > ../newoutputs/t21
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/20.tr
echo ">>>>>>>>running test 22"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst24 > ../newoutputs/t22
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/21.tr
echo ">>>>>>>>running test 23"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst3 > ../newoutputs/t23
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/22.tr
echo ">>>>>>>>running test 24"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst25 > ../newoutputs/t24
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/23.tr
echo ">>>>>>>>running test 25"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst50 > ../newoutputs/t25
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/24.tr
echo ">>>>>>>>running test 26"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst87 > ../newoutputs/t26
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/25.tr
echo ">>>>>>>>running test 27"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst91 > ../newoutputs/t27
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/26.tr
echo ">>>>>>>>running test 28"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst107 > ../newoutputs/t28
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/27.tr
echo ">>>>>>>>running test 29"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst27 > ../newoutputs/t29
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/28.tr
echo ">>>>>>>>running test 30"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst77 > ../newoutputs/t30
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/29.tr
echo ">>>>>>>>running test 31"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst98 > ../newoutputs/t31
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/30.tr
echo ">>>>>>>>running test 32"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst18 > ../newoutputs/t32
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/31.tr
echo ">>>>>>>>running test 33"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst28 > ../newoutputs/t33
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/32.tr
echo ">>>>>>>>running test 34"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst7 > ../newoutputs/t34
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/33.tr
echo ">>>>>>>>running test 35"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst30 > ../newoutputs/t35
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/34.tr
echo ">>>>>>>>running test 36"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst107 > ../newoutputs/t36
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/35.tr
echo ">>>>>>>>running test 37"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst32 > ../newoutputs/t37
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/36.tr
echo ">>>>>>>>running test 38"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst33 > ../newoutputs/t38
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/37.tr
echo ">>>>>>>>running test 39"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst2 > ../newoutputs/t39
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/38.tr
echo ">>>>>>>>running test 40"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst5 > ../newoutputs/t40
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/39.tr
echo ">>>>>>>>running test 41"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst92 > ../newoutputs/t41
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/40.tr
echo ">>>>>>>>running test 42"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst97 > ../newoutputs/t42
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/41.tr
echo ">>>>>>>>running test 43"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst31 > ../newoutputs/t43
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/42.tr
echo ">>>>>>>>running test 44"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst35 > ../newoutputs/t44
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/43.tr
echo ">>>>>>>>running test 45"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst21 > ../newoutputs/t45
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/44.tr
echo ">>>>>>>>running test 46"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst39 > ../newoutputs/t46
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/45.tr
echo ">>>>>>>>running test 47"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst12 > ../newoutputs/t47
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/46.tr
echo ">>>>>>>>running test 48"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst86 > ../newoutputs/t48
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/47.tr
echo ">>>>>>>>running test 49"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst106 > ../newoutputs/t49
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/48.tr
echo ">>>>>>>>running test 50"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst41 > ../newoutputs/t50
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/49.tr
echo ">>>>>>>>running test 51"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst43 > ../newoutputs/t51
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/50.tr
echo ">>>>>>>>running test 52"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst23 > ../newoutputs/t52
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/51.tr
echo ">>>>>>>>running test 53"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst115 > ../newoutputs/t53
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/52.tr
echo ">>>>>>>>running test 54"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst44 > ../newoutputs/t54
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/53.tr
echo ">>>>>>>>running test 55"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst68 > ../newoutputs/t55
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/54.tr
echo ">>>>>>>>running test 56"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst45 > ../newoutputs/t56
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/55.tr
echo ">>>>>>>>running test 57"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst4 > ../newoutputs/t57
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/56.tr
echo ">>>>>>>>running test 58"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst116 > ../newoutputs/t58
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/57.tr
echo ">>>>>>>>running test 59"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst85 > ../newoutputs/t59
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/58.tr
echo ">>>>>>>>running test 60"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst46 > ../newoutputs/t60
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/59.tr
echo ">>>>>>>>running test 61"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst47 > ../newoutputs/t61
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/60.tr
echo ">>>>>>>>running test 62"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst96 > ../newoutputs/t62
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/61.tr
echo ">>>>>>>>running test 63"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst73 > ../newoutputs/t63
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/62.tr
echo ">>>>>>>>running test 64"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst48 > ../newoutputs/t64
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/63.tr
echo ">>>>>>>>running test 65"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst101 > ../newoutputs/t65
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/64.tr
echo ">>>>>>>>running test 66"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst64 > ../newoutputs/t66
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/65.tr
echo ">>>>>>>>running test 67"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst84 > ../newoutputs/t67
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/66.tr
echo ">>>>>>>>running test 68"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst49 > ../newoutputs/t68
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/67.tr
echo ">>>>>>>>running test 69"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst95 > ../newoutputs/t69
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/68.tr
echo ">>>>>>>>running test 70"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst14 > ../newoutputs/t70
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/69.tr
echo ">>>>>>>>running test 71"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst51 > ../newoutputs/t71
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/70.tr
echo ">>>>>>>>running test 72"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst115 > ../newoutputs/t72
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/71.tr
echo ">>>>>>>>running test 73"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst72 > ../newoutputs/t73
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/72.tr
echo ">>>>>>>>running test 74"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst60 > ../newoutputs/t74
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/73.tr
echo ">>>>>>>>running test 75"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst83 > ../newoutputs/t75
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/74.tr
echo ">>>>>>>>running test 76"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst38 > ../newoutputs/t76
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/75.tr
echo ">>>>>>>>running test 77"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst52 > ../newoutputs/t77
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/76.tr
echo ">>>>>>>>running test 78"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst95 > ../newoutputs/t78
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/77.tr
echo ">>>>>>>>running test 79"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst82 > ../newoutputs/t79
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/78.tr
echo ">>>>>>>>running test 80"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst114 > ../newoutputs/t80
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/79.tr
echo ">>>>>>>>running test 81"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst75 > ../newoutputs/t81
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/80.tr
echo ">>>>>>>>running test 82"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst36 > ../newoutputs/t82
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/81.tr
echo ">>>>>>>>running test 83"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst54 > ../newoutputs/t83
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/82.tr
echo ">>>>>>>>running test 84"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst57 > ../newoutputs/t84
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/83.tr
echo ">>>>>>>>running test 85"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst79 > ../newoutputs/t85
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/84.tr
echo ">>>>>>>>running test 86"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst58 > ../newoutputs/t86
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/85.tr
echo ">>>>>>>>running test 87"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst94 > ../newoutputs/t87
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/86.tr
echo ">>>>>>>>running test 88"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst59 > ../newoutputs/t88
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/87.tr
echo ">>>>>>>>running test 89"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst11 > ../newoutputs/t89
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/88.tr
echo ">>>>>>>>running test 90"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst116 > ../newoutputs/t90
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/89.tr
echo ">>>>>>>>running test 91"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst40 > ../newoutputs/t91
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/90.tr
echo ">>>>>>>>running test 92"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst93 > ../newoutputs/t92
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/91.tr
echo ">>>>>>>>running test 93"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst61 > ../newoutputs/t93
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/92.tr
echo ">>>>>>>>running test 94"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst22 > ../newoutputs/t94
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/93.tr
echo ">>>>>>>>running test 95"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst42 > ../newoutputs/t95
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/94.tr
echo ">>>>>>>>running test 96"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst62 > ../newoutputs/t96
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/95.tr
echo ">>>>>>>>running test 97"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst104 > ../newoutputs/t97
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/96.tr
echo ">>>>>>>>running test 98"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst37 > ../newoutputs/t98
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/97.tr
echo ">>>>>>>>running test 99"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst81 > ../newoutputs/t99
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/98.tr
echo ">>>>>>>>running test 100"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst63 > ../newoutputs/t100
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/99.tr
echo ">>>>>>>>running test 101"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst113 > ../newoutputs/t101
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/100.tr
echo ">>>>>>>>running test 102"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst112 > ../newoutputs/t102
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/101.tr
echo ">>>>>>>>running test 103"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst26 > ../newoutputs/t103
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/102.tr
echo ">>>>>>>>running test 104"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst65 > ../newoutputs/t104
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/103.tr
echo ">>>>>>>>running test 105"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst71 > ../newoutputs/t105
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/104.tr
echo ">>>>>>>>running test 106"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst111 > ../newoutputs/t106
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/105.tr
echo ">>>>>>>>running test 107"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst74 > ../newoutputs/t107
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/106.tr
echo ">>>>>>>>running test 108"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst102 > ../newoutputs/t108
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/107.tr
echo ">>>>>>>>running test 109"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst66 > ../newoutputs/t109
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/108.tr
echo ">>>>>>>>running test 110"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst117 > ../newoutputs/t110
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/109.tr
echo ">>>>>>>>running test 111"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst67 > ../newoutputs/t111
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/110.tr
echo ">>>>>>>>running test 112"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst69 > ../newoutputs/t112
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/111.tr
echo ">>>>>>>>running test 113"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst70 > ../newoutputs/t113
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/112.tr
echo ">>>>>>>>running test 114"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst1 > ../newoutputs/t114
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/113.tr
echo ">>>>>>>>running test 115"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst103 > ../newoutputs/t115
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/114.tr
echo ">>>>>>>>running test 116"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst80 > ../newoutputs/t116
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/115.tr
echo ">>>>>>>>running test 117"
../source/tot_info.c.inst.exe  < ../inputs/universe/test3 > ../newoutputs/t117
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/116.tr
echo ">>>>>>>>running test 118"
../source/tot_info.c.inst.exe  < ../inputs/universe/test5 > ../newoutputs/t118
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/117.tr
echo ">>>>>>>>running test 119"
../source/tot_info.c.inst.exe  < ../inputs/universe/test32 > ../newoutputs/t119
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/118.tr
echo ">>>>>>>>running test 120"
../source/tot_info.c.inst.exe  < ../inputs/universe/test7 > ../newoutputs/t120
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/119.tr
echo ">>>>>>>>running test 121"
../source/tot_info.c.inst.exe  < ../inputs/universe/test8 > ../newoutputs/t121
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/120.tr
echo ">>>>>>>>running test 122"
../source/tot_info.c.inst.exe  < ../inputs/universe/test9 > ../newoutputs/t122
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/121.tr
echo ">>>>>>>>running test 123"
../source/tot_info.c.inst.exe  < ../inputs/universe/test10 > ../newoutputs/t123
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/122.tr
echo ">>>>>>>>running test 124"
../source/tot_info.c.inst.exe  < ../inputs/universe/test19 > ../newoutputs/t124
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/123.tr
echo ">>>>>>>>running test 125"
../source/tot_info.c.inst.exe  < ../inputs/universe/test31 > ../newoutputs/t125
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/124.tr
echo ">>>>>>>>running test 126"
../source/tot_info.c.inst.exe  < ../inputs/universe/test1 > ../newoutputs/t126
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/125.tr
echo ">>>>>>>>running test 127"
../source/tot_info.c.inst.exe  < ../inputs/universe/test4 > ../newoutputs/t127
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/126.tr
echo ">>>>>>>>running test 128"
../source/tot_info.c.inst.exe  < ../inputs/universe/test39 > ../newoutputs/t128
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/127.tr
echo ">>>>>>>>running test 129"
../source/tot_info.c.inst.exe  < ../inputs/universe/test11 > ../newoutputs/t129
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/128.tr
echo ">>>>>>>>running test 130"
../source/tot_info.c.inst.exe  < ../inputs/universe/test30 > ../newoutputs/t130
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/129.tr
echo ">>>>>>>>running test 131"
../source/tot_info.c.inst.exe  < ../inputs/universe/test14 > ../newoutputs/t131
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/130.tr
echo ">>>>>>>>running test 132"
../source/tot_info.c.inst.exe  < ../inputs/universe/test13 > ../newoutputs/t132
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/131.tr
echo ">>>>>>>>running test 133"
../source/tot_info.c.inst.exe  < ../inputs/universe/test15 > ../newoutputs/t133
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/132.tr
echo ">>>>>>>>running test 134"
../source/tot_info.c.inst.exe  < ../inputs/universe/test16 > ../newoutputs/t134
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/133.tr
echo ">>>>>>>>running test 135"
../source/tot_info.c.inst.exe  < ../inputs/universe/test17 > ../newoutputs/t135
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/134.tr
echo ">>>>>>>>running test 136"
../source/tot_info.c.inst.exe  < ../inputs/universe/test6 > ../newoutputs/t136
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/135.tr
echo ">>>>>>>>running test 137"
../source/tot_info.c.inst.exe  < ../inputs/universe/test33 > ../newoutputs/t137
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/136.tr
echo ">>>>>>>>running test 138"
../source/tot_info.c.inst.exe  < ../inputs/universe/test34 > ../newoutputs/t138
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/137.tr
echo ">>>>>>>>running test 139"
../source/tot_info.c.inst.exe  < ../inputs/universe/test35 > ../newoutputs/t139
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/138.tr
echo ">>>>>>>>running test 140"
../source/tot_info.c.inst.exe  < ../inputs/universe/test36 > ../newoutputs/t140
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/139.tr
echo ">>>>>>>>running test 141"
../source/tot_info.c.inst.exe  < ../inputs/universe/test18 > ../newoutputs/t141
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/140.tr
echo ">>>>>>>>running test 142"
../source/tot_info.c.inst.exe  < ../inputs/universe/test37 > ../newoutputs/t142
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/141.tr
echo ">>>>>>>>running test 143"
../source/tot_info.c.inst.exe  < ../inputs/universe/test40 > ../newoutputs/t143
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/142.tr
echo ">>>>>>>>running test 144"
../source/tot_info.c.inst.exe  < ../inputs/universe/test38 > ../newoutputs/t144
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/143.tr
echo ">>>>>>>>running test 145"
../source/tot_info.c.inst.exe  < ../inputs/universe/tstt1.mat > ../newoutputs/t145
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/144.tr
echo ">>>>>>>>running test 146"
../source/tot_info.c.inst.exe  < ../inputs/universe/jk2AAZ.mat > ../newoutputs/t146
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/145.tr
echo ">>>>>>>>running test 147"
../source/tot_info.c.inst.exe  < ../inputs/universe/jk2ABS.mat > ../newoutputs/t147
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/146.tr
echo ">>>>>>>>running test 148"
../source/tot_info.c.inst.exe  < ../inputs/universe/jk2ABk.mat > ../newoutputs/t148
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/147.tr
echo ">>>>>>>>running test 149"
../source/tot_info.c.inst.exe  < ../inputs/universe/jk1AA_.mat > ../newoutputs/t149
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/148.tr
echo ">>>>>>>>running test 150"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst29.mat > ../newoutputs/t150
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/149.tr
echo ">>>>>>>>running test 151"
../source/tot_info.c.inst.exe  < ../inputs/universe/jk1AAS.mat > ../newoutputs/t151
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/150.tr
echo ">>>>>>>>running test 152"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAAY.mat > ../newoutputs/t152
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/151.tr
echo ">>>>>>>>running test 153"
../source/tot_info.c.inst.exe  < ../inputs/universe/jk2AAy.mat > ../newoutputs/t153
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/152.tr
echo ">>>>>>>>running test 154"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAAQ.mat > ../newoutputs/t154
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/153.tr
echo ">>>>>>>>running test 155"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst21.mat > ../newoutputs/t155
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/154.tr
echo ">>>>>>>>running test 156"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAAZ.mat > ../newoutputs/t156
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/155.tr
echo ">>>>>>>>running test 157"
../source/tot_info.c.inst.exe  < ../inputs/universe/jk2ABq.mat > ../newoutputs/t157
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/156.tr
echo ">>>>>>>>running test 158"
../source/tot_info.c.inst.exe  < ../inputs/universe/jk1ABq.mat > ../newoutputs/t158
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/157.tr
echo ">>>>>>>>running test 159"
../source/tot_info.c.inst.exe  < ../inputs/universe/jk2AAX.mat > ../newoutputs/t159
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/158.tr
echo ">>>>>>>>running test 160"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkADr.mat > ../newoutputs/t160
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/159.tr
echo ">>>>>>>>running test 161"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAFi.mat > ../newoutputs/t161
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/160.tr
echo ">>>>>>>>running test 162"
../source/tot_info.c.inst.exe  < ../inputs/universe/jk2AAS.mat > ../newoutputs/t162
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/161.tr
echo ">>>>>>>>running test 163"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst2f.mat > ../newoutputs/t163
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/162.tr
echo ">>>>>>>>running test 164"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst23.mat > ../newoutputs/t164
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/163.tr
echo ">>>>>>>>running test 165"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst2E.mat > ../newoutputs/t165
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/164.tr
echo ">>>>>>>>running test 166"
../source/tot_info.c.inst.exe  < ../inputs/universe/test72 > ../newoutputs/t166
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/165.tr
echo ">>>>>>>>running test 167"
../source/tot_info.c.inst.exe  < ../inputs/universe/test77 > ../newoutputs/t167
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/166.tr
echo ">>>>>>>>running test 168"
../source/tot_info.c.inst.exe  < ../inputs/universe/test80 > ../newoutputs/t168
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/167.tr
echo ">>>>>>>>running test 169"
../source/tot_info.c.inst.exe  < ../inputs/universe/test51 > ../newoutputs/t169
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/168.tr
echo ">>>>>>>>running test 170"
../source/tot_info.c.inst.exe  < ../inputs/universe/test52 > ../newoutputs/t170
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/169.tr
echo ">>>>>>>>running test 171"
../source/tot_info.c.inst.exe  < ../inputs/universe/test53 > ../newoutputs/t171
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/170.tr
echo ">>>>>>>>running test 172"
../source/tot_info.c.inst.exe  < ../inputs/universe/test54 > ../newoutputs/t172
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/171.tr
echo ">>>>>>>>running test 173"
../source/tot_info.c.inst.exe  < ../inputs/universe/test56 > ../newoutputs/t173
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/172.tr
echo ">>>>>>>>running test 174"
../source/tot_info.c.inst.exe  < ../inputs/universe/test57 > ../newoutputs/t174
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/173.tr
echo ">>>>>>>>running test 175"
../source/tot_info.c.inst.exe  < ../inputs/universe/test60 > ../newoutputs/t175
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/174.tr
echo ">>>>>>>>running test 176"
../source/tot_info.c.inst.exe  < ../inputs/universe/test42 > ../newoutputs/t176
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/175.tr
echo ">>>>>>>>running test 177"
../source/tot_info.c.inst.exe  < ../inputs/universe/test75 > ../newoutputs/t177
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/176.tr
echo ">>>>>>>>running test 178"
../source/tot_info.c.inst.exe  < ../inputs/universe/test73 > ../newoutputs/t178
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/177.tr
echo ">>>>>>>>running test 179"
../source/tot_info.c.inst.exe  < ../inputs/universe/test99 > ../newoutputs/t179
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/178.tr
echo ">>>>>>>>running test 180"
../source/tot_info.c.inst.exe  < ../inputs/universe/test43 > ../newoutputs/t180
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/179.tr
echo ">>>>>>>>running test 181"
../source/tot_info.c.inst.exe  < ../inputs/universe/test90 > ../newoutputs/t181
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/180.tr
echo ">>>>>>>>running test 182"
../source/tot_info.c.inst.exe  < ../inputs/universe/test45 > ../newoutputs/t182
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/181.tr
echo ">>>>>>>>running test 183"
../source/tot_info.c.inst.exe  < ../inputs/universe/test46 > ../newoutputs/t183
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/182.tr
echo ">>>>>>>>running test 184"
../source/tot_info.c.inst.exe  < ../inputs/universe/test78 > ../newoutputs/t184
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/183.tr
echo ">>>>>>>>running test 185"
../source/tot_info.c.inst.exe  < ../inputs/universe/test83 > ../newoutputs/t185
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/184.tr
echo ">>>>>>>>running test 186"
../source/tot_info.c.inst.exe  < ../inputs/universe/test59 > ../newoutputs/t186
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/185.tr
echo ">>>>>>>>running test 187"
../source/tot_info.c.inst.exe  < ../inputs/universe/test49 > ../newoutputs/t187
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/186.tr
echo ">>>>>>>>running test 188"
../source/tot_info.c.inst.exe  < ../inputs/universe/test50 > ../newoutputs/t188
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/187.tr
echo ">>>>>>>>running test 189"
../source/tot_info.c.inst.exe  < ../inputs/universe/test61 > ../newoutputs/t189
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/188.tr
echo ">>>>>>>>running test 190"
../source/tot_info.c.inst.exe  < ../inputs/universe/test63 > ../newoutputs/t190
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/189.tr
echo ">>>>>>>>running test 191"
../source/tot_info.c.inst.exe  < ../inputs/universe/test74 > ../newoutputs/t191
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/190.tr
echo ">>>>>>>>running test 192"
../source/tot_info.c.inst.exe  < ../inputs/universe/test64 > ../newoutputs/t192
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/191.tr
echo ">>>>>>>>running test 193"
../source/tot_info.c.inst.exe  < ../inputs/universe/test79 > ../newoutputs/t193
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/192.tr
echo ">>>>>>>>running test 194"
../source/tot_info.c.inst.exe  < ../inputs/universe/test87 > ../newoutputs/t194
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/193.tr
echo ">>>>>>>>running test 195"
../source/tot_info.c.inst.exe  < ../inputs/universe/test66 > ../newoutputs/t195
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/194.tr
echo ">>>>>>>>running test 196"
../source/tot_info.c.inst.exe  < ../inputs/universe/test67 > ../newoutputs/t196
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/195.tr
echo ">>>>>>>>running test 197"
../source/tot_info.c.inst.exe  < ../inputs/universe/test48 > ../newoutputs/t197
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/196.tr
echo ">>>>>>>>running test 198"
../source/tot_info.c.inst.exe  < ../inputs/universe/test100 > ../newoutputs/t198
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/197.tr
echo ">>>>>>>>running test 199"
../source/tot_info.c.inst.exe  < ../inputs/universe/test92 > ../newoutputs/t199
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/198.tr
echo ">>>>>>>>running test 200"
../source/tot_info.c.inst.exe  < ../inputs/universe/test68 > ../newoutputs/t200
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/199.tr
echo ">>>>>>>>running test 201"
../source/tot_info.c.inst.exe  < ../inputs/universe/test76 > ../newoutputs/t201
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/200.tr
echo ">>>>>>>>running test 202"
../source/tot_info.c.inst.exe  < ../inputs/universe/test69 > ../newoutputs/t202
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/201.tr
echo ">>>>>>>>running test 203"
../source/tot_info.c.inst.exe  < ../inputs/universe/test44 > ../newoutputs/t203
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/202.tr
echo ">>>>>>>>running test 204"
../source/tot_info.c.inst.exe  < ../inputs/universe/test47 > ../newoutputs/t204
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/203.tr
echo ">>>>>>>>running test 205"
../source/tot_info.c.inst.exe  < ../inputs/universe/test81 > ../newoutputs/t205
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/204.tr
echo ">>>>>>>>running test 206"
../source/tot_info.c.inst.exe  < ../inputs/universe/test84 > ../newoutputs/t206
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/205.tr
echo ">>>>>>>>running test 207"
../source/tot_info.c.inst.exe  < ../inputs/universe/test98 > ../newoutputs/t207
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/206.tr
echo ">>>>>>>>running test 208"
../source/tot_info.c.inst.exe  < ../inputs/universe/test58 > ../newoutputs/t208
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/207.tr
echo ">>>>>>>>running test 209"
../source/tot_info.c.inst.exe  < ../inputs/universe/test88 > ../newoutputs/t209
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/208.tr
echo ">>>>>>>>running test 210"
../source/tot_info.c.inst.exe  < ../inputs/universe/test89 > ../newoutputs/t210
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/209.tr
echo ">>>>>>>>running test 211"
../source/tot_info.c.inst.exe  < ../inputs/universe/test91 > ../newoutputs/t211
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/210.tr
echo ">>>>>>>>running test 212"
../source/tot_info.c.inst.exe  < ../inputs/universe/test70 > ../newoutputs/t212
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/211.tr
echo ">>>>>>>>running test 213"
../source/tot_info.c.inst.exe  < ../inputs/universe/test82 > ../newoutputs/t213
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/212.tr
echo ">>>>>>>>running test 214"
../source/tot_info.c.inst.exe  < ../inputs/universe/test93 > ../newoutputs/t214
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/213.tr
echo ">>>>>>>>running test 215"
../source/tot_info.c.inst.exe  < ../inputs/universe/test94 > ../newoutputs/t215
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/214.tr
echo ">>>>>>>>running test 216"
../source/tot_info.c.inst.exe  < ../inputs/universe/test65 > ../newoutputs/t216
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/215.tr
echo ">>>>>>>>running test 217"
../source/tot_info.c.inst.exe  < ../inputs/universe/test71 > ../newoutputs/t217
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/216.tr
echo ">>>>>>>>running test 218"
../source/tot_info.c.inst.exe  < ../inputs/universe/test85 > ../newoutputs/t218
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/217.tr
echo ">>>>>>>>running test 219"
../source/tot_info.c.inst.exe  < ../inputs/universe/test101 > ../newoutputs/t219
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/218.tr
echo ">>>>>>>>running test 220"
../source/tot_info.c.inst.exe  < ../inputs/universe/test102 > ../newoutputs/t220
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/219.tr
echo ">>>>>>>>running test 221"
../source/tot_info.c.inst.exe  < ../inputs/universe/test103 > ../newoutputs/t221
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/220.tr
echo ">>>>>>>>running test 222"
../source/tot_info.c.inst.exe  < ../inputs/universe/test104 > ../newoutputs/t222
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/221.tr
echo ">>>>>>>>running test 223"
../source/tot_info.c.inst.exe  < ../inputs/universe/test105 > ../newoutputs/t223
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/222.tr
echo ">>>>>>>>running test 224"
../source/tot_info.c.inst.exe  < ../inputs/universe/test106 > ../newoutputs/t224
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/223.tr
echo ">>>>>>>>running test 225"
../source/tot_info.c.inst.exe  < ../inputs/universe/test107 > ../newoutputs/t225
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/224.tr
echo ">>>>>>>>running test 226"
../source/tot_info.c.inst.exe  < ../inputs/universe/test108 > ../newoutputs/t226
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/225.tr
echo ">>>>>>>>running test 227"
../source/tot_info.c.inst.exe  < ../inputs/universe/test1.inc > ../newoutputs/t227
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/226.tr
echo ">>>>>>>>running test 228"
../source/tot_info.c.inst.exe  < ../inputs/universe/test3.inc > ../newoutputs/t228
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/227.tr
echo ">>>>>>>>running test 229"
../source/tot_info.c.inst.exe  < ../inputs/universe/test4.inc > ../newoutputs/t229
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/228.tr
echo ">>>>>>>>running test 230"
../source/tot_info.c.inst.exe  < ../inputs/universe/test5.inc > ../newoutputs/t230
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/229.tr
echo ">>>>>>>>running test 231"
../source/tot_info.c.inst.exe  < ../inputs/universe/test6.inc > ../newoutputs/t231
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/230.tr
echo ">>>>>>>>running test 232"
../source/tot_info.c.inst.exe  < ../inputs/universe/test7.inc > ../newoutputs/t232
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/231.tr
echo ">>>>>>>>running test 233"
../source/tot_info.c.inst.exe  < ../inputs/universe/test8.inc > ../newoutputs/t233
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/232.tr
echo ">>>>>>>>running test 234"
../source/tot_info.c.inst.exe  < ../inputs/universe/test9.inc > ../newoutputs/t234
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/233.tr
echo ">>>>>>>>running test 235"
../source/tot_info.c.inst.exe  < ../inputs/universe/test10.inc > ../newoutputs/t235
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/234.tr
echo ">>>>>>>>running test 236"
../source/tot_info.c.inst.exe  < ../inputs/universe/test11.inc > ../newoutputs/t236
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/235.tr
echo ">>>>>>>>running test 237"
../source/tot_info.c.inst.exe  < ../inputs/universe/test13.inc > ../newoutputs/t237
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/236.tr
echo ">>>>>>>>running test 238"
../source/tot_info.c.inst.exe  < ../inputs/universe/test14.inc > ../newoutputs/t238
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/237.tr
echo ">>>>>>>>running test 239"
../source/tot_info.c.inst.exe  < ../inputs/universe/test15.inc > ../newoutputs/t239
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/238.tr
echo ">>>>>>>>running test 240"
../source/tot_info.c.inst.exe  < ../inputs/universe/test16.inc > ../newoutputs/t240
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/239.tr
echo ">>>>>>>>running test 241"
../source/tot_info.c.inst.exe  < ../inputs/universe/test17.inc > ../newoutputs/t241
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/240.tr
echo ">>>>>>>>running test 242"
../source/tot_info.c.inst.exe  < ../inputs/universe/test18.inc > ../newoutputs/t242
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/241.tr
echo ">>>>>>>>running test 243"
../source/tot_info.c.inst.exe  < ../inputs/universe/test19.inc > ../newoutputs/t243
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/242.tr
echo ">>>>>>>>running test 244"
../source/tot_info.c.inst.exe  < ../inputs/universe/test20.inc > ../newoutputs/t244
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/243.tr
echo ">>>>>>>>running test 245"
../source/tot_info.c.inst.exe  < ../inputs/universe/test21.inc > ../newoutputs/t245
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/244.tr
echo ">>>>>>>>running test 246"
../source/tot_info.c.inst.exe  < ../inputs/universe/test22.inc > ../newoutputs/t246
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/245.tr
echo ">>>>>>>>running test 247"
../source/tot_info.c.inst.exe  < ../inputs/universe/test23.inc > ../newoutputs/t247
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/246.tr
echo ">>>>>>>>running test 248"
../source/tot_info.c.inst.exe  < ../inputs/universe/test24.inc > ../newoutputs/t248
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/247.tr
echo ">>>>>>>>running test 249"
../source/tot_info.c.inst.exe  < ../inputs/universe/test25.inc > ../newoutputs/t249
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/248.tr
echo ">>>>>>>>running test 250"
../source/tot_info.c.inst.exe  < ../inputs/universe/test26.inc > ../newoutputs/t250
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/249.tr
echo ">>>>>>>>running test 251"
../source/tot_info.c.inst.exe  < ../inputs/universe/test27.inc > ../newoutputs/t251
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/250.tr
echo ">>>>>>>>running test 252"
../source/tot_info.c.inst.exe  < ../inputs/universe/test28.inc > ../newoutputs/t252
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/251.tr
echo ">>>>>>>>running test 253"
../source/tot_info.c.inst.exe  < ../inputs/universe/test29.inc > ../newoutputs/t253
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/252.tr
echo ">>>>>>>>running test 254"
../source/tot_info.c.inst.exe  < ../inputs/universe/test30.inc > ../newoutputs/t254
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/253.tr
echo ">>>>>>>>running test 255"
../source/tot_info.c.inst.exe  < ../inputs/universe/test31.inc > ../newoutputs/t255
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/254.tr
echo ">>>>>>>>running test 256"
../source/tot_info.c.inst.exe  < ../inputs/universe/test32.inc > ../newoutputs/t256
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/255.tr
echo ">>>>>>>>running test 257"
../source/tot_info.c.inst.exe  < ../inputs/universe/test33.inc > ../newoutputs/t257
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/256.tr
echo ">>>>>>>>running test 258"
../source/tot_info.c.inst.exe  < ../inputs/universe/test34.inc > ../newoutputs/t258
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/257.tr
echo ">>>>>>>>running test 259"
../source/tot_info.c.inst.exe  < ../inputs/universe/test35.inc > ../newoutputs/t259
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/258.tr
echo ">>>>>>>>running test 260"
../source/tot_info.c.inst.exe  < ../inputs/universe/test36.inc > ../newoutputs/t260
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/259.tr
echo ">>>>>>>>running test 261"
../source/tot_info.c.inst.exe  < ../inputs/universe/test37.inc > ../newoutputs/t261
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/260.tr
echo ">>>>>>>>running test 262"
../source/tot_info.c.inst.exe  < ../inputs/universe/test38.inc > ../newoutputs/t262
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/261.tr
echo ">>>>>>>>running test 263"
../source/tot_info.c.inst.exe  < ../inputs/universe/test39.inc > ../newoutputs/t263
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/262.tr
echo ">>>>>>>>running test 264"
../source/tot_info.c.inst.exe  < ../inputs/universe/test40.inc > ../newoutputs/t264
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/263.tr
echo ">>>>>>>>running test 265"
../source/tot_info.c.inst.exe  < ../inputs/universe/test41.inc > ../newoutputs/t265
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/264.tr
echo ">>>>>>>>running test 266"
../source/tot_info.c.inst.exe  < ../inputs/universe/test42.inc > ../newoutputs/t266
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/265.tr
echo ">>>>>>>>running test 267"
../source/tot_info.c.inst.exe  < ../inputs/universe/test43.inc > ../newoutputs/t267
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/266.tr
echo ">>>>>>>>running test 268"
../source/tot_info.c.inst.exe  < ../inputs/universe/test44.inc > ../newoutputs/t268
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/267.tr
echo ">>>>>>>>running test 269"
../source/tot_info.c.inst.exe  < ../inputs/universe/test45.inc > ../newoutputs/t269
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/268.tr
echo ">>>>>>>>running test 270"
../source/tot_info.c.inst.exe  < ../inputs/universe/test46.inc > ../newoutputs/t270
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/269.tr
echo ">>>>>>>>running test 271"
../source/tot_info.c.inst.exe  < ../inputs/universe/test47.inc > ../newoutputs/t271
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/270.tr
echo ">>>>>>>>running test 272"
../source/tot_info.c.inst.exe  < ../inputs/universe/test48.inc > ../newoutputs/t272
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/271.tr
echo ">>>>>>>>running test 273"
../source/tot_info.c.inst.exe  < ../inputs/universe/test49.inc > ../newoutputs/t273
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/272.tr
echo ">>>>>>>>running test 274"
../source/tot_info.c.inst.exe  < ../inputs/universe/test50.inc > ../newoutputs/t274
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/273.tr
echo ">>>>>>>>running test 275"
../source/tot_info.c.inst.exe  < ../inputs/universe/test51.inc > ../newoutputs/t275
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/274.tr
echo ">>>>>>>>running test 276"
../source/tot_info.c.inst.exe  < ../inputs/universe/test52.inc > ../newoutputs/t276
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/275.tr
echo ">>>>>>>>running test 277"
../source/tot_info.c.inst.exe  < ../inputs/universe/test53.inc > ../newoutputs/t277
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/276.tr
echo ">>>>>>>>running test 278"
../source/tot_info.c.inst.exe  < ../inputs/universe/test54.inc > ../newoutputs/t278
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/277.tr
echo ">>>>>>>>running test 279"
../source/tot_info.c.inst.exe  < ../inputs/universe/test55.inc > ../newoutputs/t279
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/278.tr
echo ">>>>>>>>running test 280"
../source/tot_info.c.inst.exe  < ../inputs/universe/test56.inc > ../newoutputs/t280
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/279.tr
echo ">>>>>>>>running test 281"
../source/tot_info.c.inst.exe  < ../inputs/universe/test57.inc > ../newoutputs/t281
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/280.tr
echo ">>>>>>>>running test 282"
../source/tot_info.c.inst.exe  < ../inputs/universe/test58.inc > ../newoutputs/t282
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/281.tr
echo ">>>>>>>>running test 283"
../source/tot_info.c.inst.exe  < ../inputs/universe/test59.inc > ../newoutputs/t283
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/282.tr
echo ">>>>>>>>running test 284"
../source/tot_info.c.inst.exe  < ../inputs/universe/test60.inc > ../newoutputs/t284
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/283.tr
echo ">>>>>>>>running test 285"
../source/tot_info.c.inst.exe  < ../inputs/universe/test61.inc > ../newoutputs/t285
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/284.tr
echo ">>>>>>>>running test 286"
../source/tot_info.c.inst.exe  < ../inputs/universe/test62.inc > ../newoutputs/t286
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/285.tr
echo ">>>>>>>>running test 287"
../source/tot_info.c.inst.exe  < ../inputs/universe/test63.inc > ../newoutputs/t287
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/286.tr
echo ">>>>>>>>running test 288"
../source/tot_info.c.inst.exe  < ../inputs/universe/test64.inc > ../newoutputs/t288
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/287.tr
echo ">>>>>>>>running test 289"
../source/tot_info.c.inst.exe  < ../inputs/universe/test65.inc > ../newoutputs/t289
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/288.tr
echo ">>>>>>>>running test 290"
../source/tot_info.c.inst.exe  < ../inputs/universe/test66.inc > ../newoutputs/t290
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/289.tr
echo ">>>>>>>>running test 291"
../source/tot_info.c.inst.exe  < ../inputs/universe/test67.inc > ../newoutputs/t291
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/290.tr
echo ">>>>>>>>running test 292"
../source/tot_info.c.inst.exe  < ../inputs/universe/test68.inc > ../newoutputs/t292
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/291.tr
echo ">>>>>>>>running test 293"
../source/tot_info.c.inst.exe  < ../inputs/universe/test69.inc > ../newoutputs/t293
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/292.tr
echo ">>>>>>>>running test 294"
../source/tot_info.c.inst.exe  < ../inputs/universe/test70.inc > ../newoutputs/t294
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/293.tr
echo ">>>>>>>>running test 295"
../source/tot_info.c.inst.exe  < ../inputs/universe/test71.inc > ../newoutputs/t295
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/294.tr
echo ">>>>>>>>running test 296"
../source/tot_info.c.inst.exe  < ../inputs/universe/test72.inc > ../newoutputs/t296
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/295.tr
echo ">>>>>>>>running test 297"
../source/tot_info.c.inst.exe  < ../inputs/universe/test73.inc > ../newoutputs/t297
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/296.tr
echo ">>>>>>>>running test 298"
../source/tot_info.c.inst.exe  < ../inputs/universe/test74.inc > ../newoutputs/t298
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/297.tr
echo ">>>>>>>>running test 299"
../source/tot_info.c.inst.exe  < ../inputs/universe/test75.inc > ../newoutputs/t299
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/298.tr
echo ">>>>>>>>running test 300"
../source/tot_info.c.inst.exe  < ../inputs/universe/test76.inc > ../newoutputs/t300
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/299.tr
echo ">>>>>>>>running test 301"
../source/tot_info.c.inst.exe  < ../inputs/universe/test77.inc > ../newoutputs/t301
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/300.tr
echo ">>>>>>>>running test 302"
../source/tot_info.c.inst.exe  < ../inputs/universe/test78.inc > ../newoutputs/t302
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/301.tr
echo ">>>>>>>>running test 303"
../source/tot_info.c.inst.exe  < ../inputs/universe/test79.inc > ../newoutputs/t303
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/302.tr
echo ">>>>>>>>running test 304"
../source/tot_info.c.inst.exe  < ../inputs/universe/test80.inc > ../newoutputs/t304
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/303.tr
echo ">>>>>>>>running test 305"
../source/tot_info.c.inst.exe  < ../inputs/universe/test81.inc > ../newoutputs/t305
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/304.tr
echo ">>>>>>>>running test 306"
../source/tot_info.c.inst.exe  < ../inputs/universe/test82.inc > ../newoutputs/t306
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/305.tr
echo ">>>>>>>>running test 307"
../source/tot_info.c.inst.exe  < ../inputs/universe/test83.inc > ../newoutputs/t307
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/306.tr
echo ">>>>>>>>running test 308"
../source/tot_info.c.inst.exe  < ../inputs/universe/test84.inc > ../newoutputs/t308
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/307.tr
echo ">>>>>>>>running test 309"
../source/tot_info.c.inst.exe  < ../inputs/universe/test85.inc > ../newoutputs/t309
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/308.tr
echo ">>>>>>>>running test 310"
../source/tot_info.c.inst.exe  < ../inputs/universe/test86.inc > ../newoutputs/t310
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/309.tr
echo ">>>>>>>>running test 311"
../source/tot_info.c.inst.exe  < ../inputs/universe/test87.inc > ../newoutputs/t311
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/310.tr
echo ">>>>>>>>running test 312"
../source/tot_info.c.inst.exe  < ../inputs/universe/test88.inc > ../newoutputs/t312
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/311.tr
echo ">>>>>>>>running test 313"
../source/tot_info.c.inst.exe  < ../inputs/universe/test89.inc > ../newoutputs/t313
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/312.tr
echo ">>>>>>>>running test 314"
../source/tot_info.c.inst.exe  < ../inputs/universe/test90.inc > ../newoutputs/t314
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/313.tr
echo ">>>>>>>>running test 315"
../source/tot_info.c.inst.exe  < ../inputs/universe/test91.inc > ../newoutputs/t315
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/314.tr
echo ">>>>>>>>running test 316"
../source/tot_info.c.inst.exe  < ../inputs/universe/test92.inc > ../newoutputs/t316
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/315.tr
echo ">>>>>>>>running test 317"
../source/tot_info.c.inst.exe  < ../inputs/universe/test93.inc > ../newoutputs/t317
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/316.tr
echo ">>>>>>>>running test 318"
../source/tot_info.c.inst.exe  < ../inputs/universe/test94.inc > ../newoutputs/t318
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/317.tr
echo ">>>>>>>>running test 319"
../source/tot_info.c.inst.exe  < ../inputs/universe/test95.inc > ../newoutputs/t319
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/318.tr
echo ">>>>>>>>running test 320"
../source/tot_info.c.inst.exe  < ../inputs/universe/test96.inc > ../newoutputs/t320
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/319.tr
echo ">>>>>>>>running test 321"
../source/tot_info.c.inst.exe  < ../inputs/universe/test97.inc > ../newoutputs/t321
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/320.tr
echo ">>>>>>>>running test 322"
../source/tot_info.c.inst.exe  < ../inputs/universe/test98.inc > ../newoutputs/t322
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/321.tr
echo ">>>>>>>>running test 323"
../source/tot_info.c.inst.exe  < ../inputs/universe/test99.inc > ../newoutputs/t323
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/322.tr
echo ">>>>>>>>running test 324"
../source/tot_info.c.inst.exe  < ../inputs/universe/test100.inc > ../newoutputs/t324
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/323.tr
echo ">>>>>>>>running test 325"
../source/tot_info.c.inst.exe  < ../inputs/universe/test101.inc > ../newoutputs/t325
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/324.tr
echo ">>>>>>>>running test 326"
../source/tot_info.c.inst.exe  < ../inputs/universe/test102.inc > ../newoutputs/t326
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/325.tr
echo ">>>>>>>>running test 327"
../source/tot_info.c.inst.exe  < ../inputs/universe/test103.inc > ../newoutputs/t327
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/326.tr
echo ">>>>>>>>running test 328"
../source/tot_info.c.inst.exe  < ../inputs/universe/test104.inc > ../newoutputs/t328
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/327.tr
echo ">>>>>>>>running test 329"
../source/tot_info.c.inst.exe  < ../inputs/universe/test106.inc > ../newoutputs/t329
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/328.tr
echo ">>>>>>>>running test 330"
../source/tot_info.c.inst.exe  < ../inputs/universe/test107.inc > ../newoutputs/t330
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/329.tr
echo ">>>>>>>>running test 331"
../source/tot_info.c.inst.exe  < ../inputs/universe/test108.inc > ../newoutputs/t331
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/330.tr
echo ">>>>>>>>running test 332"
../source/tot_info.c.inst.exe  < ../inputs/universe/test109.inc > ../newoutputs/t332
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/331.tr
echo ">>>>>>>>running test 333"
../source/tot_info.c.inst.exe  < ../inputs/universe/test110.inc > ../newoutputs/t333
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/332.tr
echo ">>>>>>>>running test 334"
../source/tot_info.c.inst.exe  < ../inputs/universe/test111.inc > ../newoutputs/t334
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/333.tr
echo ">>>>>>>>running test 335"
../source/tot_info.c.inst.exe  < ../inputs/universe/test112.inc > ../newoutputs/t335
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/334.tr
echo ">>>>>>>>running test 336"
../source/tot_info.c.inst.exe  < ../inputs/universe/test113.inc > ../newoutputs/t336
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/335.tr
echo ">>>>>>>>running test 337"
../source/tot_info.c.inst.exe  < ../inputs/universe/test114.inc > ../newoutputs/t337
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/336.tr
echo ">>>>>>>>running test 338"
../source/tot_info.c.inst.exe  < ../inputs/universe/test115.inc > ../newoutputs/t338
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/337.tr
echo ">>>>>>>>running test 339"
../source/tot_info.c.inst.exe  < ../inputs/universe/test116.inc > ../newoutputs/t339
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/338.tr
echo ">>>>>>>>running test 340"
../source/tot_info.c.inst.exe  < ../inputs/universe/test117.inc > ../newoutputs/t340
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/339.tr
echo ">>>>>>>>running test 341"
../source/tot_info.c.inst.exe  < ../inputs/universe/test118.inc > ../newoutputs/t341
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/340.tr
echo ">>>>>>>>running test 342"
../source/tot_info.c.inst.exe  < ../inputs/universe/test119.inc > ../newoutputs/t342
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/341.tr
echo ">>>>>>>>running test 343"
../source/tot_info.c.inst.exe  < ../inputs/universe/test120.inc > ../newoutputs/t343
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/342.tr
echo ">>>>>>>>running test 344"
../source/tot_info.c.inst.exe  < ../inputs/universe/test121.inc > ../newoutputs/t344
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/343.tr
echo ">>>>>>>>running test 345"
../source/tot_info.c.inst.exe  < ../inputs/universe/test122.inc > ../newoutputs/t345
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/344.tr
echo ">>>>>>>>running test 346"
../source/tot_info.c.inst.exe  < ../inputs/universe/test123.inc > ../newoutputs/t346
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/345.tr
echo ">>>>>>>>running test 347"
../source/tot_info.c.inst.exe  < ../inputs/universe/test124.inc > ../newoutputs/t347
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/346.tr
echo ">>>>>>>>running test 348"
../source/tot_info.c.inst.exe  < ../inputs/universe/test125.inc > ../newoutputs/t348
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/347.tr
echo ">>>>>>>>running test 349"
../source/tot_info.c.inst.exe  < ../inputs/universe/test126.inc > ../newoutputs/t349
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/348.tr
echo ">>>>>>>>running test 350"
../source/tot_info.c.inst.exe  < ../inputs/universe/test127.inc > ../newoutputs/t350
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/349.tr
echo ">>>>>>>>running test 351"
../source/tot_info.c.inst.exe  < ../inputs/universe/test128.inc > ../newoutputs/t351
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/350.tr
echo ">>>>>>>>running test 352"
../source/tot_info.c.inst.exe  < ../inputs/universe/test129.inc > ../newoutputs/t352
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/351.tr
echo ">>>>>>>>running test 353"
../source/tot_info.c.inst.exe  < ../inputs/universe/test130.inc > ../newoutputs/t353
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/352.tr
echo ">>>>>>>>running test 354"
../source/tot_info.c.inst.exe  < ../inputs/universe/test131.inc > ../newoutputs/t354
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/353.tr
echo ">>>>>>>>running test 355"
../source/tot_info.c.inst.exe  < ../inputs/universe/test132.inc > ../newoutputs/t355
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/354.tr
echo ">>>>>>>>running test 356"
../source/tot_info.c.inst.exe  < ../inputs/universe/test133.inc > ../newoutputs/t356
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/355.tr
echo ">>>>>>>>running test 357"
../source/tot_info.c.inst.exe  < ../inputs/universe/test134.inc > ../newoutputs/t357
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/356.tr
echo ">>>>>>>>running test 358"
../source/tot_info.c.inst.exe  < ../inputs/universe/test135.inc > ../newoutputs/t358
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/357.tr
echo ">>>>>>>>running test 359"
../source/tot_info.c.inst.exe  < ../inputs/universe/test136.inc > ../newoutputs/t359
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/358.tr
echo ">>>>>>>>running test 360"
../source/tot_info.c.inst.exe  < ../inputs/universe/test137.inc > ../newoutputs/t360
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/359.tr
echo ">>>>>>>>running test 361"
../source/tot_info.c.inst.exe  < ../inputs/universe/test138.inc > ../newoutputs/t361
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/360.tr
echo ">>>>>>>>running test 362"
../source/tot_info.c.inst.exe  < ../inputs/universe/test139.inc > ../newoutputs/t362
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/361.tr
echo ">>>>>>>>running test 363"
../source/tot_info.c.inst.exe  < ../inputs/universe/test140.inc	 > ../newoutputs/t363
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/362.tr
echo ">>>>>>>>running test 364"
../source/tot_info.c.inst.exe  < ../inputs/universe/test141.inc > ../newoutputs/t364
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/363.tr
echo ">>>>>>>>running test 365"
../source/tot_info.c.inst.exe  < ../inputs/universe/test142.inc > ../newoutputs/t365
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/364.tr
echo ">>>>>>>>running test 366"
../source/tot_info.c.inst.exe  < ../inputs/universe/test143.inc > ../newoutputs/t366
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/365.tr
echo ">>>>>>>>running test 367"
../source/tot_info.c.inst.exe  < ../inputs/universe/test144.inc > ../newoutputs/t367
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/366.tr
echo ">>>>>>>>running test 368"
../source/tot_info.c.inst.exe  < ../inputs/universe/test145.inc > ../newoutputs/t368
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/367.tr
echo ">>>>>>>>running test 369"
../source/tot_info.c.inst.exe  < ../inputs/universe/test146.inc > ../newoutputs/t369
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/368.tr
echo ">>>>>>>>running test 370"
../source/tot_info.c.inst.exe  < ../inputs/universe/test147.inc > ../newoutputs/t370
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/369.tr
echo ">>>>>>>>running test 371"
../source/tot_info.c.inst.exe  < ../inputs/universe/test148.inc > ../newoutputs/t371
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/370.tr
echo ">>>>>>>>running test 372"
../source/tot_info.c.inst.exe  < ../inputs/universe/test149.inc > ../newoutputs/t372
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/371.tr
echo ">>>>>>>>running test 373"
../source/tot_info.c.inst.exe  < ../inputs/universe/test151.inc > ../newoutputs/t373
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/372.tr
echo ">>>>>>>>running test 374"
../source/tot_info.c.inst.exe  < ../inputs/universe/test152.inc > ../newoutputs/t374
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/373.tr
echo ">>>>>>>>running test 375"
../source/tot_info.c.inst.exe  < ../inputs/universe/test153.inc > ../newoutputs/t375
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/374.tr
echo ">>>>>>>>running test 376"
../source/tot_info.c.inst.exe  < ../inputs/universe/test154.inc > ../newoutputs/t376
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/375.tr
echo ">>>>>>>>running test 377"
../source/tot_info.c.inst.exe  < ../inputs/universe/test155.inc > ../newoutputs/t377
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/376.tr
echo ">>>>>>>>running test 378"
../source/tot_info.c.inst.exe  < ../inputs/universe/test156.inc > ../newoutputs/t378
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/377.tr
echo ">>>>>>>>running test 379"
../source/tot_info.c.inst.exe  < ../inputs/universe/test157.inc > ../newoutputs/t379
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/378.tr
echo ">>>>>>>>running test 380"
../source/tot_info.c.inst.exe  < ../inputs/universe/test158.inc > ../newoutputs/t380
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/379.tr
echo ">>>>>>>>running test 381"
../source/tot_info.c.inst.exe  < ../inputs/universe/test159.inc > ../newoutputs/t381
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/380.tr
echo ">>>>>>>>running test 382"
../source/tot_info.c.inst.exe  < ../inputs/universe/test160.inc > ../newoutputs/t382
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/381.tr
echo ">>>>>>>>running test 383"
../source/tot_info.c.inst.exe  < ../inputs/universe/test161.inc > ../newoutputs/t383
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/382.tr
echo ">>>>>>>>running test 384"
../source/tot_info.c.inst.exe  < ../inputs/universe/test162.inc > ../newoutputs/t384
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/383.tr
echo ">>>>>>>>running test 385"
../source/tot_info.c.inst.exe  < ../inputs/universe/test163.inc > ../newoutputs/t385
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/384.tr
echo ">>>>>>>>running test 386"
../source/tot_info.c.inst.exe  < ../inputs/universe/test164.inc > ../newoutputs/t386
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/385.tr
echo ">>>>>>>>running test 387"
../source/tot_info.c.inst.exe  < ../inputs/universe/test165.inc > ../newoutputs/t387
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/386.tr
echo ">>>>>>>>running test 388"
../source/tot_info.c.inst.exe  < ../inputs/universe/test166.inc > ../newoutputs/t388
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/387.tr
echo ">>>>>>>>running test 389"
../source/tot_info.c.inst.exe  < ../inputs/universe/test167.inc > ../newoutputs/t389
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/388.tr
echo ">>>>>>>>running test 390"
../source/tot_info.c.inst.exe  < ../inputs/universe/test168.inc > ../newoutputs/t390
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/389.tr
echo ">>>>>>>>running test 391"
../source/tot_info.c.inst.exe  < ../inputs/universe/test169.inc > ../newoutputs/t391
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/390.tr
echo ">>>>>>>>running test 392"
../source/tot_info.c.inst.exe  < ../inputs/universe/test170.inc > ../newoutputs/t392
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/391.tr
echo ">>>>>>>>running test 393"
../source/tot_info.c.inst.exe  < ../inputs/universe/test171.inc > ../newoutputs/t393
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/392.tr
echo ">>>>>>>>running test 394"
../source/tot_info.c.inst.exe  < ../inputs/universe/test172.inc > ../newoutputs/t394
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/393.tr
echo ">>>>>>>>running test 395"
../source/tot_info.c.inst.exe  < ../inputs/universe/test173.inc > ../newoutputs/t395
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/394.tr
echo ">>>>>>>>running test 396"
../source/tot_info.c.inst.exe  < ../inputs/universe/test174.inc > ../newoutputs/t396
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/395.tr
echo ">>>>>>>>running test 397"
../source/tot_info.c.inst.exe  < ../inputs/universe/test175.inc > ../newoutputs/t397
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/396.tr
echo ">>>>>>>>running test 398"
../source/tot_info.c.inst.exe  < ../inputs/universe/test176.inc > ../newoutputs/t398
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/397.tr
echo ">>>>>>>>running test 399"
../source/tot_info.c.inst.exe  < ../inputs/universe/test177.inc > ../newoutputs/t399
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/398.tr
echo ">>>>>>>>running test 400"
../source/tot_info.c.inst.exe  < ../inputs/universe/test178.inc > ../newoutputs/t400
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/399.tr
echo ">>>>>>>>running test 401"
../source/tot_info.c.inst.exe  < ../inputs/universe/test179.inc > ../newoutputs/t401
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/400.tr
echo ">>>>>>>>running test 402"
../source/tot_info.c.inst.exe  < ../inputs/universe/test180.inc > ../newoutputs/t402
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/401.tr
echo ">>>>>>>>running test 403"
../source/tot_info.c.inst.exe  < ../inputs/universe/test181.inc > ../newoutputs/t403
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/402.tr
echo ">>>>>>>>running test 404"
../source/tot_info.c.inst.exe  < ../inputs/universe/test182.inc > ../newoutputs/t404
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/403.tr
echo ">>>>>>>>running test 405"
../source/tot_info.c.inst.exe  < ../inputs/universe/test183.inc > ../newoutputs/t405
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/404.tr
echo ">>>>>>>>running test 406"
../source/tot_info.c.inst.exe  < ../inputs/universe/test184.inc > ../newoutputs/t406
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/405.tr
echo ">>>>>>>>running test 407"
../source/tot_info.c.inst.exe  < ../inputs/universe/test185.inc > ../newoutputs/t407
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/406.tr
echo ">>>>>>>>running test 408"
../source/tot_info.c.inst.exe  < ../inputs/universe/test186.inc > ../newoutputs/t408
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/407.tr
echo ">>>>>>>>running test 409"
../source/tot_info.c.inst.exe  < ../inputs/universe/test187.inc > ../newoutputs/t409
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/408.tr
echo ">>>>>>>>running test 410"
../source/tot_info.c.inst.exe  < ../inputs/universe/test188.inc > ../newoutputs/t410
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/409.tr
echo ">>>>>>>>running test 411"
../source/tot_info.c.inst.exe  < ../inputs/universe/test189.inc > ../newoutputs/t411
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/410.tr
echo ">>>>>>>>running test 412"
../source/tot_info.c.inst.exe  < ../inputs/universe/test190.inc > ../newoutputs/t412
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/411.tr
echo ">>>>>>>>running test 413"
../source/tot_info.c.inst.exe  < ../inputs/universe/test191.inc > ../newoutputs/t413
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/412.tr
echo ">>>>>>>>running test 414"
../source/tot_info.c.inst.exe  < ../inputs/universe/test192.inc > ../newoutputs/t414
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/413.tr
echo ">>>>>>>>running test 415"
../source/tot_info.c.inst.exe  < ../inputs/universe/test193.inc > ../newoutputs/t415
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/414.tr
echo ">>>>>>>>running test 416"
../source/tot_info.c.inst.exe  < ../inputs/universe/test194.inc > ../newoutputs/t416
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/415.tr
echo ">>>>>>>>running test 417"
../source/tot_info.c.inst.exe  < ../inputs/universe/test195.inc > ../newoutputs/t417
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/416.tr
echo ">>>>>>>>running test 418"
../source/tot_info.c.inst.exe  < ../inputs/universe/test196.inc > ../newoutputs/t418
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/417.tr
echo ">>>>>>>>running test 419"
../source/tot_info.c.inst.exe  < ../inputs/universe/test197.inc > ../newoutputs/t419
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/418.tr
echo ">>>>>>>>running test 420"
../source/tot_info.c.inst.exe  < ../inputs/universe/test198.inc > ../newoutputs/t420
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/419.tr
echo ">>>>>>>>running test 421"
../source/tot_info.c.inst.exe  < ../inputs/universe/test199.inc > ../newoutputs/t421
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/420.tr
echo ">>>>>>>>running test 422"
../source/tot_info.c.inst.exe  < ../inputs/universe/test300.inc > ../newoutputs/t422
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/421.tr
echo ">>>>>>>>running test 423"
../source/tot_info.c.inst.exe  < ../inputs/universe/test301.inc > ../newoutputs/t423
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/422.tr
echo ">>>>>>>>running test 424"
../source/tot_info.c.inst.exe  < ../inputs/universe/test302.inc > ../newoutputs/t424
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/423.tr
echo ">>>>>>>>running test 425"
../source/tot_info.c.inst.exe  < ../inputs/universe/test303.inc > ../newoutputs/t425
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/424.tr
echo ">>>>>>>>running test 426"
../source/tot_info.c.inst.exe  < ../inputs/universe/test304.inc > ../newoutputs/t426
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/425.tr
echo ">>>>>>>>running test 427"
../source/tot_info.c.inst.exe  < ../inputs/universe/test305.inc > ../newoutputs/t427
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/426.tr
echo ">>>>>>>>running test 428"
../source/tot_info.c.inst.exe  < ../inputs/universe/test306.inc > ../newoutputs/t428
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/427.tr
echo ">>>>>>>>running test 429"
../source/tot_info.c.inst.exe  < ../inputs/universe/test307.inc > ../newoutputs/t429
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/428.tr
echo ">>>>>>>>running test 430"
../source/tot_info.c.inst.exe  < ../inputs/universe/test308.inc > ../newoutputs/t430
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/429.tr
echo ">>>>>>>>running test 431"
../source/tot_info.c.inst.exe  < ../inputs/universe/test309.inc > ../newoutputs/t431
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/430.tr
echo ">>>>>>>>running test 432"
../source/tot_info.c.inst.exe  < ../inputs/universe/test310.inc > ../newoutputs/t432
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/431.tr
echo ">>>>>>>>running test 433"
../source/tot_info.c.inst.exe  < ../inputs/universe/test311.inc > ../newoutputs/t433
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/432.tr
echo ">>>>>>>>running test 434"
../source/tot_info.c.inst.exe  < ../inputs/universe/test312.inc > ../newoutputs/t434
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/433.tr
echo ">>>>>>>>running test 435"
../source/tot_info.c.inst.exe  < ../inputs/universe/test313.inc > ../newoutputs/t435
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/434.tr
echo ">>>>>>>>running test 436"
../source/tot_info.c.inst.exe  < ../inputs/universe/test314.inc > ../newoutputs/t436
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/435.tr
echo ">>>>>>>>running test 437"
../source/tot_info.c.inst.exe  < ../inputs/universe/test315.inc > ../newoutputs/t437
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/436.tr
echo ">>>>>>>>running test 438"
../source/tot_info.c.inst.exe  < ../inputs/universe/test316.inc > ../newoutputs/t438
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/437.tr
echo ">>>>>>>>running test 439"
../source/tot_info.c.inst.exe  < ../inputs/universe/test317.inc > ../newoutputs/t439
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/438.tr
echo ">>>>>>>>running test 440"
../source/tot_info.c.inst.exe  < ../inputs/universe/test318.inc > ../newoutputs/t440
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/439.tr
echo ">>>>>>>>running test 441"
../source/tot_info.c.inst.exe  < ../inputs/universe/test319.inc > ../newoutputs/t441
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/440.tr
echo ">>>>>>>>running test 442"
../source/tot_info.c.inst.exe  < ../inputs/universe/test320.inc > ../newoutputs/t442
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/441.tr
echo ">>>>>>>>running test 443"
../source/tot_info.c.inst.exe  < ../inputs/universe/test321.inc > ../newoutputs/t443
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/442.tr
echo ">>>>>>>>running test 444"
../source/tot_info.c.inst.exe  < ../inputs/universe/test322.inc > ../newoutputs/t444
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/443.tr
echo ">>>>>>>>running test 445"
../source/tot_info.c.inst.exe  < ../inputs/universe/test323.inc > ../newoutputs/t445
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/444.tr
echo ">>>>>>>>running test 446"
../source/tot_info.c.inst.exe  < ../inputs/universe/test324.inc > ../newoutputs/t446
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/445.tr
echo ">>>>>>>>running test 447"
../source/tot_info.c.inst.exe  < ../inputs/universe/test325.inc > ../newoutputs/t447
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/446.tr
echo ">>>>>>>>running test 448"
../source/tot_info.c.inst.exe  < ../inputs/universe/test326.inc > ../newoutputs/t448
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/447.tr
echo ">>>>>>>>running test 449"
../source/tot_info.c.inst.exe  < ../inputs/universe/test327.inc > ../newoutputs/t449
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/448.tr
echo ">>>>>>>>running test 450"
../source/tot_info.c.inst.exe  < ../inputs/universe/test328.inc > ../newoutputs/t450
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/449.tr
echo ">>>>>>>>running test 451"
../source/tot_info.c.inst.exe  < ../inputs/universe/test329.inc > ../newoutputs/t451
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/450.tr
echo ">>>>>>>>running test 452"
../source/tot_info.c.inst.exe  < ../inputs/universe/test331.inc > ../newoutputs/t452
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/451.tr
echo ">>>>>>>>running test 453"
../source/tot_info.c.inst.exe  < ../inputs/universe/test332.inc > ../newoutputs/t453
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/452.tr
echo ">>>>>>>>running test 454"
../source/tot_info.c.inst.exe  < ../inputs/universe/test333.inc > ../newoutputs/t454
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/453.tr
echo ">>>>>>>>running test 455"
../source/tot_info.c.inst.exe  < ../inputs/universe/test334.inc > ../newoutputs/t455
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/454.tr
echo ">>>>>>>>running test 456"
../source/tot_info.c.inst.exe  < ../inputs/universe/test335.inc > ../newoutputs/t456
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/455.tr
echo ">>>>>>>>running test 457"
../source/tot_info.c.inst.exe  < ../inputs/universe/test336.inc > ../newoutputs/t457
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/456.tr
echo ">>>>>>>>running test 458"
../source/tot_info.c.inst.exe  < ../inputs/universe/test337.inc > ../newoutputs/t458
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/457.tr
echo ">>>>>>>>running test 459"
../source/tot_info.c.inst.exe  < ../inputs/universe/test338.inc > ../newoutputs/t459
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/458.tr
echo ">>>>>>>>running test 460"
../source/tot_info.c.inst.exe  < ../inputs/universe/test339.inc > ../newoutputs/t460
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/459.tr
echo ">>>>>>>>running test 461"
../source/tot_info.c.inst.exe  < ../inputs/universe/test340.inc > ../newoutputs/t461
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/460.tr
echo ">>>>>>>>running test 462"
../source/tot_info.c.inst.exe  < ../inputs/universe/test341.inc > ../newoutputs/t462
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/461.tr
echo ">>>>>>>>running test 463"
../source/tot_info.c.inst.exe  < ../inputs/universe/test342.inc > ../newoutputs/t463
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/462.tr
echo ">>>>>>>>running test 464"
../source/tot_info.c.inst.exe  < ../inputs/universe/test343.inc > ../newoutputs/t464
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/463.tr
echo ">>>>>>>>running test 465"
../source/tot_info.c.inst.exe  < ../inputs/universe/test344.inc > ../newoutputs/t465
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/464.tr
echo ">>>>>>>>running test 466"
../source/tot_info.c.inst.exe  < ../inputs/universe/test345.inc > ../newoutputs/t466
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/465.tr
echo ">>>>>>>>running test 467"
../source/tot_info.c.inst.exe  < ../inputs/universe/test346.inc > ../newoutputs/t467
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/466.tr
echo ">>>>>>>>running test 468"
../source/tot_info.c.inst.exe  < ../inputs/universe/test347.inc > ../newoutputs/t468
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/467.tr
echo ">>>>>>>>running test 469"
../source/tot_info.c.inst.exe  < ../inputs/universe/test348.inc > ../newoutputs/t469
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/468.tr
echo ">>>>>>>>running test 470"
../source/tot_info.c.inst.exe  < ../inputs/universe/test349.inc > ../newoutputs/t470
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/469.tr
echo ">>>>>>>>running test 471"
../source/tot_info.c.inst.exe  < ../inputs/universe/test350.inc > ../newoutputs/t471
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/470.tr
echo ">>>>>>>>running test 472"
../source/tot_info.c.inst.exe  < ../inputs/universe/test351.inc > ../newoutputs/t472
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/471.tr
echo ">>>>>>>>running test 473"
../source/tot_info.c.inst.exe  < ../inputs/universe/test352.inc > ../newoutputs/t473
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/472.tr
echo ">>>>>>>>running test 474"
../source/tot_info.c.inst.exe  < ../inputs/universe/test353.inc > ../newoutputs/t474
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/473.tr
echo ">>>>>>>>running test 475"
../source/tot_info.c.inst.exe  < ../inputs/universe/test354.inc > ../newoutputs/t475
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/474.tr
echo ">>>>>>>>running test 476"
../source/tot_info.c.inst.exe  < ../inputs/universe/test355.inc > ../newoutputs/t476
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/475.tr
echo ">>>>>>>>running test 477"
../source/tot_info.c.inst.exe  < ../inputs/universe/test356.inc > ../newoutputs/t477
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/476.tr
echo ">>>>>>>>running test 478"
../source/tot_info.c.inst.exe  < ../inputs/universe/test357.inc > ../newoutputs/t478
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/477.tr
echo ">>>>>>>>running test 479"
../source/tot_info.c.inst.exe  < ../inputs/universe/test358.inc > ../newoutputs/t479
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/478.tr
echo ">>>>>>>>running test 480"
../source/tot_info.c.inst.exe  < ../inputs/universe/test359.inc > ../newoutputs/t480
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/479.tr
echo ">>>>>>>>running test 481"
../source/tot_info.c.inst.exe  < ../inputs/universe/test361.inc > ../newoutputs/t481
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/480.tr
echo ">>>>>>>>running test 482"
../source/tot_info.c.inst.exe  < ../inputs/universe/test362.inc > ../newoutputs/t482
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/481.tr
echo ">>>>>>>>running test 483"
../source/tot_info.c.inst.exe  < ../inputs/universe/test363.inc > ../newoutputs/t483
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/482.tr
echo ">>>>>>>>running test 484"
../source/tot_info.c.inst.exe  < ../inputs/universe/test364.inc > ../newoutputs/t484
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/483.tr
echo ">>>>>>>>running test 485"
../source/tot_info.c.inst.exe  < ../inputs/universe/test365.inc > ../newoutputs/t485
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/484.tr
echo ">>>>>>>>running test 486"
../source/tot_info.c.inst.exe  < ../inputs/universe/test366.inc > ../newoutputs/t486
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/485.tr
echo ">>>>>>>>running test 487"
../source/tot_info.c.inst.exe  < ../inputs/universe/test367.inc > ../newoutputs/t487
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/486.tr
echo ">>>>>>>>running test 488"
../source/tot_info.c.inst.exe  < ../inputs/universe/test368.inc > ../newoutputs/t488
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/487.tr
echo ">>>>>>>>running test 489"
../source/tot_info.c.inst.exe  < ../inputs/universe/test369.inc > ../newoutputs/t489
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/488.tr
echo ">>>>>>>>running test 490"
../source/tot_info.c.inst.exe  < ../inputs/universe/test370.inc > ../newoutputs/t490
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/489.tr
echo ">>>>>>>>running test 491"
../source/tot_info.c.inst.exe  < ../inputs/universe/test371.inc > ../newoutputs/t491
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/490.tr
echo ">>>>>>>>running test 492"
../source/tot_info.c.inst.exe  < ../inputs/universe/test372.inc > ../newoutputs/t492
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/491.tr
echo ">>>>>>>>running test 493"
../source/tot_info.c.inst.exe  < ../inputs/universe/test373.inc > ../newoutputs/t493
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/492.tr
echo ">>>>>>>>running test 494"
../source/tot_info.c.inst.exe  < ../inputs/universe/test374.inc > ../newoutputs/t494
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/493.tr
echo ">>>>>>>>running test 495"
../source/tot_info.c.inst.exe  < ../inputs/universe/test375.inc > ../newoutputs/t495
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/494.tr
echo ">>>>>>>>running test 496"
../source/tot_info.c.inst.exe  < ../inputs/universe/test376.inc > ../newoutputs/t496
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/495.tr
echo ">>>>>>>>running test 497"
../source/tot_info.c.inst.exe  < ../inputs/universe/test377.inc > ../newoutputs/t497
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/496.tr
echo ">>>>>>>>running test 498"
../source/tot_info.c.inst.exe  < ../inputs/universe/test378.inc > ../newoutputs/t498
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/497.tr
echo ">>>>>>>>running test 499"
../source/tot_info.c.inst.exe  < ../inputs/universe/test379.inc > ../newoutputs/t499
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/498.tr
echo ">>>>>>>>running test 500"
../source/tot_info.c.inst.exe  < ../inputs/universe/test380.inc > ../newoutputs/t500
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/499.tr
echo ">>>>>>>>running test 501"
../source/tot_info.c.inst.exe  < ../inputs/universe/test381.inc > ../newoutputs/t501
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/500.tr
echo ">>>>>>>>running test 502"
../source/tot_info.c.inst.exe  < ../inputs/universe/test382.inc > ../newoutputs/t502
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/501.tr
echo ">>>>>>>>running test 503"
../source/tot_info.c.inst.exe  < ../inputs/universe/test383.inc > ../newoutputs/t503
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/502.tr
echo ">>>>>>>>running test 504"
../source/tot_info.c.inst.exe  < ../inputs/universe/test384.inc > ../newoutputs/t504
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/503.tr
echo ">>>>>>>>running test 505"
../source/tot_info.c.inst.exe  < ../inputs/universe/test385.inc > ../newoutputs/t505
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/504.tr
echo ">>>>>>>>running test 506"
../source/tot_info.c.inst.exe  < ../inputs/universe/test386.inc > ../newoutputs/t506
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/505.tr
echo ">>>>>>>>running test 507"
../source/tot_info.c.inst.exe  < ../inputs/universe/test387.inc > ../newoutputs/t507
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/506.tr
echo ">>>>>>>>running test 508"
../source/tot_info.c.inst.exe  < ../inputs/universe/test388.inc > ../newoutputs/t508
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/507.tr
echo ">>>>>>>>running test 509"
../source/tot_info.c.inst.exe  < ../inputs/universe/test390.inc > ../newoutputs/t509
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/508.tr
echo ">>>>>>>>running test 510"
../source/tot_info.c.inst.exe  < ../inputs/universe/test391.inc > ../newoutputs/t510
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/509.tr
echo ">>>>>>>>running test 511"
../source/tot_info.c.inst.exe  < ../inputs/universe/test392.inc > ../newoutputs/t511
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/510.tr
echo ">>>>>>>>running test 512"
../source/tot_info.c.inst.exe  < ../inputs/universe/test393.inc > ../newoutputs/t512
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/511.tr
echo ">>>>>>>>running test 513"
../source/tot_info.c.inst.exe  < ../inputs/universe/test394.inc > ../newoutputs/t513
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/512.tr
echo ">>>>>>>>running test 514"
../source/tot_info.c.inst.exe  < ../inputs/universe/test395.inc > ../newoutputs/t514
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/513.tr
echo ">>>>>>>>running test 515"
../source/tot_info.c.inst.exe  < ../inputs/universe/test396.inc > ../newoutputs/t515
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/514.tr
echo ">>>>>>>>running test 516"
../source/tot_info.c.inst.exe  < ../inputs/universe/test397.inc > ../newoutputs/t516
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/515.tr
echo ">>>>>>>>running test 517"
../source/tot_info.c.inst.exe  < ../inputs/universe/test398.inc > ../newoutputs/t517
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/516.tr
echo ">>>>>>>>running test 518"
../source/tot_info.c.inst.exe  < ../inputs/universe/test399.inc > ../newoutputs/t518
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/517.tr
echo ">>>>>>>>running test 519"
../source/tot_info.c.inst.exe  < ../inputs/universe/test400.inc > ../newoutputs/t519
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/518.tr
echo ">>>>>>>>running test 520"
../source/tot_info.c.inst.exe  < ../inputs/universe/test401.inc > ../newoutputs/t520
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/519.tr
echo ">>>>>>>>running test 521"
../source/tot_info.c.inst.exe  < ../inputs/universe/test402.inc > ../newoutputs/t521
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/520.tr
echo ">>>>>>>>running test 522"
../source/tot_info.c.inst.exe  < ../inputs/universe/test403.inc > ../newoutputs/t522
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/521.tr
echo ">>>>>>>>running test 523"
../source/tot_info.c.inst.exe  < ../inputs/universe/test404.inc > ../newoutputs/t523
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/522.tr
echo ">>>>>>>>running test 524"
../source/tot_info.c.inst.exe  < ../inputs/universe/test405.inc > ../newoutputs/t524
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/523.tr
echo ">>>>>>>>running test 525"
../source/tot_info.c.inst.exe  < ../inputs/universe/test406.inc > ../newoutputs/t525
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/524.tr
echo ">>>>>>>>running test 526"
../source/tot_info.c.inst.exe  < ../inputs/universe/test407.inc > ../newoutputs/t526
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/525.tr
echo ">>>>>>>>running test 527"
../source/tot_info.c.inst.exe  < ../inputs/universe/test408.inc > ../newoutputs/t527
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/526.tr
echo ">>>>>>>>running test 528"
../source/tot_info.c.inst.exe  < ../inputs/universe/test409.inc > ../newoutputs/t528
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/527.tr
echo ">>>>>>>>running test 529"
../source/tot_info.c.inst.exe  < ../inputs/universe/test410.inc > ../newoutputs/t529
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/528.tr
echo ">>>>>>>>running test 530"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst21.mat > ../newoutputs/t530
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/529.tr
echo ">>>>>>>>running test 531"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst22.mat > ../newoutputs/t531
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/530.tr
echo ">>>>>>>>running test 532"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst23.mat > ../newoutputs/t532
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/531.tr
echo ">>>>>>>>running test 533"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst24.mat > ../newoutputs/t533
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/532.tr
echo ">>>>>>>>running test 534"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst25.mat > ../newoutputs/t534
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/533.tr
echo ">>>>>>>>running test 535"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst26.mat > ../newoutputs/t535
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/534.tr
echo ">>>>>>>>running test 536"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst27.mat > ../newoutputs/t536
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/535.tr
echo ">>>>>>>>running test 537"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst28.mat > ../newoutputs/t537
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/536.tr
echo ">>>>>>>>running test 538"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst2question.mat > ../newoutputs/t538
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/537.tr
echo ">>>>>>>>running test 539"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst2rtangle.mat > ../newoutputs/t539
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/538.tr
echo ">>>>>>>>running test 540"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst2=.mat > ../newoutputs/t540
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/539.tr
echo ">>>>>>>>running test 541"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst2:.mat > ../newoutputs/t541
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/540.tr
echo ">>>>>>>>running test 542"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst2g.mat > ../newoutputs/t542
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/541.tr
echo ">>>>>>>>running test 543"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst2@.mat > ../newoutputs/t543
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/542.tr
echo ">>>>>>>>running test 544"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst2A.mat > ../newoutputs/t544
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/543.tr
echo ">>>>>>>>running test 545"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst2B.mat > ../newoutputs/t545
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/544.tr
echo ">>>>>>>>running test 546"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst2D.mat > ../newoutputs/t546
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/545.tr
echo ">>>>>>>>running test 547"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst2E.mat > ../newoutputs/t547
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/546.tr
echo ">>>>>>>>running test 548"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst2f.mat > ../newoutputs/t548
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/547.tr
echo ">>>>>>>>running test 549"
../source/tot_info.c.inst.exe  < ../inputs/universe/tst2D.mat > ../newoutputs/t549
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/548.tr
echo ">>>>>>>>running test 550"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAAA.mat > ../newoutputs/t550
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/549.tr
echo ">>>>>>>>running test 551"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAAB.mat > ../newoutputs/t551
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/550.tr
echo ">>>>>>>>running test 552"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAAC.mat > ../newoutputs/t552
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/551.tr
echo ">>>>>>>>running test 553"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAAD.mat > ../newoutputs/t553
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/552.tr
echo ">>>>>>>>running test 554"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAAE.mat > ../newoutputs/t554
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/553.tr
echo ">>>>>>>>running test 555"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAAF.mat > ../newoutputs/t555
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/554.tr
echo ">>>>>>>>running test 556"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAAG.mat > ../newoutputs/t556
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/555.tr
echo ">>>>>>>>running test 557"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAAH.mat > ../newoutputs/t557
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/556.tr
echo ">>>>>>>>running test 558"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAAI.mat > ../newoutputs/t558
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/557.tr
echo ">>>>>>>>running test 559"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAAJ.mat > ../newoutputs/t559
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/558.tr
echo ">>>>>>>>running test 560"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAFa.mat > ../newoutputs/t560
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/559.tr
echo ">>>>>>>>running test 561"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAFb.mat > ../newoutputs/t561
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/560.tr
echo ">>>>>>>>running test 562"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAFc.mat > ../newoutputs/t562
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/561.tr
echo ">>>>>>>>running test 563"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAFd.mat > ../newoutputs/t563
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/562.tr
echo ">>>>>>>>running test 564"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAFe.mat > ../newoutputs/t564
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/563.tr
echo ">>>>>>>>running test 565"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAFf.mat > ../newoutputs/t565
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/564.tr
echo ">>>>>>>>running test 566"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAFg.mat > ../newoutputs/t566
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/565.tr
echo ">>>>>>>>running test 567"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAFh.mat > ../newoutputs/t567
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/566.tr
echo ">>>>>>>>running test 568"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAFi.mat > ../newoutputs/t568
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/567.tr
echo ">>>>>>>>running test 569"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAEI.mat > ../newoutputs/t569
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/568.tr
echo ">>>>>>>>running test 570"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAEJ.mat > ../newoutputs/t570
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/569.tr
echo ">>>>>>>>running test 571"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAEK.mat > ../newoutputs/t571
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/570.tr
echo ">>>>>>>>running test 572"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAEL.mat > ../newoutputs/t572
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/571.tr
echo ">>>>>>>>running test 573"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAEM.mat > ../newoutputs/t573
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/572.tr
echo ">>>>>>>>running test 574"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAEN.mat > ../newoutputs/t574
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/573.tr
echo ">>>>>>>>running test 575"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAEO.mat > ../newoutputs/t575
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/574.tr
echo ">>>>>>>>running test 576"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAEP.mat > ../newoutputs/t576
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/575.tr
echo ">>>>>>>>running test 577"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAEQ.mat > ../newoutputs/t577
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/576.tr
echo ">>>>>>>>running test 578"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAER.mat > ../newoutputs/t578
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/577.tr
echo ">>>>>>>>running test 579"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAES.mat > ../newoutputs/t579
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/578.tr
echo ">>>>>>>>running test 580"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAET.mat > ../newoutputs/t580
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/579.tr
echo ">>>>>>>>running test 581"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAEU.mat > ../newoutputs/t581
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/580.tr
echo ">>>>>>>>running test 582"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAEV.mat > ../newoutputs/t582
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/581.tr
echo ">>>>>>>>running test 583"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAEW.mat > ../newoutputs/t583
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/582.tr
echo ">>>>>>>>running test 584"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAEX.mat > ../newoutputs/t584
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/583.tr
echo ">>>>>>>>running test 585"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAEY.mat > ../newoutputs/t585
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/584.tr
echo ">>>>>>>>running test 586"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAEZ.mat > ../newoutputs/t586
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/585.tr
echo ">>>>>>>>running test 587"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAE[.mat > ../newoutputs/t587
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/586.tr
echo ">>>>>>>>running test 588"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAE].mat > ../newoutputs/t588
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/587.tr
echo ">>>>>>>>running test 589"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAE_.mat > ../newoutputs/t589
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/588.tr
echo ">>>>>>>>running test 590"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAEa.mat > ../newoutputs/t590
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/589.tr
echo ">>>>>>>>running test 591"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAEb.mat > ../newoutputs/t591
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/590.tr
echo ">>>>>>>>running test 592"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAEc.mat > ../newoutputs/t592
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/591.tr
echo ">>>>>>>>running test 593"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAEd.mat > ../newoutputs/t593
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/592.tr
echo ">>>>>>>>running test 594"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAEe.mat > ../newoutputs/t594
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/593.tr
echo ">>>>>>>>running test 595"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAEf.mat > ../newoutputs/t595
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/594.tr
echo ">>>>>>>>running test 596"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAEg.mat > ../newoutputs/t596
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/595.tr
echo ">>>>>>>>running test 597"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAEh.mat > ../newoutputs/t597
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/596.tr
echo ">>>>>>>>running test 598"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAEi.mat > ../newoutputs/t598
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/597.tr
echo ">>>>>>>>running test 599"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAEj.mat > ../newoutputs/t599
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/598.tr
echo ">>>>>>>>running test 600"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAEk.mat > ../newoutputs/t600
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/599.tr
echo ">>>>>>>>running test 601"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAEl.mat > ../newoutputs/t601
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/600.tr
echo ">>>>>>>>running test 602"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAEm.mat > ../newoutputs/t602
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/601.tr
echo ">>>>>>>>running test 603"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAEn.mat > ../newoutputs/t603
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/602.tr
echo ">>>>>>>>running test 604"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAEo.mat > ../newoutputs/t604
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/603.tr
echo ">>>>>>>>running test 605"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAEp.mat > ../newoutputs/t605
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/604.tr
echo ">>>>>>>>running test 606"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAEq.mat > ../newoutputs/t606
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/605.tr
echo ">>>>>>>>running test 607"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAEr.mat > ../newoutputs/t607
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/606.tr
echo ">>>>>>>>running test 608"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAEs.mat > ../newoutputs/t608
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/607.tr
echo ">>>>>>>>running test 609"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAEt.mat > ../newoutputs/t609
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/608.tr
echo ">>>>>>>>running test 610"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAEu.mat > ../newoutputs/t610
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/609.tr
echo ">>>>>>>>running test 611"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAEv.mat > ../newoutputs/t611
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/610.tr
echo ">>>>>>>>running test 612"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAEw.mat > ../newoutputs/t612
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/611.tr
echo ">>>>>>>>running test 613"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAEx.mat > ../newoutputs/t613
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/612.tr
echo ">>>>>>>>running test 614"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAEy.mat > ../newoutputs/t614
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/613.tr
echo ">>>>>>>>running test 615"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAFA.mat > ../newoutputs/t615
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/614.tr
echo ">>>>>>>>running test 616"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAFB.mat > ../newoutputs/t616
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/615.tr
echo ">>>>>>>>running test 617"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAFC.mat > ../newoutputs/t617
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/616.tr
echo ">>>>>>>>running test 618"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAFD.mat > ../newoutputs/t618
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/617.tr
echo ">>>>>>>>running test 619"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAFE.mat > ../newoutputs/t619
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/618.tr
echo ">>>>>>>>running test 620"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAFF.mat > ../newoutputs/t620
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/619.tr
echo ">>>>>>>>running test 621"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAFG.mat > ../newoutputs/t621
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/620.tr
echo ">>>>>>>>running test 622"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAFH.mat > ../newoutputs/t622
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/621.tr
echo ">>>>>>>>running test 623"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAFI.mat > ../newoutputs/t623
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/622.tr
echo ">>>>>>>>running test 624"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAFJ.mat > ../newoutputs/t624
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/623.tr
echo ">>>>>>>>running test 625"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAFK.mat > ../newoutputs/t625
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/624.tr
echo ">>>>>>>>running test 626"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAFL.mat > ../newoutputs/t626
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/625.tr
echo ">>>>>>>>running test 627"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAFM.mat > ../newoutputs/t627
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/626.tr
echo ">>>>>>>>running test 628"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAFN.mat > ../newoutputs/t628
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/627.tr
echo ">>>>>>>>running test 629"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAFO.mat > ../newoutputs/t629
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/628.tr
echo ">>>>>>>>running test 630"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAFP.mat > ../newoutputs/t630
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/629.tr
echo ">>>>>>>>running test 631"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAFQ.mat > ../newoutputs/t631
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/630.tr
echo ">>>>>>>>running test 632"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAFR.mat > ../newoutputs/t632
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/631.tr
echo ">>>>>>>>running test 633"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAFS.mat > ../newoutputs/t633
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/632.tr
echo ">>>>>>>>running test 634"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAFT.mat > ../newoutputs/t634
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/633.tr
echo ">>>>>>>>running test 635"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAFU.mat > ../newoutputs/t635
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/634.tr
echo ">>>>>>>>running test 636"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAFV.mat > ../newoutputs/t636
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/635.tr
echo ">>>>>>>>running test 637"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAFW.mat > ../newoutputs/t637
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/636.tr
echo ">>>>>>>>running test 638"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAFX.mat > ../newoutputs/t638
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/637.tr
echo ">>>>>>>>running test 639"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAFY.mat > ../newoutputs/t639
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/638.tr
echo ">>>>>>>>running test 640"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAFZ.mat > ../newoutputs/t640
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/639.tr
echo ">>>>>>>>running test 641"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAF[.mat > ../newoutputs/t641
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/640.tr
echo ">>>>>>>>running test 642"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAF].mat > ../newoutputs/t642
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/641.tr
echo ">>>>>>>>running test 643"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAFhh.mat > ../newoutputs/t643
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/642.tr
echo ">>>>>>>>running test 644"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAF_.mat > ../newoutputs/t644
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/643.tr
echo ">>>>>>>>running test 645"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkACk.mat > ../newoutputs/t645
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/644.tr
echo ">>>>>>>>running test 646"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkACl.mat > ../newoutputs/t646
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/645.tr
echo ">>>>>>>>running test 647"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkACm.mat > ../newoutputs/t647
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/646.tr
echo ">>>>>>>>running test 648"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkACn.mat > ../newoutputs/t648
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/647.tr
echo ">>>>>>>>running test 649"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkACo.mat > ../newoutputs/t649
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/648.tr
echo ">>>>>>>>running test 650"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkACp.mat > ../newoutputs/t650
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/649.tr
echo ">>>>>>>>running test 651"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkACq.mat > ../newoutputs/t651
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/650.tr
echo ">>>>>>>>running test 652"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkACr.mat > ../newoutputs/t652
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/651.tr
echo ">>>>>>>>running test 653"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkACs.mat > ../newoutputs/t653
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/652.tr
echo ">>>>>>>>running test 654"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkACt.mat > ../newoutputs/t654
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/653.tr
echo ">>>>>>>>running test 655"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkACu.mat > ../newoutputs/t655
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/654.tr
echo ">>>>>>>>running test 656"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkACv.mat > ../newoutputs/t656
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/655.tr
echo ">>>>>>>>running test 657"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkACw.mat > ../newoutputs/t657
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/656.tr
echo ">>>>>>>>running test 658"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkACx.mat > ../newoutputs/t658
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/657.tr
echo ">>>>>>>>running test 659"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkACy.mat > ../newoutputs/t659
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/658.tr
echo ">>>>>>>>running test 660"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkADA.mat > ../newoutputs/t660
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/659.tr
echo ">>>>>>>>running test 661"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkADB.mat > ../newoutputs/t661
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/660.tr
echo ">>>>>>>>running test 662"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkADC.mat > ../newoutputs/t662
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/661.tr
echo ">>>>>>>>running test 663"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkADD.mat > ../newoutputs/t663
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/662.tr
echo ">>>>>>>>running test 664"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkADE.mat > ../newoutputs/t664
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/663.tr
echo ">>>>>>>>running test 665"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkADF.mat > ../newoutputs/t665
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/664.tr
echo ">>>>>>>>running test 666"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkADG.mat > ../newoutputs/t666
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/665.tr
echo ">>>>>>>>running test 667"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkADH.mat > ../newoutputs/t667
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/666.tr
echo ">>>>>>>>running test 668"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkADI.mat > ../newoutputs/t668
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/667.tr
echo ">>>>>>>>running test 669"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkADJ.mat > ../newoutputs/t669
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/668.tr
echo ">>>>>>>>running test 670"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkADK.mat > ../newoutputs/t670
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/669.tr
echo ">>>>>>>>running test 671"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkADL.mat > ../newoutputs/t671
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/670.tr
echo ">>>>>>>>running test 672"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkADM.mat > ../newoutputs/t672
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/671.tr
echo ">>>>>>>>running test 673"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkADN.mat > ../newoutputs/t673
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/672.tr
echo ">>>>>>>>running test 674"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkADO.mat > ../newoutputs/t674
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/673.tr
echo ">>>>>>>>running test 675"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkADP.mat > ../newoutputs/t675
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/674.tr
echo ">>>>>>>>running test 676"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkADQ.mat > ../newoutputs/t676
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/675.tr
echo ">>>>>>>>running test 677"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkADR.mat > ../newoutputs/t677
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/676.tr
echo ">>>>>>>>running test 678"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkADS.mat > ../newoutputs/t678
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/677.tr
echo ">>>>>>>>running test 679"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkADT.mat > ../newoutputs/t679
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/678.tr
echo ">>>>>>>>running test 680"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkADU.mat > ../newoutputs/t680
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/679.tr
echo ">>>>>>>>running test 681"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkADV.mat > ../newoutputs/t681
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/680.tr
echo ">>>>>>>>running test 682"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkADW.mat > ../newoutputs/t682
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/681.tr
echo ">>>>>>>>running test 683"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkADX.mat > ../newoutputs/t683
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/682.tr
echo ">>>>>>>>running test 684"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkADY.mat > ../newoutputs/t684
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/683.tr
echo ">>>>>>>>running test 685"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkADZ.mat > ../newoutputs/t685
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/684.tr
echo ">>>>>>>>running test 686"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAD[.mat > ../newoutputs/t686
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/685.tr
echo ">>>>>>>>running test 687"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAD].mat > ../newoutputs/t687
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/686.tr
echo ">>>>>>>>running test 688"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkADhh.mat > ../newoutputs/t688
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/687.tr
echo ">>>>>>>>running test 689"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAD_.mat > ../newoutputs/t689
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/688.tr
echo ">>>>>>>>running test 690"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkADa.mat > ../newoutputs/t690
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/689.tr
echo ">>>>>>>>running test 691"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkADb.mat > ../newoutputs/t691
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/690.tr
echo ">>>>>>>>running test 692"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAFi.mat > ../newoutputs/t692
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/691.tr
echo ">>>>>>>>running test 693"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkADd.mat > ../newoutputs/t693
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/692.tr
echo ">>>>>>>>running test 694"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkADe.mat > ../newoutputs/t694
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/693.tr
echo ">>>>>>>>running test 695"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkADf.mat > ../newoutputs/t695
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/694.tr
echo ">>>>>>>>running test 696"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkADg.mat > ../newoutputs/t696
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/695.tr
echo ">>>>>>>>running test 697"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkADh.mat > ../newoutputs/t697
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/696.tr
echo ">>>>>>>>running test 698"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkADi.mat > ../newoutputs/t698
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/697.tr
echo ">>>>>>>>running test 699"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkADj.mat > ../newoutputs/t699
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/698.tr
echo ">>>>>>>>running test 700"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkADk.mat > ../newoutputs/t700
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/699.tr
echo ">>>>>>>>running test 701"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkADl.mat > ../newoutputs/t701
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/700.tr
echo ">>>>>>>>running test 702"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkADm.mat > ../newoutputs/t702
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/701.tr
echo ">>>>>>>>running test 703"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkADn.mat > ../newoutputs/t703
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/702.tr
echo ">>>>>>>>running test 704"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkADo.mat > ../newoutputs/t704
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/703.tr
echo ">>>>>>>>running test 705"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkADp.mat > ../newoutputs/t705
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/704.tr
echo ">>>>>>>>running test 706"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkADq.mat > ../newoutputs/t706
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/705.tr
echo ">>>>>>>>running test 707"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkADr.mat > ../newoutputs/t707
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/706.tr
echo ">>>>>>>>running test 708"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkADs.mat > ../newoutputs/t708
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/707.tr
echo ">>>>>>>>running test 709"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkADt.mat > ../newoutputs/t709
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/708.tr
echo ">>>>>>>>running test 710"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkADu.mat > ../newoutputs/t710
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/709.tr
echo ">>>>>>>>running test 711"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkADv.mat > ../newoutputs/t711
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/710.tr
echo ">>>>>>>>running test 712"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkADw.mat > ../newoutputs/t712
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/711.tr
echo ">>>>>>>>running test 713"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkADx.mat > ../newoutputs/t713
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/712.tr
echo ">>>>>>>>running test 714"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkADy.mat > ../newoutputs/t714
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/713.tr
echo ">>>>>>>>running test 715"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAEA.mat > ../newoutputs/t715
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/714.tr
echo ">>>>>>>>running test 716"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAEB.mat > ../newoutputs/t716
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/715.tr
echo ">>>>>>>>running test 717"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAEC.mat > ../newoutputs/t717
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/716.tr
echo ">>>>>>>>running test 718"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAED.mat > ../newoutputs/t718
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/717.tr
echo ">>>>>>>>running test 719"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAEE.mat > ../newoutputs/t719
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/718.tr
echo ">>>>>>>>running test 720"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAEF.mat > ../newoutputs/t720
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/719.tr
echo ">>>>>>>>running test 721"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAEG.mat > ../newoutputs/t721
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/720.tr
echo ">>>>>>>>running test 722"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAEH.mat > ../newoutputs/t722
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/721.tr
echo ">>>>>>>>running test 723"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkABT.mat > ../newoutputs/t723
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/722.tr
echo ">>>>>>>>running test 724"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkABU.mat > ../newoutputs/t724
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/723.tr
echo ">>>>>>>>running test 725"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkABV.mat > ../newoutputs/t725
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/724.tr
echo ">>>>>>>>running test 726"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkABW.mat > ../newoutputs/t726
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/725.tr
echo ">>>>>>>>running test 727"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkABX.mat > ../newoutputs/t727
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/726.tr
echo ">>>>>>>>running test 728"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkABY.mat > ../newoutputs/t728
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/727.tr
echo ">>>>>>>>running test 729"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkABZ.mat > ../newoutputs/t729
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/728.tr
echo ">>>>>>>>running test 730"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAB[.mat > ../newoutputs/t730
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/729.tr
echo ">>>>>>>>running test 731"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAB].mat > ../newoutputs/t731
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/730.tr
echo ">>>>>>>>running test 732"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAB_.mat > ../newoutputs/t732
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/731.tr
echo ">>>>>>>>running test 733"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkABa.mat > ../newoutputs/t733
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/732.tr
echo ">>>>>>>>running test 734"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkABb.mat > ../newoutputs/t734
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/733.tr
echo ">>>>>>>>running test 735"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkABc.mat > ../newoutputs/t735
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/734.tr
echo ">>>>>>>>running test 736"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkABd.mat > ../newoutputs/t736
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/735.tr
echo ">>>>>>>>running test 737"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkABe.mat > ../newoutputs/t737
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/736.tr
echo ">>>>>>>>running test 738"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkABf.mat > ../newoutputs/t738
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/737.tr
echo ">>>>>>>>running test 739"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkABg.mat > ../newoutputs/t739
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/738.tr
echo ">>>>>>>>running test 740"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAB_.mat > ../newoutputs/t740
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/739.tr
echo ">>>>>>>>running test 741"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkABa.mat > ../newoutputs/t741
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/740.tr
echo ">>>>>>>>running test 742"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkABb.mat > ../newoutputs/t742
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/741.tr
echo ">>>>>>>>running test 743"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkABc.mat > ../newoutputs/t743
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/742.tr
echo ">>>>>>>>running test 744"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkABd.mat > ../newoutputs/t744
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/743.tr
echo ">>>>>>>>running test 745"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkABe.mat > ../newoutputs/t745
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/744.tr
echo ">>>>>>>>running test 746"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkABf.mat > ../newoutputs/t746
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/745.tr
echo ">>>>>>>>running test 747"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkABg.mat > ../newoutputs/t747
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/746.tr
echo ">>>>>>>>running test 748"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkABh.mat > ../newoutputs/t748
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/747.tr
echo ">>>>>>>>running test 749"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkABi.mat > ../newoutputs/t749
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/748.tr
echo ">>>>>>>>running test 750"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkABj.mat > ../newoutputs/t750
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/749.tr
echo ">>>>>>>>running test 751"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkABk.mat > ../newoutputs/t751
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/750.tr
echo ">>>>>>>>running test 752"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkABl.mat > ../newoutputs/t752
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/751.tr
echo ">>>>>>>>running test 753"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkABm.mat > ../newoutputs/t753
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/752.tr
echo ">>>>>>>>running test 754"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkABn.mat > ../newoutputs/t754
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/753.tr
echo ">>>>>>>>running test 755"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkABo.mat > ../newoutputs/t755
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/754.tr
echo ">>>>>>>>running test 756"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkABp.mat > ../newoutputs/t756
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/755.tr
echo ">>>>>>>>running test 757"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAFi.mat > ../newoutputs/t757
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/756.tr
echo ">>>>>>>>running test 758"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkACC.mat > ../newoutputs/t758
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/757.tr
echo ">>>>>>>>running test 759"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkACD.mat > ../newoutputs/t759
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/758.tr
echo ">>>>>>>>running test 760"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkACE.mat > ../newoutputs/t760
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/759.tr
echo ">>>>>>>>running test 761"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkACF.mat > ../newoutputs/t761
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/760.tr
echo ">>>>>>>>running test 762"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkACG.mat > ../newoutputs/t762
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/761.tr
echo ">>>>>>>>running test 763"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkACH.mat > ../newoutputs/t763
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/762.tr
echo ">>>>>>>>running test 764"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkACI.mat > ../newoutputs/t764
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/763.tr
echo ">>>>>>>>running test 765"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkACJ.mat > ../newoutputs/t765
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/764.tr
echo ">>>>>>>>running test 766"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkACK.mat > ../newoutputs/t766
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/765.tr
echo ">>>>>>>>running test 767"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkACL.mat > ../newoutputs/t767
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/766.tr
echo ">>>>>>>>running test 768"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkACM.mat > ../newoutputs/t768
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/767.tr
echo ">>>>>>>>running test 769"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkACN.mat > ../newoutputs/t769
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/768.tr
echo ">>>>>>>>running test 770"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkACO.mat > ../newoutputs/t770
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/769.tr
echo ">>>>>>>>running test 771"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkACP.mat > ../newoutputs/t771
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/770.tr
echo ">>>>>>>>running test 772"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkACQ.mat > ../newoutputs/t772
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/771.tr
echo ">>>>>>>>running test 773"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkACR.mat > ../newoutputs/t773
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/772.tr
echo ">>>>>>>>running test 774"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkACS.mat > ../newoutputs/t774
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/773.tr
echo ">>>>>>>>running test 775"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkACT.mat > ../newoutputs/t775
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/774.tr
echo ">>>>>>>>running test 776"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkACU.mat > ../newoutputs/t776
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/775.tr
echo ">>>>>>>>running test 777"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkACV.mat > ../newoutputs/t777
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/776.tr
echo ">>>>>>>>running test 778"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkACW.mat > ../newoutputs/t778
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/777.tr
echo ">>>>>>>>running test 779"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkACX.mat > ../newoutputs/t779
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/778.tr
echo ">>>>>>>>running test 780"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkACY.mat > ../newoutputs/t780
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/779.tr
echo ">>>>>>>>running test 781"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkACZ.mat > ../newoutputs/t781
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/780.tr
echo ">>>>>>>>running test 782"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAC[.mat > ../newoutputs/t782
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/781.tr
echo ">>>>>>>>running test 783"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAC].mat > ../newoutputs/t783
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/782.tr
echo ">>>>>>>>running test 784"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAC_.mat > ../newoutputs/t784
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/783.tr
echo ">>>>>>>>running test 785"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkACa.mat > ../newoutputs/t785
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/784.tr
echo ">>>>>>>>running test 786"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkACb.mat > ../newoutputs/t786
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/785.tr
echo ">>>>>>>>running test 787"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkACc.mat > ../newoutputs/t787
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/786.tr
echo ">>>>>>>>running test 788"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkACd.mat > ../newoutputs/t788
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/787.tr
echo ">>>>>>>>running test 789"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkACe.mat > ../newoutputs/t789
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/788.tr
echo ">>>>>>>>running test 790"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkACf.mat > ../newoutputs/t790
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/789.tr
echo ">>>>>>>>running test 791"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkACg.mat > ../newoutputs/t791
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/790.tr
echo ">>>>>>>>running test 792"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkACh.mat > ../newoutputs/t792
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/791.tr
echo ">>>>>>>>running test 793"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkACi.mat > ../newoutputs/t793
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/792.tr
echo ">>>>>>>>running test 794"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkACj.mat > ../newoutputs/t794
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/793.tr
echo ">>>>>>>>running test 795"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAAK.mat > ../newoutputs/t795
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/794.tr
echo ">>>>>>>>running test 796"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAAL.mat > ../newoutputs/t796
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/795.tr
echo ">>>>>>>>running test 797"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAAM.mat > ../newoutputs/t797
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/796.tr
echo ">>>>>>>>running test 798"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAAN.mat > ../newoutputs/t798
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/797.tr
echo ">>>>>>>>running test 799"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAAO.mat > ../newoutputs/t799
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/798.tr
echo ">>>>>>>>running test 800"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAAP.mat > ../newoutputs/t800
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/799.tr
echo ">>>>>>>>running test 801"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAAQ.mat > ../newoutputs/t801
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/800.tr
echo ">>>>>>>>running test 802"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAAR.mat > ../newoutputs/t802
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/801.tr
echo ">>>>>>>>running test 803"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAAS.mat > ../newoutputs/t803
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/802.tr
echo ">>>>>>>>running test 804"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAAT.mat > ../newoutputs/t804
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/803.tr
echo ">>>>>>>>running test 805"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAAU.mat > ../newoutputs/t805
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/804.tr
echo ">>>>>>>>running test 806"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAAV.mat > ../newoutputs/t806
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/805.tr
echo ">>>>>>>>running test 807"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAAW.mat > ../newoutputs/t807
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/806.tr
echo ">>>>>>>>running test 808"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAAX.mat > ../newoutputs/t808
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/807.tr
echo ">>>>>>>>running test 809"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAAY.mat > ../newoutputs/t809
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/808.tr
echo ">>>>>>>>running test 810"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAAZ.mat > ../newoutputs/t810
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/809.tr
echo ">>>>>>>>running test 811"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAA[.mat > ../newoutputs/t811
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/810.tr
echo ">>>>>>>>running test 812"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAA].mat > ../newoutputs/t812
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/811.tr
echo ">>>>>>>>running test 813"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAA_.mat > ../newoutputs/t813
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/812.tr
echo ">>>>>>>>running test 814"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAAa.mat > ../newoutputs/t814
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/813.tr
echo ">>>>>>>>running test 815"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAAb.mat > ../newoutputs/t815
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/814.tr
echo ">>>>>>>>running test 816"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAAc.mat > ../newoutputs/t816
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/815.tr
echo ">>>>>>>>running test 817"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAAd.mat > ../newoutputs/t817
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/816.tr
echo ">>>>>>>>running test 818"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAAe.mat > ../newoutputs/t818
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/817.tr
echo ">>>>>>>>running test 819"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAAf.mat > ../newoutputs/t819
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/818.tr
echo ">>>>>>>>running test 820"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAAg.mat > ../newoutputs/t820
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/819.tr
echo ">>>>>>>>running test 821"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAAh.mat > ../newoutputs/t821
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/820.tr
echo ">>>>>>>>running test 822"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAAi.mat > ../newoutputs/t822
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/821.tr
echo ">>>>>>>>running test 823"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAAj.mat > ../newoutputs/t823
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/822.tr
echo ">>>>>>>>running test 824"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAAk.mat > ../newoutputs/t824
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/823.tr
echo ">>>>>>>>running test 825"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAAl.mat > ../newoutputs/t825
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/824.tr
echo ">>>>>>>>running test 826"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAAm.mat > ../newoutputs/t826
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/825.tr
echo ">>>>>>>>running test 827"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAAn.mat > ../newoutputs/t827
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/826.tr
echo ">>>>>>>>running test 828"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAAo.mat > ../newoutputs/t828
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/827.tr
echo ">>>>>>>>running test 829"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAAp.mat > ../newoutputs/t829
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/828.tr
echo ">>>>>>>>running test 830"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAAq.mat > ../newoutputs/t830
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/829.tr
echo ">>>>>>>>running test 831"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAAr.mat > ../newoutputs/t831
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/830.tr
echo ">>>>>>>>running test 832"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAAs.mat > ../newoutputs/t832
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/831.tr
echo ">>>>>>>>running test 833"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAAt.mat > ../newoutputs/t833
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/832.tr
echo ">>>>>>>>running test 834"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAAu.mat > ../newoutputs/t834
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/833.tr
echo ">>>>>>>>running test 835"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAAv.mat > ../newoutputs/t835
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/834.tr
echo ">>>>>>>>running test 836"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAAw.mat > ../newoutputs/t836
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/835.tr
echo ">>>>>>>>running test 837"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAAx.mat > ../newoutputs/t837
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/836.tr
echo ">>>>>>>>running test 838"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkAAy.mat > ../newoutputs/t838
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/837.tr
echo ">>>>>>>>running test 839"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkABA.mat > ../newoutputs/t839
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/838.tr
echo ">>>>>>>>running test 840"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkABB.mat > ../newoutputs/t840
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/839.tr
echo ">>>>>>>>running test 841"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkABC.mat > ../newoutputs/t841
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/840.tr
echo ">>>>>>>>running test 842"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkABD.mat > ../newoutputs/t842
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/841.tr
echo ">>>>>>>>running test 843"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkABE.mat > ../newoutputs/t843
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/842.tr
echo ">>>>>>>>running test 844"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkABF.mat > ../newoutputs/t844
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/843.tr
echo ">>>>>>>>running test 845"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkABG.mat > ../newoutputs/t845
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/844.tr
echo ">>>>>>>>running test 846"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkABH.mat > ../newoutputs/t846
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/845.tr
echo ">>>>>>>>running test 847"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkABI.mat > ../newoutputs/t847
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/846.tr
echo ">>>>>>>>running test 848"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkABJ.mat > ../newoutputs/t848
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/847.tr
echo ">>>>>>>>running test 849"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkABK.mat > ../newoutputs/t849
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/848.tr
echo ">>>>>>>>running test 850"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkABL.mat > ../newoutputs/t850
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/849.tr
echo ">>>>>>>>running test 851"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkABM.mat > ../newoutputs/t851
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/850.tr
echo ">>>>>>>>running test 852"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkABN.mat > ../newoutputs/t852
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/851.tr
echo ">>>>>>>>running test 853"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkABO.mat > ../newoutputs/t853
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/852.tr
echo ">>>>>>>>running test 854"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkABP.mat > ../newoutputs/t854
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/853.tr
echo ">>>>>>>>running test 855"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkABQ.mat > ../newoutputs/t855
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/854.tr
echo ">>>>>>>>running test 856"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkABR.mat > ../newoutputs/t856
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/855.tr
echo ">>>>>>>>running test 857"
../source/tot_info.c.inst.exe  < ../inputs/universe/jkABS.mat > ../newoutputs/t857
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/856.tr
echo ">>>>>>>>running test 858"
../source/tot_info.c.inst.exe  < ../inputs/universe/new1 > ../newoutputs/t858
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/857.tr
echo ">>>>>>>>running test 859"
../source/tot_info.c.inst.exe  < ../inputs/universe/new10 > ../newoutputs/t859
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/858.tr
echo ">>>>>>>>running test 860"
../source/tot_info.c.inst.exe  < ../inputs/universe/new11 > ../newoutputs/t860
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/859.tr
echo ">>>>>>>>running test 861"
../source/tot_info.c.inst.exe  < ../inputs/universe/new12 > ../newoutputs/t861
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/860.tr
echo ">>>>>>>>running test 862"
../source/tot_info.c.inst.exe  < ../inputs/universe/new13 > ../newoutputs/t862
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/861.tr
echo ">>>>>>>>running test 863"
../source/tot_info.c.inst.exe  < ../inputs/universe/new14 > ../newoutputs/t863
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/862.tr
echo ">>>>>>>>running test 864"
../source/tot_info.c.inst.exe  < ../inputs/universe/new15 > ../newoutputs/t864
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/863.tr
echo ">>>>>>>>running test 865"
../source/tot_info.c.inst.exe  < ../inputs/universe/new16 > ../newoutputs/t865
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/864.tr
echo ">>>>>>>>running test 866"
../source/tot_info.c.inst.exe  < ../inputs/universe/new17 > ../newoutputs/t866
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/865.tr
echo ">>>>>>>>running test 867"
../source/tot_info.c.inst.exe  < ../inputs/universe/new18 > ../newoutputs/t867
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/866.tr
echo ">>>>>>>>running test 868"
../source/tot_info.c.inst.exe  < ../inputs/universe/new19 > ../newoutputs/t868
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/867.tr
echo ">>>>>>>>running test 869"
../source/tot_info.c.inst.exe  < ../inputs/universe/new2 > ../newoutputs/t869
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/868.tr
echo ">>>>>>>>running test 870"
../source/tot_info.c.inst.exe  < ../inputs/universe/new20 > ../newoutputs/t870
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/869.tr
echo ">>>>>>>>running test 871"
../source/tot_info.c.inst.exe  < ../inputs/universe/new21 > ../newoutputs/t871
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/870.tr
echo ">>>>>>>>running test 872"
../source/tot_info.c.inst.exe  < ../inputs/universe/new22 > ../newoutputs/t872
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/871.tr
echo ">>>>>>>>running test 873"
../source/tot_info.c.inst.exe  < ../inputs/universe/new23 > ../newoutputs/t873
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/872.tr
echo ">>>>>>>>running test 874"
../source/tot_info.c.inst.exe  < ../inputs/universe/new24 > ../newoutputs/t874
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/873.tr
echo ">>>>>>>>running test 875"
../source/tot_info.c.inst.exe  < ../inputs/universe/new25 > ../newoutputs/t875
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/874.tr
echo ">>>>>>>>running test 876"
../source/tot_info.c.inst.exe  < ../inputs/universe/new26 > ../newoutputs/t876
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/875.tr
echo ">>>>>>>>running test 877"
../source/tot_info.c.inst.exe  < ../inputs/universe/new27 > ../newoutputs/t877
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/876.tr
echo ">>>>>>>>running test 878"
../source/tot_info.c.inst.exe  < ../inputs/universe/new28 > ../newoutputs/t878
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/877.tr
echo ">>>>>>>>running test 879"
../source/tot_info.c.inst.exe  < ../inputs/universe/new29 > ../newoutputs/t879
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/878.tr
echo ">>>>>>>>running test 880"
../source/tot_info.c.inst.exe  < ../inputs/universe/new3 > ../newoutputs/t880
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/879.tr
echo ">>>>>>>>running test 881"
../source/tot_info.c.inst.exe  < ../inputs/universe/new30 > ../newoutputs/t881
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/880.tr
echo ">>>>>>>>running test 882"
../source/tot_info.c.inst.exe  < ../inputs/universe/new31 > ../newoutputs/t882
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/881.tr
echo ">>>>>>>>running test 883"
../source/tot_info.c.inst.exe  < ../inputs/universe/new32 > ../newoutputs/t883
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/882.tr
echo ">>>>>>>>running test 884"
../source/tot_info.c.inst.exe  < ../inputs/universe/new33 > ../newoutputs/t884
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/883.tr
echo ">>>>>>>>running test 885"
../source/tot_info.c.inst.exe  < ../inputs/universe/new34 > ../newoutputs/t885
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/884.tr
echo ">>>>>>>>running test 886"
../source/tot_info.c.inst.exe  < ../inputs/universe/new35 > ../newoutputs/t886
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/885.tr
echo ">>>>>>>>running test 887"
../source/tot_info.c.inst.exe  < ../inputs/universe/new36 > ../newoutputs/t887
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/886.tr
echo ">>>>>>>>running test 888"
../source/tot_info.c.inst.exe  < ../inputs/universe/new37 > ../newoutputs/t888
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/887.tr
echo ">>>>>>>>running test 889"
../source/tot_info.c.inst.exe  < ../inputs/universe/new38 > ../newoutputs/t889
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/888.tr
echo ">>>>>>>>running test 890"
../source/tot_info.c.inst.exe  < ../inputs/universe/new39 > ../newoutputs/t890
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/889.tr
echo ">>>>>>>>running test 891"
../source/tot_info.c.inst.exe  < ../inputs/universe/new4 > ../newoutputs/t891
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/890.tr
echo ">>>>>>>>running test 892"
../source/tot_info.c.inst.exe  < ../inputs/universe/new40 > ../newoutputs/t892
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/891.tr
echo ">>>>>>>>running test 893"
../source/tot_info.c.inst.exe  < ../inputs/universe/new5 > ../newoutputs/t893
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/892.tr
echo ">>>>>>>>running test 894"
../source/tot_info.c.inst.exe  < ../inputs/universe/new6 > ../newoutputs/t894
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/893.tr
echo ">>>>>>>>running test 895"
../source/tot_info.c.inst.exe  < ../inputs/universe/new7 > ../newoutputs/t895
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/894.tr
echo ">>>>>>>>running test 896"
../source/tot_info.c.inst.exe  < ../inputs/universe/new8 > ../newoutputs/t896
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/895.tr
echo ">>>>>>>>running test 897"
../source/tot_info.c.inst.exe  < ../inputs/universe/new9 > ../newoutputs/t897
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/896.tr
echo ">>>>>>>>running test 898"
../source/tot_info.c.inst.exe  < ../inputs/universe/ntest12 > ../newoutputs/t898
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/897.tr
echo ">>>>>>>>running test 899"
../source/tot_info.c.inst.exe  < ../inputs/universe/ntest13 > ../newoutputs/t899
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/898.tr
echo ">>>>>>>>running test 900"
../source/tot_info.c.inst.exe  < ../inputs/universe/ntest14 > ../newoutputs/t900
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/899.tr
echo ">>>>>>>>running test 901"
../source/tot_info.c.inst.exe  < ../inputs/universe/ntest15 > ../newoutputs/t901
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/900.tr
echo ">>>>>>>>running test 902"
../source/tot_info.c.inst.exe  < ../inputs/universe/ntest16 > ../newoutputs/t902
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/901.tr
echo ">>>>>>>>running test 903"
../source/tot_info.c.inst.exe  < ../inputs/universe/ntest17 > ../newoutputs/t903
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/902.tr
echo ">>>>>>>>running test 904"
../source/tot_info.c.inst.exe  < ../inputs/universe/ntest18 > ../newoutputs/t904
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/903.tr
echo ">>>>>>>>running test 905"
../source/tot_info.c.inst.exe  < ../inputs/universe/ntest19 > ../newoutputs/t905
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/904.tr
echo ">>>>>>>>running test 906"
../source/tot_info.c.inst.exe  < ../inputs/universe/ntest2 > ../newoutputs/t906
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/905.tr
echo ">>>>>>>>running test 907"
../source/tot_info.c.inst.exe  < ../inputs/universe/ntest20 > ../newoutputs/t907
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/906.tr
echo ">>>>>>>>running test 908"
../source/tot_info.c.inst.exe  < ../inputs/universe/ntest21 > ../newoutputs/t908
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/907.tr
echo ">>>>>>>>running test 909"
../source/tot_info.c.inst.exe  < ../inputs/universe/ntest22 > ../newoutputs/t909
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/908.tr
echo ">>>>>>>>running test 910"
../source/tot_info.c.inst.exe  < ../inputs/universe/ntest23 > ../newoutputs/t910
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/909.tr
echo ">>>>>>>>running test 911"
../source/tot_info.c.inst.exe  < ../inputs/universe/ntest24 > ../newoutputs/t911
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/910.tr
echo ">>>>>>>>running test 912"
../source/tot_info.c.inst.exe  < ../inputs/universe/ntest25 > ../newoutputs/t912
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/911.tr
echo ">>>>>>>>running test 913"
../source/tot_info.c.inst.exe  < ../inputs/universe/ntest26 > ../newoutputs/t913
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/912.tr
echo ">>>>>>>>running test 914"
../source/tot_info.c.inst.exe  < ../inputs/universe/ntest27 > ../newoutputs/t914
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/913.tr
echo ">>>>>>>>running test 915"
../source/tot_info.c.inst.exe  < ../inputs/universe/ntest28 > ../newoutputs/t915
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/914.tr
echo ">>>>>>>>running test 916"
../source/tot_info.c.inst.exe  < ../inputs/universe/ntest29 > ../newoutputs/t916
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/915.tr
echo ">>>>>>>>running test 917"
../source/tot_info.c.inst.exe  < ../inputs/universe/ntest3 > ../newoutputs/t917
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/916.tr
echo ">>>>>>>>running test 918"
../source/tot_info.c.inst.exe  < ../inputs/universe/ntest30 > ../newoutputs/t918
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/917.tr
echo ">>>>>>>>running test 919"
../source/tot_info.c.inst.exe  < ../inputs/universe/ntest31 > ../newoutputs/t919
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/918.tr
echo ">>>>>>>>running test 920"
../source/tot_info.c.inst.exe  < ../inputs/universe/ntest32 > ../newoutputs/t920
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/919.tr
echo ">>>>>>>>running test 921"
../source/tot_info.c.inst.exe  < ../inputs/universe/ntest33 > ../newoutputs/t921
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/920.tr
echo ">>>>>>>>running test 922"
../source/tot_info.c.inst.exe  < ../inputs/universe/ntest35 > ../newoutputs/t922
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/921.tr
echo ">>>>>>>>running test 923"
../source/tot_info.c.inst.exe  < ../inputs/universe/ntest36 > ../newoutputs/t923
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/922.tr
echo ">>>>>>>>running test 924"
../source/tot_info.c.inst.exe  < ../inputs/universe/ntest37 > ../newoutputs/t924
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/923.tr
echo ">>>>>>>>running test 925"
../source/tot_info.c.inst.exe  < ../inputs/universe/ntest38 > ../newoutputs/t925
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/924.tr
echo ">>>>>>>>running test 926"
../source/tot_info.c.inst.exe  < ../inputs/universe/ntest39 > ../newoutputs/t926
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/925.tr
echo ">>>>>>>>running test 927"
../source/tot_info.c.inst.exe  < ../inputs/universe/ntest4 > ../newoutputs/t927
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/926.tr
echo ">>>>>>>>running test 928"
../source/tot_info.c.inst.exe  < ../inputs/universe/ntest40 > ../newoutputs/t928
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/927.tr
echo ">>>>>>>>running test 929"
../source/tot_info.c.inst.exe  < ../inputs/universe/ntest41 > ../newoutputs/t929
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/928.tr
echo ">>>>>>>>running test 930"
../source/tot_info.c.inst.exe  < ../inputs/universe/ntest42 > ../newoutputs/t930
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/929.tr
echo ">>>>>>>>running test 931"
../source/tot_info.c.inst.exe  < ../inputs/universe/ntest43 > ../newoutputs/t931
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/930.tr
echo ">>>>>>>>running test 932"
../source/tot_info.c.inst.exe  < ../inputs/universe/ntest44 > ../newoutputs/t932
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/931.tr
echo ">>>>>>>>running test 933"
../source/tot_info.c.inst.exe  < ../inputs/universe/ntest45 > ../newoutputs/t933
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/932.tr
echo ">>>>>>>>running test 934"
../source/tot_info.c.inst.exe  < ../inputs/universe/ntest46 > ../newoutputs/t934
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/933.tr
echo ">>>>>>>>running test 935"
../source/tot_info.c.inst.exe  < ../inputs/universe/ntest48 > ../newoutputs/t935
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/934.tr
echo ">>>>>>>>running test 936"
../source/tot_info.c.inst.exe  < ../inputs/universe/ntest49 > ../newoutputs/t936
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/935.tr
echo ">>>>>>>>running test 937"
../source/tot_info.c.inst.exe  < ../inputs/universe/ntest5 > ../newoutputs/t937
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/936.tr
echo ">>>>>>>>running test 938"
../source/tot_info.c.inst.exe  < ../inputs/universe/ntest50 > ../newoutputs/t938
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/937.tr
echo ">>>>>>>>running test 939"
../source/tot_info.c.inst.exe  < ../inputs/universe/ntest51 > ../newoutputs/t939
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/938.tr
echo ">>>>>>>>running test 940"
../source/tot_info.c.inst.exe  < ../inputs/universe/ntest52 > ../newoutputs/t940
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/939.tr
echo ">>>>>>>>running test 941"
../source/tot_info.c.inst.exe  < ../inputs/universe/ntest53 > ../newoutputs/t941
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/940.tr
echo ">>>>>>>>running test 942"
../source/tot_info.c.inst.exe  < ../inputs/universe/ntest54 > ../newoutputs/t942
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/941.tr
echo ">>>>>>>>running test 943"
../source/tot_info.c.inst.exe  < ../inputs/universe/ntest55 > ../newoutputs/t943
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/942.tr
echo ">>>>>>>>running test 944"
../source/tot_info.c.inst.exe  < ../inputs/universe/ntest56 > ../newoutputs/t944
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/943.tr
echo ">>>>>>>>running test 945"
../source/tot_info.c.inst.exe  < ../inputs/universe/ntest57 > ../newoutputs/t945
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/944.tr
echo ">>>>>>>>running test 946"
../source/tot_info.c.inst.exe  < ../inputs/universe/ntest6 > ../newoutputs/t946
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/945.tr
echo ">>>>>>>>running test 947"
../source/tot_info.c.inst.exe  < ../inputs/universe/ntest7 > ../newoutputs/t947
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/946.tr
echo ">>>>>>>>running test 948"
../source/tot_info.c.inst.exe  < ../inputs/universe/ntest9 > ../newoutputs/t948
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/947.tr
echo ">>>>>>>>running test 949"
../source/tot_info.c.inst.exe  < ../inputs/universe/bnew1 > ../newoutputs/t949
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/948.tr
echo ">>>>>>>>running test 950"
../source/tot_info.c.inst.exe  < ../inputs/universe/bnew10 > ../newoutputs/t950
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/949.tr
echo ">>>>>>>>running test 951"
../source/tot_info.c.inst.exe  < ../inputs/universe/bnew11 > ../newoutputs/t951
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/950.tr
echo ">>>>>>>>running test 952"
../source/tot_info.c.inst.exe  < ../inputs/universe/bnew12 > ../newoutputs/t952
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/951.tr
echo ">>>>>>>>running test 953"
../source/tot_info.c.inst.exe  < ../inputs/universe/bnew13 > ../newoutputs/t953
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/952.tr
echo ">>>>>>>>running test 954"
../source/tot_info.c.inst.exe  < ../inputs/universe/bnew14 > ../newoutputs/t954
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/953.tr
echo ">>>>>>>>running test 955"
../source/tot_info.c.inst.exe  < ../inputs/universe/bnew15 > ../newoutputs/t955
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/954.tr
echo ">>>>>>>>running test 956"
../source/tot_info.c.inst.exe  < ../inputs/universe/bnew16 > ../newoutputs/t956
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/955.tr
echo ">>>>>>>>running test 957"
../source/tot_info.c.inst.exe  < ../inputs/universe/bnew17 > ../newoutputs/t957
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/956.tr
echo ">>>>>>>>running test 958"
../source/tot_info.c.inst.exe  < ../inputs/universe/bnew18 > ../newoutputs/t958
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/957.tr
echo ">>>>>>>>running test 959"
../source/tot_info.c.inst.exe  < ../inputs/universe/bnew19 > ../newoutputs/t959
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/958.tr
echo ">>>>>>>>running test 960"
../source/tot_info.c.inst.exe  < ../inputs/universe/bnew2 > ../newoutputs/t960
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/959.tr
echo ">>>>>>>>running test 961"
../source/tot_info.c.inst.exe  < ../inputs/universe/bnew20 > ../newoutputs/t961
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/960.tr
echo ">>>>>>>>running test 962"
../source/tot_info.c.inst.exe  < ../inputs/universe/bnew21 > ../newoutputs/t962
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/961.tr
echo ">>>>>>>>running test 963"
../source/tot_info.c.inst.exe  < ../inputs/universe/bnew22 > ../newoutputs/t963
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/962.tr
echo ">>>>>>>>running test 964"
../source/tot_info.c.inst.exe  < ../inputs/universe/bnew23 > ../newoutputs/t964
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/963.tr
echo ">>>>>>>>running test 965"
../source/tot_info.c.inst.exe  < ../inputs/universe/bnew24 > ../newoutputs/t965
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/964.tr
echo ">>>>>>>>running test 966"
../source/tot_info.c.inst.exe  < ../inputs/universe/bnew25 > ../newoutputs/t966
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/965.tr
echo ">>>>>>>>running test 967"
../source/tot_info.c.inst.exe  < ../inputs/universe/bnew26 > ../newoutputs/t967
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/966.tr
echo ">>>>>>>>running test 968"
../source/tot_info.c.inst.exe  < ../inputs/universe/bnew27 > ../newoutputs/t968
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/967.tr
echo ">>>>>>>>running test 969"
../source/tot_info.c.inst.exe  < ../inputs/universe/bnew3 > ../newoutputs/t969
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/968.tr
echo ">>>>>>>>running test 970"
../source/tot_info.c.inst.exe  < ../inputs/universe/bnew4 > ../newoutputs/t970
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/969.tr
echo ">>>>>>>>running test 971"
../source/tot_info.c.inst.exe  < ../inputs/universe/bnew5 > ../newoutputs/t971
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/970.tr
echo ">>>>>>>>running test 972"
../source/tot_info.c.inst.exe  < ../inputs/universe/bnew6 > ../newoutputs/t972
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/971.tr
echo ">>>>>>>>running test 973"
../source/tot_info.c.inst.exe  < ../inputs/universe/bnew7 > ../newoutputs/t973
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/972.tr
echo ">>>>>>>>running test 974"
../source/tot_info.c.inst.exe  < ../inputs/universe/bnew8 > ../newoutputs/t974
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/973.tr
echo ">>>>>>>>running test 975"
../source/tot_info.c.inst.exe  < ../inputs/universe/bnew9 > ../newoutputs/t975
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/974.tr
echo ">>>>>>>>running test 976"
../source/tot_info.c.inst.exe  < ../inputs/universe/bnewt1 > ../newoutputs/t976
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/975.tr
echo ">>>>>>>>running test 977"
../source/tot_info.c.inst.exe  < ../inputs/universe/bnewt10 > ../newoutputs/t977
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/976.tr
echo ">>>>>>>>running test 978"
../source/tot_info.c.inst.exe  < ../inputs/universe/bnewt11 > ../newoutputs/t978
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/977.tr
echo ">>>>>>>>running test 979"
../source/tot_info.c.inst.exe  < ../inputs/universe/bnewt12 > ../newoutputs/t979
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/978.tr
echo ">>>>>>>>running test 980"
../source/tot_info.c.inst.exe  < ../inputs/universe/bnewt13 > ../newoutputs/t980
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/979.tr
echo ">>>>>>>>running test 981"
../source/tot_info.c.inst.exe  < ../inputs/universe/bnewt14 > ../newoutputs/t981
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/980.tr
echo ">>>>>>>>running test 982"
../source/tot_info.c.inst.exe  < ../inputs/universe/bnewt15 > ../newoutputs/t982
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/981.tr
echo ">>>>>>>>running test 983"
../source/tot_info.c.inst.exe  < ../inputs/universe/bnewt16 > ../newoutputs/t983
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/982.tr
echo ">>>>>>>>running test 984"
../source/tot_info.c.inst.exe  < ../inputs/universe/bnewt2 > ../newoutputs/t984
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/983.tr
echo ">>>>>>>>running test 985"
../source/tot_info.c.inst.exe  < ../inputs/universe/bnewt3 > ../newoutputs/t985
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/984.tr
echo ">>>>>>>>running test 986"
../source/tot_info.c.inst.exe  < ../inputs/universe/bnewt4 > ../newoutputs/t986
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/985.tr
echo ">>>>>>>>running test 987"
../source/tot_info.c.inst.exe  < ../inputs/universe/bnewt5 > ../newoutputs/t987
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/986.tr
echo ">>>>>>>>running test 988"
../source/tot_info.c.inst.exe  < ../inputs/universe/bnewt6 > ../newoutputs/t988
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/987.tr
echo ">>>>>>>>running test 989"
../source/tot_info.c.inst.exe  < ../inputs/universe/bnewt7 > ../newoutputs/t989
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/988.tr
echo ">>>>>>>>running test 990"
../source/tot_info.c.inst.exe  < ../inputs/universe/bnewt8 > ../newoutputs/t990
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/989.tr
echo ">>>>>>>>running test 991"
../source/tot_info.c.inst.exe  < ../inputs/universe/bnewt9 > ../newoutputs/t991
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/990.tr
echo ">>>>>>>>running test 992"
../source/tot_info.c.inst.exe  < ../inputs/universe/12new1 > ../newoutputs/t992
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/991.tr
echo ">>>>>>>>running test 993"
../source/tot_info.c.inst.exe  < ../inputs/universe/12new10 > ../newoutputs/t993
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/992.tr
echo ">>>>>>>>running test 994"
../source/tot_info.c.inst.exe  < ../inputs/universe/12new11 > ../newoutputs/t994
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/993.tr
echo ">>>>>>>>running test 995"
../source/tot_info.c.inst.exe  < ../inputs/universe/12new12 > ../newoutputs/t995
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/994.tr
echo ">>>>>>>>running test 996"
../source/tot_info.c.inst.exe  < ../inputs/universe/12new13 > ../newoutputs/t996
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/995.tr
echo ">>>>>>>>running test 997"
../source/tot_info.c.inst.exe  < ../inputs/universe/12new14 > ../newoutputs/t997
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/996.tr
echo ">>>>>>>>running test 998"
../source/tot_info.c.inst.exe  < ../inputs/universe/12new15 > ../newoutputs/t998
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/997.tr
echo ">>>>>>>>running test 999"
../source/tot_info.c.inst.exe  < ../inputs/universe/12new16 > ../newoutputs/t999
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/998.tr
echo ">>>>>>>>running test 1000"
../source/tot_info.c.inst.exe  < ../inputs/universe/12new17 > ../newoutputs/t1000
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/999.tr
echo ">>>>>>>>running test 1001"
../source/tot_info.c.inst.exe  < ../inputs/universe/12new18 > ../newoutputs/t1001
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/1000.tr
echo ">>>>>>>>running test 1002"
../source/tot_info.c.inst.exe  < ../inputs/universe/12new19 > ../newoutputs/t1002
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/1001.tr
echo ">>>>>>>>running test 1003"
../source/tot_info.c.inst.exe  < ../inputs/universe/12new2 > ../newoutputs/t1003
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/1002.tr
echo ">>>>>>>>running test 1004"
../source/tot_info.c.inst.exe  < ../inputs/universe/12new20 > ../newoutputs/t1004
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/1003.tr
echo ">>>>>>>>running test 1005"
../source/tot_info.c.inst.exe  < ../inputs/universe/12new21 > ../newoutputs/t1005
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/1004.tr
echo ">>>>>>>>running test 1006"
../source/tot_info.c.inst.exe  < ../inputs/universe/12new22 > ../newoutputs/t1006
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/1005.tr
echo ">>>>>>>>running test 1007"
../source/tot_info.c.inst.exe  < ../inputs/universe/12new23 > ../newoutputs/t1007
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/1006.tr
echo ">>>>>>>>running test 1008"
../source/tot_info.c.inst.exe  < ../inputs/universe/12new24 > ../newoutputs/t1008
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/1007.tr
echo ">>>>>>>>running test 1009"
../source/tot_info.c.inst.exe  < ../inputs/universe/12new25 > ../newoutputs/t1009
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/1008.tr
echo ">>>>>>>>running test 1010"
../source/tot_info.c.inst.exe  < ../inputs/universe/12new26 > ../newoutputs/t1010
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/1009.tr
echo ">>>>>>>>running test 1011"
../source/tot_info.c.inst.exe  < ../inputs/universe/12new27 > ../newoutputs/t1011
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/1010.tr
echo ">>>>>>>>running test 1012"
../source/tot_info.c.inst.exe  < ../inputs/universe/12new28 > ../newoutputs/t1012
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/1011.tr
echo ">>>>>>>>running test 1013"
../source/tot_info.c.inst.exe  < ../inputs/universe/12new29 > ../newoutputs/t1013
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/1012.tr
echo ">>>>>>>>running test 1014"
../source/tot_info.c.inst.exe  < ../inputs/universe/12new3 > ../newoutputs/t1014
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/1013.tr
echo ">>>>>>>>running test 1015"
../source/tot_info.c.inst.exe  < ../inputs/universe/12new30 > ../newoutputs/t1015
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/1014.tr
echo ">>>>>>>>running test 1016"
../source/tot_info.c.inst.exe  < ../inputs/universe/12new31 > ../newoutputs/t1016
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/1015.tr
echo ">>>>>>>>running test 1017"
../source/tot_info.c.inst.exe  < ../inputs/universe/12new32 > ../newoutputs/t1017
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/1016.tr
echo ">>>>>>>>running test 1018"
../source/tot_info.c.inst.exe  < ../inputs/universe/12new33 > ../newoutputs/t1018
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/1017.tr
echo ">>>>>>>>running test 1019"
../source/tot_info.c.inst.exe  < ../inputs/universe/12new34 > ../newoutputs/t1019
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/1018.tr
echo ">>>>>>>>running test 1020"
../source/tot_info.c.inst.exe  < ../inputs/universe/12new35 > ../newoutputs/t1020
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/1019.tr
echo ">>>>>>>>running test 1021"
../source/tot_info.c.inst.exe  < ../inputs/universe/12new36 > ../newoutputs/t1021
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/1020.tr
echo ">>>>>>>>running test 1022"
../source/tot_info.c.inst.exe  < ../inputs/universe/12new37 > ../newoutputs/t1022
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/1021.tr
echo ">>>>>>>>running test 1023"
../source/tot_info.c.inst.exe  < ../inputs/universe/12new38 > ../newoutputs/t1023
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/1022.tr
echo ">>>>>>>>running test 1024"
../source/tot_info.c.inst.exe  < ../inputs/universe/12new39 > ../newoutputs/t1024
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/1023.tr
echo ">>>>>>>>running test 1025"
../source/tot_info.c.inst.exe  < ../inputs/universe/12new4 > ../newoutputs/t1025
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/1024.tr
echo ">>>>>>>>running test 1026"
../source/tot_info.c.inst.exe  < ../inputs/universe/12new40 > ../newoutputs/t1026
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/1025.tr
echo ">>>>>>>>running test 1027"
../source/tot_info.c.inst.exe  < ../inputs/universe/12new5 > ../newoutputs/t1027
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/1026.tr
echo ">>>>>>>>running test 1028"
../source/tot_info.c.inst.exe  < ../inputs/universe/12new6 > ../newoutputs/t1028
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/1027.tr
echo ">>>>>>>>running test 1029"
../source/tot_info.c.inst.exe  < ../inputs/universe/12new7 > ../newoutputs/t1029
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/1028.tr
echo ">>>>>>>>running test 1030"
../source/tot_info.c.inst.exe  < ../inputs/universe/12new8 > ../newoutputs/t1030
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/1029.tr
echo ">>>>>>>>running test 1031"
../source/tot_info.c.inst.exe  < ../inputs/universe/12new9 > ../newoutputs/t1031
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/1030.tr
echo ">>>>>>>>running test 1032"
../source/tot_info.c.inst.exe  < ../inputs/universe/12new40 > ../newoutputs/t1032
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/1031.tr
echo ">>>>>>>>running test 1033"
../source/tot_info.c.inst.exe  < ../inputs/universe/12new41 > ../newoutputs/t1033
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/1032.tr
echo ">>>>>>>>running test 1034"
../source/tot_info.c.inst.exe  < ../inputs/universe/12new42 > ../newoutputs/t1034
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/1033.tr
echo ">>>>>>>>running test 1035"
../source/tot_info.c.inst.exe  < ../inputs/universe/12new43 > ../newoutputs/t1035
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/1034.tr
echo ">>>>>>>>running test 1036"
../source/tot_info.c.inst.exe  < ../inputs/universe/12new44 > ../newoutputs/t1036
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/1035.tr
echo ">>>>>>>>running test 1037"
../source/tot_info.c.inst.exe  < ../inputs/universe/12new45 > ../newoutputs/t1037
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/1036.tr
echo ">>>>>>>>running test 1038"
../source/tot_info.c.inst.exe  < ../inputs/universe/12new46 > ../newoutputs/t1038
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/1037.tr
echo ">>>>>>>>running test 1039"
../source/tot_info.c.inst.exe  < ../inputs/universe/12new47 > ../newoutputs/t1039
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/1038.tr
echo ">>>>>>>>running test 1040"
../source/tot_info.c.inst.exe  < ../inputs/universe/12new48 > ../newoutputs/t1040
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/1039.tr
echo ">>>>>>>>running test 1041"
../source/tot_info.c.inst.exe  < ../inputs/universe/12new49 > ../newoutputs/t1041
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/1040.tr
echo ">>>>>>>>running test 1042"
../source/tot_info.c.inst.exe  < ../inputs/universe/12new50 > ../newoutputs/t1042
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/1041.tr
echo ">>>>>>>>running test 1043"
../source/tot_info.c.inst.exe  < ../inputs/universe/12new51 > ../newoutputs/t1043
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/1042.tr
echo ">>>>>>>>running test 1044"
../source/tot_info.c.inst.exe  < ../inputs/universe/12new52 > ../newoutputs/t1044
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/1043.tr
echo ">>>>>>>>running test 1045"
../source/tot_info.c.inst.exe  < ../inputs/universe/12new53 > ../newoutputs/t1045
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/1044.tr
echo ">>>>>>>>running test 1046"
../source/tot_info.c.inst.exe  < ../inputs/universe/12new54 > ../newoutputs/t1046
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/1045.tr
echo ">>>>>>>>running test 1047"
../source/tot_info.c.inst.exe  < ../inputs/universe/12new55 > ../newoutputs/t1047
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/1046.tr
echo ">>>>>>>>running test 1048"
../source/tot_info.c.inst.exe  < ../inputs/universe/12new56 > ../newoutputs/t1048
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/1047.tr
echo ">>>>>>>>running test 1049"
../source/tot_info.c.inst.exe  < ../inputs/universe/12new57 > ../newoutputs/t1049
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/1048.tr
echo ">>>>>>>>running test 1050"
../source/tot_info.c.inst.exe  < ../inputs/universe/12new58 > ../newoutputs/t1050
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/1049.tr
echo ">>>>>>>>running test 1051"
../source/tot_info.c.inst.exe  < ../inputs/universe/12new59 > ../newoutputs/t1051
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/1050.tr
echo ">>>>>>>>running test 1052"
../source/tot_info.c.inst.exe  < ../inputs/universe/12new60 > ../newoutputs/t1052
cp $ARISTOTLE_DB_DIR/tot_info.c.tr ../traces/1051.tr
