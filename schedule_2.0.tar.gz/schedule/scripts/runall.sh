echo script type: R
echo ">>>>>>>>running test 1"
../source/schedule.exe 7 1 9  < ../inputs/input/inp.58 > ../outputs/t1
echo ">>>>>>>>running test 2"
../source/schedule.exe 2 3 5  < ../inputs/input/inp.46 > ../outputs/t2
echo ">>>>>>>>running test 3"
../source/schedule.exe 4 8 8  < ../inputs/input/inp.18 > ../outputs/t3
echo ">>>>>>>>running test 4"
../source/schedule.exe 10 0 2  < ../inputs/input/inp.51 > ../outputs/t4
echo ">>>>>>>>running test 5"
../source/schedule.exe 8 3 2  < ../inputs/input/inp.99 > ../outputs/t5
echo ">>>>>>>>running test 6"
../source/schedule.exe 7 10 5  < ../inputs/input/inp.84 > ../outputs/t6
echo ">>>>>>>>running test 7"
../source/schedule.exe 4 0 6  < ../inputs/input/inp.20 > ../outputs/t7
echo ">>>>>>>>running test 8"
../source/schedule.exe 3 7 4  < ../inputs/input/inp.28 > ../outputs/t8
echo ">>>>>>>>running test 9"
../source/schedule.exe 9 7 5  < ../inputs/input/inp.9 > ../outputs/t9
echo ">>>>>>>>running test 10"
../source/schedule.exe 9 10 6  < ../inputs/input/inp.98 > ../outputs/t10
echo ">>>>>>>>running test 11"
../source/schedule.exe 7 9 8  < ../inputs/input/inp.14 > ../outputs/t11
echo ">>>>>>>>running test 12"
../source/schedule.exe 8 9 0  < ../inputs/input/inp.34 > ../outputs/t12
echo ">>>>>>>>running test 13"
../source/schedule.exe 8 5 0  < ../inputs/input/inp.42 > ../outputs/t13
echo ">>>>>>>>running test 14"
../source/schedule.exe 9 8 5  < ../inputs/input/inp.88 > ../outputs/t14
echo ">>>>>>>>running test 15"
../source/schedule.exe 7 0 6  < ../inputs/input/inp.95 > ../outputs/t15
echo ">>>>>>>>running test 16"
../source/schedule.exe 8 3 9  < ../inputs/input/inp.56 > ../outputs/t16
echo ">>>>>>>>running test 17"
../source/schedule.exe 7 4 2  < ../inputs/input/inp.12 > ../outputs/t17
echo ">>>>>>>>running test 18"
../source/schedule.exe 5 8 7  < ../inputs/input/inp.6 > ../outputs/t18
echo ">>>>>>>>running test 19"
../source/schedule.exe 0 4 1  < ../inputs/input/inp.75 > ../outputs/t19
echo ">>>>>>>>running test 20"
../source/schedule.exe 0 10 6  < ../inputs/input/inp.59 > ../outputs/t20
echo ">>>>>>>>running test 21"
../source/schedule.exe 9 0 9  < ../inputs/input/inp.20 > ../outputs/t21
echo ">>>>>>>>running test 22"
../source/schedule.exe 9 9 2  < ../inputs/input/inp.3 > ../outputs/t22
echo ">>>>>>>>running test 23"
../source/schedule.exe 6 1 0  < ../inputs/input/inp.27 > ../outputs/t23
echo ">>>>>>>>running test 24"
../source/schedule.exe 5 10 8  < ../inputs/input/inp.66 > ../outputs/t24
echo ">>>>>>>>running test 25"
../source/schedule.exe 6 9 0  < ../inputs/input/inp.88 > ../outputs/t25
echo ">>>>>>>>running test 26"
../source/schedule.exe 3 7 3  < ../inputs/input/inp.32 > ../outputs/t26
echo ">>>>>>>>running test 27"
../source/schedule.exe 1 5 5  < ../inputs/input/inp.35 > ../outputs/t27
echo ">>>>>>>>running test 28"
../source/schedule.exe 1 2 7  < ../inputs/input/inp.30 > ../outputs/t28
echo ">>>>>>>>running test 29"
../source/schedule.exe 2 7 6  < ../inputs/input/inp.19 > ../outputs/t29
echo ">>>>>>>>running test 30"
../source/schedule.exe 4 6 3  < ../inputs/input/inp.68 > ../outputs/t30
echo ">>>>>>>>running test 31"
../source/schedule.exe 4 6 2  < ../inputs/input/inp.97 > ../outputs/t31
echo ">>>>>>>>running test 32"
../source/schedule.exe 8 4 2  < ../inputs/input/inp.58 > ../outputs/t32
echo ">>>>>>>>running test 33"
../source/schedule.exe 10 0 0  < ../inputs/input/inp.21 > ../outputs/t33
echo ">>>>>>>>running test 34"
../source/schedule.exe 6 3 3  < ../inputs/input/inp.6 > ../outputs/t34
echo ">>>>>>>>running test 35"
../source/schedule.exe 8 9 10  < ../inputs/input/inp.76 > ../outputs/t35
echo ">>>>>>>>running test 36"
../source/schedule.exe 10 5 9  < ../inputs/input/inp.6 > ../outputs/t36
echo ">>>>>>>>running test 37"
../source/schedule.exe 8 9 0  < ../inputs/input/inp.37 > ../outputs/t37
echo ">>>>>>>>running test 38"
../source/schedule.exe 10 10 3  < ../inputs/input/inp.15 > ../outputs/t38
echo ">>>>>>>>running test 39"
../source/schedule.exe 1 7 2  < ../inputs/input/inp.60 > ../outputs/t39
echo ">>>>>>>>running test 40"
../source/schedule.exe 2 9 5  < ../inputs/input/inp.15 > ../outputs/t40
echo ">>>>>>>>running test 41"
../source/schedule.exe 9 4 2  < ../inputs/input/inp.15 > ../outputs/t41
echo ">>>>>>>>running test 42"
../source/schedule.exe 9 0 0  < ../inputs/input/inp.81 > ../outputs/t42
echo ">>>>>>>>running test 43"
../source/schedule.exe 0 6 4  < ../inputs/input/inp.19 > ../outputs/t43
echo ">>>>>>>>running test 44"
../source/schedule.exe 10 4 5  < ../inputs/input/inp.53 > ../outputs/t44
echo ">>>>>>>>running test 45"
../source/schedule.exe 7 6 5  < ../inputs/input/inp.89 > ../outputs/t45
echo ">>>>>>>>running test 46"
../source/schedule.exe 0 2 2  < ../inputs/input/inp.97 > ../outputs/t46
echo ">>>>>>>>running test 47"
../source/schedule.exe 10 8 8  < ../inputs/input/inp.52 > ../outputs/t47
echo ">>>>>>>>running test 48"
../source/schedule.exe 0 5 1  < ../inputs/input/inp.22 > ../outputs/t48
echo ">>>>>>>>running test 49"
../source/schedule.exe 4 1 6  < ../inputs/input/inp.23 > ../outputs/t49
echo ">>>>>>>>running test 50"
../source/schedule.exe 7 10 4  < ../inputs/input/inp.10 > ../outputs/t50
echo ">>>>>>>>running test 51"
../source/schedule.exe 8 1 0  < ../inputs/input/inp.37 > ../outputs/t51
echo ">>>>>>>>running test 52"
../source/schedule.exe 1 10 6  < ../inputs/input/inp.1 > ../outputs/t52
echo ">>>>>>>>running test 53"
../source/schedule.exe 2 8 0  < ../inputs/input/inp.55 > ../outputs/t53
echo ">>>>>>>>running test 54"
../source/schedule.exe 0 5 1  < ../inputs/input/inp.91 > ../outputs/t54
echo ">>>>>>>>running test 55"
../source/schedule.exe 0 7 4  < ../inputs/input/inp.44 > ../outputs/t55
echo ">>>>>>>>running test 56"
../source/schedule.exe 6 2 3  < ../inputs/input/inp.2 > ../outputs/t56
echo ">>>>>>>>running test 57"
../source/schedule.exe 6 3 8  < ../inputs/input/inp.78 > ../outputs/t57
echo ">>>>>>>>running test 58"
../source/schedule.exe 6 10 8  < ../inputs/input/inp.28 > ../outputs/t58
echo ">>>>>>>>running test 59"
../source/schedule.exe 3 3 2  < ../inputs/input/inp.27 > ../outputs/t59
echo ">>>>>>>>running test 60"
../source/schedule.exe 6 1 4  < ../inputs/input/inp.60 > ../outputs/t60
echo ">>>>>>>>running test 61"
../source/schedule.exe 0 6 8  < ../inputs/input/inp.90 > ../outputs/t61
echo ">>>>>>>>running test 62"
../source/schedule.exe 5 2 8  < ../inputs/input/inp.81 > ../outputs/t62
echo ">>>>>>>>running test 63"
../source/schedule.exe 3 4 5  < ../inputs/input/inp.46 > ../outputs/t63
echo ">>>>>>>>running test 64"
../source/schedule.exe 10 4 0  < ../inputs/input/inp.86 > ../outputs/t64
echo ">>>>>>>>running test 65"
../source/schedule.exe 6 1 2  < ../inputs/input/inp.38 > ../outputs/t65
echo ">>>>>>>>running test 66"
../source/schedule.exe 8 2 9  < ../inputs/input/inp.39 > ../outputs/t66
echo ">>>>>>>>running test 67"
../source/schedule.exe 6 7 7  < ../inputs/input/inp.3 > ../outputs/t67
echo ">>>>>>>>running test 68"
../source/schedule.exe 2 5 5  < ../inputs/input/inp.6 > ../outputs/t68
echo ">>>>>>>>running test 69"
../source/schedule.exe 7 5 7  < ../inputs/input/inp.66 > ../outputs/t69
echo ">>>>>>>>running test 70"
../source/schedule.exe 3 6 1  < ../inputs/input/inp.61 > ../outputs/t70
echo ">>>>>>>>running test 71"
../source/schedule.exe 4 9 6  < ../inputs/input/inp.30 > ../outputs/t71
echo ">>>>>>>>running test 72"
../source/schedule.exe 6 0 1  < ../inputs/input/inp.26 > ../outputs/t72
echo ">>>>>>>>running test 73"
../source/schedule.exe 3 5 6  < ../inputs/input/inp.84 > ../outputs/t73
echo ">>>>>>>>running test 74"
../source/schedule.exe 4 8 0  < ../inputs/input/inp.51 > ../outputs/t74
echo ">>>>>>>>running test 75"
../source/schedule.exe 2 3 7  < ../inputs/input/inp.30 > ../outputs/t75
echo ">>>>>>>>running test 76"
../source/schedule.exe 1 4 4  < ../inputs/input/inp.68 > ../outputs/t76
echo ">>>>>>>>running test 77"
../source/schedule.exe 0 4 4  < ../inputs/input/inp.56 > ../outputs/t77
echo ">>>>>>>>running test 78"
../source/schedule.exe 1 3 8  < ../inputs/input/inp.43 > ../outputs/t78
echo ">>>>>>>>running test 79"
../source/schedule.exe 4 6 6  < ../inputs/input/inp.39 > ../outputs/t79
echo ">>>>>>>>running test 80"
../source/schedule.exe 7 6 8  < ../inputs/input/inp.26 > ../outputs/t80
echo ">>>>>>>>running test 81"
../source/schedule.exe 1 3 10  < ../inputs/input/inp.27 > ../outputs/t81
echo ">>>>>>>>running test 82"
../source/schedule.exe 7 3 8  < ../inputs/input/inp.86 > ../outputs/t82
echo ">>>>>>>>running test 83"
../source/schedule.exe 3 3 8  < ../inputs/input/inp.3 > ../outputs/t83
echo ">>>>>>>>running test 84"
../source/schedule.exe 1 10 1  < ../inputs/input/inp.61 > ../outputs/t84
echo ">>>>>>>>running test 85"
../source/schedule.exe 8 5 3  < ../inputs/input/inp.91 > ../outputs/t85
echo ">>>>>>>>running test 86"
../source/schedule.exe 3 5 3  < ../inputs/input/inp.43 > ../outputs/t86
echo ">>>>>>>>running test 87"
../source/schedule.exe 7 6 0  < ../inputs/input/inp.5 > ../outputs/t87
echo ">>>>>>>>running test 88"
../source/schedule.exe 4 6 7  < ../inputs/input/inp.28 > ../outputs/t88
echo ">>>>>>>>running test 89"
../source/schedule.exe 9 0 3  < ../inputs/input/inp.73 > ../outputs/t89
echo ">>>>>>>>running test 90"
../source/schedule.exe 8 7 6  < ../inputs/input/inp.54 > ../outputs/t90
echo ">>>>>>>>running test 91"
../source/schedule.exe 6 10 9  < ../inputs/input/inp.74 > ../outputs/t91
echo ">>>>>>>>running test 92"
../source/schedule.exe 5 4 8  < ../inputs/input/inp.99 > ../outputs/t92
echo ">>>>>>>>running test 93"
../source/schedule.exe 3 0 2  < ../inputs/input/inp.38 > ../outputs/t93
echo ">>>>>>>>running test 94"
../source/schedule.exe 2 0 1  < ../inputs/input/inp.3 > ../outputs/t94
echo ">>>>>>>>running test 95"
../source/schedule.exe 6 4 6  < ../inputs/input/inp.58 > ../outputs/t95
echo ">>>>>>>>running test 96"
../source/schedule.exe 8 9 6  < ../inputs/input/inp.32 > ../outputs/t96
echo ">>>>>>>>running test 97"
../source/schedule.exe 7 1 8  < ../inputs/input/inp.91 > ../outputs/t97
echo ">>>>>>>>running test 98"
../source/schedule.exe 9 3 7  < ../inputs/input/inp.40 > ../outputs/t98
echo ">>>>>>>>running test 99"
../source/schedule.exe 3 9 4  < ../inputs/input/inp.41 > ../outputs/t99
echo ">>>>>>>>running test 100"
../source/schedule.exe 6 10 0  < ../inputs/input/inp.56 > ../outputs/t100
echo ">>>>>>>>running test 101"
../source/schedule.exe 3 0 7  < ../inputs/input/inp.71 > ../outputs/t101
echo ">>>>>>>>running test 102"
../source/schedule.exe 2 9 4  < ../inputs/input/inp.20 > ../outputs/t102
echo ">>>>>>>>running test 103"
../source/schedule.exe 6 1 7  < ../inputs/input/inp.91 > ../outputs/t103
echo ">>>>>>>>running test 104"
../source/schedule.exe 2 9 9  < ../inputs/input/inp.25 > ../outputs/t104
echo ">>>>>>>>running test 105"
../source/schedule.exe 0 10 3  < ../inputs/input/inp.6 > ../outputs/t105
echo ">>>>>>>>running test 106"
../source/schedule.exe 3 10 10  < ../inputs/input/inp.63 > ../outputs/t106
echo ">>>>>>>>running test 107"
../source/schedule.exe 10 1 7  < ../inputs/input/inp.74 > ../outputs/t107
echo ">>>>>>>>running test 108"
../source/schedule.exe 7 1 2  < ../inputs/input/inp.16 > ../outputs/t108
echo ">>>>>>>>running test 109"
../source/schedule.exe 1 4 5  < ../inputs/input/inp.24 > ../outputs/t109
echo ">>>>>>>>running test 110"
../source/schedule.exe 0 0 1  < ../inputs/input/inp.71 > ../outputs/t110
echo ">>>>>>>>running test 111"
../source/schedule.exe 8 5 1  < ../inputs/input/inp.92 > ../outputs/t111
echo ">>>>>>>>running test 112"
../source/schedule.exe 10 5 8  < ../inputs/input/inp.82 > ../outputs/t112
echo ">>>>>>>>running test 113"
../source/schedule.exe 4 9 4  < ../inputs/input/inp.44 > ../outputs/t113
echo ">>>>>>>>running test 114"
../source/schedule.exe 8 7 4  < ../inputs/input/inp.20 > ../outputs/t114
echo ">>>>>>>>running test 115"
../source/schedule.exe 0 0 8  < ../inputs/input/inp.29 > ../outputs/t115
echo ">>>>>>>>running test 116"
../source/schedule.exe 5 7 9  < ../inputs/input/inp.39 > ../outputs/t116
echo ">>>>>>>>running test 117"
../source/schedule.exe 0 8 2  < ../inputs/input/inp.47 > ../outputs/t117
echo ">>>>>>>>running test 118"
../source/schedule.exe 2 3 3  < ../inputs/input/inp.3 > ../outputs/t118
echo ">>>>>>>>running test 119"
../source/schedule.exe 2 3 7  < ../inputs/input/inp.12 > ../outputs/t119
echo ">>>>>>>>running test 120"
../source/schedule.exe 8 0 0  < ../inputs/input/inp.32 > ../outputs/t120
echo ">>>>>>>>running test 121"
../source/schedule.exe 7 3 7  < ../inputs/input/inp.12 > ../outputs/t121
echo ">>>>>>>>running test 122"
../source/schedule.exe 5 5 8  < ../inputs/input/inp.74 > ../outputs/t122
echo ">>>>>>>>running test 123"
../source/schedule.exe 1 7 2  < ../inputs/input/inp.59 > ../outputs/t123
echo ">>>>>>>>running test 124"
../source/schedule.exe 3 1 10  < ../inputs/input/inp.71 > ../outputs/t124
echo ">>>>>>>>running test 125"
../source/schedule.exe 7 5 2  < ../inputs/input/inp.98 > ../outputs/t125
echo ">>>>>>>>running test 126"
../source/schedule.exe 6 9 0  < ../inputs/input/inp.74 > ../outputs/t126
echo ">>>>>>>>running test 127"
../source/schedule.exe 5 1 1  < ../inputs/input/inp.60 > ../outputs/t127
echo ">>>>>>>>running test 128"
../source/schedule.exe 10 10 6  < ../inputs/input/inp.79 > ../outputs/t128
echo ">>>>>>>>running test 129"
../source/schedule.exe 2 2 3  < ../inputs/input/inp.35 > ../outputs/t129
echo ">>>>>>>>running test 130"
../source/schedule.exe 6 2 6  < ../inputs/input/inp.20 > ../outputs/t130
echo ">>>>>>>>running test 131"
../source/schedule.exe 4 8 2  < ../inputs/input/inp.91 > ../outputs/t131
echo ">>>>>>>>running test 132"
../source/schedule.exe 8 4 9  < ../inputs/input/inp.54 > ../outputs/t132
echo ">>>>>>>>running test 133"
../source/schedule.exe 1 1 4  < ../inputs/input/inp.30 > ../outputs/t133
echo ">>>>>>>>running test 134"
../source/schedule.exe 5 8 10  < ../inputs/input/inp.76 > ../outputs/t134
echo ">>>>>>>>running test 135"
../source/schedule.exe 2 1 6  < ../inputs/input/inp.95 > ../outputs/t135
echo ">>>>>>>>running test 136"
../source/schedule.exe 4 9 10  < ../inputs/input/inp.33 > ../outputs/t136
echo ">>>>>>>>running test 137"
../source/schedule.exe 7 9 0  < ../inputs/input/inp.25 > ../outputs/t137
echo ">>>>>>>>running test 138"
../source/schedule.exe 2 6 0  < ../inputs/input/inp.45 > ../outputs/t138
echo ">>>>>>>>running test 139"
../source/schedule.exe 2 3 7  < ../inputs/input/inp.99 > ../outputs/t139
echo ">>>>>>>>running test 140"
../source/schedule.exe 2 2 10  < ../inputs/input/inp.45 > ../outputs/t140
echo ">>>>>>>>running test 141"
../source/schedule.exe 5 0 9  < ../inputs/input/inp.11 > ../outputs/t141
echo ">>>>>>>>running test 142"
../source/schedule.exe 4 8 1  < ../inputs/input/inp.53 > ../outputs/t142
echo ">>>>>>>>running test 143"
../source/schedule.exe 5 3 2  < ../inputs/input/inp.38 > ../outputs/t143
echo ">>>>>>>>running test 144"
../source/schedule.exe 10 3 3  < ../inputs/input/inp.78 > ../outputs/t144
echo ">>>>>>>>running test 145"
../source/schedule.exe 1 6 10  < ../inputs/input/inp.57 > ../outputs/t145
echo ">>>>>>>>running test 146"
../source/schedule.exe 0 4 10  < ../inputs/input/inp.82 > ../outputs/t146
echo ">>>>>>>>running test 147"
../source/schedule.exe 4 10 2  < ../inputs/input/inp.91 > ../outputs/t147
echo ">>>>>>>>running test 148"
../source/schedule.exe 1 2 10  < ../inputs/input/inp.40 > ../outputs/t148
echo ">>>>>>>>running test 149"
../source/schedule.exe 6 8 9  < ../inputs/input/inp.100 > ../outputs/t149
echo ">>>>>>>>running test 150"
../source/schedule.exe 8 3 8  < ../inputs/input/inp.92 > ../outputs/t150
echo ">>>>>>>>running test 151"
../source/schedule.exe 1 10 7  < ../inputs/input/inp.18 > ../outputs/t151
echo ">>>>>>>>running test 152"
../source/schedule.exe 7 8 5  < ../inputs/input/inp.9 > ../outputs/t152
echo ">>>>>>>>running test 153"
../source/schedule.exe 7 6 5  < ../inputs/input/inp.24 > ../outputs/t153
echo ">>>>>>>>running test 154"
../source/schedule.exe 4 3 0  < ../inputs/input/inp.2 > ../outputs/t154
echo ">>>>>>>>running test 155"
../source/schedule.exe 10 5 6  < ../inputs/input/inp.2 > ../outputs/t155
echo ">>>>>>>>running test 156"
../source/schedule.exe 9 8 9  < ../inputs/input/inp.26 > ../outputs/t156
echo ">>>>>>>>running test 157"
../source/schedule.exe 4 2 4  < ../inputs/input/inp.22 > ../outputs/t157
echo ">>>>>>>>running test 158"
../source/schedule.exe 8 7 4  < ../inputs/input/inp.94 > ../outputs/t158
echo ">>>>>>>>running test 159"
../source/schedule.exe 8 7 4  < ../inputs/input/inp.40 > ../outputs/t159
echo ">>>>>>>>running test 160"
../source/schedule.exe 5 6 2  < ../inputs/input/inp.92 > ../outputs/t160
echo ">>>>>>>>running test 161"
../source/schedule.exe 9 8 3  < ../inputs/input/inp.0 > ../outputs/t161
echo ">>>>>>>>running test 162"
../source/schedule.exe 7 6 2  < ../inputs/input/inp.86 > ../outputs/t162
echo ">>>>>>>>running test 163"
../source/schedule.exe 1 1 1  < ../inputs/input/inp.78 > ../outputs/t163
echo ">>>>>>>>running test 164"
../source/schedule.exe 3 7 3  < ../inputs/input/inp.7 > ../outputs/t164
echo ">>>>>>>>running test 165"
../source/schedule.exe 3 8 8  < ../inputs/input/inp.61 > ../outputs/t165
echo ">>>>>>>>running test 166"
../source/schedule.exe 10 2 4  < ../inputs/input/inp.84 > ../outputs/t166
echo ">>>>>>>>running test 167"
../source/schedule.exe 2 2 2  < ../inputs/input/inp.51 > ../outputs/t167
echo ">>>>>>>>running test 168"
../source/schedule.exe 0 4 2  < ../inputs/input/inp.2 > ../outputs/t168
echo ">>>>>>>>running test 169"
../source/schedule.exe 5 2 0  < ../inputs/input/inp.76 > ../outputs/t169
echo ">>>>>>>>running test 170"
../source/schedule.exe 7 10 1  < ../inputs/input/inp.21 > ../outputs/t170
echo ">>>>>>>>running test 171"
../source/schedule.exe 7 0 0  < ../inputs/input/inp.39 > ../outputs/t171
echo ">>>>>>>>running test 172"
../source/schedule.exe 10 4 3  < ../inputs/input/inp.35 > ../outputs/t172
echo ">>>>>>>>running test 173"
../source/schedule.exe 1 8 1  < ../inputs/input/inp.5 > ../outputs/t173
echo ">>>>>>>>running test 174"
../source/schedule.exe 2 1 10  < ../inputs/input/inp.20 > ../outputs/t174
echo ">>>>>>>>running test 175"
../source/schedule.exe 10 1 6  < ../inputs/input/inp.8 > ../outputs/t175
echo ">>>>>>>>running test 176"
../source/schedule.exe 10 5 7  < ../inputs/input/inp.72 > ../outputs/t176
echo ">>>>>>>>running test 177"
../source/schedule.exe 9 10 5  < ../inputs/input/inp.96 > ../outputs/t177
echo ">>>>>>>>running test 178"
../source/schedule.exe 1 1 8  < ../inputs/input/inp.14 > ../outputs/t178
echo ">>>>>>>>running test 179"
../source/schedule.exe 3 9 5  < ../inputs/input/inp.2 > ../outputs/t179
echo ">>>>>>>>running test 180"
../source/schedule.exe 6 2 10  < ../inputs/input/inp.71 > ../outputs/t180
echo ">>>>>>>>running test 181"
../source/schedule.exe 7 8 4  < ../inputs/input/inp.30 > ../outputs/t181
echo ">>>>>>>>running test 182"
../source/schedule.exe 9 5 7  < ../inputs/input/inp.96 > ../outputs/t182
echo ">>>>>>>>running test 183"
../source/schedule.exe 10 6 5  < ../inputs/input/inp.35 > ../outputs/t183
echo ">>>>>>>>running test 184"
../source/schedule.exe 8 2 8  < ../inputs/input/inp.50 > ../outputs/t184
echo ">>>>>>>>running test 185"
../source/schedule.exe 10 7 4  < ../inputs/input/inp.72 > ../outputs/t185
echo ">>>>>>>>running test 186"
../source/schedule.exe 0 2 5  < ../inputs/input/inp.16 > ../outputs/t186
echo ">>>>>>>>running test 187"
../source/schedule.exe 0 0 7  < ../inputs/input/inp.60 > ../outputs/t187
echo ">>>>>>>>running test 188"
../source/schedule.exe 7 8 9  < ../inputs/input/inp.64 > ../outputs/t188
echo ">>>>>>>>running test 189"
../source/schedule.exe 1 3 8  < ../inputs/input/inp.65 > ../outputs/t189
echo ">>>>>>>>running test 190"
../source/schedule.exe 2 0 8  < ../inputs/input/inp.86 > ../outputs/t190
echo ">>>>>>>>running test 191"
../source/schedule.exe 1 5 3  < ../inputs/input/inp.33 > ../outputs/t191
echo ">>>>>>>>running test 192"
../source/schedule.exe 2 2 0  < ../inputs/input/inp.85 > ../outputs/t192
echo ">>>>>>>>running test 193"
../source/schedule.exe 4 6 10  < ../inputs/input/inp.86 > ../outputs/t193
echo ">>>>>>>>running test 194"
../source/schedule.exe 5 0 2  < ../inputs/input/inp.83 > ../outputs/t194
echo ">>>>>>>>running test 195"
../source/schedule.exe 5 7 6  < ../inputs/input/inp.75 > ../outputs/t195
echo ">>>>>>>>running test 196"
../source/schedule.exe 4 2 2  < ../inputs/input/inp.77 > ../outputs/t196
echo ">>>>>>>>running test 197"
../source/schedule.exe 4 3 1  < ../inputs/input/inp.91 > ../outputs/t197
echo ">>>>>>>>running test 198"
../source/schedule.exe 10 3 8  < ../inputs/input/inp.7 > ../outputs/t198
echo ">>>>>>>>running test 199"
../source/schedule.exe 4 0 6  < ../inputs/input/inp.99 > ../outputs/t199
echo ">>>>>>>>running test 200"
../source/schedule.exe 2 6 2  < ../inputs/input/inp.92 > ../outputs/t200
echo ">>>>>>>>running test 201"
../source/schedule.exe 2 8 10  < ../inputs/input/inp.97 > ../outputs/t201
echo ">>>>>>>>running test 202"
../source/schedule.exe 4 7 6  < ../inputs/input/inp.30 > ../outputs/t202
echo ">>>>>>>>running test 203"
../source/schedule.exe 6 6 3  < ../inputs/input/inp.55 > ../outputs/t203
echo ">>>>>>>>running test 204"
../source/schedule.exe 9 0 5  < ../inputs/input/inp.51 > ../outputs/t204
echo ">>>>>>>>running test 205"
../source/schedule.exe 2 10 3  < ../inputs/input/inp.5 > ../outputs/t205
echo ">>>>>>>>running test 206"
../source/schedule.exe 7 2 2  < ../inputs/input/inp.17 > ../outputs/t206
echo ">>>>>>>>running test 207"
../source/schedule.exe 9 8 10  < ../inputs/input/inp.35 > ../outputs/t207
echo ">>>>>>>>running test 208"
../source/schedule.exe 7 8 10  < ../inputs/input/inp.30 > ../outputs/t208
echo ">>>>>>>>running test 209"
../source/schedule.exe 5 7 9  < ../inputs/input/inp.76 > ../outputs/t209
echo ">>>>>>>>running test 210"
../source/schedule.exe 10 10 10  < ../inputs/input/inp.97 > ../outputs/t210
echo ">>>>>>>>running test 211"
../source/schedule.exe 5 0 10  < ../inputs/input/inp.52 > ../outputs/t211
echo ">>>>>>>>running test 212"
../source/schedule.exe 1 2 5  < ../inputs/input/inp.45 > ../outputs/t212
echo ">>>>>>>>running test 213"
../source/schedule.exe 3 2 0  < ../inputs/input/inp.22 > ../outputs/t213
echo ">>>>>>>>running test 214"
../source/schedule.exe 9 2 6  < ../inputs/input/inp.23 > ../outputs/t214
echo ">>>>>>>>running test 215"
../source/schedule.exe 3 7 4  < ../inputs/input/inp.2 > ../outputs/t215
echo ">>>>>>>>running test 216"
../source/schedule.exe 5 2 3  < ../inputs/input/inp.37 > ../outputs/t216
echo ">>>>>>>>running test 217"
../source/schedule.exe 2 9 10  < ../inputs/input/inp.34 > ../outputs/t217
echo ">>>>>>>>running test 218"
../source/schedule.exe 4 2 10  < ../inputs/input/inp.97 > ../outputs/t218
echo ">>>>>>>>running test 219"
../source/schedule.exe 1 5 4  < ../inputs/input/inp.61 > ../outputs/t219
echo ">>>>>>>>running test 220"
../source/schedule.exe 2 9 9  < ../inputs/input/inp.65 > ../outputs/t220
echo ">>>>>>>>running test 221"
../source/schedule.exe 6 10 5  < ../inputs/input/inp.13 > ../outputs/t221
echo ">>>>>>>>running test 222"
../source/schedule.exe 1 3 3  < ../inputs/input/inp.15 > ../outputs/t222
echo ">>>>>>>>running test 223"
../source/schedule.exe 8 7 6  < ../inputs/input/inp.59 > ../outputs/t223
echo ">>>>>>>>running test 224"
../source/schedule.exe 2 5 6  < ../inputs/input/inp.12 > ../outputs/t224
echo ">>>>>>>>running test 225"
../source/schedule.exe 10 10 4  < ../inputs/input/inp.18 > ../outputs/t225
echo ">>>>>>>>running test 226"
../source/schedule.exe 9 1 3  < ../inputs/input/inp.1 > ../outputs/t226
echo ">>>>>>>>running test 227"
../source/schedule.exe 3 7 6  < ../inputs/input/inp.47 > ../outputs/t227
echo ">>>>>>>>running test 228"
../source/schedule.exe 2 4 10  < ../inputs/input/inp.18 > ../outputs/t228
echo ">>>>>>>>running test 229"
../source/schedule.exe 2 3 9  < ../inputs/input/inp.4 > ../outputs/t229
echo ">>>>>>>>running test 230"
../source/schedule.exe 10 10 3  < ../inputs/input/inp.61 > ../outputs/t230
echo ">>>>>>>>running test 231"
../source/schedule.exe 9 0 8  < ../inputs/input/inp.87 > ../outputs/t231
echo ">>>>>>>>running test 232"
../source/schedule.exe 9 10 7  < ../inputs/input/inp.66 > ../outputs/t232
echo ">>>>>>>>running test 233"
../source/schedule.exe 6 5 0  < ../inputs/input/inp.53 > ../outputs/t233
echo ">>>>>>>>running test 234"
../source/schedule.exe 8 2 7  < ../inputs/input/inp.53 > ../outputs/t234
echo ">>>>>>>>running test 235"
../source/schedule.exe 8 0 6  < ../inputs/input/inp.4 > ../outputs/t235
echo ">>>>>>>>running test 236"
../source/schedule.exe 2 1 4  < ../inputs/input/inp.81 > ../outputs/t236
echo ">>>>>>>>running test 237"
../source/schedule.exe 9 6 10  < ../inputs/input/inp.99 > ../outputs/t237
echo ">>>>>>>>running test 238"
../source/schedule.exe 8 8 9  < ../inputs/input/inp.89 > ../outputs/t238
echo ">>>>>>>>running test 239"
../source/schedule.exe 8 0 7  < ../inputs/input/inp.28 > ../outputs/t239
echo ">>>>>>>>running test 240"
../source/schedule.exe 4 10 7  < ../inputs/input/inp.66 > ../outputs/t240
echo ">>>>>>>>running test 241"
../source/schedule.exe 7 0 5  < ../inputs/input/inp.70 > ../outputs/t241
echo ">>>>>>>>running test 242"
../source/schedule.exe 0 1 10  < ../inputs/input/inp.83 > ../outputs/t242
echo ">>>>>>>>running test 243"
../source/schedule.exe 0 0 9  < ../inputs/input/inp.63 > ../outputs/t243
echo ">>>>>>>>running test 244"
../source/schedule.exe 2 3 6  < ../inputs/input/inp.83 > ../outputs/t244
echo ">>>>>>>>running test 245"
../source/schedule.exe 4 7 0  < ../inputs/input/inp.66 > ../outputs/t245
echo ">>>>>>>>running test 246"
../source/schedule.exe 1 7 7  < ../inputs/input/inp.40 > ../outputs/t246
echo ">>>>>>>>running test 247"
../source/schedule.exe 7 4 6  < ../inputs/input/inp.51 > ../outputs/t247
echo ">>>>>>>>running test 248"
../source/schedule.exe 8 1 2  < ../inputs/input/inp.42 > ../outputs/t248
echo ">>>>>>>>running test 249"
../source/schedule.exe 0 3 1  < ../inputs/input/inp.66 > ../outputs/t249
echo ">>>>>>>>running test 250"
../source/schedule.exe 10 6 3  < ../inputs/input/inp.42 > ../outputs/t250
echo ">>>>>>>>running test 251"
../source/schedule.exe 0 2 3  < ../inputs/input/inp.39 > ../outputs/t251
echo ">>>>>>>>running test 252"
../source/schedule.exe 9 7 3  < ../inputs/input/inp.56 > ../outputs/t252
echo ">>>>>>>>running test 253"
../source/schedule.exe 3 0 5  < ../inputs/input/inp.1 > ../outputs/t253
echo ">>>>>>>>running test 254"
../source/schedule.exe 5 4 4  < ../inputs/input/inp.44 > ../outputs/t254
echo ">>>>>>>>running test 255"
../source/schedule.exe 10 5 6  < ../inputs/input/inp.27 > ../outputs/t255
echo ">>>>>>>>running test 256"
../source/schedule.exe 6 6 0  < ../inputs/input/inp.59 > ../outputs/t256
echo ">>>>>>>>running test 257"
../source/schedule.exe 2 2 5  < ../inputs/input/inp.25 > ../outputs/t257
echo ">>>>>>>>running test 258"
../source/schedule.exe 4 6 6  < ../inputs/input/inp.52 > ../outputs/t258
echo ">>>>>>>>running test 259"
../source/schedule.exe 8 5 8  < ../inputs/input/inp.19 > ../outputs/t259
echo ">>>>>>>>running test 260"
../source/schedule.exe 1 9 4  < ../inputs/input/inp.16 > ../outputs/t260
echo ">>>>>>>>running test 261"
../source/schedule.exe 1 1 6  < ../inputs/input/inp.84 > ../outputs/t261
echo ">>>>>>>>running test 262"
../source/schedule.exe 6 9 6  < ../inputs/input/inp.2 > ../outputs/t262
echo ">>>>>>>>running test 263"
../source/schedule.exe 2 6 10  < ../inputs/input/inp.20 > ../outputs/t263
echo ">>>>>>>>running test 264"
../source/schedule.exe 2 1 2  < ../inputs/input/inp.58 > ../outputs/t264
echo ">>>>>>>>running test 265"
../source/schedule.exe 4 2 0  < ../inputs/input/inp.39 > ../outputs/t265
echo ">>>>>>>>running test 266"
../source/schedule.exe 2 8 1  < ../inputs/input/inp.10 > ../outputs/t266
echo ">>>>>>>>running test 267"
../source/schedule.exe 8 10 0  < ../inputs/input/inp.73 > ../outputs/t267
echo ">>>>>>>>running test 268"
../source/schedule.exe 7 8 5  < ../inputs/input/inp.34 > ../outputs/t268
echo ">>>>>>>>running test 269"
../source/schedule.exe 1 1 6  < ../inputs/input/inp.8 > ../outputs/t269
echo ">>>>>>>>running test 270"
../source/schedule.exe 9 5 3  < ../inputs/input/inp.24 > ../outputs/t270
echo ">>>>>>>>running test 271"
../source/schedule.exe 8 0 3  < ../inputs/input/inp.80 > ../outputs/t271
echo ">>>>>>>>running test 272"
../source/schedule.exe 10 2 6  < ../inputs/input/inp.33 > ../outputs/t272
echo ">>>>>>>>running test 273"
../source/schedule.exe 4 10 3  < ../inputs/input/inp.98 > ../outputs/t273
echo ">>>>>>>>running test 274"
../source/schedule.exe 6 7 10  < ../inputs/input/inp.20 > ../outputs/t274
echo ">>>>>>>>running test 275"
../source/schedule.exe 8 10 4  < ../inputs/input/inp.17 > ../outputs/t275
echo ">>>>>>>>running test 276"
../source/schedule.exe 8 2 9  < ../inputs/input/inp.70 > ../outputs/t276
echo ">>>>>>>>running test 277"
../source/schedule.exe 0 2 1  < ../inputs/input/inp.55 > ../outputs/t277
echo ">>>>>>>>running test 278"
../source/schedule.exe 8 7 8  < ../inputs/input/inp.17 > ../outputs/t278
echo ">>>>>>>>running test 279"
../source/schedule.exe 6 10 7  < ../inputs/input/inp.82 > ../outputs/t279
echo ">>>>>>>>running test 280"
../source/schedule.exe 2 2 2  < ../inputs/input/inp.60 > ../outputs/t280
echo ">>>>>>>>running test 281"
../source/schedule.exe 9 7 9  < ../inputs/input/inp.38 > ../outputs/t281
echo ">>>>>>>>running test 282"
../source/schedule.exe 5 3 10  < ../inputs/input/inp.96 > ../outputs/t282
echo ">>>>>>>>running test 283"
../source/schedule.exe 9 6 6  < ../inputs/input/inp.75 > ../outputs/t283
echo ">>>>>>>>running test 284"
../source/schedule.exe 3 6 3  < ../inputs/input/inp.20 > ../outputs/t284
echo ">>>>>>>>running test 285"
../source/schedule.exe 0 8 8  < ../inputs/input/inp.34 > ../outputs/t285
echo ">>>>>>>>running test 286"
../source/schedule.exe 7 5 5  < ../inputs/input/inp.78 > ../outputs/t286
echo ">>>>>>>>running test 287"
../source/schedule.exe 6 2 3  < ../inputs/input/inp.66 > ../outputs/t287
echo ">>>>>>>>running test 288"
../source/schedule.exe 10 6 6  < ../inputs/input/inp.47 > ../outputs/t288
echo ">>>>>>>>running test 289"
../source/schedule.exe 9 3 6  < ../inputs/input/inp.37 > ../outputs/t289
echo ">>>>>>>>running test 290"
../source/schedule.exe 9 3 9  < ../inputs/input/inp.100 > ../outputs/t290
echo ">>>>>>>>running test 291"
../source/schedule.exe 3 2 7  < ../inputs/input/inp.48 > ../outputs/t291
echo ">>>>>>>>running test 292"
../source/schedule.exe 8 7 4  < ../inputs/input/inp.21 > ../outputs/t292
echo ">>>>>>>>running test 293"
../source/schedule.exe 7 8 3  < ../inputs/input/inp.97 > ../outputs/t293
echo ">>>>>>>>running test 294"
../source/schedule.exe 8 7 10  < ../inputs/input/inp.63 > ../outputs/t294
echo ">>>>>>>>running test 295"
../source/schedule.exe 9 9 7  < ../inputs/input/inp.64 > ../outputs/t295
echo ">>>>>>>>running test 296"
../source/schedule.exe 7 3 8  < ../inputs/input/inp.12 > ../outputs/t296
echo ">>>>>>>>running test 297"
../source/schedule.exe 0 0 6  < ../inputs/input/inp.81 > ../outputs/t297
echo ">>>>>>>>running test 298"
../source/schedule.exe 3 9 4  < ../inputs/input/inp.70 > ../outputs/t298
echo ">>>>>>>>running test 299"
../source/schedule.exe 4 2 3  < ../inputs/input/inp.48 > ../outputs/t299
echo ">>>>>>>>running test 300"
../source/schedule.exe 6 7 9  < ../inputs/input/inp.48 > ../outputs/t300
echo ">>>>>>>>running test 301"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.1 > ../outputs/t301
echo ">>>>>>>>running test 302"
../source/schedule.exe  3 0 0  < ../inputs/input/tc.2 > ../outputs/t302
echo ">>>>>>>>running test 303"
../source/schedule.exe  0 1 0  < ../inputs/input/tc.3 > ../outputs/t303
echo ">>>>>>>>running test 304"
../source/schedule.exe  0 0 3  < ../inputs/input/tc.4 > ../outputs/t304
echo ">>>>>>>>running test 305"
../source/schedule.exe  2 1 4  < ../inputs/input/tc.5 > ../outputs/t305
echo ">>>>>>>>running test 306"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.6 > ../outputs/t306
echo ">>>>>>>>running test 307"
../source/schedule.exe  0 4 0  < ../inputs/input/tc.7 > ../outputs/t307
echo ">>>>>>>>running test 308"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.8 > ../outputs/t308
echo ">>>>>>>>running test 309"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.9 > ../outputs/t309
echo ">>>>>>>>running test 310"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.10 > ../outputs/t310
echo ">>>>>>>>running test 311"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.11 > ../outputs/t311
echo ">>>>>>>>running test 312"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.12 > ../outputs/t312
echo ">>>>>>>>running test 313"
../source/schedule.exe  0 2 0  < ../inputs/input/tc.13 > ../outputs/t313
echo ">>>>>>>>running test 314"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.14 > ../outputs/t314
echo ">>>>>>>>running test 315"
../source/schedule.exe  3 0 0  < ../inputs/input/tc.15 > ../outputs/t315
echo ">>>>>>>>running test 316"
../source/schedule.exe  4 2 3  < ../inputs/input/tc.16 > ../outputs/t316
echo ">>>>>>>>running test 317"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.17 > ../outputs/t317
echo ">>>>>>>>running test 318"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.18 > ../outputs/t318
echo ">>>>>>>>running test 319"
../source/schedule.exe  0 0 1  < ../inputs/input/tc.19 > ../outputs/t319
echo ">>>>>>>>running test 320"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.20 > ../outputs/t320
echo ">>>>>>>>running test 321"
../source/schedule.exe  2 0 0  < ../inputs/input/tc.21 > ../outputs/t321
echo ">>>>>>>>running test 322"
../source/schedule.exe  0 4 0  < ../inputs/input/tc.22 > ../outputs/t322
echo ">>>>>>>>running test 323"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.23 > ../outputs/t323
echo ">>>>>>>>running test 324"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.24 > ../outputs/t324
echo ">>>>>>>>running test 325"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.25 > ../outputs/t325
echo ">>>>>>>>running test 326"
../source/schedule.exe  0 4 0  < ../inputs/input/tc.26 > ../outputs/t326
echo ">>>>>>>>running test 327"
../source/schedule.exe  0 0 3  < ../inputs/input/tc.27 > ../outputs/t327
echo ">>>>>>>>running test 328"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.28 > ../outputs/t328
echo ">>>>>>>>running test 329"
../source/schedule.exe  0 0 3  < ../inputs/input/tc.29 > ../outputs/t329
echo ">>>>>>>>running test 330"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.30 > ../outputs/t330
echo ">>>>>>>>running test 331"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.31 > ../outputs/t331
echo ">>>>>>>>running test 332"
../source/schedule.exe  0 0 1  < ../inputs/input/tc.32 > ../outputs/t332
echo ">>>>>>>>running test 333"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.33 > ../outputs/t333
echo ">>>>>>>>running test 334"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.34 > ../outputs/t334
echo ">>>>>>>>running test 335"
../source/schedule.exe  0 0 2  < ../inputs/input/tc.35 > ../outputs/t335
echo ">>>>>>>>running test 336"
../source/schedule.exe  3 4 3  < ../inputs/input/tc.36 > ../outputs/t336
echo ">>>>>>>>running test 337"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.37 > ../outputs/t337
echo ">>>>>>>>running test 338"
../source/schedule.exe  4 2 4  < ../inputs/input/tc.38 > ../outputs/t338
echo ">>>>>>>>running test 339"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.39 > ../outputs/t339
echo ">>>>>>>>running test 340"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.40 > ../outputs/t340
echo ">>>>>>>>running test 341"
../source/schedule.exe  0 0 2  < ../inputs/input/tc.41 > ../outputs/t341
echo ">>>>>>>>running test 342"
../source/schedule.exe  4 0 0  < ../inputs/input/tc.42 > ../outputs/t342
echo ">>>>>>>>running test 343"
../source/schedule.exe  0 0 3  < ../inputs/input/tc.43 > ../outputs/t343
echo ">>>>>>>>running test 344"
../source/schedule.exe  3 3 3  < ../inputs/input/tc.44 > ../outputs/t344
echo ">>>>>>>>running test 345"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.45 > ../outputs/t345
echo ">>>>>>>>running test 346"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.46 > ../outputs/t346
echo ">>>>>>>>running test 347"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.47 > ../outputs/t347
echo ">>>>>>>>running test 348"
../source/schedule.exe  4 4 1  < ../inputs/input/tc.48 > ../outputs/t348
echo ">>>>>>>>running test 349"
../source/schedule.exe  0 0 1  < ../inputs/input/tc.49 > ../outputs/t349
echo ">>>>>>>>running test 350"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.50 > ../outputs/t350
echo ">>>>>>>>running test 351"
../source/schedule.exe  1 1 3  < ../inputs/input/tc.51 > ../outputs/t351
echo ">>>>>>>>running test 352"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.52 > ../outputs/t352
echo ">>>>>>>>running test 353"
../source/schedule.exe  0 0 3  < ../inputs/input/tc.53 > ../outputs/t353
echo ">>>>>>>>running test 354"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.54 > ../outputs/t354
echo ">>>>>>>>running test 355"
../source/schedule.exe  4 1 3  < ../inputs/input/tc.55 > ../outputs/t355
echo ">>>>>>>>running test 356"
../source/schedule.exe  0 4 0  < ../inputs/input/tc.56 > ../outputs/t356
echo ">>>>>>>>running test 357"
../source/schedule.exe  0 2 0  < ../inputs/input/tc.57 > ../outputs/t357
echo ">>>>>>>>running test 358"
../source/schedule.exe  1 3 4  < ../inputs/input/tc.58 > ../outputs/t358
echo ">>>>>>>>running test 359"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.59 > ../outputs/t359
echo ">>>>>>>>running test 360"
../source/schedule.exe  1 3 2  < ../inputs/input/tc.60 > ../outputs/t360
echo ">>>>>>>>running test 361"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.61 > ../outputs/t361
echo ">>>>>>>>running test 362"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.62 > ../outputs/t362
echo ">>>>>>>>running test 363"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.63 > ../outputs/t363
echo ">>>>>>>>running test 364"
../source/schedule.exe  0 0 1  < ../inputs/input/tc.64 > ../outputs/t364
echo ">>>>>>>>running test 365"
../source/schedule.exe  3 4 1  < ../inputs/input/tc.65 > ../outputs/t365
echo ">>>>>>>>running test 366"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.66 > ../outputs/t366
echo ">>>>>>>>running test 367"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.67 > ../outputs/t367
echo ">>>>>>>>running test 368"
../source/schedule.exe  0 1 0  < ../inputs/input/tc.68 > ../outputs/t368
echo ">>>>>>>>running test 369"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.69 > ../outputs/t369
echo ">>>>>>>>running test 370"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.70 > ../outputs/t370
echo ">>>>>>>>running test 371"
../source/schedule.exe  0 0 4  < ../inputs/input/tc.71 > ../outputs/t371
echo ">>>>>>>>running test 372"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.72 > ../outputs/t372
echo ">>>>>>>>running test 373"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.73 > ../outputs/t373
echo ">>>>>>>>running test 374"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.74 > ../outputs/t374
echo ">>>>>>>>running test 375"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.75 > ../outputs/t375
echo ">>>>>>>>running test 376"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.76 > ../outputs/t376
echo ">>>>>>>>running test 377"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.77 > ../outputs/t377
echo ">>>>>>>>running test 378"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.78 > ../outputs/t378
echo ">>>>>>>>running test 379"
../source/schedule.exe  0 0 2  < ../inputs/input/tc.79 > ../outputs/t379
echo ">>>>>>>>running test 380"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.80 > ../outputs/t380
echo ">>>>>>>>running test 381"
../source/schedule.exe  3 0 0  < ../inputs/input/tc.81 > ../outputs/t381
echo ">>>>>>>>running test 382"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.82 > ../outputs/t382
echo ">>>>>>>>running test 383"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.83 > ../outputs/t383
echo ">>>>>>>>running test 384"
../source/schedule.exe  2 1 3  < ../inputs/input/tc.84 > ../outputs/t384
echo ">>>>>>>>running test 385"
../source/schedule.exe  0 1 0  < ../inputs/input/tc.85 > ../outputs/t385
echo ">>>>>>>>running test 386"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.86 > ../outputs/t386
echo ">>>>>>>>running test 387"
../source/schedule.exe  0 0 4  < ../inputs/input/tc.87 > ../outputs/t387
echo ">>>>>>>>running test 388"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.88 > ../outputs/t388
echo ">>>>>>>>running test 389"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.89 > ../outputs/t389
echo ">>>>>>>>running test 390"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.90 > ../outputs/t390
echo ">>>>>>>>running test 391"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.91 > ../outputs/t391
echo ">>>>>>>>running test 392"
../source/schedule.exe  2 2 4  < ../inputs/input/tc.92 > ../outputs/t392
echo ">>>>>>>>running test 393"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.93 > ../outputs/t393
echo ">>>>>>>>running test 394"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.94 > ../outputs/t394
echo ">>>>>>>>running test 395"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.95 > ../outputs/t395
echo ">>>>>>>>running test 396"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.96 > ../outputs/t396
echo ">>>>>>>>running test 397"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.97 > ../outputs/t397
echo ">>>>>>>>running test 398"
../source/schedule.exe  3 3 3  < ../inputs/input/tc.98 > ../outputs/t398
echo ">>>>>>>>running test 399"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.99 > ../outputs/t399
echo ">>>>>>>>running test 400"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.100 > ../outputs/t400
echo ">>>>>>>>running test 401"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.101 > ../outputs/t401
echo ">>>>>>>>running test 402"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.102 > ../outputs/t402
echo ">>>>>>>>running test 403"
../source/schedule.exe  3 0 0  < ../inputs/input/tc.103 > ../outputs/t403
echo ">>>>>>>>running test 404"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.104 > ../outputs/t404
echo ">>>>>>>>running test 405"
../source/schedule.exe  0 2 0  < ../inputs/input/tc.105 > ../outputs/t405
echo ">>>>>>>>running test 406"
../source/schedule.exe  1 0 0  < ../inputs/input/tc.106 > ../outputs/t406
echo ">>>>>>>>running test 407"
../source/schedule.exe  0 0 1  < ../inputs/input/tc.107 > ../outputs/t407
echo ">>>>>>>>running test 408"
../source/schedule.exe  1 0 0  < ../inputs/input/tc.108 > ../outputs/t408
echo ">>>>>>>>running test 409"
../source/schedule.exe  1 3 3  < ../inputs/input/tc.109 > ../outputs/t409
echo ">>>>>>>>running test 410"
../source/schedule.exe  3 4 1  < ../inputs/input/tc.110 > ../outputs/t410
echo ">>>>>>>>running test 411"
../source/schedule.exe  0 2 0  < ../inputs/input/tc.111 > ../outputs/t411
echo ">>>>>>>>running test 412"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.112 > ../outputs/t412
echo ">>>>>>>>running test 413"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.113 > ../outputs/t413
echo ">>>>>>>>running test 414"
../source/schedule.exe  0 0 4  < ../inputs/input/tc.114 > ../outputs/t414
echo ">>>>>>>>running test 415"
../source/schedule.exe  1 0 0  < ../inputs/input/tc.115 > ../outputs/t415
echo ">>>>>>>>running test 416"
../source/schedule.exe  1 4 1  < ../inputs/input/tc.116 > ../outputs/t416
echo ">>>>>>>>running test 417"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.117 > ../outputs/t417
echo ">>>>>>>>running test 418"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.118 > ../outputs/t418
echo ">>>>>>>>running test 419"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.119 > ../outputs/t419
echo ">>>>>>>>running test 420"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.120 > ../outputs/t420
echo ">>>>>>>>running test 421"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.121 > ../outputs/t421
echo ">>>>>>>>running test 422"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.122 > ../outputs/t422
echo ">>>>>>>>running test 423"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.123 > ../outputs/t423
echo ">>>>>>>>running test 424"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.124 > ../outputs/t424
echo ">>>>>>>>running test 425"
../source/schedule.exe  2 2 4  < ../inputs/input/tc.125 > ../outputs/t425
echo ">>>>>>>>running test 426"
../source/schedule.exe  0 0 3  < ../inputs/input/tc.126 > ../outputs/t426
echo ">>>>>>>>running test 427"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.127 > ../outputs/t427
echo ">>>>>>>>running test 428"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.128 > ../outputs/t428
echo ">>>>>>>>running test 429"
../source/schedule.exe  3 0 0  < ../inputs/input/tc.129 > ../outputs/t429
echo ">>>>>>>>running test 430"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.130 > ../outputs/t430
echo ">>>>>>>>running test 431"
../source/schedule.exe  0 0 2  < ../inputs/input/tc.131 > ../outputs/t431
echo ">>>>>>>>running test 432"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.132 > ../outputs/t432
echo ">>>>>>>>running test 433"
../source/schedule.exe  0 4 0  < ../inputs/input/tc.133 > ../outputs/t433
echo ">>>>>>>>running test 434"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.134 > ../outputs/t434
echo ">>>>>>>>running test 435"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.135 > ../outputs/t435
echo ">>>>>>>>running test 436"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.136 > ../outputs/t436
echo ">>>>>>>>running test 437"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.137 > ../outputs/t437
echo ">>>>>>>>running test 438"
../source/schedule.exe  1 0 0  < ../inputs/input/tc.138 > ../outputs/t438
echo ">>>>>>>>running test 439"
../source/schedule.exe  4 0 0  < ../inputs/input/tc.139 > ../outputs/t439
echo ">>>>>>>>running test 440"
../source/schedule.exe  0 1 0  < ../inputs/input/tc.140 > ../outputs/t440
echo ">>>>>>>>running test 441"
../source/schedule.exe  0 0 2  < ../inputs/input/tc.141 > ../outputs/t441
echo ">>>>>>>>running test 442"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.142 > ../outputs/t442
echo ">>>>>>>>running test 443"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.143 > ../outputs/t443
echo ">>>>>>>>running test 444"
../source/schedule.exe  0 1 0  < ../inputs/input/tc.144 > ../outputs/t444
echo ">>>>>>>>running test 445"
../source/schedule.exe  0 2 0  < ../inputs/input/tc.145 > ../outputs/t445
echo ">>>>>>>>running test 446"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.146 > ../outputs/t446
echo ">>>>>>>>running test 447"
../source/schedule.exe  0 2 0  < ../inputs/input/tc.147 > ../outputs/t447
echo ">>>>>>>>running test 448"
../source/schedule.exe  2 2 3  < ../inputs/input/tc.148 > ../outputs/t448
echo ">>>>>>>>running test 449"
../source/schedule.exe  0 2 0  < ../inputs/input/tc.149 > ../outputs/t449
echo ">>>>>>>>running test 450"
../source/schedule.exe  0 3 0  < ../inputs/input/tc.150 > ../outputs/t450
echo ">>>>>>>>running test 451"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.151 > ../outputs/t451
echo ">>>>>>>>running test 452"
../source/schedule.exe  0 0 2  < ../inputs/input/tc.152 > ../outputs/t452
echo ">>>>>>>>running test 453"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.153 > ../outputs/t453
echo ">>>>>>>>running test 454"
../source/schedule.exe  3 0 0  < ../inputs/input/tc.154 > ../outputs/t454
echo ">>>>>>>>running test 455"
../source/schedule.exe  1 4 3  < ../inputs/input/tc.155 > ../outputs/t455
echo ">>>>>>>>running test 456"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.156 > ../outputs/t456
echo ">>>>>>>>running test 457"
../source/schedule.exe  2 1 4  < ../inputs/input/tc.157 > ../outputs/t457
echo ">>>>>>>>running test 458"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.158 > ../outputs/t458
echo ">>>>>>>>running test 459"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.159 > ../outputs/t459
echo ">>>>>>>>running test 460"
../source/schedule.exe  3 0 0  < ../inputs/input/tc.160 > ../outputs/t460
echo ">>>>>>>>running test 461"
../source/schedule.exe  0 2 0  < ../inputs/input/tc.161 > ../outputs/t461
echo ">>>>>>>>running test 462"
../source/schedule.exe  0 0 3  < ../inputs/input/tc.162 > ../outputs/t462
echo ">>>>>>>>running test 463"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.163 > ../outputs/t463
echo ">>>>>>>>running test 464"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.164 > ../outputs/t464
echo ">>>>>>>>running test 465"
../source/schedule.exe  0 4 0  < ../inputs/input/tc.165 > ../outputs/t465
echo ">>>>>>>>running test 466"
../source/schedule.exe  0 1 0  < ../inputs/input/tc.166 > ../outputs/t466
echo ">>>>>>>>running test 467"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.167 > ../outputs/t467
echo ">>>>>>>>running test 468"
../source/schedule.exe  4 3 1  < ../inputs/input/tc.168 > ../outputs/t468
echo ">>>>>>>>running test 469"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.169 > ../outputs/t469
echo ">>>>>>>>running test 470"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.170 > ../outputs/t470
echo ">>>>>>>>running test 471"
../source/schedule.exe  2 0 0  < ../inputs/input/tc.171 > ../outputs/t471
echo ">>>>>>>>running test 472"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.172 > ../outputs/t472
echo ">>>>>>>>running test 473"
../source/schedule.exe  4 3 1  < ../inputs/input/tc.173 > ../outputs/t473
echo ">>>>>>>>running test 474"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.174 > ../outputs/t474
echo ">>>>>>>>running test 475"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.175 > ../outputs/t475
echo ">>>>>>>>running test 476"
../source/schedule.exe  1 0 0  < ../inputs/input/tc.176 > ../outputs/t476
echo ">>>>>>>>running test 477"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.177 > ../outputs/t477
echo ">>>>>>>>running test 478"
../source/schedule.exe  3 3 1  < ../inputs/input/tc.178 > ../outputs/t478
echo ">>>>>>>>running test 479"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.179 > ../outputs/t479
echo ">>>>>>>>running test 480"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.180 > ../outputs/t480
echo ">>>>>>>>running test 481"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.181 > ../outputs/t481
echo ">>>>>>>>running test 482"
../source/schedule.exe  0 0 2  < ../inputs/input/tc.182 > ../outputs/t482
echo ">>>>>>>>running test 483"
../source/schedule.exe  0 0 2  < ../inputs/input/tc.183 > ../outputs/t483
echo ">>>>>>>>running test 484"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.184 > ../outputs/t484
echo ">>>>>>>>running test 485"
../source/schedule.exe  3 1 1  < ../inputs/input/tc.185 > ../outputs/t485
echo ">>>>>>>>running test 486"
../source/schedule.exe  1 0 0  < ../inputs/input/tc.186 > ../outputs/t486
echo ">>>>>>>>running test 487"
../source/schedule.exe  4 0 0  < ../inputs/input/tc.187 > ../outputs/t487
echo ">>>>>>>>running test 488"
../source/schedule.exe  0 0 1  < ../inputs/input/tc.188 > ../outputs/t488
echo ">>>>>>>>running test 489"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.189 > ../outputs/t489
echo ">>>>>>>>running test 490"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.190 > ../outputs/t490
echo ">>>>>>>>running test 491"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.191 > ../outputs/t491
echo ">>>>>>>>running test 492"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.192 > ../outputs/t492
echo ">>>>>>>>running test 493"
../source/schedule.exe  1 0 0  < ../inputs/input/tc.193 > ../outputs/t493
echo ">>>>>>>>running test 494"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.194 > ../outputs/t494
echo ">>>>>>>>running test 495"
../source/schedule.exe  2 0 0  < ../inputs/input/tc.195 > ../outputs/t495
echo ">>>>>>>>running test 496"
../source/schedule.exe  4 3 2  < ../inputs/input/tc.196 > ../outputs/t496
echo ">>>>>>>>running test 497"
../source/schedule.exe  1 2 2  < ../inputs/input/tc.197 > ../outputs/t497
echo ">>>>>>>>running test 498"
../source/schedule.exe  2 2 4  < ../inputs/input/tc.198 > ../outputs/t498
echo ">>>>>>>>running test 499"
../source/schedule.exe  1 4 1  < ../inputs/input/tc.199 > ../outputs/t499
echo ">>>>>>>>running test 500"
../source/schedule.exe  3 0 0  < ../inputs/input/tc.200 > ../outputs/t500
echo ">>>>>>>>running test 501"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.201 > ../outputs/t501
echo ">>>>>>>>running test 502"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.202 > ../outputs/t502
echo ">>>>>>>>running test 503"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.203 > ../outputs/t503
echo ">>>>>>>>running test 504"
../source/schedule.exe  0 1 0  < ../inputs/input/tc.204 > ../outputs/t504
echo ">>>>>>>>running test 505"
../source/schedule.exe  0 2 0  < ../inputs/input/tc.205 > ../outputs/t505
echo ">>>>>>>>running test 506"
../source/schedule.exe  0 0 3  < ../inputs/input/tc.206 > ../outputs/t506
echo ">>>>>>>>running test 507"
../source/schedule.exe  0 0 2  < ../inputs/input/tc.207 > ../outputs/t507
echo ">>>>>>>>running test 508"
../source/schedule.exe  3 2 4  < ../inputs/input/tc.208 > ../outputs/t508
echo ">>>>>>>>running test 509"
../source/schedule.exe  0 0 4  < ../inputs/input/tc.209 > ../outputs/t509
echo ">>>>>>>>running test 510"
../source/schedule.exe  0 4 0  < ../inputs/input/tc.210 > ../outputs/t510
echo ">>>>>>>>running test 511"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.211 > ../outputs/t511
echo ">>>>>>>>running test 512"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.212 > ../outputs/t512
echo ">>>>>>>>running test 513"
../source/schedule.exe  3 0 0  < ../inputs/input/tc.213 > ../outputs/t513
echo ">>>>>>>>running test 514"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.214 > ../outputs/t514
echo ">>>>>>>>running test 515"
../source/schedule.exe  1 0 0  < ../inputs/input/tc.215 > ../outputs/t515
echo ">>>>>>>>running test 516"
../source/schedule.exe  4 3 2  < ../inputs/input/tc.216 > ../outputs/t516
echo ">>>>>>>>running test 517"
../source/schedule.exe  2 3 2  < ../inputs/input/tc.217 > ../outputs/t517
echo ">>>>>>>>running test 518"
../source/schedule.exe  0 0 1  < ../inputs/input/tc.218 > ../outputs/t518
echo ">>>>>>>>running test 519"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.219 > ../outputs/t519
echo ">>>>>>>>running test 520"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.220 > ../outputs/t520
echo ">>>>>>>>running test 521"
../source/schedule.exe  3 3 3  < ../inputs/input/tc.221 > ../outputs/t521
echo ">>>>>>>>running test 522"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.222 > ../outputs/t522
echo ">>>>>>>>running test 523"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.223 > ../outputs/t523
echo ">>>>>>>>running test 524"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.224 > ../outputs/t524
echo ">>>>>>>>running test 525"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.225 > ../outputs/t525
echo ">>>>>>>>running test 526"
../source/schedule.exe  1 0 0  < ../inputs/input/tc.226 > ../outputs/t526
echo ">>>>>>>>running test 527"
../source/schedule.exe  1 3 3  < ../inputs/input/tc.227 > ../outputs/t527
echo ">>>>>>>>running test 528"
../source/schedule.exe  0 1 0  < ../inputs/input/tc.228 > ../outputs/t528
echo ">>>>>>>>running test 529"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.229 > ../outputs/t529
echo ">>>>>>>>running test 530"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.230 > ../outputs/t530
echo ">>>>>>>>running test 531"
../source/schedule.exe  4 3 4  < ../inputs/input/tc.231 > ../outputs/t531
echo ">>>>>>>>running test 532"
../source/schedule.exe  0 0 2  < ../inputs/input/tc.232 > ../outputs/t532
echo ">>>>>>>>running test 533"
../source/schedule.exe  3 3 4  < ../inputs/input/tc.233 > ../outputs/t533
echo ">>>>>>>>running test 534"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.234 > ../outputs/t534
echo ">>>>>>>>running test 535"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.235 > ../outputs/t535
echo ">>>>>>>>running test 536"
../source/schedule.exe  3 0 0  < ../inputs/input/tc.236 > ../outputs/t536
echo ">>>>>>>>running test 537"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.237 > ../outputs/t537
echo ">>>>>>>>running test 538"
../source/schedule.exe  0 0 3  < ../inputs/input/tc.238 > ../outputs/t538
echo ">>>>>>>>running test 539"
../source/schedule.exe  3 0 0  < ../inputs/input/tc.239 > ../outputs/t539
echo ">>>>>>>>running test 540"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.240 > ../outputs/t540
echo ">>>>>>>>running test 541"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.241 > ../outputs/t541
echo ">>>>>>>>running test 542"
../source/schedule.exe  4 4 4  < ../inputs/input/tc.242 > ../outputs/t542
echo ">>>>>>>>running test 543"
../source/schedule.exe  0 3 0  < ../inputs/input/tc.243 > ../outputs/t543
echo ">>>>>>>>running test 544"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.244 > ../outputs/t544
echo ">>>>>>>>running test 545"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.245 > ../outputs/t545
echo ">>>>>>>>running test 546"
../source/schedule.exe  2 0 0  < ../inputs/input/tc.246 > ../outputs/t546
echo ">>>>>>>>running test 547"
../source/schedule.exe  4 0 0  < ../inputs/input/tc.247 > ../outputs/t547
echo ">>>>>>>>running test 548"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.248 > ../outputs/t548
echo ">>>>>>>>running test 549"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.249 > ../outputs/t549
echo ">>>>>>>>running test 550"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.250 > ../outputs/t550
echo ">>>>>>>>running test 551"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.251 > ../outputs/t551
echo ">>>>>>>>running test 552"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.252 > ../outputs/t552
echo ">>>>>>>>running test 553"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.253 > ../outputs/t553
echo ">>>>>>>>running test 554"
../source/schedule.exe  0 4 0  < ../inputs/input/tc.254 > ../outputs/t554
echo ">>>>>>>>running test 555"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.255 > ../outputs/t555
echo ">>>>>>>>running test 556"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.256 > ../outputs/t556
echo ">>>>>>>>running test 557"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.257 > ../outputs/t557
echo ">>>>>>>>running test 558"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.258 > ../outputs/t558
echo ">>>>>>>>running test 559"
../source/schedule.exe  3 0 0  < ../inputs/input/tc.259 > ../outputs/t559
echo ">>>>>>>>running test 560"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.260 > ../outputs/t560
echo ">>>>>>>>running test 561"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.261 > ../outputs/t561
echo ">>>>>>>>running test 562"
../source/schedule.exe  2 3 4  < ../inputs/input/tc.262 > ../outputs/t562
echo ">>>>>>>>running test 563"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.263 > ../outputs/t563
echo ">>>>>>>>running test 564"
../source/schedule.exe  0 0 2  < ../inputs/input/tc.264 > ../outputs/t564
echo ">>>>>>>>running test 565"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.265 > ../outputs/t565
echo ">>>>>>>>running test 566"
../source/schedule.exe  0 0 1  < ../inputs/input/tc.266 > ../outputs/t566
echo ">>>>>>>>running test 567"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.267 > ../outputs/t567
echo ">>>>>>>>running test 568"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.268 > ../outputs/t568
echo ">>>>>>>>running test 569"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.269 > ../outputs/t569
echo ">>>>>>>>running test 570"
../source/schedule.exe  0 0 4  < ../inputs/input/tc.270 > ../outputs/t570
echo ">>>>>>>>running test 571"
../source/schedule.exe  0 2 0  < ../inputs/input/tc.271 > ../outputs/t571
echo ">>>>>>>>running test 572"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.272 > ../outputs/t572
echo ">>>>>>>>running test 573"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.273 > ../outputs/t573
echo ">>>>>>>>running test 574"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.274 > ../outputs/t574
echo ">>>>>>>>running test 575"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.275 > ../outputs/t575
echo ">>>>>>>>running test 576"
../source/schedule.exe  0 3 0  < ../inputs/input/tc.276 > ../outputs/t576
echo ">>>>>>>>running test 577"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.277 > ../outputs/t577
echo ">>>>>>>>running test 578"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.278 > ../outputs/t578
echo ">>>>>>>>running test 579"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.279 > ../outputs/t579
echo ">>>>>>>>running test 580"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.280 > ../outputs/t580
echo ">>>>>>>>running test 581"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.281 > ../outputs/t581
echo ">>>>>>>>running test 582"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.282 > ../outputs/t582
echo ">>>>>>>>running test 583"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.283 > ../outputs/t583
echo ">>>>>>>>running test 584"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.284 > ../outputs/t584
echo ">>>>>>>>running test 585"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.285 > ../outputs/t585
echo ">>>>>>>>running test 586"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.286 > ../outputs/t586
echo ">>>>>>>>running test 587"
../source/schedule.exe  2 0 0  < ../inputs/input/tc.287 > ../outputs/t587
echo ">>>>>>>>running test 588"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.288 > ../outputs/t588
echo ">>>>>>>>running test 589"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.289 > ../outputs/t589
echo ">>>>>>>>running test 590"
../source/schedule.exe  0 0 4  < ../inputs/input/tc.290 > ../outputs/t590
echo ">>>>>>>>running test 591"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.291 > ../outputs/t591
echo ">>>>>>>>running test 592"
../source/schedule.exe  0 3 0  < ../inputs/input/tc.292 > ../outputs/t592
echo ">>>>>>>>running test 593"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.293 > ../outputs/t593
echo ">>>>>>>>running test 594"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.294 > ../outputs/t594
echo ">>>>>>>>running test 595"
../source/schedule.exe  0 2 0  < ../inputs/input/tc.295 > ../outputs/t595
echo ">>>>>>>>running test 596"
../source/schedule.exe  0 0 1  < ../inputs/input/tc.296 > ../outputs/t596
echo ">>>>>>>>running test 597"
../source/schedule.exe  1 4 2  < ../inputs/input/tc.297 > ../outputs/t597
echo ">>>>>>>>running test 598"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.298 > ../outputs/t598
echo ">>>>>>>>running test 599"
../source/schedule.exe  0 3 0  < ../inputs/input/tc.299 > ../outputs/t599
echo ">>>>>>>>running test 600"
../source/schedule.exe  0 0 0  < ../inputs/input/tc.300 > ../outputs/t600
echo ">>>>>>>>running test 601"
../source/schedule.exe  5 4 2  < ../inputs/input/dat000 > ../outputs/t601
echo ">>>>>>>>running test 602"
../source/schedule.exe  2 5 2  < ../inputs/input/dat001 > ../outputs/t602
echo ">>>>>>>>running test 603"
../source/schedule.exe  0 3 2  < ../inputs/input/dat002 > ../outputs/t603
echo ">>>>>>>>running test 604"
../source/schedule.exe  5 3 2  < ../inputs/input/dat003 > ../outputs/t604
echo ">>>>>>>>running test 605"
../source/schedule.exe  3 2 1  < ../inputs/input/dat004 > ../outputs/t605
echo ">>>>>>>>running test 606"
../source/schedule.exe  1 1 5  < ../inputs/input/dat005 > ../outputs/t606
echo ">>>>>>>>running test 607"
../source/schedule.exe  2 0 4  < ../inputs/input/dat006 > ../outputs/t607
echo ">>>>>>>>running test 608"
../source/schedule.exe  2 4 4  < ../inputs/input/dat007 > ../outputs/t608
echo ">>>>>>>>running test 609"
../source/schedule.exe  1 3 2  < ../inputs/input/dat008 > ../outputs/t609
echo ">>>>>>>>running test 610"
../source/schedule.exe  5 0 3  < ../inputs/input/dat009 > ../outputs/t610
echo ">>>>>>>>running test 611"
../source/schedule.exe  3 2 3  < ../inputs/input/dat010 > ../outputs/t611
echo ">>>>>>>>running test 612"
../source/schedule.exe  2 5 4  < ../inputs/input/dat011 > ../outputs/t612
echo ">>>>>>>>running test 613"
../source/schedule.exe  3 4 0  < ../inputs/input/dat012 > ../outputs/t613
echo ">>>>>>>>running test 614"
../source/schedule.exe  3 4 2  < ../inputs/input/dat013 > ../outputs/t614
echo ">>>>>>>>running test 615"
../source/schedule.exe  1 1 1  < ../inputs/input/dat014 > ../outputs/t615
echo ">>>>>>>>running test 616"
../source/schedule.exe  1 5 1  < ../inputs/input/dat015 > ../outputs/t616
echo ">>>>>>>>running test 617"
../source/schedule.exe  3 2 3  < ../inputs/input/dat016 > ../outputs/t617
echo ">>>>>>>>running test 618"
../source/schedule.exe  2 4 2  < ../inputs/input/dat017 > ../outputs/t618
echo ">>>>>>>>running test 619"
../source/schedule.exe  1 5 2  < ../inputs/input/dat018 > ../outputs/t619
echo ">>>>>>>>running test 620"
../source/schedule.exe  0 0 5  < ../inputs/input/dat019 > ../outputs/t620
echo ">>>>>>>>running test 621"
../source/schedule.exe  3 4 3  < ../inputs/input/dat020 > ../outputs/t621
echo ">>>>>>>>running test 622"
../source/schedule.exe  4 1 3  < ../inputs/input/dat021 > ../outputs/t622
echo ">>>>>>>>running test 623"
../source/schedule.exe  0 3 0  < ../inputs/input/dat022 > ../outputs/t623
echo ">>>>>>>>running test 624"
../source/schedule.exe  1 1 3  < ../inputs/input/dat023 > ../outputs/t624
echo ">>>>>>>>running test 625"
../source/schedule.exe  5 5 1  < ../inputs/input/dat024 > ../outputs/t625
echo ">>>>>>>>running test 626"
../source/schedule.exe  2 1 3  < ../inputs/input/dat025 > ../outputs/t626
echo ">>>>>>>>running test 627"
../source/schedule.exe  2 2 5  < ../inputs/input/dat026 > ../outputs/t627
echo ">>>>>>>>running test 628"
../source/schedule.exe  5 1 1  < ../inputs/input/dat027 > ../outputs/t628
echo ">>>>>>>>running test 629"
../source/schedule.exe  2 5 1  < ../inputs/input/dat028 > ../outputs/t629
echo ">>>>>>>>running test 630"
../source/schedule.exe  1 1 3  < ../inputs/input/dat029 > ../outputs/t630
echo ">>>>>>>>running test 631"
../source/schedule.exe  5 3 0  < ../inputs/input/dat030 > ../outputs/t631
echo ">>>>>>>>running test 632"
../source/schedule.exe  3 4 1  < ../inputs/input/dat031 > ../outputs/t632
echo ">>>>>>>>running test 633"
../source/schedule.exe  2 0 3  < ../inputs/input/dat032 > ../outputs/t633
echo ">>>>>>>>running test 634"
../source/schedule.exe  2 2 1  < ../inputs/input/dat033 > ../outputs/t634
echo ">>>>>>>>running test 635"
../source/schedule.exe  2 0 4  < ../inputs/input/dat034 > ../outputs/t635
echo ">>>>>>>>running test 636"
../source/schedule.exe  4 2 4  < ../inputs/input/dat035 > ../outputs/t636
echo ">>>>>>>>running test 637"
../source/schedule.exe  5 1 0  < ../inputs/input/dat036 > ../outputs/t637
echo ">>>>>>>>running test 638"
../source/schedule.exe  1 0 3  < ../inputs/input/dat037 > ../outputs/t638
echo ">>>>>>>>running test 639"
../source/schedule.exe  2 5 5  < ../inputs/input/dat038 > ../outputs/t639
echo ">>>>>>>>running test 640"
../source/schedule.exe  5 4 0  < ../inputs/input/dat039 > ../outputs/t640
echo ">>>>>>>>running test 641"
../source/schedule.exe  4 2 2  < ../inputs/input/dat040 > ../outputs/t641
echo ">>>>>>>>running test 642"
../source/schedule.exe  4 4 3  < ../inputs/input/dat041 > ../outputs/t642
echo ">>>>>>>>running test 643"
../source/schedule.exe  3 3 4  < ../inputs/input/dat042 > ../outputs/t643
echo ">>>>>>>>running test 644"
../source/schedule.exe  1 1 4  < ../inputs/input/dat043 > ../outputs/t644
echo ">>>>>>>>running test 645"
../source/schedule.exe  2 2 1  < ../inputs/input/dat044 > ../outputs/t645
echo ">>>>>>>>running test 646"
../source/schedule.exe  1 1 3  < ../inputs/input/dat045 > ../outputs/t646
echo ">>>>>>>>running test 647"
../source/schedule.exe  3 3 4  < ../inputs/input/dat046 > ../outputs/t647
echo ">>>>>>>>running test 648"
../source/schedule.exe  5 2 0  < ../inputs/input/dat047 > ../outputs/t648
echo ">>>>>>>>running test 649"
../source/schedule.exe  3 4 1  < ../inputs/input/dat048 > ../outputs/t649
echo ">>>>>>>>running test 650"
../source/schedule.exe  0 1 1  < ../inputs/input/dat049 > ../outputs/t650
echo ">>>>>>>>running test 651"
../source/schedule.exe  1 1 2  < ../inputs/input/dat050 > ../outputs/t651
echo ">>>>>>>>running test 652"
../source/schedule.exe  4 4 5  < ../inputs/input/dat051 > ../outputs/t652
echo ">>>>>>>>running test 653"
../source/schedule.exe  4 4 2  < ../inputs/input/dat052 > ../outputs/t653
echo ">>>>>>>>running test 654"
../source/schedule.exe  5 0 3  < ../inputs/input/dat053 > ../outputs/t654
echo ">>>>>>>>running test 655"
../source/schedule.exe  4 1 2  < ../inputs/input/dat054 > ../outputs/t655
echo ">>>>>>>>running test 656"
../source/schedule.exe  1 5 5  < ../inputs/input/dat055 > ../outputs/t656
echo ">>>>>>>>running test 657"
../source/schedule.exe  0 3 1  < ../inputs/input/dat056 > ../outputs/t657
echo ">>>>>>>>running test 658"
../source/schedule.exe  0 4 3  < ../inputs/input/dat057 > ../outputs/t658
echo ">>>>>>>>running test 659"
../source/schedule.exe  1 3 2  < ../inputs/input/dat058 > ../outputs/t659
echo ">>>>>>>>running test 660"
../source/schedule.exe  4 0 1  < ../inputs/input/dat059 > ../outputs/t660
echo ">>>>>>>>running test 661"
../source/schedule.exe  2 0 3  < ../inputs/input/dat060 > ../outputs/t661
echo ">>>>>>>>running test 662"
../source/schedule.exe  4 4 5  < ../inputs/input/dat061 > ../outputs/t662
echo ">>>>>>>>running test 663"
../source/schedule.exe  5 5 0  < ../inputs/input/dat062 > ../outputs/t663
echo ">>>>>>>>running test 664"
../source/schedule.exe  1 0 1  < ../inputs/input/dat063 > ../outputs/t664
echo ">>>>>>>>running test 665"
../source/schedule.exe  1 5 1  < ../inputs/input/dat064 > ../outputs/t665
echo ">>>>>>>>running test 666"
../source/schedule.exe  3 2 0  < ../inputs/input/dat065 > ../outputs/t666
echo ">>>>>>>>running test 667"
../source/schedule.exe  0 3 2  < ../inputs/input/dat066 > ../outputs/t667
echo ">>>>>>>>running test 668"
../source/schedule.exe  4 2 2  < ../inputs/input/dat067 > ../outputs/t668
echo ">>>>>>>>running test 669"
../source/schedule.exe  3 5 1  < ../inputs/input/dat068 > ../outputs/t669
echo ">>>>>>>>running test 670"
../source/schedule.exe  0 4 3  < ../inputs/input/dat069 > ../outputs/t670
echo ">>>>>>>>running test 671"
../source/schedule.exe  1 0 1  < ../inputs/input/dat070 > ../outputs/t671
echo ">>>>>>>>running test 672"
../source/schedule.exe  1 2 2  < ../inputs/input/dat071 > ../outputs/t672
echo ">>>>>>>>running test 673"
../source/schedule.exe  5 1 0  < ../inputs/input/dat072 > ../outputs/t673
echo ">>>>>>>>running test 674"
../source/schedule.exe  4 2 1  < ../inputs/input/dat073 > ../outputs/t674
echo ">>>>>>>>running test 675"
../source/schedule.exe  5 3 0  < ../inputs/input/dat074 > ../outputs/t675
echo ">>>>>>>>running test 676"
../source/schedule.exe  5 4 3  < ../inputs/input/dat075 > ../outputs/t676
echo ">>>>>>>>running test 677"
../source/schedule.exe  3 3 4  < ../inputs/input/dat076 > ../outputs/t677
echo ">>>>>>>>running test 678"
../source/schedule.exe  1 2 1  < ../inputs/input/dat077 > ../outputs/t678
echo ">>>>>>>>running test 679"
../source/schedule.exe  4 3 3  < ../inputs/input/dat078 > ../outputs/t679
echo ">>>>>>>>running test 680"
../source/schedule.exe  0 1 0  < ../inputs/input/dat079 > ../outputs/t680
echo ">>>>>>>>running test 681"
../source/schedule.exe  0 5 5  < ../inputs/input/dat080 > ../outputs/t681
echo ">>>>>>>>running test 682"
../source/schedule.exe  3 1 5  < ../inputs/input/dat081 > ../outputs/t682
echo ">>>>>>>>running test 683"
../source/schedule.exe  0 5 1  < ../inputs/input/dat082 > ../outputs/t683
echo ">>>>>>>>running test 684"
../source/schedule.exe  1 1 3  < ../inputs/input/dat083 > ../outputs/t684
echo ">>>>>>>>running test 685"
../source/schedule.exe  3 1 3  < ../inputs/input/dat084 > ../outputs/t685
echo ">>>>>>>>running test 686"
../source/schedule.exe  4 4 0  < ../inputs/input/dat085 > ../outputs/t686
echo ">>>>>>>>running test 687"
../source/schedule.exe  1 0 3  < ../inputs/input/dat086 > ../outputs/t687
echo ">>>>>>>>running test 688"
../source/schedule.exe  5 1 0  < ../inputs/input/dat087 > ../outputs/t688
echo ">>>>>>>>running test 689"
../source/schedule.exe  0 2 2  < ../inputs/input/dat088 > ../outputs/t689
echo ">>>>>>>>running test 690"
../source/schedule.exe  0 4 4  < ../inputs/input/dat089 > ../outputs/t690
echo ">>>>>>>>running test 691"
../source/schedule.exe  5 5 4  < ../inputs/input/dat090 > ../outputs/t691
echo ">>>>>>>>running test 692"
../source/schedule.exe  0 2 1  < ../inputs/input/dat091 > ../outputs/t692
echo ">>>>>>>>running test 693"
../source/schedule.exe  2 5 2  < ../inputs/input/dat092 > ../outputs/t693
echo ">>>>>>>>running test 694"
../source/schedule.exe  1 1 5  < ../inputs/input/dat093 > ../outputs/t694
echo ">>>>>>>>running test 695"
../source/schedule.exe  2 3 1  < ../inputs/input/dat094 > ../outputs/t695
echo ">>>>>>>>running test 696"
../source/schedule.exe  5 1 0  < ../inputs/input/dat095 > ../outputs/t696
echo ">>>>>>>>running test 697"
../source/schedule.exe  5 4 1  < ../inputs/input/dat096 > ../outputs/t697
echo ">>>>>>>>running test 698"
../source/schedule.exe  5 5 1  < ../inputs/input/dat097 > ../outputs/t698
echo ">>>>>>>>running test 699"
../source/schedule.exe  3 2 1  < ../inputs/input/dat098 > ../outputs/t699
echo ">>>>>>>>running test 700"
../source/schedule.exe  0 5 3  < ../inputs/input/dat099 > ../outputs/t700
echo ">>>>>>>>running test 701"
../source/schedule.exe  0 1 2  < ../inputs/input/dat100 > ../outputs/t701
echo ">>>>>>>>running test 702"
../source/schedule.exe  2 5 0  < ../inputs/input/dat101 > ../outputs/t702
echo ">>>>>>>>running test 703"
../source/schedule.exe  1 2 3  < ../inputs/input/dat102 > ../outputs/t703
echo ">>>>>>>>running test 704"
../source/schedule.exe  2 4 4  < ../inputs/input/dat103 > ../outputs/t704
echo ">>>>>>>>running test 705"
../source/schedule.exe  2 0 0  < ../inputs/input/dat104 > ../outputs/t705
echo ">>>>>>>>running test 706"
../source/schedule.exe  2 4 1  < ../inputs/input/dat105 > ../outputs/t706
echo ">>>>>>>>running test 707"
../source/schedule.exe  5 2 4  < ../inputs/input/dat106 > ../outputs/t707
echo ">>>>>>>>running test 708"
../source/schedule.exe  0 5 3  < ../inputs/input/dat107 > ../outputs/t708
echo ">>>>>>>>running test 709"
../source/schedule.exe  3 2 2  < ../inputs/input/dat108 > ../outputs/t709
echo ">>>>>>>>running test 710"
../source/schedule.exe  3 5 5  < ../inputs/input/dat109 > ../outputs/t710
echo ">>>>>>>>running test 711"
../source/schedule.exe  5 0 3  < ../inputs/input/dat110 > ../outputs/t711
echo ">>>>>>>>running test 712"
../source/schedule.exe  2 4 5  < ../inputs/input/dat111 > ../outputs/t712
echo ">>>>>>>>running test 713"
../source/schedule.exe  3 5 1  < ../inputs/input/dat112 > ../outputs/t713
echo ">>>>>>>>running test 714"
../source/schedule.exe  0 3 1  < ../inputs/input/dat113 > ../outputs/t714
echo ">>>>>>>>running test 715"
../source/schedule.exe  1 1 3  < ../inputs/input/dat114 > ../outputs/t715
echo ">>>>>>>>running test 716"
../source/schedule.exe  1 5 4  < ../inputs/input/dat115 > ../outputs/t716
echo ">>>>>>>>running test 717"
../source/schedule.exe  3 1 2  < ../inputs/input/dat116 > ../outputs/t717
echo ">>>>>>>>running test 718"
../source/schedule.exe  1 5 5  < ../inputs/input/dat117 > ../outputs/t718
echo ">>>>>>>>running test 719"
../source/schedule.exe  1 3 5  < ../inputs/input/dat118 > ../outputs/t719
echo ">>>>>>>>running test 720"
../source/schedule.exe  2 1 1  < ../inputs/input/dat119 > ../outputs/t720
echo ">>>>>>>>running test 721"
../source/schedule.exe  4 2 3  < ../inputs/input/dat120 > ../outputs/t721
echo ">>>>>>>>running test 722"
../source/schedule.exe  4 4 1  < ../inputs/input/dat121 > ../outputs/t722
echo ">>>>>>>>running test 723"
../source/schedule.exe  1 1 2  < ../inputs/input/dat122 > ../outputs/t723
echo ">>>>>>>>running test 724"
../source/schedule.exe  1 4 3  < ../inputs/input/dat123 > ../outputs/t724
echo ">>>>>>>>running test 725"
../source/schedule.exe  0 1 4  < ../inputs/input/dat124 > ../outputs/t725
echo ">>>>>>>>running test 726"
../source/schedule.exe  0 4 3  < ../inputs/input/dat125 > ../outputs/t726
echo ">>>>>>>>running test 727"
../source/schedule.exe  3 5 5  < ../inputs/input/dat126 > ../outputs/t727
echo ">>>>>>>>running test 728"
../source/schedule.exe  5 3 5  < ../inputs/input/dat127 > ../outputs/t728
echo ">>>>>>>>running test 729"
../source/schedule.exe  1 5 1  < ../inputs/input/dat128 > ../outputs/t729
echo ">>>>>>>>running test 730"
../source/schedule.exe  0 5 1  < ../inputs/input/dat129 > ../outputs/t730
echo ">>>>>>>>running test 731"
../source/schedule.exe  4 3 1  < ../inputs/input/dat130 > ../outputs/t731
echo ">>>>>>>>running test 732"
../source/schedule.exe  4 4 4  < ../inputs/input/dat131 > ../outputs/t732
echo ">>>>>>>>running test 733"
../source/schedule.exe  4 2 3  < ../inputs/input/dat132 > ../outputs/t733
echo ">>>>>>>>running test 734"
../source/schedule.exe  2 3 3  < ../inputs/input/dat133 > ../outputs/t734
echo ">>>>>>>>running test 735"
../source/schedule.exe  0 4 5  < ../inputs/input/dat134 > ../outputs/t735
echo ">>>>>>>>running test 736"
../source/schedule.exe  5 3 2  < ../inputs/input/dat135 > ../outputs/t736
echo ">>>>>>>>running test 737"
../source/schedule.exe  2 5 5  < ../inputs/input/dat136 > ../outputs/t737
echo ">>>>>>>>running test 738"
../source/schedule.exe  3 2 2  < ../inputs/input/dat137 > ../outputs/t738
echo ">>>>>>>>running test 739"
../source/schedule.exe  0 3 3  < ../inputs/input/dat138 > ../outputs/t739
echo ">>>>>>>>running test 740"
../source/schedule.exe  2 4 5  < ../inputs/input/dat139 > ../outputs/t740
echo ">>>>>>>>running test 741"
../source/schedule.exe  0 4 5  < ../inputs/input/dat140 > ../outputs/t741
echo ">>>>>>>>running test 742"
../source/schedule.exe  4 0 3  < ../inputs/input/dat141 > ../outputs/t742
echo ">>>>>>>>running test 743"
../source/schedule.exe  1 0 2  < ../inputs/input/dat142 > ../outputs/t743
echo ">>>>>>>>running test 744"
../source/schedule.exe  5 3 5  < ../inputs/input/dat143 > ../outputs/t744
echo ">>>>>>>>running test 745"
../source/schedule.exe  5 5 4  < ../inputs/input/dat144 > ../outputs/t745
echo ">>>>>>>>running test 746"
../source/schedule.exe  1 3 5  < ../inputs/input/dat145 > ../outputs/t746
echo ">>>>>>>>running test 747"
../source/schedule.exe  5 4 0  < ../inputs/input/dat146 > ../outputs/t747
echo ">>>>>>>>running test 748"
../source/schedule.exe  3 0 1  < ../inputs/input/dat147 > ../outputs/t748
echo ">>>>>>>>running test 749"
../source/schedule.exe  5 4 4  < ../inputs/input/dat148 > ../outputs/t749
echo ">>>>>>>>running test 750"
../source/schedule.exe  3 5 3  < ../inputs/input/dat149 > ../outputs/t750
echo ">>>>>>>>running test 751"
../source/schedule.exe  1 0 3  < ../inputs/input/dat150 > ../outputs/t751
echo ">>>>>>>>running test 752"
../source/schedule.exe  2 0 5  < ../inputs/input/dat151 > ../outputs/t752
echo ">>>>>>>>running test 753"
../source/schedule.exe  5 3 2  < ../inputs/input/dat152 > ../outputs/t753
echo ">>>>>>>>running test 754"
../source/schedule.exe  2 1 0  < ../inputs/input/dat153 > ../outputs/t754
echo ">>>>>>>>running test 755"
../source/schedule.exe  1 4 0  < ../inputs/input/dat154 > ../outputs/t755
echo ">>>>>>>>running test 756"
../source/schedule.exe  4 1 5  < ../inputs/input/dat155 > ../outputs/t756
echo ">>>>>>>>running test 757"
../source/schedule.exe  1 3 5  < ../inputs/input/dat156 > ../outputs/t757
echo ">>>>>>>>running test 758"
../source/schedule.exe  5 4 5  < ../inputs/input/dat157 > ../outputs/t758
echo ">>>>>>>>running test 759"
../source/schedule.exe  4 0 2  < ../inputs/input/dat158 > ../outputs/t759
echo ">>>>>>>>running test 760"
../source/schedule.exe  2 0 0  < ../inputs/input/dat159 > ../outputs/t760
echo ">>>>>>>>running test 761"
../source/schedule.exe  1 1 1  < ../inputs/input/dat160 > ../outputs/t761
echo ">>>>>>>>running test 762"
../source/schedule.exe  4 3 4  < ../inputs/input/dat161 > ../outputs/t762
echo ">>>>>>>>running test 763"
../source/schedule.exe  0 2 1  < ../inputs/input/dat162 > ../outputs/t763
echo ">>>>>>>>running test 764"
../source/schedule.exe  4 5 4  < ../inputs/input/dat163 > ../outputs/t764
echo ">>>>>>>>running test 765"
../source/schedule.exe  4 1 5  < ../inputs/input/dat164 > ../outputs/t765
echo ">>>>>>>>running test 766"
../source/schedule.exe  3 4 4  < ../inputs/input/dat165 > ../outputs/t766
echo ">>>>>>>>running test 767"
../source/schedule.exe  4 5 1  < ../inputs/input/dat166 > ../outputs/t767
echo ">>>>>>>>running test 768"
../source/schedule.exe  1 0 1  < ../inputs/input/dat167 > ../outputs/t768
echo ">>>>>>>>running test 769"
../source/schedule.exe  4 5 3  < ../inputs/input/dat168 > ../outputs/t769
echo ">>>>>>>>running test 770"
../source/schedule.exe  2 3 0  < ../inputs/input/dat169 > ../outputs/t770
echo ">>>>>>>>running test 771"
../source/schedule.exe  5 0 5  < ../inputs/input/dat170 > ../outputs/t771
echo ">>>>>>>>running test 772"
../source/schedule.exe  2 4 4  < ../inputs/input/dat171 > ../outputs/t772
echo ">>>>>>>>running test 773"
../source/schedule.exe  5 0 2  < ../inputs/input/dat172 > ../outputs/t773
echo ">>>>>>>>running test 774"
../source/schedule.exe  2 5 4  < ../inputs/input/dat173 > ../outputs/t774
echo ">>>>>>>>running test 775"
../source/schedule.exe  0 2 3  < ../inputs/input/dat174 > ../outputs/t775
echo ">>>>>>>>running test 776"
../source/schedule.exe  4 1 5  < ../inputs/input/dat175 > ../outputs/t776
echo ">>>>>>>>running test 777"
../source/schedule.exe  4 2 0  < ../inputs/input/dat176 > ../outputs/t777
echo ">>>>>>>>running test 778"
../source/schedule.exe  5 3 0  < ../inputs/input/dat177 > ../outputs/t778
echo ">>>>>>>>running test 779"
../source/schedule.exe  5 4 2  < ../inputs/input/dat178 > ../outputs/t779
echo ">>>>>>>>running test 780"
../source/schedule.exe  4 2 3  < ../inputs/input/dat179 > ../outputs/t780
echo ">>>>>>>>running test 781"
../source/schedule.exe  3 5 0  < ../inputs/input/dat180 > ../outputs/t781
echo ">>>>>>>>running test 782"
../source/schedule.exe  2 2 0  < ../inputs/input/dat181 > ../outputs/t782
echo ">>>>>>>>running test 783"
../source/schedule.exe  5 4 5  < ../inputs/input/dat182 > ../outputs/t783
echo ">>>>>>>>running test 784"
../source/schedule.exe  5 0 2  < ../inputs/input/dat183 > ../outputs/t784
echo ">>>>>>>>running test 785"
../source/schedule.exe  5 2 0  < ../inputs/input/dat184 > ../outputs/t785
echo ">>>>>>>>running test 786"
../source/schedule.exe  5 2 0  < ../inputs/input/dat185 > ../outputs/t786
echo ">>>>>>>>running test 787"
../source/schedule.exe  1 4 5  < ../inputs/input/dat186 > ../outputs/t787
echo ">>>>>>>>running test 788"
../source/schedule.exe  5 1 1  < ../inputs/input/dat187 > ../outputs/t788
echo ">>>>>>>>running test 789"
../source/schedule.exe  1 1 5  < ../inputs/input/dat188 > ../outputs/t789
echo ">>>>>>>>running test 790"
../source/schedule.exe  3 5 0  < ../inputs/input/dat189 > ../outputs/t790
echo ">>>>>>>>running test 791"
../source/schedule.exe  3 1 3  < ../inputs/input/dat190 > ../outputs/t791
echo ">>>>>>>>running test 792"
../source/schedule.exe  4 2 2  < ../inputs/input/dat191 > ../outputs/t792
echo ">>>>>>>>running test 793"
../source/schedule.exe  2 2 3  < ../inputs/input/dat192 > ../outputs/t793
echo ">>>>>>>>running test 794"
../source/schedule.exe  5 3 2  < ../inputs/input/dat193 > ../outputs/t794
echo ">>>>>>>>running test 795"
../source/schedule.exe  4 4 1  < ../inputs/input/dat194 > ../outputs/t795
echo ">>>>>>>>running test 796"
../source/schedule.exe  3 2 1  < ../inputs/input/dat195 > ../outputs/t796
echo ">>>>>>>>running test 797"
../source/schedule.exe  1 2 4  < ../inputs/input/dat196 > ../outputs/t797
echo ">>>>>>>>running test 798"
../source/schedule.exe  0 1 2  < ../inputs/input/dat197 > ../outputs/t798
echo ">>>>>>>>running test 799"
../source/schedule.exe  3 2 4  < ../inputs/input/dat198 > ../outputs/t799
echo ">>>>>>>>running test 800"
../source/schedule.exe  1 3 4  < ../inputs/input/dat199 > ../outputs/t800
echo ">>>>>>>>running test 801"
../source/schedule.exe  5 3 2  < ../inputs/input/dat200 > ../outputs/t801
echo ">>>>>>>>running test 802"
../source/schedule.exe  5 3 4  < ../inputs/input/dat201 > ../outputs/t802
echo ">>>>>>>>running test 803"
../source/schedule.exe  4 1 0  < ../inputs/input/dat202 > ../outputs/t803
echo ">>>>>>>>running test 804"
../source/schedule.exe  2 2 1  < ../inputs/input/dat203 > ../outputs/t804
echo ">>>>>>>>running test 805"
../source/schedule.exe  0 3 2  < ../inputs/input/dat204 > ../outputs/t805
echo ">>>>>>>>running test 806"
../source/schedule.exe  0 1 4  < ../inputs/input/dat205 > ../outputs/t806
echo ">>>>>>>>running test 807"
../source/schedule.exe  2 0 3  < ../inputs/input/dat206 > ../outputs/t807
echo ">>>>>>>>running test 808"
../source/schedule.exe  1 3 3  < ../inputs/input/dat207 > ../outputs/t808
echo ">>>>>>>>running test 809"
../source/schedule.exe  1 2 0  < ../inputs/input/dat208 > ../outputs/t809
echo ">>>>>>>>running test 810"
../source/schedule.exe  1 4 1  < ../inputs/input/dat209 > ../outputs/t810
echo ">>>>>>>>running test 811"
../source/schedule.exe  2 4 3  < ../inputs/input/dat210 > ../outputs/t811
echo ">>>>>>>>running test 812"
../source/schedule.exe  5 1 1  < ../inputs/input/dat211 > ../outputs/t812
echo ">>>>>>>>running test 813"
../source/schedule.exe  3 2 5  < ../inputs/input/dat212 > ../outputs/t813
echo ">>>>>>>>running test 814"
../source/schedule.exe  5 3 1  < ../inputs/input/dat213 > ../outputs/t814
echo ">>>>>>>>running test 815"
../source/schedule.exe  0 5 4  < ../inputs/input/dat214 > ../outputs/t815
echo ">>>>>>>>running test 816"
../source/schedule.exe  0 4 4  < ../inputs/input/dat215 > ../outputs/t816
echo ">>>>>>>>running test 817"
../source/schedule.exe  2 2 3  < ../inputs/input/dat216 > ../outputs/t817
echo ">>>>>>>>running test 818"
../source/schedule.exe  5 2 4  < ../inputs/input/dat217 > ../outputs/t818
echo ">>>>>>>>running test 819"
../source/schedule.exe  0 5 4  < ../inputs/input/dat218 > ../outputs/t819
echo ">>>>>>>>running test 820"
../source/schedule.exe  1 0 4  < ../inputs/input/dat219 > ../outputs/t820
echo ">>>>>>>>running test 821"
../source/schedule.exe  1 2 5  < ../inputs/input/dat220 > ../outputs/t821
echo ">>>>>>>>running test 822"
../source/schedule.exe  2 1 1  < ../inputs/input/dat221 > ../outputs/t822
echo ">>>>>>>>running test 823"
../source/schedule.exe  5 2 1  < ../inputs/input/dat222 > ../outputs/t823
echo ">>>>>>>>running test 824"
../source/schedule.exe  3 2 0  < ../inputs/input/dat223 > ../outputs/t824
echo ">>>>>>>>running test 825"
../source/schedule.exe  3 5 0  < ../inputs/input/dat224 > ../outputs/t825
echo ">>>>>>>>running test 826"
../source/schedule.exe  4 2 5  < ../inputs/input/dat225 > ../outputs/t826
echo ">>>>>>>>running test 827"
../source/schedule.exe  5 5 3  < ../inputs/input/dat226 > ../outputs/t827
echo ">>>>>>>>running test 828"
../source/schedule.exe  0 4 1  < ../inputs/input/dat227 > ../outputs/t828
echo ">>>>>>>>running test 829"
../source/schedule.exe  2 1 1  < ../inputs/input/dat228 > ../outputs/t829
echo ">>>>>>>>running test 830"
../source/schedule.exe  4 4 0  < ../inputs/input/dat229 > ../outputs/t830
echo ">>>>>>>>running test 831"
../source/schedule.exe  0 3 2  < ../inputs/input/dat230 > ../outputs/t831
echo ">>>>>>>>running test 832"
../source/schedule.exe  2 1 3  < ../inputs/input/dat231 > ../outputs/t832
echo ">>>>>>>>running test 833"
../source/schedule.exe  5 0 2  < ../inputs/input/dat232 > ../outputs/t833
echo ">>>>>>>>running test 834"
../source/schedule.exe  5 2 4  < ../inputs/input/dat233 > ../outputs/t834
echo ">>>>>>>>running test 835"
../source/schedule.exe  4 2 2  < ../inputs/input/dat234 > ../outputs/t835
echo ">>>>>>>>running test 836"
../source/schedule.exe  0 4 5  < ../inputs/input/dat235 > ../outputs/t836
echo ">>>>>>>>running test 837"
../source/schedule.exe  3 1 3  < ../inputs/input/dat236 > ../outputs/t837
echo ">>>>>>>>running test 838"
../source/schedule.exe  4 1 0  < ../inputs/input/dat237 > ../outputs/t838
echo ">>>>>>>>running test 839"
../source/schedule.exe  0 5 3  < ../inputs/input/dat238 > ../outputs/t839
echo ">>>>>>>>running test 840"
../source/schedule.exe  1 0 2  < ../inputs/input/dat239 > ../outputs/t840
echo ">>>>>>>>running test 841"
../source/schedule.exe  4 3 1  < ../inputs/input/dat240 > ../outputs/t841
echo ">>>>>>>>running test 842"
../source/schedule.exe  5 1 1  < ../inputs/input/dat241 > ../outputs/t842
echo ">>>>>>>>running test 843"
../source/schedule.exe  3 4 2  < ../inputs/input/dat242 > ../outputs/t843
echo ">>>>>>>>running test 844"
../source/schedule.exe  4 2 4  < ../inputs/input/dat243 > ../outputs/t844
echo ">>>>>>>>running test 845"
../source/schedule.exe  4 3 4  < ../inputs/input/dat244 > ../outputs/t845
echo ">>>>>>>>running test 846"
../source/schedule.exe  3 0 2  < ../inputs/input/dat245 > ../outputs/t846
echo ">>>>>>>>running test 847"
../source/schedule.exe  0 4 3  < ../inputs/input/dat246 > ../outputs/t847
echo ">>>>>>>>running test 848"
../source/schedule.exe  0 0 5  < ../inputs/input/dat247 > ../outputs/t848
echo ">>>>>>>>running test 849"
../source/schedule.exe  2 4 0  < ../inputs/input/dat248 > ../outputs/t849
echo ">>>>>>>>running test 850"
../source/schedule.exe  4 3 2  < ../inputs/input/dat249 > ../outputs/t850
echo ">>>>>>>>running test 851"
../source/schedule.exe  1 5 4  < ../inputs/input/dat250 > ../outputs/t851
echo ">>>>>>>>running test 852"
../source/schedule.exe  4 2 4  < ../inputs/input/dat251 > ../outputs/t852
echo ">>>>>>>>running test 853"
../source/schedule.exe  0 2 1  < ../inputs/input/dat252 > ../outputs/t853
echo ">>>>>>>>running test 854"
../source/schedule.exe  0 1 3  < ../inputs/input/dat253 > ../outputs/t854
echo ">>>>>>>>running test 855"
../source/schedule.exe  3 2 2  < ../inputs/input/dat254 > ../outputs/t855
echo ">>>>>>>>running test 856"
../source/schedule.exe  3 2 0  < ../inputs/input/dat255 > ../outputs/t856
echo ">>>>>>>>running test 857"
../source/schedule.exe  5 1 1  < ../inputs/input/dat256 > ../outputs/t857
echo ">>>>>>>>running test 858"
../source/schedule.exe  1 3 3  < ../inputs/input/dat257 > ../outputs/t858
echo ">>>>>>>>running test 859"
../source/schedule.exe  0 3 3  < ../inputs/input/dat258 > ../outputs/t859
echo ">>>>>>>>running test 860"
../source/schedule.exe  1 0 2  < ../inputs/input/dat259 > ../outputs/t860
echo ">>>>>>>>running test 861"
../source/schedule.exe  2 5 1  < ../inputs/input/dat260 > ../outputs/t861
echo ">>>>>>>>running test 862"
../source/schedule.exe  1 3 4  < ../inputs/input/dat261 > ../outputs/t862
echo ">>>>>>>>running test 863"
../source/schedule.exe  3 5 3  < ../inputs/input/dat262 > ../outputs/t863
echo ">>>>>>>>running test 864"
../source/schedule.exe  1 1 3  < ../inputs/input/dat263 > ../outputs/t864
echo ">>>>>>>>running test 865"
../source/schedule.exe  4 2 3  < ../inputs/input/dat264 > ../outputs/t865
echo ">>>>>>>>running test 866"
../source/schedule.exe  0 0 4  < ../inputs/input/dat265 > ../outputs/t866
echo ">>>>>>>>running test 867"
../source/schedule.exe  4 0 1  < ../inputs/input/dat266 > ../outputs/t867
echo ">>>>>>>>running test 868"
../source/schedule.exe  1 1 5  < ../inputs/input/dat267 > ../outputs/t868
echo ">>>>>>>>running test 869"
../source/schedule.exe  0 0 2  < ../inputs/input/dat268 > ../outputs/t869
echo ">>>>>>>>running test 870"
../source/schedule.exe  5 4 1  < ../inputs/input/dat269 > ../outputs/t870
echo ">>>>>>>>running test 871"
../source/schedule.exe  3 3 3  < ../inputs/input/dat270 > ../outputs/t871
echo ">>>>>>>>running test 872"
../source/schedule.exe  2 1 0  < ../inputs/input/dat271 > ../outputs/t872
echo ">>>>>>>>running test 873"
../source/schedule.exe  3 3 4  < ../inputs/input/dat272 > ../outputs/t873
echo ">>>>>>>>running test 874"
../source/schedule.exe  5 4 4  < ../inputs/input/dat273 > ../outputs/t874
echo ">>>>>>>>running test 875"
../source/schedule.exe  5 1 2  < ../inputs/input/dat274 > ../outputs/t875
echo ">>>>>>>>running test 876"
../source/schedule.exe  2 4 3  < ../inputs/input/dat275 > ../outputs/t876
echo ">>>>>>>>running test 877"
../source/schedule.exe  3 4 4  < ../inputs/input/dat276 > ../outputs/t877
echo ">>>>>>>>running test 878"
../source/schedule.exe  1 3 5  < ../inputs/input/dat277 > ../outputs/t878
echo ">>>>>>>>running test 879"
../source/schedule.exe  5 4 4  < ../inputs/input/dat278 > ../outputs/t879
echo ">>>>>>>>running test 880"
../source/schedule.exe  1 1 4  < ../inputs/input/dat279 > ../outputs/t880
echo ">>>>>>>>running test 881"
../source/schedule.exe  0 3 0  < ../inputs/input/dat280 > ../outputs/t881
echo ">>>>>>>>running test 882"
../source/schedule.exe  1 1 5  < ../inputs/input/dat281 > ../outputs/t882
echo ">>>>>>>>running test 883"
../source/schedule.exe  4 5 2  < ../inputs/input/dat282 > ../outputs/t883
echo ">>>>>>>>running test 884"
../source/schedule.exe  3 3 2  < ../inputs/input/dat283 > ../outputs/t884
echo ">>>>>>>>running test 885"
../source/schedule.exe  2 4 2  < ../inputs/input/dat284 > ../outputs/t885
echo ">>>>>>>>running test 886"
../source/schedule.exe  4 4 5  < ../inputs/input/dat285 > ../outputs/t886
echo ">>>>>>>>running test 887"
../source/schedule.exe  2 1 0  < ../inputs/input/dat286 > ../outputs/t887
echo ">>>>>>>>running test 888"
../source/schedule.exe  1 4 1  < ../inputs/input/dat287 > ../outputs/t888
echo ">>>>>>>>running test 889"
../source/schedule.exe  5 1 5  < ../inputs/input/dat288 > ../outputs/t889
echo ">>>>>>>>running test 890"
../source/schedule.exe  1 0 1  < ../inputs/input/dat289 > ../outputs/t890
echo ">>>>>>>>running test 891"
../source/schedule.exe  3 2 0  < ../inputs/input/dat290 > ../outputs/t891
echo ">>>>>>>>running test 892"
../source/schedule.exe  3 1 3  < ../inputs/input/dat291 > ../outputs/t892
echo ">>>>>>>>running test 893"
../source/schedule.exe  5 2 5  < ../inputs/input/dat292 > ../outputs/t893
echo ">>>>>>>>running test 894"
../source/schedule.exe  3 2 0  < ../inputs/input/dat293 > ../outputs/t894
echo ">>>>>>>>running test 895"
../source/schedule.exe  2 1 5  < ../inputs/input/dat294 > ../outputs/t895
echo ">>>>>>>>running test 896"
../source/schedule.exe  4 0 1  < ../inputs/input/dat295 > ../outputs/t896
echo ">>>>>>>>running test 897"
../source/schedule.exe  0 4 2  < ../inputs/input/dat296 > ../outputs/t897
echo ">>>>>>>>running test 898"
../source/schedule.exe  0 5 0  < ../inputs/input/dat297 > ../outputs/t898
echo ">>>>>>>>running test 899"
../source/schedule.exe  4 5 1  < ../inputs/input/dat298 > ../outputs/t899
echo ">>>>>>>>running test 900"
../source/schedule.exe  5 1 5  < ../inputs/input/dat299 > ../outputs/t900
echo ">>>>>>>>running test 901"
../source/schedule.exe  0 1 3  < ../inputs/input/dat300 > ../outputs/t901
echo ">>>>>>>>running test 902"
../source/schedule.exe  0 0 1  < ../inputs/input/dat301 > ../outputs/t902
echo ">>>>>>>>running test 903"
../source/schedule.exe  0 0 3  < ../inputs/input/dat302 > ../outputs/t903
echo ">>>>>>>>running test 904"
../source/schedule.exe  3 0 5  < ../inputs/input/dat303 > ../outputs/t904
echo ">>>>>>>>running test 905"
../source/schedule.exe  5 3 2  < ../inputs/input/dat304 > ../outputs/t905
echo ">>>>>>>>running test 906"
../source/schedule.exe  3 5 1  < ../inputs/input/dat305 > ../outputs/t906
echo ">>>>>>>>running test 907"
../source/schedule.exe  2 1 1  < ../inputs/input/dat306 > ../outputs/t907
echo ">>>>>>>>running test 908"
../source/schedule.exe  2 2 1  < ../inputs/input/dat307 > ../outputs/t908
echo ">>>>>>>>running test 909"
../source/schedule.exe  0 2 1  < ../inputs/input/dat308 > ../outputs/t909
echo ">>>>>>>>running test 910"
../source/schedule.exe  4 0 0  < ../inputs/input/dat309 > ../outputs/t910
echo ">>>>>>>>running test 911"
../source/schedule.exe  4 2 5  < ../inputs/input/dat310 > ../outputs/t911
echo ">>>>>>>>running test 912"
../source/schedule.exe  1 4 1  < ../inputs/input/dat311 > ../outputs/t912
echo ">>>>>>>>running test 913"
../source/schedule.exe  5 4 2  < ../inputs/input/dat312 > ../outputs/t913
echo ">>>>>>>>running test 914"
../source/schedule.exe  5 5 2  < ../inputs/input/dat313 > ../outputs/t914
echo ">>>>>>>>running test 915"
../source/schedule.exe  4 4 2  < ../inputs/input/dat314 > ../outputs/t915
echo ">>>>>>>>running test 916"
../source/schedule.exe  4 1 2  < ../inputs/input/dat315 > ../outputs/t916
echo ">>>>>>>>running test 917"
../source/schedule.exe  3 0 2  < ../inputs/input/dat316 > ../outputs/t917
echo ">>>>>>>>running test 918"
../source/schedule.exe  0 3 1  < ../inputs/input/dat317 > ../outputs/t918
echo ">>>>>>>>running test 919"
../source/schedule.exe  2 0 3  < ../inputs/input/dat318 > ../outputs/t919
echo ">>>>>>>>running test 920"
../source/schedule.exe  3 3 2  < ../inputs/input/dat319 > ../outputs/t920
echo ">>>>>>>>running test 921"
../source/schedule.exe  0 2 2  < ../inputs/input/dat320 > ../outputs/t921
echo ">>>>>>>>running test 922"
../source/schedule.exe  0 5 4  < ../inputs/input/dat321 > ../outputs/t922
echo ">>>>>>>>running test 923"
../source/schedule.exe  3 2 4  < ../inputs/input/dat322 > ../outputs/t923
echo ">>>>>>>>running test 924"
../source/schedule.exe  0 1 0  < ../inputs/input/dat323 > ../outputs/t924
echo ">>>>>>>>running test 925"
../source/schedule.exe  2 3 2  < ../inputs/input/dat324 > ../outputs/t925
echo ">>>>>>>>running test 926"
../source/schedule.exe  2 5 5  < ../inputs/input/dat325 > ../outputs/t926
echo ">>>>>>>>running test 927"
../source/schedule.exe  0 3 3  < ../inputs/input/dat326 > ../outputs/t927
echo ">>>>>>>>running test 928"
../source/schedule.exe  2 5 0  < ../inputs/input/dat327 > ../outputs/t928
echo ">>>>>>>>running test 929"
../source/schedule.exe  3 2 2  < ../inputs/input/dat328 > ../outputs/t929
echo ">>>>>>>>running test 930"
../source/schedule.exe  0 4 3  < ../inputs/input/dat329 > ../outputs/t930
echo ">>>>>>>>running test 931"
../source/schedule.exe  0 0 2  < ../inputs/input/dat330 > ../outputs/t931
echo ">>>>>>>>running test 932"
../source/schedule.exe  0 0 1  < ../inputs/input/dat331 > ../outputs/t932
echo ">>>>>>>>running test 933"
../source/schedule.exe  5 2 2  < ../inputs/input/dat332 > ../outputs/t933
echo ">>>>>>>>running test 934"
../source/schedule.exe  1 3 2  < ../inputs/input/dat333 > ../outputs/t934
echo ">>>>>>>>running test 935"
../source/schedule.exe  0 5 1  < ../inputs/input/dat334 > ../outputs/t935
echo ">>>>>>>>running test 936"
../source/schedule.exe  1 4 5  < ../inputs/input/dat335 > ../outputs/t936
echo ">>>>>>>>running test 937"
../source/schedule.exe  5 4 4  < ../inputs/input/dat336 > ../outputs/t937
echo ">>>>>>>>running test 938"
../source/schedule.exe  5 1 2  < ../inputs/input/dat337 > ../outputs/t938
echo ">>>>>>>>running test 939"
../source/schedule.exe  0 2 5  < ../inputs/input/dat338 > ../outputs/t939
echo ">>>>>>>>running test 940"
../source/schedule.exe  2 4 3  < ../inputs/input/dat339 > ../outputs/t940
echo ">>>>>>>>running test 941"
../source/schedule.exe  2 4 1  < ../inputs/input/dat340 > ../outputs/t941
echo ">>>>>>>>running test 942"
../source/schedule.exe  1 0 3  < ../inputs/input/dat341 > ../outputs/t942
echo ">>>>>>>>running test 943"
../source/schedule.exe  4 1 5  < ../inputs/input/dat342 > ../outputs/t943
echo ">>>>>>>>running test 944"
../source/schedule.exe  1 1 1  < ../inputs/input/dat343 > ../outputs/t944
echo ">>>>>>>>running test 945"
../source/schedule.exe  1 1 1  < ../inputs/input/dat344 > ../outputs/t945
echo ">>>>>>>>running test 946"
../source/schedule.exe  2 4 1  < ../inputs/input/dat345 > ../outputs/t946
echo ">>>>>>>>running test 947"
../source/schedule.exe  0 2 3  < ../inputs/input/dat346 > ../outputs/t947
echo ">>>>>>>>running test 948"
../source/schedule.exe  5 0 1  < ../inputs/input/dat347 > ../outputs/t948
echo ">>>>>>>>running test 949"
../source/schedule.exe  4 5 5  < ../inputs/input/dat348 > ../outputs/t949
echo ">>>>>>>>running test 950"
../source/schedule.exe  5 0 4  < ../inputs/input/dat349 > ../outputs/t950
echo ">>>>>>>>running test 951"
../source/schedule.exe  4 3 1  < ../inputs/input/dat350 > ../outputs/t951
echo ">>>>>>>>running test 952"
../source/schedule.exe  4 1 3  < ../inputs/input/dat351 > ../outputs/t952
echo ">>>>>>>>running test 953"
../source/schedule.exe  3 2 3  < ../inputs/input/dat352 > ../outputs/t953
echo ">>>>>>>>running test 954"
../source/schedule.exe  4 3 5  < ../inputs/input/dat353 > ../outputs/t954
echo ">>>>>>>>running test 955"
../source/schedule.exe  1 3 0  < ../inputs/input/dat354 > ../outputs/t955
echo ">>>>>>>>running test 956"
../source/schedule.exe  2 5 3  < ../inputs/input/dat355 > ../outputs/t956
echo ">>>>>>>>running test 957"
../source/schedule.exe  0 1 1  < ../inputs/input/dat356 > ../outputs/t957
echo ">>>>>>>>running test 958"
../source/schedule.exe  3 1 5  < ../inputs/input/dat357 > ../outputs/t958
echo ">>>>>>>>running test 959"
../source/schedule.exe  3 1 2  < ../inputs/input/dat358 > ../outputs/t959
echo ">>>>>>>>running test 960"
../source/schedule.exe  5 2 5  < ../inputs/input/dat359 > ../outputs/t960
echo ">>>>>>>>running test 961"
../source/schedule.exe  0 1 2  < ../inputs/input/dat360 > ../outputs/t961
echo ">>>>>>>>running test 962"
../source/schedule.exe  3 1 5  < ../inputs/input/dat361 > ../outputs/t962
echo ">>>>>>>>running test 963"
../source/schedule.exe  5 0 1  < ../inputs/input/dat362 > ../outputs/t963
echo ">>>>>>>>running test 964"
../source/schedule.exe  4 2 3  < ../inputs/input/dat363 > ../outputs/t964
echo ">>>>>>>>running test 965"
../source/schedule.exe  3 4 2  < ../inputs/input/dat364 > ../outputs/t965
echo ">>>>>>>>running test 966"
../source/schedule.exe  3 3 4  < ../inputs/input/dat365 > ../outputs/t966
echo ">>>>>>>>running test 967"
../source/schedule.exe  4 2 2  < ../inputs/input/dat366 > ../outputs/t967
echo ">>>>>>>>running test 968"
../source/schedule.exe  5 5 0  < ../inputs/input/dat367 > ../outputs/t968
echo ">>>>>>>>running test 969"
../source/schedule.exe  2 1 2  < ../inputs/input/dat368 > ../outputs/t969
echo ">>>>>>>>running test 970"
../source/schedule.exe  1 4 5  < ../inputs/input/dat369 > ../outputs/t970
echo ">>>>>>>>running test 971"
../source/schedule.exe  3 2 0  < ../inputs/input/dat370 > ../outputs/t971
echo ">>>>>>>>running test 972"
../source/schedule.exe  0 4 4  < ../inputs/input/dat371 > ../outputs/t972
echo ">>>>>>>>running test 973"
../source/schedule.exe  2 0 5  < ../inputs/input/dat372 > ../outputs/t973
echo ">>>>>>>>running test 974"
../source/schedule.exe  4 1 5  < ../inputs/input/dat373 > ../outputs/t974
echo ">>>>>>>>running test 975"
../source/schedule.exe  5 5 4  < ../inputs/input/dat374 > ../outputs/t975
echo ">>>>>>>>running test 976"
../source/schedule.exe  0 5 4  < ../inputs/input/dat375 > ../outputs/t976
echo ">>>>>>>>running test 977"
../source/schedule.exe  2 4 4  < ../inputs/input/dat376 > ../outputs/t977
echo ">>>>>>>>running test 978"
../source/schedule.exe  0 2 1  < ../inputs/input/dat377 > ../outputs/t978
echo ">>>>>>>>running test 979"
../source/schedule.exe  3 3 2  < ../inputs/input/dat378 > ../outputs/t979
echo ">>>>>>>>running test 980"
../source/schedule.exe  2 0 1  < ../inputs/input/dat379 > ../outputs/t980
echo ">>>>>>>>running test 981"
../source/schedule.exe  0 3 3  < ../inputs/input/dat380 > ../outputs/t981
echo ">>>>>>>>running test 982"
../source/schedule.exe  2 4 2  < ../inputs/input/dat381 > ../outputs/t982
echo ">>>>>>>>running test 983"
../source/schedule.exe  0 5 0  < ../inputs/input/dat382 > ../outputs/t983
echo ">>>>>>>>running test 984"
../source/schedule.exe  4 4 0  < ../inputs/input/dat383 > ../outputs/t984
echo ">>>>>>>>running test 985"
../source/schedule.exe  2 5 5  < ../inputs/input/dat384 > ../outputs/t985
echo ">>>>>>>>running test 986"
../source/schedule.exe  0 2 5  < ../inputs/input/dat385 > ../outputs/t986
echo ">>>>>>>>running test 987"
../source/schedule.exe  5 3 1  < ../inputs/input/dat386 > ../outputs/t987
echo ">>>>>>>>running test 988"
../source/schedule.exe  3 1 4  < ../inputs/input/dat387 > ../outputs/t988
echo ">>>>>>>>running test 989"
../source/schedule.exe  5 0 2  < ../inputs/input/dat388 > ../outputs/t989
echo ">>>>>>>>running test 990"
../source/schedule.exe  3 3 1  < ../inputs/input/dat389 > ../outputs/t990
echo ">>>>>>>>running test 991"
../source/schedule.exe  4 4 3  < ../inputs/input/dat390 > ../outputs/t991
echo ">>>>>>>>running test 992"
../source/schedule.exe  4 4 2  < ../inputs/input/dat391 > ../outputs/t992
echo ">>>>>>>>running test 993"
../source/schedule.exe  2 2 1  < ../inputs/input/dat392 > ../outputs/t993
echo ">>>>>>>>running test 994"
../source/schedule.exe  1 3 0  < ../inputs/input/dat393 > ../outputs/t994
echo ">>>>>>>>running test 995"
../source/schedule.exe  5 4 0  < ../inputs/input/dat394 > ../outputs/t995
echo ">>>>>>>>running test 996"
../source/schedule.exe  4 5 2  < ../inputs/input/dat395 > ../outputs/t996
echo ">>>>>>>>running test 997"
../source/schedule.exe  4 3 2  < ../inputs/input/dat396 > ../outputs/t997
echo ">>>>>>>>running test 998"
../source/schedule.exe  3 3 2  < ../inputs/input/dat397 > ../outputs/t998
echo ">>>>>>>>running test 999"
../source/schedule.exe  2 5 4  < ../inputs/input/dat398 > ../outputs/t999
echo ">>>>>>>>running test 1000"
../source/schedule.exe  0 0 5  < ../inputs/input/dat399 > ../outputs/t1000
echo ">>>>>>>>running test 1001"
../source/schedule.exe  5 4 5  < ../inputs/input/dat400 > ../outputs/t1001
echo ">>>>>>>>running test 1002"
../source/schedule.exe  5 0 5  < ../inputs/input/dat401 > ../outputs/t1002
echo ">>>>>>>>running test 1003"
../source/schedule.exe  2 0 3  < ../inputs/input/dat402 > ../outputs/t1003
echo ">>>>>>>>running test 1004"
../source/schedule.exe  3 5 5  < ../inputs/input/dat403 > ../outputs/t1004
echo ">>>>>>>>running test 1005"
../source/schedule.exe  1 3 2  < ../inputs/input/dat404 > ../outputs/t1005
echo ">>>>>>>>running test 1006"
../source/schedule.exe  2 3 3  < ../inputs/input/dat405 > ../outputs/t1006
echo ">>>>>>>>running test 1007"
../source/schedule.exe  1 2 1  < ../inputs/input/dat406 > ../outputs/t1007
echo ">>>>>>>>running test 1008"
../source/schedule.exe  3 4 2  < ../inputs/input/dat407 > ../outputs/t1008
echo ">>>>>>>>running test 1009"
../source/schedule.exe  2 2 4  < ../inputs/input/dat408 > ../outputs/t1009
echo ">>>>>>>>running test 1010"
../source/schedule.exe  5 4 1  < ../inputs/input/dat409 > ../outputs/t1010
echo ">>>>>>>>running test 1011"
../source/schedule.exe  2 3 5  < ../inputs/input/dat410 > ../outputs/t1011
echo ">>>>>>>>running test 1012"
../source/schedule.exe  2 2 2  < ../inputs/input/dat411 > ../outputs/t1012
echo ">>>>>>>>running test 1013"
../source/schedule.exe  3 1 4  < ../inputs/input/dat412 > ../outputs/t1013
echo ">>>>>>>>running test 1014"
../source/schedule.exe  1 4 0  < ../inputs/input/dat413 > ../outputs/t1014
echo ">>>>>>>>running test 1015"
../source/schedule.exe  0 1 5  < ../inputs/input/dat414 > ../outputs/t1015
echo ">>>>>>>>running test 1016"
../source/schedule.exe  3 2 1  < ../inputs/input/dat415 > ../outputs/t1016
echo ">>>>>>>>running test 1017"
../source/schedule.exe  0 1 4  < ../inputs/input/dat416 > ../outputs/t1017
echo ">>>>>>>>running test 1018"
../source/schedule.exe  5 0 5  < ../inputs/input/dat417 > ../outputs/t1018
echo ">>>>>>>>running test 1019"
../source/schedule.exe  5 1 4  < ../inputs/input/dat418 > ../outputs/t1019
echo ">>>>>>>>running test 1020"
../source/schedule.exe  4 3 3  < ../inputs/input/dat419 > ../outputs/t1020
echo ">>>>>>>>running test 1021"
../source/schedule.exe  1 2 0  < ../inputs/input/dat420 > ../outputs/t1021
echo ">>>>>>>>running test 1022"
../source/schedule.exe  2 5 2  < ../inputs/input/dat421 > ../outputs/t1022
echo ">>>>>>>>running test 1023"
../source/schedule.exe  2 3 4  < ../inputs/input/dat422 > ../outputs/t1023
echo ">>>>>>>>running test 1024"
../source/schedule.exe  3 4 4  < ../inputs/input/dat423 > ../outputs/t1024
echo ">>>>>>>>running test 1025"
../source/schedule.exe  1 0 5  < ../inputs/input/dat424 > ../outputs/t1025
echo ">>>>>>>>running test 1026"
../source/schedule.exe  3 3 2  < ../inputs/input/dat425 > ../outputs/t1026
echo ">>>>>>>>running test 1027"
../source/schedule.exe  0 3 0  < ../inputs/input/dat426 > ../outputs/t1027
echo ">>>>>>>>running test 1028"
../source/schedule.exe  0 2 4  < ../inputs/input/dat427 > ../outputs/t1028
echo ">>>>>>>>running test 1029"
../source/schedule.exe  0 1 5  < ../inputs/input/dat428 > ../outputs/t1029
echo ">>>>>>>>running test 1030"
../source/schedule.exe  2 5 4  < ../inputs/input/dat429 > ../outputs/t1030
echo ">>>>>>>>running test 1031"
../source/schedule.exe  0 4 3  < ../inputs/input/dat430 > ../outputs/t1031
echo ">>>>>>>>running test 1032"
../source/schedule.exe  0 1 5  < ../inputs/input/dat431 > ../outputs/t1032
echo ">>>>>>>>running test 1033"
../source/schedule.exe  1 2 5  < ../inputs/input/dat432 > ../outputs/t1033
echo ">>>>>>>>running test 1034"
../source/schedule.exe  2 4 3  < ../inputs/input/dat433 > ../outputs/t1034
echo ">>>>>>>>running test 1035"
../source/schedule.exe  5 0 2  < ../inputs/input/dat434 > ../outputs/t1035
echo ">>>>>>>>running test 1036"
../source/schedule.exe  5 4 5  < ../inputs/input/dat435 > ../outputs/t1036
echo ">>>>>>>>running test 1037"
../source/schedule.exe  1 4 3  < ../inputs/input/dat436 > ../outputs/t1037
echo ">>>>>>>>running test 1038"
../source/schedule.exe  4 1 3  < ../inputs/input/dat437 > ../outputs/t1038
echo ">>>>>>>>running test 1039"
../source/schedule.exe  3 2 0  < ../inputs/input/dat438 > ../outputs/t1039
echo ">>>>>>>>running test 1040"
../source/schedule.exe  4 1 5  < ../inputs/input/dat439 > ../outputs/t1040
echo ">>>>>>>>running test 1041"
../source/schedule.exe  5 1 0  < ../inputs/input/dat440 > ../outputs/t1041
echo ">>>>>>>>running test 1042"
../source/schedule.exe  5 3 0  < ../inputs/input/dat441 > ../outputs/t1042
echo ">>>>>>>>running test 1043"
../source/schedule.exe  5 3 3  < ../inputs/input/dat442 > ../outputs/t1043
echo ">>>>>>>>running test 1044"
../source/schedule.exe  3 1 4  < ../inputs/input/dat443 > ../outputs/t1044
echo ">>>>>>>>running test 1045"
../source/schedule.exe  5 5 2  < ../inputs/input/dat444 > ../outputs/t1045
echo ">>>>>>>>running test 1046"
../source/schedule.exe  2 4 5  < ../inputs/input/dat445 > ../outputs/t1046
echo ">>>>>>>>running test 1047"
../source/schedule.exe  5 1 3  < ../inputs/input/dat446 > ../outputs/t1047
echo ">>>>>>>>running test 1048"
../source/schedule.exe  5 0 1  < ../inputs/input/dat447 > ../outputs/t1048
echo ">>>>>>>>running test 1049"
../source/schedule.exe  5 0 3  < ../inputs/input/dat448 > ../outputs/t1049
echo ">>>>>>>>running test 1050"
../source/schedule.exe  2 4 5  < ../inputs/input/dat449 > ../outputs/t1050
echo ">>>>>>>>running test 1051"
../source/schedule.exe  5 0 1  < ../inputs/input/dat450 > ../outputs/t1051
echo ">>>>>>>>running test 1052"
../source/schedule.exe  2 4 2  < ../inputs/input/dat451 > ../outputs/t1052
echo ">>>>>>>>running test 1053"
../source/schedule.exe  4 2 3  < ../inputs/input/dat452 > ../outputs/t1053
echo ">>>>>>>>running test 1054"
../source/schedule.exe  2 5 3  < ../inputs/input/dat453 > ../outputs/t1054
echo ">>>>>>>>running test 1055"
../source/schedule.exe  0 4 2  < ../inputs/input/dat454 > ../outputs/t1055
echo ">>>>>>>>running test 1056"
../source/schedule.exe  2 4 3  < ../inputs/input/dat455 > ../outputs/t1056
echo ">>>>>>>>running test 1057"
../source/schedule.exe  3 2 1  < ../inputs/input/dat456 > ../outputs/t1057
echo ">>>>>>>>running test 1058"
../source/schedule.exe  0 0 3  < ../inputs/input/dat457 > ../outputs/t1058
echo ">>>>>>>>running test 1059"
../source/schedule.exe  5 0 2  < ../inputs/input/dat458 > ../outputs/t1059
echo ">>>>>>>>running test 1060"
../source/schedule.exe  4 2 1  < ../inputs/input/dat459 > ../outputs/t1060
echo ">>>>>>>>running test 1061"
../source/schedule.exe  0 0 4  < ../inputs/input/dat460 > ../outputs/t1061
echo ">>>>>>>>running test 1062"
../source/schedule.exe  1 2 4  < ../inputs/input/dat461 > ../outputs/t1062
echo ">>>>>>>>running test 1063"
../source/schedule.exe  1 5 5  < ../inputs/input/dat462 > ../outputs/t1063
echo ">>>>>>>>running test 1064"
../source/schedule.exe  3 0 4  < ../inputs/input/dat463 > ../outputs/t1064
echo ">>>>>>>>running test 1065"
../source/schedule.exe  0 2 3  < ../inputs/input/dat464 > ../outputs/t1065
echo ">>>>>>>>running test 1066"
../source/schedule.exe  3 1 1  < ../inputs/input/dat465 > ../outputs/t1066
echo ">>>>>>>>running test 1067"
../source/schedule.exe  4 1 2  < ../inputs/input/dat466 > ../outputs/t1067
echo ">>>>>>>>running test 1068"
../source/schedule.exe  4 3 1  < ../inputs/input/dat467 > ../outputs/t1068
echo ">>>>>>>>running test 1069"
../source/schedule.exe  5 1 4  < ../inputs/input/dat468 > ../outputs/t1069
echo ">>>>>>>>running test 1070"
../source/schedule.exe  5 1 2  < ../inputs/input/dat469 > ../outputs/t1070
echo ">>>>>>>>running test 1071"
../source/schedule.exe  3 3 0  < ../inputs/input/dat470 > ../outputs/t1071
echo ">>>>>>>>running test 1072"
../source/schedule.exe  1 2 2  < ../inputs/input/dat471 > ../outputs/t1072
echo ">>>>>>>>running test 1073"
../source/schedule.exe  0 3 0  < ../inputs/input/dat472 > ../outputs/t1073
echo ">>>>>>>>running test 1074"
../source/schedule.exe  1 0 5  < ../inputs/input/dat473 > ../outputs/t1074
echo ">>>>>>>>running test 1075"
../source/schedule.exe  0 4 2  < ../inputs/input/dat474 > ../outputs/t1075
echo ">>>>>>>>running test 1076"
../source/schedule.exe  3 3 4  < ../inputs/input/dat475 > ../outputs/t1076
echo ">>>>>>>>running test 1077"
../source/schedule.exe  3 0 1  < ../inputs/input/dat476 > ../outputs/t1077
echo ">>>>>>>>running test 1078"
../source/schedule.exe  0 0 5  < ../inputs/input/dat477 > ../outputs/t1078
echo ">>>>>>>>running test 1079"
../source/schedule.exe  5 3 3  < ../inputs/input/dat478 > ../outputs/t1079
echo ">>>>>>>>running test 1080"
../source/schedule.exe  0 1 2  < ../inputs/input/dat479 > ../outputs/t1080
echo ">>>>>>>>running test 1081"
../source/schedule.exe  2 3 3  < ../inputs/input/dat480 > ../outputs/t1081
echo ">>>>>>>>running test 1082"
../source/schedule.exe  0 4 3  < ../inputs/input/dat481 > ../outputs/t1082
echo ">>>>>>>>running test 1083"
../source/schedule.exe  2 0 2  < ../inputs/input/dat482 > ../outputs/t1083
echo ">>>>>>>>running test 1084"
../source/schedule.exe  1 5 4  < ../inputs/input/dat483 > ../outputs/t1084
echo ">>>>>>>>running test 1085"
../source/schedule.exe  5 5 0  < ../inputs/input/dat484 > ../outputs/t1085
echo ">>>>>>>>running test 1086"
../source/schedule.exe  0 3 5  < ../inputs/input/dat485 > ../outputs/t1086
echo ">>>>>>>>running test 1087"
../source/schedule.exe  2 1 3  < ../inputs/input/dat486 > ../outputs/t1087
echo ">>>>>>>>running test 1088"
../source/schedule.exe  0 2 2  < ../inputs/input/dat487 > ../outputs/t1088
echo ">>>>>>>>running test 1089"
../source/schedule.exe  4 0 4  < ../inputs/input/dat488 > ../outputs/t1089
echo ">>>>>>>>running test 1090"
../source/schedule.exe  3 3 5  < ../inputs/input/dat489 > ../outputs/t1090
echo ">>>>>>>>running test 1091"
../source/schedule.exe  5 5 0  < ../inputs/input/dat490 > ../outputs/t1091
echo ">>>>>>>>running test 1092"
../source/schedule.exe  3 5 3  < ../inputs/input/dat491 > ../outputs/t1092
echo ">>>>>>>>running test 1093"
../source/schedule.exe  5 4 5  < ../inputs/input/dat492 > ../outputs/t1093
echo ">>>>>>>>running test 1094"
../source/schedule.exe  4 5 1  < ../inputs/input/dat493 > ../outputs/t1094
echo ">>>>>>>>running test 1095"
../source/schedule.exe  1 2 1  < ../inputs/input/dat494 > ../outputs/t1095
echo ">>>>>>>>running test 1096"
../source/schedule.exe  4 3 4  < ../inputs/input/dat495 > ../outputs/t1096
echo ">>>>>>>>running test 1097"
../source/schedule.exe  0 4 2  < ../inputs/input/dat496 > ../outputs/t1097
echo ">>>>>>>>running test 1098"
../source/schedule.exe  5 4 1  < ../inputs/input/dat497 > ../outputs/t1098
echo ">>>>>>>>running test 1099"
../source/schedule.exe  3 2 1  < ../inputs/input/dat498 > ../outputs/t1099
echo ">>>>>>>>running test 1100"
../source/schedule.exe  5 3 2  < ../inputs/input/dat499 > ../outputs/t1100
echo ">>>>>>>>running test 1101"
../source/schedule.exe  3 1 4  < ../inputs/input/dat500 > ../outputs/t1101
echo ">>>>>>>>running test 1102"
../source/schedule.exe  5 4 0  < ../inputs/input/dat501 > ../outputs/t1102
echo ">>>>>>>>running test 1103"
../source/schedule.exe  2 3 0  < ../inputs/input/dat502 > ../outputs/t1103
echo ">>>>>>>>running test 1104"
../source/schedule.exe  2 5 0  < ../inputs/input/dat503 > ../outputs/t1104
echo ">>>>>>>>running test 1105"
../source/schedule.exe  1 1 0  < ../inputs/input/dat504 > ../outputs/t1105
echo ">>>>>>>>running test 1106"
../source/schedule.exe  4 5 1  < ../inputs/input/dat505 > ../outputs/t1106
echo ">>>>>>>>running test 1107"
../source/schedule.exe  1 0 2  < ../inputs/input/dat506 > ../outputs/t1107
echo ">>>>>>>>running test 1108"
../source/schedule.exe  1 5 4  < ../inputs/input/dat507 > ../outputs/t1108
echo ">>>>>>>>running test 1109"
../source/schedule.exe  2 5 5  < ../inputs/input/dat508 > ../outputs/t1109
echo ">>>>>>>>running test 1110"
../source/schedule.exe  1 0 3  < ../inputs/input/dat509 > ../outputs/t1110
echo ">>>>>>>>running test 1111"
../source/schedule.exe  3 1 2  < ../inputs/input/dat510 > ../outputs/t1111
echo ">>>>>>>>running test 1112"
../source/schedule.exe  2 4 1  < ../inputs/input/dat511 > ../outputs/t1112
echo ">>>>>>>>running test 1113"
../source/schedule.exe  5 2 4  < ../inputs/input/dat512 > ../outputs/t1113
echo ">>>>>>>>running test 1114"
../source/schedule.exe  4 5 1  < ../inputs/input/dat513 > ../outputs/t1114
echo ">>>>>>>>running test 1115"
../source/schedule.exe  3 1 1  < ../inputs/input/dat514 > ../outputs/t1115
echo ">>>>>>>>running test 1116"
../source/schedule.exe  1 3 1  < ../inputs/input/dat515 > ../outputs/t1116
echo ">>>>>>>>running test 1117"
../source/schedule.exe  0 0 5  < ../inputs/input/dat516 > ../outputs/t1117
echo ">>>>>>>>running test 1118"
../source/schedule.exe  5 5 1  < ../inputs/input/dat517 > ../outputs/t1118
echo ">>>>>>>>running test 1119"
../source/schedule.exe  5 0 1  < ../inputs/input/dat518 > ../outputs/t1119
echo ">>>>>>>>running test 1120"
../source/schedule.exe  3 5 2  < ../inputs/input/dat519 > ../outputs/t1120
echo ">>>>>>>>running test 1121"
../source/schedule.exe  5 5 0  < ../inputs/input/dat520 > ../outputs/t1121
echo ">>>>>>>>running test 1122"
../source/schedule.exe  0 1 0  < ../inputs/input/dat521 > ../outputs/t1122
echo ">>>>>>>>running test 1123"
../source/schedule.exe  0 0 3  < ../inputs/input/dat522 > ../outputs/t1123
echo ">>>>>>>>running test 1124"
../source/schedule.exe  0 1 4  < ../inputs/input/dat523 > ../outputs/t1124
echo ">>>>>>>>running test 1125"
../source/schedule.exe  1 4 3  < ../inputs/input/dat524 > ../outputs/t1125
echo ">>>>>>>>running test 1126"
../source/schedule.exe  0 2 0  < ../inputs/input/dat525 > ../outputs/t1126
echo ">>>>>>>>running test 1127"
../source/schedule.exe  4 0 3  < ../inputs/input/dat526 > ../outputs/t1127
echo ">>>>>>>>running test 1128"
../source/schedule.exe  3 1 5  < ../inputs/input/dat527 > ../outputs/t1128
echo ">>>>>>>>running test 1129"
../source/schedule.exe  3 0 5  < ../inputs/input/dat528 > ../outputs/t1129
echo ">>>>>>>>running test 1130"
../source/schedule.exe  5 3 3  < ../inputs/input/dat529 > ../outputs/t1130
echo ">>>>>>>>running test 1131"
../source/schedule.exe  4 5 3  < ../inputs/input/dat530 > ../outputs/t1131
echo ">>>>>>>>running test 1132"
../source/schedule.exe  1 0 0  < ../inputs/input/dat531 > ../outputs/t1132
echo ">>>>>>>>running test 1133"
../source/schedule.exe  1 4 5  < ../inputs/input/dat532 > ../outputs/t1133
echo ">>>>>>>>running test 1134"
../source/schedule.exe  0 4 0  < ../inputs/input/dat533 > ../outputs/t1134
echo ">>>>>>>>running test 1135"
../source/schedule.exe  5 5 3  < ../inputs/input/dat534 > ../outputs/t1135
echo ">>>>>>>>running test 1136"
../source/schedule.exe  2 1 0  < ../inputs/input/dat535 > ../outputs/t1136
echo ">>>>>>>>running test 1137"
../source/schedule.exe  1 0 2  < ../inputs/input/dat536 > ../outputs/t1137
echo ">>>>>>>>running test 1138"
../source/schedule.exe  3 1 5  < ../inputs/input/dat537 > ../outputs/t1138
echo ">>>>>>>>running test 1139"
../source/schedule.exe  4 3 2  < ../inputs/input/dat538 > ../outputs/t1139
echo ">>>>>>>>running test 1140"
../source/schedule.exe  1 0 0  < ../inputs/input/dat539 > ../outputs/t1140
echo ">>>>>>>>running test 1141"
../source/schedule.exe  1 0 0  < ../inputs/input/dat540 > ../outputs/t1141
echo ">>>>>>>>running test 1142"
../source/schedule.exe  2 5 3  < ../inputs/input/dat541 > ../outputs/t1142
echo ">>>>>>>>running test 1143"
../source/schedule.exe  2 3 2  < ../inputs/input/dat542 > ../outputs/t1143
echo ">>>>>>>>running test 1144"
../source/schedule.exe  4 0 5  < ../inputs/input/dat543 > ../outputs/t1144
echo ">>>>>>>>running test 1145"
../source/schedule.exe  2 4 5  < ../inputs/input/dat544 > ../outputs/t1145
echo ">>>>>>>>running test 1146"
../source/schedule.exe  4 4 2  < ../inputs/input/dat545 > ../outputs/t1146
echo ">>>>>>>>running test 1147"
../source/schedule.exe  5 3 4  < ../inputs/input/dat546 > ../outputs/t1147
echo ">>>>>>>>running test 1148"
../source/schedule.exe  2 1 5  < ../inputs/input/dat547 > ../outputs/t1148
echo ">>>>>>>>running test 1149"
../source/schedule.exe  5 5 4  < ../inputs/input/dat548 > ../outputs/t1149
echo ">>>>>>>>running test 1150"
../source/schedule.exe  2 3 3  < ../inputs/input/dat549 > ../outputs/t1150
echo ">>>>>>>>running test 1151"
../source/schedule.exe  0 0 3  < ../inputs/input/dat550 > ../outputs/t1151
echo ">>>>>>>>running test 1152"
../source/schedule.exe  4 0 3  < ../inputs/input/dat551 > ../outputs/t1152
echo ">>>>>>>>running test 1153"
../source/schedule.exe  3 2 2  < ../inputs/input/dat552 > ../outputs/t1153
echo ">>>>>>>>running test 1154"
../source/schedule.exe  2 1 0  < ../inputs/input/dat553 > ../outputs/t1154
echo ">>>>>>>>running test 1155"
../source/schedule.exe  4 3 2  < ../inputs/input/dat554 > ../outputs/t1155
echo ">>>>>>>>running test 1156"
../source/schedule.exe  0 0 0  < ../inputs/input/dat555 > ../outputs/t1156
echo ">>>>>>>>running test 1157"
../source/schedule.exe  4 1 3  < ../inputs/input/dat556 > ../outputs/t1157
echo ">>>>>>>>running test 1158"
../source/schedule.exe  1 4 2  < ../inputs/input/dat557 > ../outputs/t1158
echo ">>>>>>>>running test 1159"
../source/schedule.exe  5 5 1  < ../inputs/input/dat558 > ../outputs/t1159
echo ">>>>>>>>running test 1160"
../source/schedule.exe  4 3 2  < ../inputs/input/dat559 > ../outputs/t1160
echo ">>>>>>>>running test 1161"
../source/schedule.exe  0 4 2  < ../inputs/input/dat560 > ../outputs/t1161
echo ">>>>>>>>running test 1162"
../source/schedule.exe  5 5 0  < ../inputs/input/dat561 > ../outputs/t1162
echo ">>>>>>>>running test 1163"
../source/schedule.exe  4 2 2  < ../inputs/input/dat562 > ../outputs/t1163
echo ">>>>>>>>running test 1164"
../source/schedule.exe  3 5 2  < ../inputs/input/dat563 > ../outputs/t1164
echo ">>>>>>>>running test 1165"
../source/schedule.exe  0 4 2  < ../inputs/input/dat564 > ../outputs/t1165
echo ">>>>>>>>running test 1166"
../source/schedule.exe  2 5 2  < ../inputs/input/dat565 > ../outputs/t1166
echo ">>>>>>>>running test 1167"
../source/schedule.exe  2 5 1  < ../inputs/input/dat566 > ../outputs/t1167
echo ">>>>>>>>running test 1168"
../source/schedule.exe  0 4 1  < ../inputs/input/dat567 > ../outputs/t1168
echo ">>>>>>>>running test 1169"
../source/schedule.exe  4 0 0  < ../inputs/input/dat568 > ../outputs/t1169
echo ">>>>>>>>running test 1170"
../source/schedule.exe  4 0 5  < ../inputs/input/dat569 > ../outputs/t1170
echo ">>>>>>>>running test 1171"
../source/schedule.exe  1 4 2  < ../inputs/input/dat570 > ../outputs/t1171
echo ">>>>>>>>running test 1172"
../source/schedule.exe  1 5 1  < ../inputs/input/dat571 > ../outputs/t1172
echo ">>>>>>>>running test 1173"
../source/schedule.exe  2 2 2  < ../inputs/input/dat572 > ../outputs/t1173
echo ">>>>>>>>running test 1174"
../source/schedule.exe  3 2 0  < ../inputs/input/dat573 > ../outputs/t1174
echo ">>>>>>>>running test 1175"
../source/schedule.exe  0 0 5  < ../inputs/input/dat574 > ../outputs/t1175
echo ">>>>>>>>running test 1176"
../source/schedule.exe  2 1 5  < ../inputs/input/dat575 > ../outputs/t1176
echo ">>>>>>>>running test 1177"
../source/schedule.exe  3 1 0  < ../inputs/input/dat576 > ../outputs/t1177
echo ">>>>>>>>running test 1178"
../source/schedule.exe  0 2 2  < ../inputs/input/dat577 > ../outputs/t1178
echo ">>>>>>>>running test 1179"
../source/schedule.exe  2 2 1  < ../inputs/input/dat578 > ../outputs/t1179
echo ">>>>>>>>running test 1180"
../source/schedule.exe  3 2 0  < ../inputs/input/dat579 > ../outputs/t1180
echo ">>>>>>>>running test 1181"
../source/schedule.exe  3 3 2  < ../inputs/input/dat580 > ../outputs/t1181
echo ">>>>>>>>running test 1182"
../source/schedule.exe  2 2 1  < ../inputs/input/dat581 > ../outputs/t1182
echo ">>>>>>>>running test 1183"
../source/schedule.exe  3 1 3  < ../inputs/input/dat582 > ../outputs/t1183
echo ">>>>>>>>running test 1184"
../source/schedule.exe  1 2 2  < ../inputs/input/dat583 > ../outputs/t1184
echo ">>>>>>>>running test 1185"
../source/schedule.exe  5 4 4  < ../inputs/input/dat584 > ../outputs/t1185
echo ">>>>>>>>running test 1186"
../source/schedule.exe  3 0 5  < ../inputs/input/dat585 > ../outputs/t1186
echo ">>>>>>>>running test 1187"
../source/schedule.exe  1 0 3  < ../inputs/input/dat586 > ../outputs/t1187
echo ">>>>>>>>running test 1188"
../source/schedule.exe  2 3 4  < ../inputs/input/dat587 > ../outputs/t1188
echo ">>>>>>>>running test 1189"
../source/schedule.exe  5 1 0  < ../inputs/input/dat588 > ../outputs/t1189
echo ">>>>>>>>running test 1190"
../source/schedule.exe  3 3 1  < ../inputs/input/dat589 > ../outputs/t1190
echo ">>>>>>>>running test 1191"
../source/schedule.exe  1 4 2  < ../inputs/input/dat590 > ../outputs/t1191
echo ">>>>>>>>running test 1192"
../source/schedule.exe  5 0 4  < ../inputs/input/dat591 > ../outputs/t1192
echo ">>>>>>>>running test 1193"
../source/schedule.exe  5 3 5  < ../inputs/input/dat592 > ../outputs/t1193
echo ">>>>>>>>running test 1194"
../source/schedule.exe  2 0 0  < ../inputs/input/dat593 > ../outputs/t1194
echo ">>>>>>>>running test 1195"
../source/schedule.exe  5 2 4  < ../inputs/input/dat594 > ../outputs/t1195
echo ">>>>>>>>running test 1196"
../source/schedule.exe  3 5 3  < ../inputs/input/dat595 > ../outputs/t1196
echo ">>>>>>>>running test 1197"
../source/schedule.exe  5 1 1  < ../inputs/input/dat596 > ../outputs/t1197
echo ">>>>>>>>running test 1198"
../source/schedule.exe  4 5 0  < ../inputs/input/dat597 > ../outputs/t1198
echo ">>>>>>>>running test 1199"
../source/schedule.exe  3 2 5  < ../inputs/input/dat598 > ../outputs/t1199
echo ">>>>>>>>running test 1200"
../source/schedule.exe  2 0 3  < ../inputs/input/dat599 > ../outputs/t1200
echo ">>>>>>>>running test 1201"
../source/schedule.exe  0 1 2  < ../inputs/input/dat600 > ../outputs/t1201
echo ">>>>>>>>running test 1202"
../source/schedule.exe  0 1 0  < ../inputs/input/dat601 > ../outputs/t1202
echo ">>>>>>>>running test 1203"
../source/schedule.exe  1 4 2  < ../inputs/input/dat602 > ../outputs/t1203
echo ">>>>>>>>running test 1204"
../source/schedule.exe  2 3 5  < ../inputs/input/dat603 > ../outputs/t1204
echo ">>>>>>>>running test 1205"
../source/schedule.exe  3 1 0  < ../inputs/input/dat604 > ../outputs/t1205
echo ">>>>>>>>running test 1206"
../source/schedule.exe  1 5 1  < ../inputs/input/dat605 > ../outputs/t1206
echo ">>>>>>>>running test 1207"
../source/schedule.exe  2 0 3  < ../inputs/input/dat606 > ../outputs/t1207
echo ">>>>>>>>running test 1208"
../source/schedule.exe  3 4 1  < ../inputs/input/dat607 > ../outputs/t1208
echo ">>>>>>>>running test 1209"
../source/schedule.exe  5 4 3  < ../inputs/input/dat608 > ../outputs/t1209
echo ">>>>>>>>running test 1210"
../source/schedule.exe  1 1 5  < ../inputs/input/dat609 > ../outputs/t1210
echo ">>>>>>>>running test 1211"
../source/schedule.exe  5 4 3  < ../inputs/input/dat610 > ../outputs/t1211
echo ">>>>>>>>running test 1212"
../source/schedule.exe  3 1 5  < ../inputs/input/dat612 > ../outputs/t1212
echo ">>>>>>>>running test 1213"
../source/schedule.exe  0 1 5  < ../inputs/input/dat613 > ../outputs/t1213
echo ">>>>>>>>running test 1214"
../source/schedule.exe  4 4 0  < ../inputs/input/dat614 > ../outputs/t1214
echo ">>>>>>>>running test 1215"
../source/schedule.exe  5 1 5  < ../inputs/input/dat615 > ../outputs/t1215
echo ">>>>>>>>running test 1216"
../source/schedule.exe  3 3 5  < ../inputs/input/dat616 > ../outputs/t1216
echo ">>>>>>>>running test 1217"
../source/schedule.exe  1 0 1  < ../inputs/input/dat617 > ../outputs/t1217
echo ">>>>>>>>running test 1218"
../source/schedule.exe  5 3 0  < ../inputs/input/dat618 > ../outputs/t1218
echo ">>>>>>>>running test 1219"
../source/schedule.exe  0 4 0  < ../inputs/input/dat619 > ../outputs/t1219
echo ">>>>>>>>running test 1220"
../source/schedule.exe  1 2 3  < ../inputs/input/dat620 > ../outputs/t1220
echo ">>>>>>>>running test 1221"
../source/schedule.exe  2 2 3  < ../inputs/input/dat621 > ../outputs/t1221
echo ">>>>>>>>running test 1222"
../source/schedule.exe  0 0 0  < ../inputs/input/dat622 > ../outputs/t1222
echo ">>>>>>>>running test 1223"
../source/schedule.exe  5 5 3  < ../inputs/input/dat623 > ../outputs/t1223
echo ">>>>>>>>running test 1224"
../source/schedule.exe  1 0 5  < ../inputs/input/dat624 > ../outputs/t1224
echo ">>>>>>>>running test 1225"
../source/schedule.exe  0 4 5  < ../inputs/input/dat625 > ../outputs/t1225
echo ">>>>>>>>running test 1226"
../source/schedule.exe  3 5 3  < ../inputs/input/dat626 > ../outputs/t1226
echo ">>>>>>>>running test 1227"
../source/schedule.exe  5 0 3  < ../inputs/input/dat627 > ../outputs/t1227
echo ">>>>>>>>running test 1228"
../source/schedule.exe  3 4 1  < ../inputs/input/dat628 > ../outputs/t1228
echo ">>>>>>>>running test 1229"
../source/schedule.exe  4 5 5  < ../inputs/input/dat629 > ../outputs/t1229
echo ">>>>>>>>running test 1230"
../source/schedule.exe  3 0 5  < ../inputs/input/dat630 > ../outputs/t1230
echo ">>>>>>>>running test 1231"
../source/schedule.exe  4 4 3  < ../inputs/input/dat631 > ../outputs/t1231
echo ">>>>>>>>running test 1232"
../source/schedule.exe  4 1 5  < ../inputs/input/dat632 > ../outputs/t1232
echo ">>>>>>>>running test 1233"
../source/schedule.exe  3 2 1  < ../inputs/input/dat633 > ../outputs/t1233
echo ">>>>>>>>running test 1234"
../source/schedule.exe  4 5 4  < ../inputs/input/dat634 > ../outputs/t1234
echo ">>>>>>>>running test 1235"
../source/schedule.exe  1 0 2  < ../inputs/input/dat635 > ../outputs/t1235
echo ">>>>>>>>running test 1236"
../source/schedule.exe  5 4 5  < ../inputs/input/dat636 > ../outputs/t1236
echo ">>>>>>>>running test 1237"
../source/schedule.exe  4 5 1  < ../inputs/input/dat637 > ../outputs/t1237
echo ">>>>>>>>running test 1238"
../source/schedule.exe  0 2 0  < ../inputs/input/dat638 > ../outputs/t1238
echo ">>>>>>>>running test 1239"
../source/schedule.exe  1 3 4  < ../inputs/input/dat639 > ../outputs/t1239
echo ">>>>>>>>running test 1240"
../source/schedule.exe  0 0 4  < ../inputs/input/dat640 > ../outputs/t1240
echo ">>>>>>>>running test 1241"
../source/schedule.exe  3 4 4  < ../inputs/input/dat641 > ../outputs/t1241
echo ">>>>>>>>running test 1242"
../source/schedule.exe  2 5 0  < ../inputs/input/dat642 > ../outputs/t1242
echo ">>>>>>>>running test 1243"
../source/schedule.exe  5 3 0  < ../inputs/input/dat643 > ../outputs/t1243
echo ">>>>>>>>running test 1244"
../source/schedule.exe  1 3 3  < ../inputs/input/dat644 > ../outputs/t1244
echo ">>>>>>>>running test 1245"
../source/schedule.exe  3 5 1  < ../inputs/input/dat645 > ../outputs/t1245
echo ">>>>>>>>running test 1246"
../source/schedule.exe  0 1 2  < ../inputs/input/dat646 > ../outputs/t1246
echo ">>>>>>>>running test 1247"
../source/schedule.exe  5 5 2  < ../inputs/input/dat647 > ../outputs/t1247
echo ">>>>>>>>running test 1248"
../source/schedule.exe  4 2 3  < ../inputs/input/dat648 > ../outputs/t1248
echo ">>>>>>>>running test 1249"
../source/schedule.exe  4 3 5  < ../inputs/input/dat649 > ../outputs/t1249
echo ">>>>>>>>running test 1250"
../source/schedule.exe  2 1 2  < ../inputs/input/dat650 > ../outputs/t1250
echo ">>>>>>>>running test 1251"
../source/schedule.exe  4 4 4  < ../inputs/input/dat651 > ../outputs/t1251
echo ">>>>>>>>running test 1252"
../source/schedule.exe  4 1 2  < ../inputs/input/dat652 > ../outputs/t1252
echo ">>>>>>>>running test 1253"
../source/schedule.exe  2 5 4  < ../inputs/input/dat653 > ../outputs/t1253
echo ">>>>>>>>running test 1254"
../source/schedule.exe  5 3 2  < ../inputs/input/dat654 > ../outputs/t1254
echo ">>>>>>>>running test 1255"
../source/schedule.exe  1 5 0  < ../inputs/input/dat655 > ../outputs/t1255
echo ">>>>>>>>running test 1256"
../source/schedule.exe  0 4 5  < ../inputs/input/dat656 > ../outputs/t1256
echo ">>>>>>>>running test 1257"
../source/schedule.exe  3 3 4  < ../inputs/input/dat657 > ../outputs/t1257
echo ">>>>>>>>running test 1258"
../source/schedule.exe  0 3 3  < ../inputs/input/dat658 > ../outputs/t1258
echo ">>>>>>>>running test 1259"
../source/schedule.exe  3 2 0  < ../inputs/input/dat659 > ../outputs/t1259
echo ">>>>>>>>running test 1260"
../source/schedule.exe  0 0 3  < ../inputs/input/dat660 > ../outputs/t1260
echo ">>>>>>>>running test 1261"
../source/schedule.exe  3 4 1  < ../inputs/input/dat661 > ../outputs/t1261
echo ">>>>>>>>running test 1262"
../source/schedule.exe  5 0 5  < ../inputs/input/dat662 > ../outputs/t1262
echo ">>>>>>>>running test 1263"
../source/schedule.exe  3 3 4  < ../inputs/input/dat663 > ../outputs/t1263
echo ">>>>>>>>running test 1264"
../source/schedule.exe  3 5 1  < ../inputs/input/dat664 > ../outputs/t1264
echo ">>>>>>>>running test 1265"
../source/schedule.exe  4 4 0  < ../inputs/input/dat665 > ../outputs/t1265
echo ">>>>>>>>running test 1266"
../source/schedule.exe  3 1 1  < ../inputs/input/dat666 > ../outputs/t1266
echo ">>>>>>>>running test 1267"
../source/schedule.exe  4 4 3  < ../inputs/input/dat667 > ../outputs/t1267
echo ">>>>>>>>running test 1268"
../source/schedule.exe  2 2 1  < ../inputs/input/dat668 > ../outputs/t1268
echo ">>>>>>>>running test 1269"
../source/schedule.exe  2 4 3  < ../inputs/input/dat669 > ../outputs/t1269
echo ">>>>>>>>running test 1270"
../source/schedule.exe  4 0 2  < ../inputs/input/dat670 > ../outputs/t1270
echo ">>>>>>>>running test 1271"
../source/schedule.exe  4 0 4  < ../inputs/input/dat671 > ../outputs/t1271
echo ">>>>>>>>running test 1272"
../source/schedule.exe  0 2 2  < ../inputs/input/dat672 > ../outputs/t1272
echo ">>>>>>>>running test 1273"
../source/schedule.exe  5 0 3  < ../inputs/input/dat673 > ../outputs/t1273
echo ">>>>>>>>running test 1274"
../source/schedule.exe  1 1 1  < ../inputs/input/dat674 > ../outputs/t1274
echo ">>>>>>>>running test 1275"
../source/schedule.exe  3 5 1  < ../inputs/input/dat675 > ../outputs/t1275
echo ">>>>>>>>running test 1276"
../source/schedule.exe  1 1 3  < ../inputs/input/dat676 > ../outputs/t1276
echo ">>>>>>>>running test 1277"
../source/schedule.exe  5 3 0  < ../inputs/input/dat677 > ../outputs/t1277
echo ">>>>>>>>running test 1278"
../source/schedule.exe  2 3 1  < ../inputs/input/dat678 > ../outputs/t1278
echo ">>>>>>>>running test 1279"
../source/schedule.exe  0 3 3  < ../inputs/input/dat679 > ../outputs/t1279
echo ">>>>>>>>running test 1280"
../source/schedule.exe  2 5 1  < ../inputs/input/dat680 > ../outputs/t1280
echo ">>>>>>>>running test 1281"
../source/schedule.exe  5 4 3  < ../inputs/input/dat681 > ../outputs/t1281
echo ">>>>>>>>running test 1282"
../source/schedule.exe  3 0 0  < ../inputs/input/dat682 > ../outputs/t1282
echo ">>>>>>>>running test 1283"
../source/schedule.exe  2 3 0  < ../inputs/input/dat683 > ../outputs/t1283
echo ">>>>>>>>running test 1284"
../source/schedule.exe  0 3 3  < ../inputs/input/dat684 > ../outputs/t1284
echo ">>>>>>>>running test 1285"
../source/schedule.exe  1 1 0  < ../inputs/input/dat685 > ../outputs/t1285
echo ">>>>>>>>running test 1286"
../source/schedule.exe  0 0 1  < ../inputs/input/dat686 > ../outputs/t1286
echo ">>>>>>>>running test 1287"
../source/schedule.exe  0 3 1  < ../inputs/input/dat687 > ../outputs/t1287
echo ">>>>>>>>running test 1288"
../source/schedule.exe  5 2 4  < ../inputs/input/dat688 > ../outputs/t1288
echo ">>>>>>>>running test 1289"
../source/schedule.exe  5 1 4  < ../inputs/input/dat689 > ../outputs/t1289
echo ">>>>>>>>running test 1290"
../source/schedule.exe  2 5 1  < ../inputs/input/dat690 > ../outputs/t1290
echo ">>>>>>>>running test 1291"
../source/schedule.exe  0 5 5  < ../inputs/input/dat691 > ../outputs/t1291
echo ">>>>>>>>running test 1292"
../source/schedule.exe  3 0 0  < ../inputs/input/dat692 > ../outputs/t1292
echo ">>>>>>>>running test 1293"
../source/schedule.exe  3 2 4  < ../inputs/input/dat693 > ../outputs/t1293
echo ">>>>>>>>running test 1294"
../source/schedule.exe  3 1 5  < ../inputs/input/dat694 > ../outputs/t1294
echo ">>>>>>>>running test 1295"
../source/schedule.exe  4 1 2  < ../inputs/input/dat695 > ../outputs/t1295
echo ">>>>>>>>running test 1296"
../source/schedule.exe  2 3 5  < ../inputs/input/dat696 > ../outputs/t1296
echo ">>>>>>>>running test 1297"
../source/schedule.exe  3 1 1  < ../inputs/input/dat697 > ../outputs/t1297
echo ">>>>>>>>running test 1298"
../source/schedule.exe  2 2 1  < ../inputs/input/dat698 > ../outputs/t1298
echo ">>>>>>>>running test 1299"
../source/schedule.exe  0 1 3  < ../inputs/input/dat699 > ../outputs/t1299
echo ">>>>>>>>running test 1300"
../source/schedule.exe  1 1 5  < ../inputs/input/dat700 > ../outputs/t1300
echo ">>>>>>>>running test 1301"
../source/schedule.exe  2 0 3  < ../inputs/input/dat701 > ../outputs/t1301
echo ">>>>>>>>running test 1302"
../source/schedule.exe  0 2 1  < ../inputs/input/dat702 > ../outputs/t1302
echo ">>>>>>>>running test 1303"
../source/schedule.exe  2 0 4  < ../inputs/input/dat703 > ../outputs/t1303
echo ">>>>>>>>running test 1304"
../source/schedule.exe  3 4 5  < ../inputs/input/dat704 > ../outputs/t1304
echo ">>>>>>>>running test 1305"
../source/schedule.exe  5 5 0  < ../inputs/input/dat705 > ../outputs/t1305
echo ">>>>>>>>running test 1306"
../source/schedule.exe  3 5 2  < ../inputs/input/dat706 > ../outputs/t1306
echo ">>>>>>>>running test 1307"
../source/schedule.exe  0 2 3  < ../inputs/input/dat707 > ../outputs/t1307
echo ">>>>>>>>running test 1308"
../source/schedule.exe  4 1 1  < ../inputs/input/dat708 > ../outputs/t1308
echo ">>>>>>>>running test 1309"
../source/schedule.exe  3 0 2  < ../inputs/input/dat709 > ../outputs/t1309
echo ">>>>>>>>running test 1310"
../source/schedule.exe  1 1 3  < ../inputs/input/dat710 > ../outputs/t1310
echo ">>>>>>>>running test 1311"
../source/schedule.exe  0 0 3  < ../inputs/input/dat711 > ../outputs/t1311
echo ">>>>>>>>running test 1312"
../source/schedule.exe  4 2 2  < ../inputs/input/dat712 > ../outputs/t1312
echo ">>>>>>>>running test 1313"
../source/schedule.exe  5 1 3  < ../inputs/input/dat713 > ../outputs/t1313
echo ">>>>>>>>running test 1314"
../source/schedule.exe  4 4 0  < ../inputs/input/dat714 > ../outputs/t1314
echo ">>>>>>>>running test 1315"
../source/schedule.exe  5 0 0  < ../inputs/input/dat715 > ../outputs/t1315
echo ">>>>>>>>running test 1316"
../source/schedule.exe  0 1 3  < ../inputs/input/dat716 > ../outputs/t1316
echo ">>>>>>>>running test 1317"
../source/schedule.exe  0 5 2  < ../inputs/input/dat717 > ../outputs/t1317
echo ">>>>>>>>running test 1318"
../source/schedule.exe  1 5 2  < ../inputs/input/dat718 > ../outputs/t1318
echo ">>>>>>>>running test 1319"
../source/schedule.exe  0 5 3  < ../inputs/input/dat719 > ../outputs/t1319
echo ">>>>>>>>running test 1320"
../source/schedule.exe  3 3 4  < ../inputs/input/dat720 > ../outputs/t1320
echo ">>>>>>>>running test 1321"
../source/schedule.exe  2 5 4  < ../inputs/input/dat721 > ../outputs/t1321
echo ">>>>>>>>running test 1322"
../source/schedule.exe  4 4 1  < ../inputs/input/dat722 > ../outputs/t1322
echo ">>>>>>>>running test 1323"
../source/schedule.exe  0 1 5  < ../inputs/input/dat723 > ../outputs/t1323
echo ">>>>>>>>running test 1324"
../source/schedule.exe  2 1 0  < ../inputs/input/dat724 > ../outputs/t1324
echo ">>>>>>>>running test 1325"
../source/schedule.exe  3 1 5  < ../inputs/input/dat725 > ../outputs/t1325
echo ">>>>>>>>running test 1326"
../source/schedule.exe  2 0 3  < ../inputs/input/dat726 > ../outputs/t1326
echo ">>>>>>>>running test 1327"
../source/schedule.exe  5 3 0  < ../inputs/input/dat727 > ../outputs/t1327
echo ">>>>>>>>running test 1328"
../source/schedule.exe  2 2 5  < ../inputs/input/dat728 > ../outputs/t1328
echo ">>>>>>>>running test 1329"
../source/schedule.exe  0 0 2  < ../inputs/input/dat729 > ../outputs/t1329
echo ">>>>>>>>running test 1330"
../source/schedule.exe  0 5 1  < ../inputs/input/dat730 > ../outputs/t1330
echo ">>>>>>>>running test 1331"
../source/schedule.exe  0 2 3  < ../inputs/input/dat731 > ../outputs/t1331
echo ">>>>>>>>running test 1332"
../source/schedule.exe  0 4 5  < ../inputs/input/dat732 > ../outputs/t1332
echo ">>>>>>>>running test 1333"
../source/schedule.exe  3 5 4  < ../inputs/input/dat733 > ../outputs/t1333
echo ">>>>>>>>running test 1334"
../source/schedule.exe  2 5 0  < ../inputs/input/dat734 > ../outputs/t1334
echo ">>>>>>>>running test 1335"
../source/schedule.exe  3 3 3  < ../inputs/input/dat735 > ../outputs/t1335
echo ">>>>>>>>running test 1336"
../source/schedule.exe  2 1 1  < ../inputs/input/dat736 > ../outputs/t1336
echo ">>>>>>>>running test 1337"
../source/schedule.exe  2 2 1  < ../inputs/input/dat737 > ../outputs/t1337
echo ">>>>>>>>running test 1338"
../source/schedule.exe  5 4 1  < ../inputs/input/dat738 > ../outputs/t1338
echo ">>>>>>>>running test 1339"
../source/schedule.exe  3 3 0  < ../inputs/input/dat739 > ../outputs/t1339
echo ">>>>>>>>running test 1340"
../source/schedule.exe  0 0 1  < ../inputs/input/dat740 > ../outputs/t1340
echo ">>>>>>>>running test 1341"
../source/schedule.exe  5 3 2  < ../inputs/input/dat741 > ../outputs/t1341
echo ">>>>>>>>running test 1342"
../source/schedule.exe  5 5 5  < ../inputs/input/dat742 > ../outputs/t1342
echo ">>>>>>>>running test 1343"
../source/schedule.exe  5 4 3  < ../inputs/input/dat743 > ../outputs/t1343
echo ">>>>>>>>running test 1344"
../source/schedule.exe  4 3 2  < ../inputs/input/dat744 > ../outputs/t1344
echo ">>>>>>>>running test 1345"
../source/schedule.exe  5 5 4  < ../inputs/input/dat745 > ../outputs/t1345
echo ">>>>>>>>running test 1346"
../source/schedule.exe  1 1 5  < ../inputs/input/dat746 > ../outputs/t1346
echo ">>>>>>>>running test 1347"
../source/schedule.exe  0 4 4  < ../inputs/input/dat747 > ../outputs/t1347
echo ">>>>>>>>running test 1348"
../source/schedule.exe  0 0 1  < ../inputs/input/dat748 > ../outputs/t1348
echo ">>>>>>>>running test 1349"
../source/schedule.exe  4 5 3  < ../inputs/input/dat749 > ../outputs/t1349
echo ">>>>>>>>running test 1350"
../source/schedule.exe  4 4 5  < ../inputs/input/dat750 > ../outputs/t1350
echo ">>>>>>>>running test 1351"
../source/schedule.exe  3 1 5  < ../inputs/input/dat751 > ../outputs/t1351
echo ">>>>>>>>running test 1352"
../source/schedule.exe  4 4 2  < ../inputs/input/dat752 > ../outputs/t1352
echo ">>>>>>>>running test 1353"
../source/schedule.exe  2 1 0  < ../inputs/input/dat753 > ../outputs/t1353
echo ">>>>>>>>running test 1354"
../source/schedule.exe  2 1 2  < ../inputs/input/dat754 > ../outputs/t1354
echo ">>>>>>>>running test 1355"
../source/schedule.exe  0 4 1  < ../inputs/input/dat755 > ../outputs/t1355
echo ">>>>>>>>running test 1356"
../source/schedule.exe  4 1 0  < ../inputs/input/dat756 > ../outputs/t1356
echo ">>>>>>>>running test 1357"
../source/schedule.exe  5 5 2  < ../inputs/input/dat757 > ../outputs/t1357
echo ">>>>>>>>running test 1358"
../source/schedule.exe  2 4 5  < ../inputs/input/dat758 > ../outputs/t1358
echo ">>>>>>>>running test 1359"
../source/schedule.exe  3 5 0  < ../inputs/input/dat759 > ../outputs/t1359
echo ">>>>>>>>running test 1360"
../source/schedule.exe  1 2 4  < ../inputs/input/dat760 > ../outputs/t1360
echo ">>>>>>>>running test 1361"
../source/schedule.exe  3 4 4  < ../inputs/input/dat761 > ../outputs/t1361
echo ">>>>>>>>running test 1362"
../source/schedule.exe  4 2 1  < ../inputs/input/dat762 > ../outputs/t1362
echo ">>>>>>>>running test 1363"
../source/schedule.exe  3 3 0  < ../inputs/input/dat763 > ../outputs/t1363
echo ">>>>>>>>running test 1364"
../source/schedule.exe  3 4 3  < ../inputs/input/dat764 > ../outputs/t1364
echo ">>>>>>>>running test 1365"
../source/schedule.exe  0 5 5  < ../inputs/input/dat765 > ../outputs/t1365
echo ">>>>>>>>running test 1366"
../source/schedule.exe  5 4 0  < ../inputs/input/dat766 > ../outputs/t1366
echo ">>>>>>>>running test 1367"
../source/schedule.exe  0 3 2  < ../inputs/input/dat767 > ../outputs/t1367
echo ">>>>>>>>running test 1368"
../source/schedule.exe  2 3 0  < ../inputs/input/dat768 > ../outputs/t1368
echo ">>>>>>>>running test 1369"
../source/schedule.exe  5 0 1  < ../inputs/input/dat769 > ../outputs/t1369
echo ">>>>>>>>running test 1370"
../source/schedule.exe  0 5 1  < ../inputs/input/dat770 > ../outputs/t1370
echo ">>>>>>>>running test 1371"
../source/schedule.exe  4 4 5  < ../inputs/input/dat771 > ../outputs/t1371
echo ">>>>>>>>running test 1372"
../source/schedule.exe  0 2 2  < ../inputs/input/dat772 > ../outputs/t1372
echo ">>>>>>>>running test 1373"
../source/schedule.exe  1 1 1  < ../inputs/input/dat773 > ../outputs/t1373
echo ">>>>>>>>running test 1374"
../source/schedule.exe  0 2 0  < ../inputs/input/dat774 > ../outputs/t1374
echo ">>>>>>>>running test 1375"
../source/schedule.exe  0 3 0  < ../inputs/input/dat775 > ../outputs/t1375
echo ">>>>>>>>running test 1376"
../source/schedule.exe  4 5 2  < ../inputs/input/dat776 > ../outputs/t1376
echo ">>>>>>>>running test 1377"
../source/schedule.exe  4 2 1  < ../inputs/input/dat777 > ../outputs/t1377
echo ">>>>>>>>running test 1378"
../source/schedule.exe  2 2 5  < ../inputs/input/dat778 > ../outputs/t1378
echo ">>>>>>>>running test 1379"
../source/schedule.exe  5 2 3  < ../inputs/input/dat779 > ../outputs/t1379
echo ">>>>>>>>running test 1380"
../source/schedule.exe  3 1 2  < ../inputs/input/dat780 > ../outputs/t1380
echo ">>>>>>>>running test 1381"
../source/schedule.exe  3 0 3  < ../inputs/input/dat781 > ../outputs/t1381
echo ">>>>>>>>running test 1382"
../source/schedule.exe  5 4 3  < ../inputs/input/dat782 > ../outputs/t1382
echo ">>>>>>>>running test 1383"
../source/schedule.exe  1 3 2  < ../inputs/input/dat783 > ../outputs/t1383
echo ">>>>>>>>running test 1384"
../source/schedule.exe  3 0 0  < ../inputs/input/dat784 > ../outputs/t1384
echo ">>>>>>>>running test 1385"
../source/schedule.exe  4 2 5  < ../inputs/input/dat785 > ../outputs/t1385
echo ">>>>>>>>running test 1386"
../source/schedule.exe  4 3 5  < ../inputs/input/dat786 > ../outputs/t1386
echo ">>>>>>>>running test 1387"
../source/schedule.exe  4 2 4  < ../inputs/input/dat787 > ../outputs/t1387
echo ">>>>>>>>running test 1388"
../source/schedule.exe  1 5 4  < ../inputs/input/dat788 > ../outputs/t1388
echo ">>>>>>>>running test 1389"
../source/schedule.exe  4 0 1  < ../inputs/input/dat789 > ../outputs/t1389
echo ">>>>>>>>running test 1390"
../source/schedule.exe  3 5 4  < ../inputs/input/dat790 > ../outputs/t1390
echo ">>>>>>>>running test 1391"
../source/schedule.exe  2 3 5  < ../inputs/input/dat791 > ../outputs/t1391
echo ">>>>>>>>running test 1392"
../source/schedule.exe  1 3 0  < ../inputs/input/dat792 > ../outputs/t1392
echo ">>>>>>>>running test 1393"
../source/schedule.exe  0 2 4  < ../inputs/input/dat793 > ../outputs/t1393
echo ">>>>>>>>running test 1394"
../source/schedule.exe  2 4 1  < ../inputs/input/dat794 > ../outputs/t1394
echo ">>>>>>>>running test 1395"
../source/schedule.exe  2 0 0  < ../inputs/input/dat795 > ../outputs/t1395
echo ">>>>>>>>running test 1396"
../source/schedule.exe  5 0 2  < ../inputs/input/dat796 > ../outputs/t1396
echo ">>>>>>>>running test 1397"
../source/schedule.exe  5 0 1  < ../inputs/input/dat797 > ../outputs/t1397
echo ">>>>>>>>running test 1398"
../source/schedule.exe  0 4 5  < ../inputs/input/dat798 > ../outputs/t1398
echo ">>>>>>>>running test 1399"
../source/schedule.exe  5 5 3  < ../inputs/input/dat800 > ../outputs/t1399
echo ">>>>>>>>running test 1400"
../source/schedule.exe  2 2 1  < ../inputs/input/dat799 > ../outputs/t1400
echo ">>>>>>>>running test 1401"
../source/schedule.exe 1 1 1  < ../inputs/input/ad.1 > ../outputs/t1401
echo ">>>>>>>>running test 1402"
../source/schedule.exe 1 1 0  < ../inputs/input/ad.2 > ../outputs/t1402
echo ">>>>>>>>running test 1403"
../source/schedule.exe 1 2  < ../inputs/input/ad.1 > ../outputs/t1403
echo ">>>>>>>>running test 1404"
../source/schedule.exe 1  < ../inputs/input/ad.1 > ../outputs/t1404
echo ">>>>>>>>running test 1405"
../source/schedule.exe  < ../inputs/input/ad.1 > ../outputs/t1405
echo ">>>>>>>>running test 1406"
../source/schedule.exe 1 2 3 4  < ../inputs/input/ad.1 > ../outputs/t1406
echo ">>>>>>>>running test 1407"
../source/schedule.exe 7 1 9  < ../inputs/input/add.58 > ../outputs/t1407
echo ">>>>>>>>running test 1408"
../source/schedule.exe 7 1 4  < ../inputs/input/add.100 > ../outputs/t1408
echo ">>>>>>>>running test 1409"
../source/schedule.exe 3 5 9  < ../inputs/input/add.95 > ../outputs/t1409
echo ">>>>>>>>running test 1410"
../source/schedule.exe 9 7 2  < ../inputs/input/add.0 > ../outputs/t1410
echo ">>>>>>>>running test 1411"
../source/schedule.exe 0 2 6  < ../inputs/input/add.52 > ../outputs/t1411
echo ">>>>>>>>running test 1412"
../source/schedule.exe 3 2 0  < ../inputs/input/add.48 > ../outputs/t1412
echo ">>>>>>>>running test 1413"
../source/schedule.exe 10 5 0  < ../inputs/input/add.20 > ../outputs/t1413
echo ">>>>>>>>running test 1414"
../source/schedule.exe 7 4 10  < ../inputs/input/add.37 > ../outputs/t1414
echo ">>>>>>>>running test 1415"
../source/schedule.exe 9 2 0  < ../inputs/input/add.13 > ../outputs/t1415
echo ">>>>>>>>running test 1416"
../source/schedule.exe 9 1 2  < ../inputs/input/add.14 > ../outputs/t1416
echo ">>>>>>>>running test 1417"
../source/schedule.exe 1 3 10  < ../inputs/input/add.100 > ../outputs/t1417
echo ">>>>>>>>running test 1418"
../source/schedule.exe 1 2 1  < ../inputs/input/add.0 > ../outputs/t1418
echo ">>>>>>>>running test 1419"
../source/schedule.exe 5 5 4  < ../inputs/input/add.11 > ../outputs/t1419
echo ">>>>>>>>running test 1420"
../source/schedule.exe 1 6 10  < ../inputs/input/add.38 > ../outputs/t1420
echo ">>>>>>>>running test 1421"
../source/schedule.exe 4 0 8  < ../inputs/input/add.92 > ../outputs/t1421
echo ">>>>>>>>running test 1422"
../source/schedule.exe 1 10 8  < ../inputs/input/add.50 > ../outputs/t1422
echo ">>>>>>>>running test 1423"
../source/schedule.exe 1 4 5  < ../inputs/input/add.51 > ../outputs/t1423
echo ">>>>>>>>running test 1424"
../source/schedule.exe 9 9 3  < ../inputs/input/add.43 > ../outputs/t1424
echo ">>>>>>>>running test 1425"
../source/schedule.exe 2 6 6  < ../inputs/input/add.78 > ../outputs/t1425
echo ">>>>>>>>running test 1426"
../source/schedule.exe 1 7 4  < ../inputs/input/add.42 > ../outputs/t1426
echo ">>>>>>>>running test 1427"
../source/schedule.exe 3 1 0  < ../inputs/input/add.33 > ../outputs/t1427
echo ">>>>>>>>running test 1428"
../source/schedule.exe 3 2 2  < ../inputs/input/add.56 > ../outputs/t1428
echo ">>>>>>>>running test 1429"
../source/schedule.exe 2 7 9  < ../inputs/input/add.57 > ../outputs/t1429
echo ">>>>>>>>running test 1430"
../source/schedule.exe 0 0 7  < ../inputs/input/add.34 > ../outputs/t1430
echo ">>>>>>>>running test 1431"
../source/schedule.exe 3 6 5  < ../inputs/input/add.86 > ../outputs/t1431
echo ">>>>>>>>running test 1432"
../source/schedule.exe 4 6 2  < ../inputs/input/add.97 > ../outputs/t1432
echo ">>>>>>>>running test 1433"
../source/schedule.exe 5 10 5  < ../inputs/input/add.52 > ../outputs/t1433
echo ">>>>>>>>running test 1434"
../source/schedule.exe 9 3 10  < ../inputs/input/add.73 > ../outputs/t1434
echo ">>>>>>>>running test 1435"
../source/schedule.exe 6 10 6  < ../inputs/input/add.69 > ../outputs/t1435
echo ">>>>>>>>running test 1436"
../source/schedule.exe 2 0 9  < ../inputs/input/add.53 > ../outputs/t1436
echo ">>>>>>>>running test 1437"
../source/schedule.exe 1 0 4  < ../inputs/input/add.77 > ../outputs/t1437
echo ">>>>>>>>running test 1438"
../source/schedule.exe 6 5 9  < ../inputs/input/add.32 > ../outputs/t1438
echo ">>>>>>>>running test 1439"
../source/schedule.exe 4 3 7  < ../inputs/input/add.82 > ../outputs/t1439
echo ">>>>>>>>running test 1440"
../source/schedule.exe 6 6 0  < ../inputs/input/add.19 > ../outputs/t1440
echo ">>>>>>>>running test 1441"
../source/schedule.exe 3 3 4  < ../inputs/input/add.85 > ../outputs/t1441
echo ">>>>>>>>running test 1442"
../source/schedule.exe 1 10 6  < ../inputs/input/add.7 > ../outputs/t1442
echo ">>>>>>>>running test 1443"
../source/schedule.exe 2 0 9  < ../inputs/input/add.15 > ../outputs/t1443
echo ">>>>>>>>running test 1444"
../source/schedule.exe 4 7 0  < ../inputs/input/add.90 > ../outputs/t1444
echo ">>>>>>>>running test 1445"
../source/schedule.exe 6 0 3  < ../inputs/input/add.91 > ../outputs/t1445
echo ">>>>>>>>running test 1446"
../source/schedule.exe 3 3 0  < ../inputs/input/add.23 > ../outputs/t1446
echo ">>>>>>>>running test 1447"
../source/schedule.exe 7 9 2  < ../inputs/input/add.50 > ../outputs/t1447
echo ">>>>>>>>running test 1448"
../source/schedule.exe 4 10 7  < ../inputs/input/add.83 > ../outputs/t1448
echo ">>>>>>>>running test 1449"
../source/schedule.exe 2 2 10  < ../inputs/input/add.77 > ../outputs/t1449
echo ">>>>>>>>running test 1450"
../source/schedule.exe 1 5 3  < ../inputs/input/add.11 > ../outputs/t1450
echo ">>>>>>>>running test 1451"
../source/schedule.exe 2 4 3  < ../inputs/input/add.37 > ../outputs/t1451
echo ">>>>>>>>running test 1452"
../source/schedule.exe 3 2 3  < ../inputs/input/add.65 > ../outputs/t1452
echo ">>>>>>>>running test 1453"
../source/schedule.exe 7 4 2  < ../inputs/input/add.37 > ../outputs/t1453
echo ">>>>>>>>running test 1454"
../source/schedule.exe 5 0 9  < ../inputs/input/add.64 > ../outputs/t1454
echo ">>>>>>>>running test 1455"
../source/schedule.exe 3 0 7  < ../inputs/input/add.73 > ../outputs/t1455
echo ">>>>>>>>running test 1456"
../source/schedule.exe 4 8 9  < ../inputs/input/add.70 > ../outputs/t1456
echo ">>>>>>>>running test 1457"
../source/schedule.exe 10 10 8  < ../inputs/input/add.26 > ../outputs/t1457
echo ">>>>>>>>running test 1458"
../source/schedule.exe 2 8 6  < ../inputs/input/add.21 > ../outputs/t1458
echo ">>>>>>>>running test 1459"
../source/schedule.exe 10 2 1  < ../inputs/input/add.6 > ../outputs/t1459
echo ">>>>>>>>running test 1460"
../source/schedule.exe 0 4 10  < ../inputs/input/add.82 > ../outputs/t1460
echo ">>>>>>>>running test 1461"
../source/schedule.exe 7 0 3  < ../inputs/input/add.48 > ../outputs/t1461
echo ">>>>>>>>running test 1462"
../source/schedule.exe 9 1 6  < ../inputs/input/add.83 > ../outputs/t1462
echo ">>>>>>>>running test 1463"
../source/schedule.exe 3 9 10  < ../inputs/input/add.9 > ../outputs/t1463
echo ">>>>>>>>running test 1464"
../source/schedule.exe 10 3 7  < ../inputs/input/add.20 > ../outputs/t1464
echo ">>>>>>>>running test 1465"
../source/schedule.exe 1 1 0  < ../inputs/input/add.91 > ../outputs/t1465
echo ">>>>>>>>running test 1466"
../source/schedule.exe 6 9 8  < ../inputs/input/add.78 > ../outputs/t1466
echo ">>>>>>>>running test 1467"
../source/schedule.exe 0 7 6  < ../inputs/input/add.45 > ../outputs/t1467
echo ">>>>>>>>running test 1468"
../source/schedule.exe 8 0 2  < ../inputs/input/add.12 > ../outputs/t1468
echo ">>>>>>>>running test 1469"
../source/schedule.exe 7 1 10  < ../inputs/input/add.25 > ../outputs/t1469
echo ">>>>>>>>running test 1470"
../source/schedule.exe 8 2 7  < ../inputs/input/add.68 > ../outputs/t1470
echo ">>>>>>>>running test 1471"
../source/schedule.exe 0 6 1  < ../inputs/input/add.39 > ../outputs/t1471
echo ">>>>>>>>running test 1472"
../source/schedule.exe 4 5 5  < ../inputs/input/add.62 > ../outputs/t1472
echo ">>>>>>>>running test 1473"
../source/schedule.exe 7 2 9  < ../inputs/input/add.72 > ../outputs/t1473
echo ">>>>>>>>running test 1474"
../source/schedule.exe 10 10 6  < ../inputs/input/add.35 > ../outputs/t1474
echo ">>>>>>>>running test 1475"
../source/schedule.exe 3 3 2  < ../inputs/input/add.74 > ../outputs/t1475
echo ">>>>>>>>running test 1476"
../source/schedule.exe 4 7 2  < ../inputs/input/add.47 > ../outputs/t1476
echo ">>>>>>>>running test 1477"
../source/schedule.exe 8 8 0  < ../inputs/input/add.54 > ../outputs/t1477
echo ">>>>>>>>running test 1478"
../source/schedule.exe 3 8 5  < ../inputs/input/add.48 > ../outputs/t1478
echo ">>>>>>>>running test 1479"
../source/schedule.exe 8 6 3  < ../inputs/input/add.11 > ../outputs/t1479
echo ">>>>>>>>running test 1480"
../source/schedule.exe 2 10 7  < ../inputs/input/add.91 > ../outputs/t1480
echo ">>>>>>>>running test 1481"
../source/schedule.exe 4 4 3  < ../inputs/input/add.97 > ../outputs/t1481
echo ">>>>>>>>running test 1482"
../source/schedule.exe 8 4 0  < ../inputs/input/add.37 > ../outputs/t1482
echo ">>>>>>>>running test 1483"
../source/schedule.exe 7 1 1  < ../inputs/input/add.88 > ../outputs/t1483
echo ">>>>>>>>running test 1484"
../source/schedule.exe 6 9 10  < ../inputs/input/add.50 > ../outputs/t1484
echo ">>>>>>>>running test 1485"
../source/schedule.exe 0 1 8  < ../inputs/input/add.75 > ../outputs/t1485
echo ">>>>>>>>running test 1486"
../source/schedule.exe 10 4 10  < ../inputs/input/add.3 > ../outputs/t1486
echo ">>>>>>>>running test 1487"
../source/schedule.exe 5 10 7  < ../inputs/input/add.22 > ../outputs/t1487
echo ">>>>>>>>running test 1488"
../source/schedule.exe 2 3 9  < ../inputs/input/add.95 > ../outputs/t1488
echo ">>>>>>>>running test 1489"
../source/schedule.exe 4 2 9  < ../inputs/input/add.60 > ../outputs/t1489
echo ">>>>>>>>running test 1490"
../source/schedule.exe 0 9 2  < ../inputs/input/add.31 > ../outputs/t1490
echo ">>>>>>>>running test 1491"
../source/schedule.exe 1 2 6  < ../inputs/input/add.45 > ../outputs/t1491
echo ">>>>>>>>running test 1492"
../source/schedule.exe 5 2 0  < ../inputs/input/add.34 > ../outputs/t1492
echo ">>>>>>>>running test 1493"
../source/schedule.exe 9 8 2  < ../inputs/input/add.77 > ../outputs/t1493
echo ">>>>>>>>running test 1494"
../source/schedule.exe 5 4 3  < ../inputs/input/add.29 > ../outputs/t1494
echo ">>>>>>>>running test 1495"
../source/schedule.exe 1 10 8  < ../inputs/input/add.22 > ../outputs/t1495
echo ">>>>>>>>running test 1496"
../source/schedule.exe 2 9 3  < ../inputs/input/add.38 > ../outputs/t1496
echo ">>>>>>>>running test 1497"
../source/schedule.exe 10 10 5  < ../inputs/input/add.89 > ../outputs/t1497
echo ">>>>>>>>running test 1498"
../source/schedule.exe 0 6 3  < ../inputs/input/add.43 > ../outputs/t1498
echo ">>>>>>>>running test 1499"
../source/schedule.exe 2 7 0  < ../inputs/input/add.94 > ../outputs/t1499
echo ">>>>>>>>running test 1500"
../source/schedule.exe 0 0 5  < ../inputs/input/add.79 > ../outputs/t1500
echo ">>>>>>>>running test 1501"
../source/schedule.exe 10 2 4  < ../inputs/input/add.17 > ../outputs/t1501
echo ">>>>>>>>running test 1502"
../source/schedule.exe 10 4 0  < ../inputs/input/add.36 > ../outputs/t1502
echo ">>>>>>>>running test 1503"
../source/schedule.exe 4 1 2  < ../inputs/input/add.20 > ../outputs/t1503
echo ">>>>>>>>running test 1504"
../source/schedule.exe 9 6 5  < ../inputs/input/add.86 > ../outputs/t1504
echo ">>>>>>>>running test 1505"
../source/schedule.exe 7 7 3  < ../inputs/input/add.11 > ../outputs/t1505
echo ">>>>>>>>running test 1506"
../source/schedule.exe 0 1 8  < ../inputs/input/add.67 > ../outputs/t1506
echo ">>>>>>>>running test 1507"
../source/schedule.exe 7 1 9  < ../inputs/input/adt.58 > ../outputs/t1507
echo ">>>>>>>>running test 1508"
../source/schedule.exe 7 1 4  < ../inputs/input/adt.100 > ../outputs/t1508
echo ">>>>>>>>running test 1509"
../source/schedule.exe 3 5 9  < ../inputs/input/adt.95 > ../outputs/t1509
echo ">>>>>>>>running test 1510"
../source/schedule.exe 9 7 2  < ../inputs/input/adt.0 > ../outputs/t1510
echo ">>>>>>>>running test 1511"
../source/schedule.exe 0 2 6  < ../inputs/input/adt.52 > ../outputs/t1511
echo ">>>>>>>>running test 1512"
../source/schedule.exe 3 2 0  < ../inputs/input/adt.48 > ../outputs/t1512
echo ">>>>>>>>running test 1513"
../source/schedule.exe 10 5 0  < ../inputs/input/adt.20 > ../outputs/t1513
echo ">>>>>>>>running test 1514"
../source/schedule.exe 10 5 10  < ../inputs/input/adt.3 > ../outputs/t1514
echo ">>>>>>>>running test 1515"
../source/schedule.exe 5 7 8  < ../inputs/input/adt.89 > ../outputs/t1515
echo ">>>>>>>>running test 1516"
../source/schedule.exe 7 5 3  < ../inputs/input/adt.75 > ../outputs/t1516
echo ">>>>>>>>running test 1517"
../source/schedule.exe 1 10 0  < ../inputs/input/adt.93 > ../outputs/t1517
echo ">>>>>>>>running test 1518"
../source/schedule.exe 2 9 9  < ../inputs/input/adt.24 > ../outputs/t1518
echo ">>>>>>>>running test 1519"
../source/schedule.exe 1 8 5  < ../inputs/input/adt.24 > ../outputs/t1519
echo ">>>>>>>>running test 1520"
../source/schedule.exe 6 0 2  < ../inputs/input/adt.54 > ../outputs/t1520
echo ">>>>>>>>running test 1521"
../source/schedule.exe 10 3 0  < ../inputs/input/adt.48 > ../outputs/t1521
echo ">>>>>>>>running test 1522"
../source/schedule.exe 2 5 6  < ../inputs/input/adt.55 > ../outputs/t1522
echo ">>>>>>>>running test 1523"
../source/schedule.exe 3 2 8  < ../inputs/input/adt.44 > ../outputs/t1523
echo ">>>>>>>>running test 1524"
../source/schedule.exe 0 10 1  < ../inputs/input/adt.14 > ../outputs/t1524
echo ">>>>>>>>running test 1525"
../source/schedule.exe 5 5 4  < ../inputs/input/adt.96 > ../outputs/t1525
echo ">>>>>>>>running test 1526"
../source/schedule.exe 1 4 3  < ../inputs/input/adt.57 > ../outputs/t1526
echo ">>>>>>>>running test 1527"
../source/schedule.exe 1 0 3  < ../inputs/input/adt.74 > ../outputs/t1527
echo ">>>>>>>>running test 1528"
../source/schedule.exe 10 6 1  < ../inputs/input/adt.37 > ../outputs/t1528
echo ">>>>>>>>running test 1529"
../source/schedule.exe 6 3 10  < ../inputs/input/adt.9 > ../outputs/t1529
echo ">>>>>>>>running test 1530"
../source/schedule.exe 7 9 10  < ../inputs/input/adt.36 > ../outputs/t1530
echo ">>>>>>>>running test 1531"
../source/schedule.exe 6 9 7  < ../inputs/input/adt.55 > ../outputs/t1531
echo ">>>>>>>>running test 1532"
../source/schedule.exe 0 0 4  < ../inputs/input/adt.40 > ../outputs/t1532
echo ">>>>>>>>running test 1533"
../source/schedule.exe 9 7 0  < ../inputs/input/adt.0 > ../outputs/t1533
echo ">>>>>>>>running test 1534"
../source/schedule.exe 3 1 9  < ../inputs/input/adt.11 > ../outputs/t1534
echo ">>>>>>>>running test 1535"
../source/schedule.exe 8 1 0  < ../inputs/input/adt.90 > ../outputs/t1535
echo ">>>>>>>>running test 1536"
../source/schedule.exe 3 3 1  < ../inputs/input/adt.62 > ../outputs/t1536
echo ">>>>>>>>running test 1537"
../source/schedule.exe 1 1 10  < ../inputs/input/adt.4 > ../outputs/t1537
echo ">>>>>>>>running test 1538"
../source/schedule.exe 10 8 9  < ../inputs/input/adt.54 > ../outputs/t1538
echo ">>>>>>>>running test 1539"
../source/schedule.exe 4 2 10  < ../inputs/input/adt.21 > ../outputs/t1539
echo ">>>>>>>>running test 1540"
../source/schedule.exe 3 7 3  < ../inputs/input/adt.32 > ../outputs/t1540
echo ">>>>>>>>running test 1541"
../source/schedule.exe 2 8 0  < ../inputs/input/adt.57 > ../outputs/t1541
echo ">>>>>>>>running test 1542"
../source/schedule.exe 9 10 2  < ../inputs/input/adt.3 > ../outputs/t1542
echo ">>>>>>>>running test 1543"
../source/schedule.exe 4 1 7  < ../inputs/input/adt.74 > ../outputs/t1543
echo ">>>>>>>>running test 1544"
../source/schedule.exe 1 10 9  < ../inputs/input/adt.0 > ../outputs/t1544
echo ">>>>>>>>running test 1545"
../source/schedule.exe 3 1 1  < ../inputs/input/adt.54 > ../outputs/t1545
echo ">>>>>>>>running test 1546"
../source/schedule.exe 6 6 1  < ../inputs/input/adt.36 > ../outputs/t1546
echo ">>>>>>>>running test 1547"
../source/schedule.exe 6 5 9  < ../inputs/input/adt.34 > ../outputs/t1547
echo ">>>>>>>>running test 1548"
../source/schedule.exe 9 7 3  < ../inputs/input/adt.64 > ../outputs/t1548
echo ">>>>>>>>running test 1549"
../source/schedule.exe 5 2 1  < ../inputs/input/adt.34 > ../outputs/t1549
echo ">>>>>>>>running test 1550"
../source/schedule.exe 6 9 8  < ../inputs/input/adt.8 > ../outputs/t1550
echo ">>>>>>>>running test 1551"
../source/schedule.exe 3 5 4  < ../inputs/input/adt.16 > ../outputs/t1551
echo ">>>>>>>>running test 1552"
../source/schedule.exe 10 0 6  < ../inputs/input/adt.30 > ../outputs/t1552
echo ">>>>>>>>running test 1553"
../source/schedule.exe 7 5 1  < ../inputs/input/adt.26 > ../outputs/t1553
echo ">>>>>>>>running test 1554"
../source/schedule.exe 0 7 6  < ../inputs/input/adt.3 > ../outputs/t1554
echo ">>>>>>>>running test 1555"
../source/schedule.exe 7 2 1  < ../inputs/input/adt.17 > ../outputs/t1555
echo ">>>>>>>>running test 1556"
../source/schedule.exe 6 0 6  < ../inputs/input/adt.21 > ../outputs/t1556
echo ">>>>>>>>running test 1557"
../source/schedule.exe 7 1 9  < ../inputs/input/inp.hf.1 > ../outputs/t1557
echo ">>>>>>>>running test 1558"
../source/schedule.exe 2 3 5  < ../inputs/input/inp.hf.2 > ../outputs/t1558
echo ">>>>>>>>running test 1559"
../source/schedule.exe 4 8 8  < ../inputs/input/inp.hf.3 > ../outputs/t1559
echo ">>>>>>>>running test 1560"
../source/schedule.exe 10 0 2  < ../inputs/input/inp.hf.4 > ../outputs/t1560
echo ">>>>>>>>running test 1561"
../source/schedule.exe 8 3 2  < ../inputs/input/inp.hf.5 > ../outputs/t1561
echo ">>>>>>>>running test 1562"
../source/schedule.exe 7 10 5  < ../inputs/input/inp.hf.6 > ../outputs/t1562
echo ">>>>>>>>running test 1563"
../source/schedule.exe 4 0 6  < ../inputs/input/inp.hf.7 > ../outputs/t1563
echo ">>>>>>>>running test 1564"
../source/schedule.exe 3 7 4  < ../inputs/input/inp.hf.8 > ../outputs/t1564
echo ">>>>>>>>running test 1565"
../source/schedule.exe 9 7 5  < ../inputs/input/inp.hf.9 > ../outputs/t1565
echo ">>>>>>>>running test 1566"
../source/schedule.exe 9 10 6  < ../inputs/input/inp.hf.10 > ../outputs/t1566
echo ">>>>>>>>running test 1567"
../source/schedule.exe 7 9 8  < ../inputs/input/inp.hf.11 > ../outputs/t1567
echo ">>>>>>>>running test 1568"
../source/schedule.exe 8 9 0  < ../inputs/input/inp.hf.12 > ../outputs/t1568
echo ">>>>>>>>running test 1569"
../source/schedule.exe 8 5 0  < ../inputs/input/inp.hf.13 > ../outputs/t1569
echo ">>>>>>>>running test 1570"
../source/schedule.exe 9 8 5  < ../inputs/input/inp.hf.14 > ../outputs/t1570
echo ">>>>>>>>running test 1571"
../source/schedule.exe 7 0 6  < ../inputs/input/inp.hf.15 > ../outputs/t1571
echo ">>>>>>>>running test 1572"
../source/schedule.exe 8 3 9  < ../inputs/input/inp.hf.16 > ../outputs/t1572
echo ">>>>>>>>running test 1573"
../source/schedule.exe 7 4 2  < ../inputs/input/inp.hf.17 > ../outputs/t1573
echo ">>>>>>>>running test 1574"
../source/schedule.exe 5 8 7  < ../inputs/input/inp.hf.18 > ../outputs/t1574
echo ">>>>>>>>running test 1575"
../source/schedule.exe 0 4 1  < ../inputs/input/inp.hf.19 > ../outputs/t1575
echo ">>>>>>>>running test 1576"
../source/schedule.exe 0 10 6  < ../inputs/input/inp.hf.20 > ../outputs/t1576
echo ">>>>>>>>running test 1577"
../source/schedule.exe 9 0 9  < ../inputs/input/inp.hf.21 > ../outputs/t1577
echo ">>>>>>>>running test 1578"
../source/schedule.exe 9 9 2  < ../inputs/input/inp.hf.22 > ../outputs/t1578
echo ">>>>>>>>running test 1579"
../source/schedule.exe 6 1 0  < ../inputs/input/inp.hf.23 > ../outputs/t1579
echo ">>>>>>>>running test 1580"
../source/schedule.exe 5 10 8  < ../inputs/input/inp.hf.24 > ../outputs/t1580
echo ">>>>>>>>running test 1581"
../source/schedule.exe 6 9 0  < ../inputs/input/inp.hf.25 > ../outputs/t1581
echo ">>>>>>>>running test 1582"
../source/schedule.exe 3 7 3  < ../inputs/input/inp.hf.26 > ../outputs/t1582
echo ">>>>>>>>running test 1583"
../source/schedule.exe 1 5 5  < ../inputs/input/inp.hf.27 > ../outputs/t1583
echo ">>>>>>>>running test 1584"
../source/schedule.exe 1 2 7  < ../inputs/input/inp.hf.28 > ../outputs/t1584
echo ">>>>>>>>running test 1585"
../source/schedule.exe 2 7 6  < ../inputs/input/inp.hf.29 > ../outputs/t1585
echo ">>>>>>>>running test 1586"
../source/schedule.exe 4 6 3  < ../inputs/input/inp.hf.30 > ../outputs/t1586
echo ">>>>>>>>running test 1587"
../source/schedule.exe 7 1 9  < ../inputs/input/adt.158 > ../outputs/t1587
echo ">>>>>>>>running test 1588"
../source/schedule.exe 7 1 4  < ../inputs/input/adt.200 > ../outputs/t1588
echo ">>>>>>>>running test 1589"
../source/schedule.exe 3 5 9  < ../inputs/input/adt.195 > ../outputs/t1589
echo ">>>>>>>>running test 1590"
../source/schedule.exe 9 7 2  < ../inputs/input/adt.100 > ../outputs/t1590
echo ">>>>>>>>running test 1591"
../source/schedule.exe 0 2 6  < ../inputs/input/adt.152 > ../outputs/t1591
echo ">>>>>>>>running test 1592"
../source/schedule.exe 3 2 0  < ../inputs/input/adt.148 > ../outputs/t1592
echo ">>>>>>>>running test 1593"
../source/schedule.exe 10 5 0  < ../inputs/input/adt.120 > ../outputs/t1593
echo ">>>>>>>>running test 1594"
../source/schedule.exe 10 5 10  < ../inputs/input/adt.103 > ../outputs/t1594
echo ">>>>>>>>running test 1595"
../source/schedule.exe 5 7 8  < ../inputs/input/adt.189 > ../outputs/t1595
echo ">>>>>>>>running test 1596"
../source/schedule.exe 7 5 3  < ../inputs/input/adt.175 > ../outputs/t1596
echo ">>>>>>>>running test 1597"
../source/schedule.exe 1 10 0  < ../inputs/input/adt.193 > ../outputs/t1597
echo ">>>>>>>>running test 1598"
../source/schedule.exe 2 9 9  < ../inputs/input/adt.124 > ../outputs/t1598
echo ">>>>>>>>running test 1599"
../source/schedule.exe 1 8 5  < ../inputs/input/adt.124 > ../outputs/t1599
echo ">>>>>>>>running test 1600"
../source/schedule.exe 6 0 2  < ../inputs/input/adt.154 > ../outputs/t1600
echo ">>>>>>>>running test 1601"
../source/schedule.exe 10 3 0  < ../inputs/input/adt.148 > ../outputs/t1601
echo ">>>>>>>>running test 1602"
../source/schedule.exe 2 5 6  < ../inputs/input/adt.155 > ../outputs/t1602
echo ">>>>>>>>running test 1603"
../source/schedule.exe 3 2 8  < ../inputs/input/adt.144 > ../outputs/t1603
echo ">>>>>>>>running test 1604"
../source/schedule.exe 0 10 1  < ../inputs/input/adt.114 > ../outputs/t1604
echo ">>>>>>>>running test 1605"
../source/schedule.exe 5 5 4  < ../inputs/input/adt.196 > ../outputs/t1605
echo ">>>>>>>>running test 1606"
../source/schedule.exe 1 4 3  < ../inputs/input/adt.157 > ../outputs/t1606
echo ">>>>>>>>running test 1607"
../source/schedule.exe 1 0 3  < ../inputs/input/adt.174 > ../outputs/t1607
echo ">>>>>>>>running test 1608"
../source/schedule.exe 10 6 1  < ../inputs/input/adt.137 > ../outputs/t1608
echo ">>>>>>>>running test 1609"
../source/schedule.exe 6 3 10  < ../inputs/input/adt.109 > ../outputs/t1609
echo ">>>>>>>>running test 1610"
../source/schedule.exe 7 9 10  < ../inputs/input/adt.136 > ../outputs/t1610
echo ">>>>>>>>running test 1611"
../source/schedule.exe 6 9 7  < ../inputs/input/adt.155 > ../outputs/t1611
echo ">>>>>>>>running test 1612"
../source/schedule.exe 0 0 4  < ../inputs/input/adt.140 > ../outputs/t1612
echo ">>>>>>>>running test 1613"
../source/schedule.exe 9 7 0  < ../inputs/input/adt.100 > ../outputs/t1613
echo ">>>>>>>>running test 1614"
../source/schedule.exe 3 1 9  < ../inputs/input/adt.111 > ../outputs/t1614
echo ">>>>>>>>running test 1615"
../source/schedule.exe 8 1 0  < ../inputs/input/adt.190 > ../outputs/t1615
echo ">>>>>>>>running test 1616"
../source/schedule.exe 3 3 1  < ../inputs/input/adt.162 > ../outputs/t1616
echo ">>>>>>>>running test 1617"
../source/schedule.exe 1 1 10  < ../inputs/input/adt.104 > ../outputs/t1617
echo ">>>>>>>>running test 1618"
../source/schedule.exe 10 8 9  < ../inputs/input/adt.154 > ../outputs/t1618
echo ">>>>>>>>running test 1619"
../source/schedule.exe 4 2 10  < ../inputs/input/adt.121 > ../outputs/t1619
echo ">>>>>>>>running test 1620"
../source/schedule.exe 3 7 3  < ../inputs/input/adt.132 > ../outputs/t1620
echo ">>>>>>>>running test 1621"
../source/schedule.exe 2 8 0  < ../inputs/input/adt.157 > ../outputs/t1621
echo ">>>>>>>>running test 1622"
../source/schedule.exe 9 10 2  < ../inputs/input/adt.103 > ../outputs/t1622
echo ">>>>>>>>running test 1623"
../source/schedule.exe 4 1 7  < ../inputs/input/adt.174 > ../outputs/t1623
echo ">>>>>>>>running test 1624"
../source/schedule.exe 1 10 9  < ../inputs/input/adt.100 > ../outputs/t1624
echo ">>>>>>>>running test 1625"
../source/schedule.exe 3 1 1  < ../inputs/input/adt.154 > ../outputs/t1625
echo ">>>>>>>>running test 1626"
../source/schedule.exe 6 6 1  < ../inputs/input/adt.136 > ../outputs/t1626
echo ">>>>>>>>running test 1627"
../source/schedule.exe 6 5 9  < ../inputs/input/adt.134 > ../outputs/t1627
echo ">>>>>>>>running test 1628"
../source/schedule.exe 9 7 3  < ../inputs/input/adt.164 > ../outputs/t1628
echo ">>>>>>>>running test 1629"
../source/schedule.exe 5 2 1  < ../inputs/input/adt.134 > ../outputs/t1629
echo ">>>>>>>>running test 1630"
../source/schedule.exe 6 9 8  < ../inputs/input/adt.108 > ../outputs/t1630
echo ">>>>>>>>running test 1631"
../source/schedule.exe 3 5 4  < ../inputs/input/adt.116 > ../outputs/t1631
echo ">>>>>>>>running test 1632"
../source/schedule.exe 10 0 6  < ../inputs/input/adt.130 > ../outputs/t1632
echo ">>>>>>>>running test 1633"
../source/schedule.exe 7 5 1  < ../inputs/input/adt.126 > ../outputs/t1633
echo ">>>>>>>>running test 1634"
../source/schedule.exe 0 7 6  < ../inputs/input/adt.103 > ../outputs/t1634
echo ">>>>>>>>running test 1635"
../source/schedule.exe 7 2 1  < ../inputs/input/adt.117 > ../outputs/t1635
echo ">>>>>>>>running test 1636"
../source/schedule.exe 6 0 6  < ../inputs/input/adt.121 > ../outputs/t1636
echo ">>>>>>>>running test 1637"
../source/schedule.exe 0 6 6  < ../inputs/input/adt.127 > ../outputs/t1637
echo ">>>>>>>>running test 1638"
../source/schedule.exe 2 6 0  < ../inputs/input/adt.158 > ../outputs/t1638
echo ">>>>>>>>running test 1639"
../source/schedule.exe 4 10 7  < ../inputs/input/adt.174 > ../outputs/t1639
echo ">>>>>>>>running test 1640"
../source/schedule.exe 2 6 0  < ../inputs/input/adt.103 > ../outputs/t1640
echo ">>>>>>>>running test 1641"
../source/schedule.exe 1 1 10  < ../inputs/input/adt.103 > ../outputs/t1641
echo ">>>>>>>>running test 1642"
../source/schedule.exe 10 5 7  < ../inputs/input/adt.150 > ../outputs/t1642
echo ">>>>>>>>running test 1643"
../source/schedule.exe 4 5 0  < ../inputs/input/adt.189 > ../outputs/t1643
echo ">>>>>>>>running test 1644"
../source/schedule.exe 4 5 5  < ../inputs/input/adt.189 > ../outputs/t1644
echo ">>>>>>>>running test 1645"
../source/schedule.exe 8 3 1  < ../inputs/input/adt.170 > ../outputs/t1645
echo ">>>>>>>>running test 1646"
../source/schedule.exe 8 9 4  < ../inputs/input/adt.100 > ../outputs/t1646
echo ">>>>>>>>running test 1647"
../source/schedule.exe 8 6 10  < ../inputs/input/adt.173 > ../outputs/t1647
echo ">>>>>>>>running test 1648"
../source/schedule.exe 0 2 5  < ../inputs/input/adt.146 > ../outputs/t1648
echo ">>>>>>>>running test 1649"
../source/schedule.exe 6 2 7  < ../inputs/input/adt.136 > ../outputs/t1649
echo ">>>>>>>>running test 1650"
../source/schedule.exe 1 8 1  < ../inputs/input/adt.107 > ../outputs/t1650
echo ">>>>>>>>running test 1651"
../source/schedule.exe 7 4 0  < ../inputs/input/adt.113 > ../outputs/t1651
echo ">>>>>>>>running test 1652"
../source/schedule.exe 5 6 0  < ../inputs/input/adt.160 > ../outputs/t1652
echo ">>>>>>>>running test 1653"
../source/schedule.exe 7 6 6  < ../inputs/input/adt.192 > ../outputs/t1653
echo ">>>>>>>>running test 1654"
../source/schedule.exe 4 5 0  < ../inputs/input/adt.115 > ../outputs/t1654
echo ">>>>>>>>running test 1655"
../source/schedule.exe 5 3 4  < ../inputs/input/adt.156 > ../outputs/t1655
echo ">>>>>>>>running test 1656"
../source/schedule.exe 2 9 8  < ../inputs/input/adt.199 > ../outputs/t1656
echo ">>>>>>>>running test 1657"
../source/schedule.exe 4 0 3  < ../inputs/input/adt.108 > ../outputs/t1657
echo ">>>>>>>>running test 1658"
../source/schedule.exe 0 10 6  < ../inputs/input/adt.101 > ../outputs/t1658
echo ">>>>>>>>running test 1659"
../source/schedule.exe 9 3 9  < ../inputs/input/adt.123 > ../outputs/t1659
echo ">>>>>>>>running test 1660"
../source/schedule.exe 6 2 3  < ../inputs/input/adt.155 > ../outputs/t1660
echo ">>>>>>>>running test 1661"
../source/schedule.exe 1 8 7  < ../inputs/input/adt.116 > ../outputs/t1661
echo ">>>>>>>>running test 1662"
../source/schedule.exe 8 2 7  < ../inputs/input/adt.150 > ../outputs/t1662
echo ">>>>>>>>running test 1663"
../source/schedule.exe 0 6 8  < ../inputs/input/adt.172 > ../outputs/t1663
echo ">>>>>>>>running test 1664"
../source/schedule.exe 3 9 2  < ../inputs/input/adt.175 > ../outputs/t1664
echo ">>>>>>>>running test 1665"
../source/schedule.exe 9 4 7  < ../inputs/input/adt.122 > ../outputs/t1665
echo ">>>>>>>>running test 1666"
../source/schedule.exe 0 7 2  < ../inputs/input/adt.116 > ../outputs/t1666
echo ">>>>>>>>running test 1667"
../source/schedule.exe 7 4 9  < ../inputs/input/adt.102 > ../outputs/t1667
echo ">>>>>>>>running test 1668"
../source/schedule.exe 3 1 9  < ../inputs/input/adt.165 > ../outputs/t1668
echo ">>>>>>>>running test 1669"
../source/schedule.exe 1 3 9  < ../inputs/input/adt.159 > ../outputs/t1669
echo ">>>>>>>>running test 1670"
../source/schedule.exe 0 7 0  < ../inputs/input/adt.163 > ../outputs/t1670
echo ">>>>>>>>running test 1671"
../source/schedule.exe 1 3 5  < ../inputs/input/adt.144 > ../outputs/t1671
echo ">>>>>>>>running test 1672"
../source/schedule.exe 1 1 1  < ../inputs/input/adt.164 > ../outputs/t1672
echo ">>>>>>>>running test 1673"
../source/schedule.exe 3 4 3  < ../inputs/input/adt.179 > ../outputs/t1673
echo ">>>>>>>>running test 1674"
../source/schedule.exe 10 5 4  < ../inputs/input/adt.159 > ../outputs/t1674
echo ">>>>>>>>running test 1675"
../source/schedule.exe 8 7 6  < ../inputs/input/adt.140 > ../outputs/t1675
echo ">>>>>>>>running test 1676"
../source/schedule.exe 3 3 5  < ../inputs/input/adt.118 > ../outputs/t1676
echo ">>>>>>>>running test 1677"
../source/schedule.exe 0 0 2  < ../inputs/input/adt.119 > ../outputs/t1677
echo ">>>>>>>>running test 1678"
../source/schedule.exe 4 8 0  < ../inputs/input/adt.151 > ../outputs/t1678
echo ">>>>>>>>running test 1679"
../source/schedule.exe 3 5 6  < ../inputs/input/adt.103 > ../outputs/t1679
echo ">>>>>>>>running test 1680"
../source/schedule.exe 1 2 9  < ../inputs/input/adt.112 > ../outputs/t1680
echo ">>>>>>>>running test 1681"
../source/schedule.exe 7 0 1  < ../inputs/input/adt.114 > ../outputs/t1681
echo ">>>>>>>>running test 1682"
../source/schedule.exe 8 5 1  < ../inputs/input/adt.113 > ../outputs/t1682
echo ">>>>>>>>running test 1683"
../source/schedule.exe 1 0 0  < ../inputs/input/adt.178 > ../outputs/t1683
echo ">>>>>>>>running test 1684"
../source/schedule.exe 9 0 7  < ../inputs/input/adt.140 > ../outputs/t1684
echo ">>>>>>>>running test 1685"
../source/schedule.exe 10 3 9  < ../inputs/input/adt.136 > ../outputs/t1685
echo ">>>>>>>>running test 1686"
../source/schedule.exe 8 4 3  < ../inputs/input/adt.131 > ../outputs/t1686
echo ">>>>>>>>running test 1687"
../source/schedule.exe 4 1 4  < ../inputs/input/dat615 > ../outputs/t1687
echo ">>>>>>>>running test 1688"
../source/schedule.exe 1 0 1  < ../inputs/input/dat615 > ../outputs/t1688
echo ">>>>>>>>running test 1689"
../source/schedule.exe 1 1 0  < ../inputs/input/nt.31 > ../outputs/t1689
echo ">>>>>>>>running test 1690"
../source/schedule.exe 1 1 1  < ../inputs/input/nt.32 > ../outputs/t1690
echo ">>>>>>>>running test 1691"
../source/schedule.exe 2 0 1  < ../inputs/input/nt.32 > ../outputs/t1691
echo ">>>>>>>>running test 1692"
../source/schedule.exe 1 0 1  < ../inputs/input/nt.33 > ../outputs/t1692
echo ">>>>>>>>running test 1693"
../source/schedule.exe 5 1 4  < ../inputs/input/dat615 > ../outputs/t1693
echo ">>>>>>>>running test 1694"
../source/schedule.exe 5 3 3  < ../inputs/input/dat610 > ../outputs/t1694
echo ">>>>>>>>running test 1695"
../source/schedule.exe 1 2 1  < ../inputs/input/dat581 > ../outputs/t1695
echo ">>>>>>>>running test 1696"
../source/schedule.exe 1 3 2  < ../inputs/input/dat557 > ../outputs/t1696
echo ">>>>>>>>running test 1697"
../source/schedule.exe 0 5 1  < ../inputs/input/dat317 > ../outputs/t1697
echo ">>>>>>>>running test 1698"
../source/schedule.exe 4 0 1  < ../inputs/input/dat309 > ../outputs/t1698
echo ">>>>>>>>running test 1699"
../source/schedule.exe 5 0 4  < ../inputs/input/dat217 > ../outputs/t1699
echo ">>>>>>>>running test 1700"
../source/schedule.exe 1 2 0  < ../inputs/input/dat185 > ../outputs/t1700
echo ">>>>>>>>running test 1701"
../source/schedule.exe 3 0 2  < ../inputs/input/dat108 > ../outputs/t1701
echo ">>>>>>>>running test 1702"
../source/schedule.exe 4 1 0  < ../inputs/input/dat054 > ../outputs/t1702
echo ">>>>>>>>running test 1703"
../source/schedule.exe 1 0 2  < ../inputs/input/dat050 > ../outputs/t1703
echo ">>>>>>>>running test 1704"
../source/schedule.exe 5 1 1  < ../inputs/input/dat036 > ../outputs/t1704
echo ">>>>>>>>running test 1705"
../source/schedule.exe 2 0 1  < ../inputs/input/dat581 > ../outputs/t1705
echo ">>>>>>>>running test 1706"
../source/schedule.exe 1 4 2  < ../inputs/input/dat557 > ../outputs/t1706
echo ">>>>>>>>running test 1707"
../source/schedule.exe 0 3 0  < ../inputs/input/dat317 > ../outputs/t1707
echo ">>>>>>>>running test 1708"
../source/schedule.exe 4 1 0  < ../inputs/input/dat309 > ../outputs/t1708
echo ">>>>>>>>running test 1709"
../source/schedule.exe 5 4 4  < ../inputs/input/dat217 > ../outputs/t1709
echo ">>>>>>>>running test 1710"
../source/schedule.exe 5 0 2  < ../inputs/input/dat185 > ../outputs/t1710
echo ">>>>>>>>running test 1711"
../source/schedule.exe 3 4 2  < ../inputs/input/dat108 > ../outputs/t1711
echo ">>>>>>>>running test 1712"
../source/schedule.exe 4 1 1  < ../inputs/input/dat054 > ../outputs/t1712
echo ">>>>>>>>running test 1713"
../source/schedule.exe 1 1 0  < ../inputs/input/dat050 > ../outputs/t1713
echo ">>>>>>>>running test 1714"
../source/schedule.exe 5 0 1  < ../inputs/input/dat036 > ../outputs/t1714
echo ">>>>>>>>running test 1715"
../source/schedule.exe 0 0 0  < ../inputs/input/nt.1 > ../outputs/t1715
echo ">>>>>>>>running test 1716"
../source/schedule.exe 0 0 0  < ../inputs/input/nt.2 > ../outputs/t1716
echo ">>>>>>>>running test 1717"
../source/schedule.exe 0 0 0  < ../inputs/input/nt.3 > ../outputs/t1717
echo ">>>>>>>>running test 1718"
../source/schedule.exe 0 0 0  < ../inputs/input/nt.4 > ../outputs/t1718
echo ">>>>>>>>running test 1719"
../source/schedule.exe 0 0 0  < ../inputs/input/nt.5 > ../outputs/t1719
echo ">>>>>>>>running test 1720"
../source/schedule.exe 0 0 0  < ../inputs/input/nt.6 > ../outputs/t1720
echo ">>>>>>>>running test 1721"
../source/schedule.exe 0 0 0  < ../inputs/input/nt.7 > ../outputs/t1721
echo ">>>>>>>>running test 1722"
../source/schedule.exe 0 0 0  < ../inputs/input/nt.8 > ../outputs/t1722
echo ">>>>>>>>running test 1723"
../source/schedule.exe 0 0 0  < ../inputs/input/nt.9 > ../outputs/t1723
echo ">>>>>>>>running test 1724"
../source/schedule.exe 0 0 0  < ../inputs/input/nt.10 > ../outputs/t1724
echo ">>>>>>>>running test 1725"
../source/schedule.exe 0 0 0  < ../inputs/input/nt.11 > ../outputs/t1725
echo ">>>>>>>>running test 1726"
../source/schedule.exe 0 0 0  < ../inputs/input/nt.12 > ../outputs/t1726
echo ">>>>>>>>running test 1727"
../source/schedule.exe 0 0 0  < ../inputs/input/nt.13 > ../outputs/t1727
echo ">>>>>>>>running test 1728"
../source/schedule.exe 0 0 0  < ../inputs/input/nt.14 > ../outputs/t1728
echo ">>>>>>>>running test 1729"
../source/schedule.exe 0 0 0  < ../inputs/input/nt.15 > ../outputs/t1729
echo ">>>>>>>>running test 1730"
../source/schedule.exe 0 0 0  < ../inputs/input/nt.16 > ../outputs/t1730
echo ">>>>>>>>running test 1731"
../source/schedule.exe 0 0 0  < ../inputs/input/nt.17 > ../outputs/t1731
echo ">>>>>>>>running test 1732"
../source/schedule.exe 0 0 0  < ../inputs/input/nt.18 > ../outputs/t1732
echo ">>>>>>>>running test 1733"
../source/schedule.exe 0 0 0  < ../inputs/input/nt.19 > ../outputs/t1733
echo ">>>>>>>>running test 1734"
../source/schedule.exe 0 0 0  < ../inputs/input/nt.20 > ../outputs/t1734
echo ">>>>>>>>running test 1735"
../source/schedule.exe 0 0 0  < ../inputs/input/nt.21 > ../outputs/t1735
echo ">>>>>>>>running test 1736"
../source/schedule.exe 0 0 0  < ../inputs/input/nt.22 > ../outputs/t1736
echo ">>>>>>>>running test 1737"
../source/schedule.exe 0 0 0  < ../inputs/input/nt.23 > ../outputs/t1737
echo ">>>>>>>>running test 1738"
../source/schedule.exe 0 0 0  < ../inputs/input/nt.24 > ../outputs/t1738
echo ">>>>>>>>running test 1739"
../source/schedule.exe 0 0 0  < ../inputs/input/nt.25 > ../outputs/t1739
echo ">>>>>>>>running test 1740"
../source/schedule.exe 0 0 0  < ../inputs/input/nt.26 > ../outputs/t1740
echo ">>>>>>>>running test 1741"
../source/schedule.exe 0 0 0  < ../inputs/input/nt.27 > ../outputs/t1741
echo ">>>>>>>>running test 1742"
../source/schedule.exe 0 0 0  < ../inputs/input/nt.28 > ../outputs/t1742
echo ">>>>>>>>running test 1743"
../source/schedule.exe 0 0 0  < ../inputs/input/nt.29 > ../outputs/t1743
echo ">>>>>>>>running test 1744"
../source/schedule.exe 0 0 0  < ../inputs/input/nt.30 > ../outputs/t1744
echo ">>>>>>>>running test 1745"
../source/schedule.exe 5 0 4  < ../inputs/input/dat615 > ../outputs/t1745
echo ">>>>>>>>running test 1746"
../source/schedule.exe 5 3 3  < ../inputs/input/dat610 > ../outputs/t1746
echo ">>>>>>>>running test 1747"
../source/schedule.exe 0 2 1  < ../inputs/input/dat581 > ../outputs/t1747
echo ">>>>>>>>running test 1748"
../source/schedule.exe 0 3 2  < ../inputs/input/dat557 > ../outputs/t1748
echo ">>>>>>>>running test 1749"
../source/schedule.exe 0 3 1  < ../inputs/input/dat317 > ../outputs/t1749
echo ">>>>>>>>running test 1750"
../source/schedule.exe 4 2 1  < ../inputs/input/dat309 > ../outputs/t1750
echo ">>>>>>>>running test 1751"
../source/schedule.exe 5 1 4  < ../inputs/input/dat217 > ../outputs/t1751
echo ">>>>>>>>running test 1752"
../source/schedule.exe 1 0 0  < ../inputs/input/dat185 > ../outputs/t1752
echo ">>>>>>>>running test 1753"
../source/schedule.exe 1 0 2  < ../inputs/input/dat108 > ../outputs/t1753
echo ">>>>>>>>running test 1754"
../source/schedule.exe 0 1 0  < ../inputs/input/dat054 > ../outputs/t1754
echo ">>>>>>>>running test 1755"
../source/schedule.exe 1 1 2  < ../inputs/input/dat050 > ../outputs/t1755
echo ">>>>>>>>running test 1756"
../source/schedule.exe 5 1 0  < ../inputs/input/dat036 > ../outputs/t1756
echo ">>>>>>>>running test 1757"
../source/schedule.exe 5 0 1  < ../inputs/input/dat581 > ../outputs/t1757
echo ">>>>>>>>running test 1758"
../source/schedule.exe 1 2 2  < ../inputs/input/dat557 > ../outputs/t1758
echo ">>>>>>>>running test 1759"
../source/schedule.exe 0 1 0  < ../inputs/input/dat317 > ../outputs/t1759
echo ">>>>>>>>running test 1760"
../source/schedule.exe 4 1 3  < ../inputs/input/dat309 > ../outputs/t1760
echo ">>>>>>>>running test 1761"
../source/schedule.exe 5 0 4  < ../inputs/input/dat217 > ../outputs/t1761
echo ">>>>>>>>running test 1762"
../source/schedule.exe 5 0 1  < ../inputs/input/dat185 > ../outputs/t1762
echo ">>>>>>>>running test 1763"
../source/schedule.exe 2 4 2  < ../inputs/input/dat108 > ../outputs/t1763
echo ">>>>>>>>running test 1764"
../source/schedule.exe 4 0 1  < ../inputs/input/dat054 > ../outputs/t1764
echo ">>>>>>>>running test 1765"
../source/schedule.exe 1 0 0  < ../inputs/input/dat050 > ../outputs/t1765
echo ">>>>>>>>running test 1766"
../source/schedule.exe 5 4 1  < ../inputs/input/dat036 > ../outputs/t1766
echo ">>>>>>>>running test 1767"
../source/schedule.exe 7 1 9  < ../inputs/input/add.327 > ../outputs/t1767
echo ">>>>>>>>running test 1768"
../source/schedule.exe 7 1 4  < ../inputs/input/add.340 > ../outputs/t1768
echo ">>>>>>>>running test 1769"
../source/schedule.exe 3 5 9  < ../inputs/input/add.316 > ../outputs/t1769
echo ">>>>>>>>running test 1770"
../source/schedule.exe 9 7 2  < ../inputs/input/add.344 > ../outputs/t1770
echo ">>>>>>>>running test 1771"
../source/schedule.exe 0 2 6  < ../inputs/input/add.333 > ../outputs/t1771
echo ">>>>>>>>running test 1772"
../source/schedule.exe 3 2 0  < ../inputs/input/add.325 > ../outputs/t1772
echo ">>>>>>>>running test 1773"
../source/schedule.exe 10 5 0  < ../inputs/input/add.312 > ../outputs/t1773
echo ">>>>>>>>running test 1774"
../source/schedule.exe 7 4 10  < ../inputs/input/add.350 > ../outputs/t1774
echo ">>>>>>>>running test 1775"
../source/schedule.exe 2 2 3  < ../inputs/input/add.319 > ../outputs/t1775
echo ">>>>>>>>running test 1776"
../source/schedule.exe 8 5 3  < ../inputs/input/add.309 > ../outputs/t1776
echo ">>>>>>>>running test 1777"
../source/schedule.exe 9 5 1  < ../inputs/input/add.312 > ../outputs/t1777
echo ">>>>>>>>running test 1778"
../source/schedule.exe 0 10 1  < ../inputs/input/add.305 > ../outputs/t1778
echo ">>>>>>>>running test 1779"
../source/schedule.exe 4 1 0  < ../inputs/input/add.308 > ../outputs/t1779
echo ">>>>>>>>running test 1780"
../source/schedule.exe 10 0 4  < ../inputs/input/add.306 > ../outputs/t1780
echo ">>>>>>>>running test 1781"
../source/schedule.exe 10 3 0  < ../inputs/input/add.310 > ../outputs/t1781
echo ">>>>>>>>running test 1782"
../source/schedule.exe 9 5 5  < ../inputs/input/add.336 > ../outputs/t1782
echo ">>>>>>>>running test 1783"
../source/schedule.exe 0 9 7  < ../inputs/input/add.317 > ../outputs/t1783
echo ">>>>>>>>running test 1784"
../source/schedule.exe 2 7 3  < ../inputs/input/add.337 > ../outputs/t1784
echo ">>>>>>>>running test 1785"
../source/schedule.exe 7 10 9  < ../inputs/input/add.333 > ../outputs/t1785
echo ">>>>>>>>running test 1786"
../source/schedule.exe 5 9 3  < ../inputs/input/add.320 > ../outputs/t1786
echo ">>>>>>>>running test 1787"
../source/schedule.exe 1 8 3  < ../inputs/input/add.319 > ../outputs/t1787
echo ">>>>>>>>running test 1788"
../source/schedule.exe 5 10 9  < ../inputs/input/add.341 > ../outputs/t1788
echo ">>>>>>>>running test 1789"
../source/schedule.exe 9 9 0  < ../inputs/input/add.341 > ../outputs/t1789
echo ">>>>>>>>running test 1790"
../source/schedule.exe 4 4 2  < ../inputs/input/add.312 > ../outputs/t1790
echo ">>>>>>>>running test 1791"
../source/schedule.exe 9 10 7  < ../inputs/input/add.345 > ../outputs/t1791
echo ">>>>>>>>running test 1792"
../source/schedule.exe 2 9 7  < ../inputs/input/add.341 > ../outputs/t1792
echo ">>>>>>>>running test 1793"
../source/schedule.exe 2 1 5  < ../inputs/input/add.343 > ../outputs/t1793
echo ">>>>>>>>running test 1794"
../source/schedule.exe 9 3 2  < ../inputs/input/add.334 > ../outputs/t1794
echo ">>>>>>>>running test 1795"
../source/schedule.exe 6 9 1  < ../inputs/input/add.308 > ../outputs/t1795
echo ">>>>>>>>running test 1796"
../source/schedule.exe 6 4 9  < ../inputs/input/add.319 > ../outputs/t1796
echo ">>>>>>>>running test 1797"
../source/schedule.exe 10 9 4  < ../inputs/input/add.349 > ../outputs/t1797
echo ">>>>>>>>running test 1798"
../source/schedule.exe 1 3 4  < ../inputs/input/add.310 > ../outputs/t1798
echo ">>>>>>>>running test 1799"
../source/schedule.exe 0 7 0  < ../inputs/input/add.334 > ../outputs/t1799
echo ">>>>>>>>running test 1800"
../source/schedule.exe 3 2 4  < ../inputs/input/add.343 > ../outputs/t1800
echo ">>>>>>>>running test 1801"
../source/schedule.exe 6 2 0  < ../inputs/input/add.347 > ../outputs/t1801
echo ">>>>>>>>running test 1802"
../source/schedule.exe 7 6 9  < ../inputs/input/add.320 > ../outputs/t1802
echo ">>>>>>>>running test 1803"
../source/schedule.exe 0 7 6  < ../inputs/input/add.334 > ../outputs/t1803
echo ">>>>>>>>running test 1804"
../source/schedule.exe 10 0 0  < ../inputs/input/add.300 > ../outputs/t1804
echo ">>>>>>>>running test 1805"
../source/schedule.exe 6 1 8  < ../inputs/input/add.350 > ../outputs/t1805
echo ">>>>>>>>running test 1806"
../source/schedule.exe 3 10 6  < ../inputs/input/add.325 > ../outputs/t1806
echo ">>>>>>>>running test 1807"
../source/schedule.exe 10 7 5  < ../inputs/input/add.332 > ../outputs/t1807
echo ">>>>>>>>running test 1808"
../source/schedule.exe 7 10 10  < ../inputs/input/add.325 > ../outputs/t1808
echo ">>>>>>>>running test 1809"
../source/schedule.exe 7 10 4  < ../inputs/input/add.313 > ../outputs/t1809
echo ">>>>>>>>running test 1810"
../source/schedule.exe 10 4 3  < ../inputs/input/add.302 > ../outputs/t1810
echo ">>>>>>>>running test 1811"
../source/schedule.exe 10 6 1  < ../inputs/input/add.335 > ../outputs/t1811
echo ">>>>>>>>running test 1812"
../source/schedule.exe 0 3 3  < ../inputs/input/add.304 > ../outputs/t1812
echo ">>>>>>>>running test 1813"
../source/schedule.exe 2 10 4  < ../inputs/input/add.312 > ../outputs/t1813
echo ">>>>>>>>running test 1814"
../source/schedule.exe 9 4 2  < ../inputs/input/add.319 > ../outputs/t1814
echo ">>>>>>>>running test 1815"
../source/schedule.exe 7 10 5  < ../inputs/input/add.322 > ../outputs/t1815
echo ">>>>>>>>running test 1816"
../source/schedule.exe 4 3 4  < ../inputs/input/add.343 > ../outputs/t1816
echo ">>>>>>>>running test 1817"
../source/schedule.exe 5 6 9  < ../inputs/input/add.335 > ../outputs/t1817
echo ">>>>>>>>running test 1818"
../source/schedule.exe 3 5 0  < ../inputs/input/add.313 > ../outputs/t1818
echo ">>>>>>>>running test 1819"
../source/schedule.exe 5 3 9  < ../inputs/input/add.302 > ../outputs/t1819
echo ">>>>>>>>running test 1820"
../source/schedule.exe 2 2 4  < ../inputs/input/add.303 > ../outputs/t1820
echo ">>>>>>>>running test 1821"
../source/schedule.exe 4 4 3  < ../inputs/input/add.324 > ../outputs/t1821
echo ">>>>>>>>running test 1822"
../source/schedule.exe 0 1 9  < ../inputs/input/add.333 > ../outputs/t1822
echo ">>>>>>>>running test 1823"
../source/schedule.exe 2 0 10  < ../inputs/input/add.301 > ../outputs/t1823
echo ">>>>>>>>running test 1824"
../source/schedule.exe 0 0 6  < ../inputs/input/add.349 > ../outputs/t1824
echo ">>>>>>>>running test 1825"
../source/schedule.exe 6 1 3  < ../inputs/input/add.329 > ../outputs/t1825
echo ">>>>>>>>running test 1826"
../source/schedule.exe 10 4 1  < ../inputs/input/add.321 > ../outputs/t1826
echo ">>>>>>>>running test 1827"
../source/schedule.exe 6 10 9  < ../inputs/input/add.309 > ../outputs/t1827
echo ">>>>>>>>running test 1828"
../source/schedule.exe 1 0 2  < ../inputs/input/add.327 > ../outputs/t1828
echo ">>>>>>>>running test 1829"
../source/schedule.exe 7 1 2  < ../inputs/input/add.301 > ../outputs/t1829
echo ">>>>>>>>running test 1830"
../source/schedule.exe 0 3 1  < ../inputs/input/add.313 > ../outputs/t1830
echo ">>>>>>>>running test 1831"
../source/schedule.exe 6 7 4  < ../inputs/input/add.324 > ../outputs/t1831
echo ">>>>>>>>running test 1832"
../source/schedule.exe 7 10 2  < ../inputs/input/add.302 > ../outputs/t1832
echo ">>>>>>>>running test 1833"
../source/schedule.exe 3 9 2  < ../inputs/input/add.317 > ../outputs/t1833
echo ">>>>>>>>running test 1834"
../source/schedule.exe 2 3 8  < ../inputs/input/add.305 > ../outputs/t1834
echo ">>>>>>>>running test 1835"
../source/schedule.exe 8 10 9  < ../inputs/input/add.339 > ../outputs/t1835
echo ">>>>>>>>running test 1836"
../source/schedule.exe 2 10 2  < ../inputs/input/add.304 > ../outputs/t1836
echo ">>>>>>>>running test 1837"
../source/schedule.exe 1 9 5  < ../inputs/input/add.348 > ../outputs/t1837
echo ">>>>>>>>running test 1838"
../source/schedule.exe 2 3 0  < ../inputs/input/add.344 > ../outputs/t1838
echo ">>>>>>>>running test 1839"
../source/schedule.exe 3 8 6  < ../inputs/input/add.341 > ../outputs/t1839
echo ">>>>>>>>running test 1840"
../source/schedule.exe 1 1 9  < ../inputs/input/add.307 > ../outputs/t1840
echo ">>>>>>>>running test 1841"
../source/schedule.exe 9 10 10  < ../inputs/input/add.347 > ../outputs/t1841
echo ">>>>>>>>running test 1842"
../source/schedule.exe 0 7 5  < ../inputs/input/add.316 > ../outputs/t1842
echo ">>>>>>>>running test 1843"
../source/schedule.exe 8 7 1  < ../inputs/input/add.336 > ../outputs/t1843
echo ">>>>>>>>running test 1844"
../source/schedule.exe 4 2 6  < ../inputs/input/add.326 > ../outputs/t1844
echo ">>>>>>>>running test 1845"
../source/schedule.exe 9 4 6  < ../inputs/input/add.304 > ../outputs/t1845
echo ">>>>>>>>running test 1846"
../source/schedule.exe 7 6 8  < ../inputs/input/add.314 > ../outputs/t1846
echo ">>>>>>>>running test 1847"
../source/schedule.exe 3 9 7  < ../inputs/input/add.350 > ../outputs/t1847
echo ">>>>>>>>running test 1848"
../source/schedule.exe 1 1 10  < ../inputs/input/add.327 > ../outputs/t1848
echo ">>>>>>>>running test 1849"
../source/schedule.exe 9 8 4  < ../inputs/input/add.343 > ../outputs/t1849
echo ">>>>>>>>running test 1850"
../source/schedule.exe 10 9 0  < ../inputs/input/add.305 > ../outputs/t1850
echo ">>>>>>>>running test 1851"
../source/schedule.exe 0 2 2  < ../inputs/input/add.305 > ../outputs/t1851
echo ">>>>>>>>running test 1852"
../source/schedule.exe 6 10 7  < ../inputs/input/add.331 > ../outputs/t1852
echo ">>>>>>>>running test 1853"
../source/schedule.exe 1 5 10  < ../inputs/input/add.306 > ../outputs/t1853
echo ">>>>>>>>running test 1854"
../source/schedule.exe 4 3 8  < ../inputs/input/add.330 > ../outputs/t1854
echo ">>>>>>>>running test 1855"
../source/schedule.exe 2 1 9  < ../inputs/input/add.344 > ../outputs/t1855
echo ">>>>>>>>running test 1856"
../source/schedule.exe 2 7 0  < ../inputs/input/add.308 > ../outputs/t1856
echo ">>>>>>>>running test 1857"
../source/schedule.exe 5 0 6  < ../inputs/input/add.303 > ../outputs/t1857
echo ">>>>>>>>running test 1858"
../source/schedule.exe 1 10 10  < ../inputs/input/add.320 > ../outputs/t1858
echo ">>>>>>>>running test 1859"
../source/schedule.exe 8 0 3  < ../inputs/input/add.341 > ../outputs/t1859
echo ">>>>>>>>running test 1860"
../source/schedule.exe 6 8 8  < ../inputs/input/add.330 > ../outputs/t1860
echo ">>>>>>>>running test 1861"
../source/schedule.exe 8 0 7  < ../inputs/input/add.316 > ../outputs/t1861
echo ">>>>>>>>running test 1862"
../source/schedule.exe 2 4 1  < ../inputs/input/add.306 > ../outputs/t1862
echo ">>>>>>>>running test 1863"
../source/schedule.exe 2 7 3  < ../inputs/input/add.314 > ../outputs/t1863
echo ">>>>>>>>running test 1864"
../source/schedule.exe 8 4 5  < ../inputs/input/add.343 > ../outputs/t1864
echo ">>>>>>>>running test 1865"
../source/schedule.exe 10 7 3  < ../inputs/input/add.323 > ../outputs/t1865
echo ">>>>>>>>running test 1866"
../source/schedule.exe 0 6 3  < ../inputs/input/add.315 > ../outputs/t1866
echo ">>>>>>>>running test 1867"
../source/schedule.exe 1  6  5   < ../inputs/input/lu1 > ../outputs/t1867
echo ">>>>>>>>running test 1868"
../source/schedule.exe 2  5  10   < ../inputs/input/lu2 > ../outputs/t1868
echo ">>>>>>>>running test 1869"
../source/schedule.exe 3  6  7   < ../inputs/input/lu3 > ../outputs/t1869
echo ">>>>>>>>running test 1870"
../source/schedule.exe 8  9  2   < ../inputs/input/lu4 > ../outputs/t1870
echo ">>>>>>>>running test 1871"
../source/schedule.exe 7  2  9   < ../inputs/input/lu5 > ../outputs/t1871
echo ">>>>>>>>running test 1872"
../source/schedule.exe 2  7  10   < ../inputs/input/lu6 > ../outputs/t1872
echo ">>>>>>>>running test 1873"
../source/schedule.exe 3  10  3   < ../inputs/input/lu7 > ../outputs/t1873
echo ">>>>>>>>running test 1874"
../source/schedule.exe 6  3  2   < ../inputs/input/lu8 > ../outputs/t1874
echo ">>>>>>>>running test 1875"
../source/schedule.exe 9  6  5   < ../inputs/input/lu9 > ../outputs/t1875
echo ">>>>>>>>running test 1876"
../source/schedule.exe 2  7  6   < ../inputs/input/lu10 > ../outputs/t1876
echo ">>>>>>>>running test 1877"
../source/schedule.exe 3  2  3   < ../inputs/input/lu11 > ../outputs/t1877
echo ">>>>>>>>running test 1878"
../source/schedule.exe 6  1  6   < ../inputs/input/lu12 > ../outputs/t1878
echo ">>>>>>>>running test 1879"
../source/schedule.exe 3  10  5   < ../inputs/input/lu13 > ../outputs/t1879
echo ">>>>>>>>running test 1880"
../source/schedule.exe 6  7  10   < ../inputs/input/lu14 > ../outputs/t1880
echo ">>>>>>>>running test 1881"
../source/schedule.exe 5  4  5   < ../inputs/input/lu15 > ../outputs/t1881
echo ">>>>>>>>running test 1882"
../source/schedule.exe 2  3  6   < ../inputs/input/lu16 > ../outputs/t1882
echo ">>>>>>>>running test 1883"
../source/schedule.exe 5  8  3   < ../inputs/input/lu17 > ../outputs/t1883
echo ">>>>>>>>running test 1884"
../source/schedule.exe 8  7  8   < ../inputs/input/lu18 > ../outputs/t1884
echo ">>>>>>>>running test 1885"
../source/schedule.exe 9  6  3   < ../inputs/input/lu19 > ../outputs/t1885
echo ">>>>>>>>running test 1886"
../source/schedule.exe 4  1  6   < ../inputs/input/lu20 > ../outputs/t1886
echo ">>>>>>>>running test 1887"
../source/schedule.exe 5  6  7   < ../inputs/input/lu21 > ../outputs/t1887
echo ">>>>>>>>running test 1888"
../source/schedule.exe 4  3  10   < ../inputs/input/lu22 > ../outputs/t1888
echo ">>>>>>>>running test 1889"
../source/schedule.exe 7  2  5   < ../inputs/input/lu23 > ../outputs/t1889
echo ">>>>>>>>running test 1890"
../source/schedule.exe 4  7  2   < ../inputs/input/lu24 > ../outputs/t1890
echo ">>>>>>>>running test 1891"
../source/schedule.exe 9  10  5   < ../inputs/input/lu25 > ../outputs/t1891
echo ">>>>>>>>running test 1892"
../source/schedule.exe 4  1  2   < ../inputs/input/lu26 > ../outputs/t1892
echo ">>>>>>>>running test 1893"
../source/schedule.exe 9  10  9   < ../inputs/input/lu27 > ../outputs/t1893
echo ">>>>>>>>running test 1894"
../source/schedule.exe 4  7  2   < ../inputs/input/lu28 > ../outputs/t1894
echo ">>>>>>>>running test 1895"
../source/schedule.exe 3  8  3   < ../inputs/input/lu29 > ../outputs/t1895
echo ">>>>>>>>running test 1896"
../source/schedule.exe 6  3  6   < ../inputs/input/lu30 > ../outputs/t1896
echo ">>>>>>>>running test 1897"
../source/schedule.exe 5  4  9   < ../inputs/input/lu31 > ../outputs/t1897
echo ">>>>>>>>running test 1898"
../source/schedule.exe 6  3  6   < ../inputs/input/lu32 > ../outputs/t1898
echo ">>>>>>>>running test 1899"
../source/schedule.exe 9  10  7   < ../inputs/input/lu33 > ../outputs/t1899
echo ">>>>>>>>running test 1900"
../source/schedule.exe 6  9  6   < ../inputs/input/lu34 > ../outputs/t1900
echo ">>>>>>>>running test 1901"
../source/schedule.exe 7  10  3   < ../inputs/input/lu35 > ../outputs/t1901
echo ">>>>>>>>running test 1902"
../source/schedule.exe 2  7  10   < ../inputs/input/lu36 > ../outputs/t1902
echo ">>>>>>>>running test 1903"
../source/schedule.exe 1  8  3   < ../inputs/input/lu37 > ../outputs/t1903
echo ">>>>>>>>running test 1904"
../source/schedule.exe 6  9  6   < ../inputs/input/lu38 > ../outputs/t1904
echo ">>>>>>>>running test 1905"
../source/schedule.exe 1  8  3   < ../inputs/input/lu39 > ../outputs/t1905
echo ">>>>>>>>running test 1906"
../source/schedule.exe 10  1  10   < ../inputs/input/lu40 > ../outputs/t1906
echo ">>>>>>>>running test 1907"
../source/schedule.exe 7  6  1   < ../inputs/input/lu41 > ../outputs/t1907
echo ">>>>>>>>running test 1908"
../source/schedule.exe 8  9  8   < ../inputs/input/lu42 > ../outputs/t1908
echo ">>>>>>>>running test 1909"
../source/schedule.exe 7  4  1   < ../inputs/input/lu43 > ../outputs/t1909
echo ">>>>>>>>running test 1910"
../source/schedule.exe 6  3  2   < ../inputs/input/lu44 > ../outputs/t1910
echo ">>>>>>>>running test 1911"
../source/schedule.exe 1  8  3   < ../inputs/input/lu45 > ../outputs/t1911
echo ">>>>>>>>running test 1912"
../source/schedule.exe 8  9  2   < ../inputs/input/lu46 > ../outputs/t1912
echo ">>>>>>>>running test 1913"
../source/schedule.exe 1  10  3   < ../inputs/input/lu47 > ../outputs/t1913
echo ">>>>>>>>running test 1914"
../source/schedule.exe 4  7  4   < ../inputs/input/lu48 > ../outputs/t1914
echo ">>>>>>>>running test 1915"
../source/schedule.exe 9  4  9   < ../inputs/input/lu49 > ../outputs/t1915
echo ">>>>>>>>running test 1916"
../source/schedule.exe 2  3  4   < ../inputs/input/lu50 > ../outputs/t1916
echo ">>>>>>>>running test 1917"
../source/schedule.exe 5  2  5   < ../inputs/input/lu51 > ../outputs/t1917
echo ">>>>>>>>running test 1918"
../source/schedule.exe 4  1  4   < ../inputs/input/lu52 > ../outputs/t1918
echo ">>>>>>>>running test 1919"
../source/schedule.exe 9  2  1   < ../inputs/input/lu53 > ../outputs/t1919
echo ">>>>>>>>running test 1920"
../source/schedule.exe 2  1  10   < ../inputs/input/lu54 > ../outputs/t1920
echo ">>>>>>>>running test 1921"
../source/schedule.exe 1  6  3   < ../inputs/input/lu55 > ../outputs/t1921
echo ">>>>>>>>running test 1922"
../source/schedule.exe 10  9  8   < ../inputs/input/lu56 > ../outputs/t1922
echo ">>>>>>>>running test 1923"
../source/schedule.exe 1  6  1   < ../inputs/input/lu57 > ../outputs/t1923
echo ">>>>>>>>running test 1924"
../source/schedule.exe 6  7  6   < ../inputs/input/lu58 > ../outputs/t1924
echo ">>>>>>>>running test 1925"
../source/schedule.exe 9  6  3   < ../inputs/input/lu59 > ../outputs/t1925
echo ">>>>>>>>running test 1926"
../source/schedule.exe 4  9  8   < ../inputs/input/lu60 > ../outputs/t1926
echo ">>>>>>>>running test 1927"
../source/schedule.exe 9  4  5   < ../inputs/input/lu61 > ../outputs/t1927
echo ">>>>>>>>running test 1928"
../source/schedule.exe 4  5  6   < ../inputs/input/lu62 > ../outputs/t1928
echo ">>>>>>>>running test 1929"
../source/schedule.exe 9  4  3   < ../inputs/input/lu63 > ../outputs/t1929
echo ">>>>>>>>running test 1930"
../source/schedule.exe 8  9  10   < ../inputs/input/lu64 > ../outputs/t1930
echo ">>>>>>>>running test 1931"
../source/schedule.exe 1  6  1   < ../inputs/input/lu65 > ../outputs/t1931
echo ">>>>>>>>running test 1932"
../source/schedule.exe 2  7  2   < ../inputs/input/lu66 > ../outputs/t1932
echo ">>>>>>>>running test 1933"
../source/schedule.exe 7  6  1   < ../inputs/input/lu67 > ../outputs/t1933
echo ">>>>>>>>running test 1934"
../source/schedule.exe 6  5  6   < ../inputs/input/lu68 > ../outputs/t1934
echo ">>>>>>>>running test 1935"
../source/schedule.exe 1  6  5   < ../inputs/input/lu69 > ../outputs/t1935
echo ">>>>>>>>running test 1936"
../source/schedule.exe 6  1  8   < ../inputs/input/lu70 > ../outputs/t1936
echo ">>>>>>>>running test 1937"
../source/schedule.exe 5  4  9   < ../inputs/input/lu71 > ../outputs/t1937
echo ">>>>>>>>running test 1938"
../source/schedule.exe 2  5  6   < ../inputs/input/lu72 > ../outputs/t1938
echo ">>>>>>>>running test 1939"
../source/schedule.exe 3  6  7   < ../inputs/input/lu73 > ../outputs/t1939
echo ">>>>>>>>running test 1940"
../source/schedule.exe 8  1  10   < ../inputs/input/lu74 > ../outputs/t1940
echo ">>>>>>>>running test 1941"
../source/schedule.exe 5  10  3   < ../inputs/input/lu75 > ../outputs/t1941
echo ">>>>>>>>running test 1942"
../source/schedule.exe 4  7  10   < ../inputs/input/lu76 > ../outputs/t1942
echo ">>>>>>>>running test 1943"
../source/schedule.exe 9  2  7   < ../inputs/input/lu77 > ../outputs/t1943
echo ">>>>>>>>running test 1944"
../source/schedule.exe 4  1  10   < ../inputs/input/lu78 > ../outputs/t1944
echo ">>>>>>>>running test 1945"
../source/schedule.exe 5  2  3   < ../inputs/input/lu79 > ../outputs/t1945
echo ">>>>>>>>running test 1946"
../source/schedule.exe 4  5  6   < ../inputs/input/lu80 > ../outputs/t1946
echo ">>>>>>>>running test 1947"
../source/schedule.exe 3  2  3   < ../inputs/input/lu81 > ../outputs/t1947
echo ">>>>>>>>running test 1948"
../source/schedule.exe 8  3  2   < ../inputs/input/lu82 > ../outputs/t1948
echo ">>>>>>>>running test 1949"
../source/schedule.exe 3  6  5   < ../inputs/input/lu83 > ../outputs/t1949
echo ">>>>>>>>running test 1950"
../source/schedule.exe 6  7  8   < ../inputs/input/lu84 > ../outputs/t1950
echo ">>>>>>>>running test 1951"
../source/schedule.exe 1  6  9   < ../inputs/input/lu85 > ../outputs/t1951
echo ">>>>>>>>running test 1952"
../source/schedule.exe 4  1  6   < ../inputs/input/lu86 > ../outputs/t1952
echo ">>>>>>>>running test 1953"
../source/schedule.exe 1  8  3   < ../inputs/input/lu87 > ../outputs/t1953
echo ">>>>>>>>running test 1954"
../source/schedule.exe 6  3  4   < ../inputs/input/lu88 > ../outputs/t1954
echo ">>>>>>>>running test 1955"
../source/schedule.exe 5  10  7   < ../inputs/input/lu89 > ../outputs/t1955
echo ">>>>>>>>running test 1956"
../source/schedule.exe 6  9  2   < ../inputs/input/lu90 > ../outputs/t1956
echo ">>>>>>>>running test 1957"
../source/schedule.exe 5  10  1   < ../inputs/input/lu91 > ../outputs/t1957
echo ">>>>>>>>running test 1958"
../source/schedule.exe 4  7  8   < ../inputs/input/lu92 > ../outputs/t1958
echo ">>>>>>>>running test 1959"
../source/schedule.exe 5  2  5   < ../inputs/input/lu93 > ../outputs/t1959
echo ">>>>>>>>running test 1960"
../source/schedule.exe 4  7  8   < ../inputs/input/lu94 > ../outputs/t1960
echo ">>>>>>>>running test 1961"
../source/schedule.exe 3  4  9   < ../inputs/input/lu95 > ../outputs/t1961
echo ">>>>>>>>running test 1962"
../source/schedule.exe 8  5  4   < ../inputs/input/lu96 > ../outputs/t1962
echo ">>>>>>>>running test 1963"
../source/schedule.exe 9  10  5   < ../inputs/input/lu97 > ../outputs/t1963
echo ">>>>>>>>running test 1964"
../source/schedule.exe 4  9  8   < ../inputs/input/lu98 > ../outputs/t1964
echo ">>>>>>>>running test 1965"
../source/schedule.exe 5  2  7   < ../inputs/input/lu99 > ../outputs/t1965
echo ">>>>>>>>running test 1966"
../source/schedule.exe 4  5  2   < ../inputs/input/lu100 > ../outputs/t1966
echo ">>>>>>>>running test 1967"
../source/schedule.exe 5  6  1   < ../inputs/input/lu101 > ../outputs/t1967
echo ">>>>>>>>running test 1968"
../source/schedule.exe 4  7  8   < ../inputs/input/lu102 > ../outputs/t1968
echo ">>>>>>>>running test 1969"
../source/schedule.exe 1  6  1   < ../inputs/input/lu103 > ../outputs/t1969
echo ">>>>>>>>running test 1970"
../source/schedule.exe 2  7  10   < ../inputs/input/lu104 > ../outputs/t1970
echo ">>>>>>>>running test 1971"
../source/schedule.exe 1  10  5   < ../inputs/input/lu105 > ../outputs/t1971
echo ">>>>>>>>running test 1972"
../source/schedule.exe 6  3  8   < ../inputs/input/lu106 > ../outputs/t1972
echo ">>>>>>>>running test 1973"
../source/schedule.exe 5  2  7   < ../inputs/input/lu107 > ../outputs/t1973
echo ">>>>>>>>running test 1974"
../source/schedule.exe 10  1  10   < ../inputs/input/lu108 > ../outputs/t1974
echo ">>>>>>>>running test 1975"
../source/schedule.exe 9  2  3   < ../inputs/input/lu109 > ../outputs/t1975
echo ">>>>>>>>running test 1976"
../source/schedule.exe 6  9  6   < ../inputs/input/lu110 > ../outputs/t1976
echo ">>>>>>>>running test 1977"
../source/schedule.exe 3  2  1   < ../inputs/input/lu111 > ../outputs/t1977
echo ">>>>>>>>running test 1978"
../source/schedule.exe 2  5  6   < ../inputs/input/lu112 > ../outputs/t1978
echo ">>>>>>>>running test 1979"
../source/schedule.exe 3  10  7   < ../inputs/input/lu113 > ../outputs/t1979
echo ">>>>>>>>running test 1980"
../source/schedule.exe 8  5  10   < ../inputs/input/lu114 > ../outputs/t1980
echo ">>>>>>>>running test 1981"
../source/schedule.exe 3  6  9   < ../inputs/input/lu115 > ../outputs/t1981
echo ">>>>>>>>running test 1982"
../source/schedule.exe 10  5  2   < ../inputs/input/lu116 > ../outputs/t1982
echo ">>>>>>>>running test 1983"
../source/schedule.exe 7  8  9   < ../inputs/input/lu117 > ../outputs/t1983
echo ">>>>>>>>running test 1984"
../source/schedule.exe 4  3  2   < ../inputs/input/lu118 > ../outputs/t1984
echo ">>>>>>>>running test 1985"
../source/schedule.exe 9  6  7   < ../inputs/input/lu119 > ../outputs/t1985
echo ">>>>>>>>running test 1986"
../source/schedule.exe 8  7  4   < ../inputs/input/lu120 > ../outputs/t1986
echo ">>>>>>>>running test 1987"
../source/schedule.exe 1  4  5   < ../inputs/input/lu121 > ../outputs/t1987
echo ">>>>>>>>running test 1988"
../source/schedule.exe 4  3  6   < ../inputs/input/lu122 > ../outputs/t1988
echo ">>>>>>>>running test 1989"
../source/schedule.exe 7  4  5   < ../inputs/input/lu123 > ../outputs/t1989
echo ">>>>>>>>running test 1990"
../source/schedule.exe 8  3  2   < ../inputs/input/lu124 > ../outputs/t1990
echo ">>>>>>>>running test 1991"
../source/schedule.exe 9  10  1   < ../inputs/input/lu125 > ../outputs/t1991
echo ">>>>>>>>running test 1992"
../source/schedule.exe 6  3  6   < ../inputs/input/lu126 > ../outputs/t1992
echo ">>>>>>>>running test 1993"
../source/schedule.exe 1  2  3   < ../inputs/input/lu127 > ../outputs/t1993
echo ">>>>>>>>running test 1994"
../source/schedule.exe 6  1  6   < ../inputs/input/lu128 > ../outputs/t1994
echo ">>>>>>>>running test 1995"
../source/schedule.exe 1  2  1   < ../inputs/input/lu129 > ../outputs/t1995
echo ">>>>>>>>running test 1996"
../source/schedule.exe 2  7  8   < ../inputs/input/lu130 > ../outputs/t1996
echo ">>>>>>>>running test 1997"
../source/schedule.exe 9  2  7   < ../inputs/input/lu131 > ../outputs/t1997
echo ">>>>>>>>running test 1998"
../source/schedule.exe 8  5  4   < ../inputs/input/lu132 > ../outputs/t1998
echo ">>>>>>>>running test 1999"
../source/schedule.exe 3  10  7   < ../inputs/input/lu133 > ../outputs/t1999
echo ">>>>>>>>running test 2000"
../source/schedule.exe 2  3  4   < ../inputs/input/lu134 > ../outputs/t2000
echo ">>>>>>>>running test 2001"
../source/schedule.exe 9  4  5   < ../inputs/input/lu135 > ../outputs/t2001
echo ">>>>>>>>running test 2002"
../source/schedule.exe 8  3  4   < ../inputs/input/lu136 > ../outputs/t2002
echo ">>>>>>>>running test 2003"
../source/schedule.exe 3  4  9   < ../inputs/input/lu137 > ../outputs/t2003
echo ">>>>>>>>running test 2004"
../source/schedule.exe 10  9  8   < ../inputs/input/lu138 > ../outputs/t2004
echo ">>>>>>>>running test 2005"
../source/schedule.exe 9  2  7   < ../inputs/input/lu139 > ../outputs/t2005
echo ">>>>>>>>running test 2006"
../source/schedule.exe 8  9  6   < ../inputs/input/lu140 > ../outputs/t2006
echo ">>>>>>>>running test 2007"
../source/schedule.exe 9  8  5   < ../inputs/input/lu141 > ../outputs/t2007
echo ">>>>>>>>running test 2008"
../source/schedule.exe 6  9  10   < ../inputs/input/lu142 > ../outputs/t2008
echo ">>>>>>>>running test 2009"
../source/schedule.exe 3  6  1   < ../inputs/input/lu143 > ../outputs/t2009
echo ">>>>>>>>running test 2010"
../source/schedule.exe 8  1  4   < ../inputs/input/lu144 > ../outputs/t2010
echo ">>>>>>>>running test 2011"
../source/schedule.exe 3  6  1   < ../inputs/input/lu145 > ../outputs/t2011
echo ">>>>>>>>running test 2012"
../source/schedule.exe 2  7  4   < ../inputs/input/lu146 > ../outputs/t2012
echo ">>>>>>>>running test 2013"
../source/schedule.exe 7  2  5   < ../inputs/input/lu147 > ../outputs/t2013
echo ">>>>>>>>running test 2014"
../source/schedule.exe 2  7  4   < ../inputs/input/lu148 > ../outputs/t2014
echo ">>>>>>>>running test 2015"
../source/schedule.exe 1  2  7   < ../inputs/input/lu149 > ../outputs/t2015
echo ">>>>>>>>running test 2016"
../source/schedule.exe 2  7  4   < ../inputs/input/lu150 > ../outputs/t2016
echo ">>>>>>>>running test 2017"
../source/schedule.exe 9  6  9   < ../inputs/input/lu151 > ../outputs/t2017
echo ">>>>>>>>running test 2018"
../source/schedule.exe 4  9  2   < ../inputs/input/lu152 > ../outputs/t2018
echo ">>>>>>>>running test 2019"
../source/schedule.exe 7  2  7   < ../inputs/input/lu153 > ../outputs/t2019
echo ">>>>>>>>running test 2020"
../source/schedule.exe 2  3  6   < ../inputs/input/lu154 > ../outputs/t2020
echo ">>>>>>>>running test 2021"
../source/schedule.exe 3  6  7   < ../inputs/input/lu155 > ../outputs/t2021
echo ">>>>>>>>running test 2022"
../source/schedule.exe 4  7  8   < ../inputs/input/lu156 > ../outputs/t2022
echo ">>>>>>>>running test 2023"
../source/schedule.exe 9  2  1   < ../inputs/input/lu157 > ../outputs/t2023
echo ">>>>>>>>running test 2024"
../source/schedule.exe 6  3  6   < ../inputs/input/lu158 > ../outputs/t2024
echo ">>>>>>>>running test 2025"
../source/schedule.exe 5  4  9   < ../inputs/input/lu159 > ../outputs/t2025
echo ">>>>>>>>running test 2026"
../source/schedule.exe 2  3  2   < ../inputs/input/lu160 > ../outputs/t2026
echo ">>>>>>>>running test 2027"
../source/schedule.exe 7  6  7   < ../inputs/input/lu161 > ../outputs/t2027
echo ">>>>>>>>running test 2028"
../source/schedule.exe 4  3  4   < ../inputs/input/lu162 > ../outputs/t2028
echo ">>>>>>>>running test 2029"
../source/schedule.exe 5  10  9   < ../inputs/input/lu163 > ../outputs/t2029
echo ">>>>>>>>running test 2030"
../source/schedule.exe 10  5  6   < ../inputs/input/lu164 > ../outputs/t2030
echo ">>>>>>>>running test 2031"
../source/schedule.exe 1  6  9   < ../inputs/input/lu165 > ../outputs/t2031
echo ">>>>>>>>running test 2032"
../source/schedule.exe 4  5  8   < ../inputs/input/lu166 > ../outputs/t2032
echo ">>>>>>>>running test 2033"
../source/schedule.exe 5  8  1   < ../inputs/input/lu167 > ../outputs/t2033
echo ">>>>>>>>running test 2034"
../source/schedule.exe 8  7  4   < ../inputs/input/lu168 > ../outputs/t2034
echo ">>>>>>>>running test 2035"
../source/schedule.exe 7  6  3   < ../inputs/input/lu169 > ../outputs/t2035
echo ">>>>>>>>running test 2036"
../source/schedule.exe 8  7  10   < ../inputs/input/lu170 > ../outputs/t2036
echo ">>>>>>>>running test 2037"
../source/schedule.exe 7  2  3   < ../inputs/input/lu171 > ../outputs/t2037
echo ">>>>>>>>running test 2038"
../source/schedule.exe 2  7  8   < ../inputs/input/lu172 > ../outputs/t2038
echo ">>>>>>>>running test 2039"
../source/schedule.exe 5  2  7   < ../inputs/input/lu173 > ../outputs/t2039
echo ">>>>>>>>running test 2040"
../source/schedule.exe 8  1  2   < ../inputs/input/lu174 > ../outputs/t2040
echo ">>>>>>>>running test 2041"
../source/schedule.exe 3  2  1   < ../inputs/input/lu175 > ../outputs/t2041
echo ">>>>>>>>running test 2042"
../source/schedule.exe 6  3  6   < ../inputs/input/lu176 > ../outputs/t2042
echo ">>>>>>>>running test 2043"
../source/schedule.exe 9  6  1   < ../inputs/input/lu177 > ../outputs/t2043
echo ">>>>>>>>running test 2044"
../source/schedule.exe 10  3  4   < ../inputs/input/lu178 > ../outputs/t2044
echo ">>>>>>>>running test 2045"
../source/schedule.exe 1  2  5   < ../inputs/input/lu179 > ../outputs/t2045
echo ">>>>>>>>running test 2046"
../source/schedule.exe 8  9  6   < ../inputs/input/lu180 > ../outputs/t2046
echo ">>>>>>>>running test 2047"
../source/schedule.exe 1  8  1   < ../inputs/input/lu181 > ../outputs/t2047
echo ">>>>>>>>running test 2048"
../source/schedule.exe 2  5  8   < ../inputs/input/lu182 > ../outputs/t2048
echo ">>>>>>>>running test 2049"
../source/schedule.exe 3  10  9   < ../inputs/input/lu183 > ../outputs/t2049
echo ">>>>>>>>running test 2050"
../source/schedule.exe 6  1  10   < ../inputs/input/lu184 > ../outputs/t2050
echo ">>>>>>>>running test 2051"
../source/schedule.exe 1  4  7   < ../inputs/input/lu185 > ../outputs/t2051
echo ">>>>>>>>running test 2052"
../source/schedule.exe 8  7  6   < ../inputs/input/lu186 > ../outputs/t2052
echo ">>>>>>>>running test 2053"
../source/schedule.exe 1  8  5   < ../inputs/input/lu187 > ../outputs/t2053
echo ">>>>>>>>running test 2054"
../source/schedule.exe 10  3  8   < ../inputs/input/lu188 > ../outputs/t2054
echo ">>>>>>>>running test 2055"
../source/schedule.exe 7  2  3   < ../inputs/input/lu189 > ../outputs/t2055
echo ">>>>>>>>running test 2056"
../source/schedule.exe 10  3  2   < ../inputs/input/lu190 > ../outputs/t2056
echo ">>>>>>>>running test 2057"
../source/schedule.exe 5  10  5   < ../inputs/input/lu191 > ../outputs/t2057
echo ">>>>>>>>running test 2058"
../source/schedule.exe 6  3  4   < ../inputs/input/lu192 > ../outputs/t2058
echo ">>>>>>>>running test 2059"
../source/schedule.exe 1  10  1   < ../inputs/input/lu193 > ../outputs/t2059
echo ">>>>>>>>running test 2060"
../source/schedule.exe 4  5  10   < ../inputs/input/lu194 > ../outputs/t2060
echo ">>>>>>>>running test 2061"
../source/schedule.exe 3  2  9   < ../inputs/input/lu195 > ../outputs/t2061
echo ">>>>>>>>running test 2062"
../source/schedule.exe 8  5  8   < ../inputs/input/lu196 > ../outputs/t2062
echo ">>>>>>>>running test 2063"
../source/schedule.exe 7  6  7   < ../inputs/input/lu197 > ../outputs/t2063
echo ">>>>>>>>running test 2064"
../source/schedule.exe 10  3  10   < ../inputs/input/lu198 > ../outputs/t2064
echo ">>>>>>>>running test 2065"
../source/schedule.exe 9  4  9   < ../inputs/input/lu199 > ../outputs/t2065
echo ">>>>>>>>running test 2066"
../source/schedule.exe 8  1  4   < ../inputs/input/lu200 > ../outputs/t2066
echo ">>>>>>>>running test 2067"
../source/schedule.exe 3  2  9   < ../inputs/input/lu201 > ../outputs/t2067
echo ">>>>>>>>running test 2068"
../source/schedule.exe 2  9  8   < ../inputs/input/lu202 > ../outputs/t2068
echo ">>>>>>>>running test 2069"
../source/schedule.exe 1  8  7   < ../inputs/input/lu203 > ../outputs/t2069
echo ">>>>>>>>running test 2070"
../source/schedule.exe 6  1  4   < ../inputs/input/lu204 > ../outputs/t2070
echo ">>>>>>>>running test 2071"
../source/schedule.exe 3  10  5   < ../inputs/input/lu205 > ../outputs/t2071
echo ">>>>>>>>running test 2072"
../source/schedule.exe 2  3  8   < ../inputs/input/lu206 > ../outputs/t2072
echo ">>>>>>>>running test 2073"
../source/schedule.exe 5  2  3   < ../inputs/input/lu207 > ../outputs/t2073
echo ">>>>>>>>running test 2074"
../source/schedule.exe 4  5  2   < ../inputs/input/lu208 > ../outputs/t2074
echo ">>>>>>>>running test 2075"
../source/schedule.exe 5  6  1   < ../inputs/input/lu209 > ../outputs/t2075
echo ">>>>>>>>running test 2076"
../source/schedule.exe 2  5  6   < ../inputs/input/lu210 > ../outputs/t2076
echo ">>>>>>>>running test 2077"
../source/schedule.exe 1  6  3   < ../inputs/input/lu211 > ../outputs/t2077
echo ">>>>>>>>running test 2078"
../source/schedule.exe 2  7  4   < ../inputs/input/lu212 > ../outputs/t2078
echo ">>>>>>>>running test 2079"
../source/schedule.exe 5  8  7   < ../inputs/input/lu213 > ../outputs/t2079
echo ">>>>>>>>running test 2080"
../source/schedule.exe 10  5  2   < ../inputs/input/lu214 > ../outputs/t2080
echo ">>>>>>>>running test 2081"
../source/schedule.exe 1  4  9   < ../inputs/input/lu215 > ../outputs/t2081
echo ">>>>>>>>running test 2082"
../source/schedule.exe 8  1  6   < ../inputs/input/lu216 > ../outputs/t2082
echo ">>>>>>>>running test 2083"
../source/schedule.exe 3  4  9   < ../inputs/input/lu217 > ../outputs/t2083
echo ">>>>>>>>running test 2084"
../source/schedule.exe 6  5  2   < ../inputs/input/lu218 > ../outputs/t2084
echo ">>>>>>>>running test 2085"
../source/schedule.exe 7  6  3   < ../inputs/input/lu219 > ../outputs/t2085
echo ">>>>>>>>running test 2086"
../source/schedule.exe 4  7  8   < ../inputs/input/lu220 > ../outputs/t2086
echo ">>>>>>>>running test 2087"
../source/schedule.exe 3  8  1   < ../inputs/input/lu221 > ../outputs/t2087
echo ">>>>>>>>running test 2088"
../source/schedule.exe 10  1  4   < ../inputs/input/lu222 > ../outputs/t2088
echo ">>>>>>>>running test 2089"
../source/schedule.exe 1  10  7   < ../inputs/input/lu223 > ../outputs/t2089
echo ">>>>>>>>running test 2090"
../source/schedule.exe 4  7  10   < ../inputs/input/lu224 > ../outputs/t2090
echo ">>>>>>>>running test 2091"
../source/schedule.exe 5  4  3   < ../inputs/input/lu225 > ../outputs/t2091
echo ">>>>>>>>running test 2092"
../source/schedule.exe 10  5  4   < ../inputs/input/lu226 > ../outputs/t2092
echo ">>>>>>>>running test 2093"
../source/schedule.exe 1  4  9   < ../inputs/input/lu227 > ../outputs/t2093
echo ">>>>>>>>running test 2094"
../source/schedule.exe 2  5  4   < ../inputs/input/lu228 > ../outputs/t2094
echo ">>>>>>>>running test 2095"
../source/schedule.exe 7  10  9   < ../inputs/input/lu229 > ../outputs/t2095
echo ">>>>>>>>running test 2096"
../source/schedule.exe 2  7  2   < ../inputs/input/lu230 > ../outputs/t2096
echo ">>>>>>>>running test 2097"
../source/schedule.exe 3  8  9   < ../inputs/input/lu231 > ../outputs/t2097
echo ">>>>>>>>running test 2098"
../source/schedule.exe 4  9  2   < ../inputs/input/lu232 > ../outputs/t2098
echo ">>>>>>>>running test 2099"
../source/schedule.exe 9  8  7   < ../inputs/input/lu233 > ../outputs/t2099
echo ">>>>>>>>running test 2100"
../source/schedule.exe 6  9  4   < ../inputs/input/lu234 > ../outputs/t2100
echo ">>>>>>>>running test 2101"
../source/schedule.exe 9  4  3   < ../inputs/input/lu235 > ../outputs/t2101
echo ">>>>>>>>running test 2102"
../source/schedule.exe 2  7  6   < ../inputs/input/lu236 > ../outputs/t2102
echo ">>>>>>>>running test 2103"
../source/schedule.exe 1  8  9   < ../inputs/input/lu237 > ../outputs/t2103
echo ">>>>>>>>running test 2104"
../source/schedule.exe 8  1  6   < ../inputs/input/lu238 > ../outputs/t2104
echo ">>>>>>>>running test 2105"
../source/schedule.exe 7  10  9   < ../inputs/input/lu239 > ../outputs/t2105
echo ">>>>>>>>running test 2106"
../source/schedule.exe 4  3  2   < ../inputs/input/lu240 > ../outputs/t2106
echo ">>>>>>>>running test 2107"
../source/schedule.exe 9  4  5   < ../inputs/input/lu241 > ../outputs/t2107
echo ">>>>>>>>running test 2108"
../source/schedule.exe 6  1  10   < ../inputs/input/lu242 > ../outputs/t2108
echo ">>>>>>>>running test 2109"
../source/schedule.exe 1  10  1   < ../inputs/input/lu243 > ../outputs/t2109
echo ">>>>>>>>running test 2110"
../source/schedule.exe 6  3  10   < ../inputs/input/lu244 > ../outputs/t2110
echo ">>>>>>>>running test 2111"
../source/schedule.exe 1  4  3   < ../inputs/input/lu245 > ../outputs/t2111
echo ">>>>>>>>running test 2112"
../source/schedule.exe 8  3  10   < ../inputs/input/lu246 > ../outputs/t2112
echo ">>>>>>>>running test 2113"
../source/schedule.exe 9  2  5   < ../inputs/input/lu247 > ../outputs/t2113
echo ">>>>>>>>running test 2114"
../source/schedule.exe 8  5  6   < ../inputs/input/lu248 > ../outputs/t2114
echo ">>>>>>>>running test 2115"
../source/schedule.exe 3  4  3   < ../inputs/input/lu249 > ../outputs/t2115
echo ">>>>>>>>running test 2116"
../source/schedule.exe 10  7  2   < ../inputs/input/lu250 > ../outputs/t2116
echo ">>>>>>>>running test 2117"
../source/schedule.exe 1  2  3   < ../inputs/input/lu251 > ../outputs/t2117
echo ">>>>>>>>running test 2118"
../source/schedule.exe 2  5  4   < ../inputs/input/lu252 > ../outputs/t2118
echo ">>>>>>>>running test 2119"
../source/schedule.exe 7  4  5   < ../inputs/input/lu253 > ../outputs/t2119
echo ">>>>>>>>running test 2120"
../source/schedule.exe 4  3  2   < ../inputs/input/lu254 > ../outputs/t2120
echo ">>>>>>>>running test 2121"
../source/schedule.exe 5  4  9   < ../inputs/input/lu255 > ../outputs/t2121
echo ">>>>>>>>running test 2122"
../source/schedule.exe 2  5  10   < ../inputs/input/lu256 > ../outputs/t2122
echo ">>>>>>>>running test 2123"
../source/schedule.exe 7  6  1   < ../inputs/input/lu257 > ../outputs/t2123
echo ">>>>>>>>running test 2124"
../source/schedule.exe 6  9  6   < ../inputs/input/lu258 > ../outputs/t2124
echo ">>>>>>>>running test 2125"
../source/schedule.exe 3  2  5   < ../inputs/input/lu259 > ../outputs/t2125
echo ">>>>>>>>running test 2126"
../source/schedule.exe 8  3  4   < ../inputs/input/lu260 > ../outputs/t2126
echo ">>>>>>>>running test 2127"
../source/schedule.exe 5  6  7   < ../inputs/input/lu261 > ../outputs/t2127
echo ">>>>>>>>running test 2128"
../source/schedule.exe 6  1  10   < ../inputs/input/lu262 > ../outputs/t2128
echo ">>>>>>>>running test 2129"
../source/schedule.exe 9  8  5   < ../inputs/input/lu263 > ../outputs/t2129
echo ">>>>>>>>running test 2130"
../source/schedule.exe 4  3  4   < ../inputs/input/lu264 > ../outputs/t2130
echo ">>>>>>>>running test 2131"
../source/schedule.exe 1  4  3   < ../inputs/input/lu265 > ../outputs/t2131
echo ">>>>>>>>running test 2132"
../source/schedule.exe 8  1  10   < ../inputs/input/lu266 > ../outputs/t2132
echo ">>>>>>>>running test 2133"
../source/schedule.exe 1  6  5   < ../inputs/input/lu267 > ../outputs/t2133
echo ">>>>>>>>running test 2134"
../source/schedule.exe 8  1  6   < ../inputs/input/lu268 > ../outputs/t2134
echo ">>>>>>>>running test 2135"
../source/schedule.exe 9  4  9   < ../inputs/input/lu269 > ../outputs/t2135
echo ">>>>>>>>running test 2136"
../source/schedule.exe 8  9  4   < ../inputs/input/lu270 > ../outputs/t2136
echo ">>>>>>>>running test 2137"
../source/schedule.exe 5  8  3   < ../inputs/input/lu271 > ../outputs/t2137
echo ">>>>>>>>running test 2138"
../source/schedule.exe 2  1  8   < ../inputs/input/lu272 > ../outputs/t2138
echo ">>>>>>>>running test 2139"
../source/schedule.exe 7  6  3   < ../inputs/input/lu273 > ../outputs/t2139
echo ">>>>>>>>running test 2140"
../source/schedule.exe 10  7  10   < ../inputs/input/lu274 > ../outputs/t2140
echo ">>>>>>>>running test 2141"
../source/schedule.exe 5  10  9   < ../inputs/input/lu275 > ../outputs/t2141
echo ">>>>>>>>running test 2142"
../source/schedule.exe 6  1  2   < ../inputs/input/lu276 > ../outputs/t2142
echo ">>>>>>>>running test 2143"
../source/schedule.exe 7  2  3   < ../inputs/input/lu277 > ../outputs/t2143
echo ">>>>>>>>running test 2144"
../source/schedule.exe 4  9  4   < ../inputs/input/lu278 > ../outputs/t2144
echo ">>>>>>>>running test 2145"
../source/schedule.exe 5  2  7   < ../inputs/input/lu279 > ../outputs/t2145
echo ">>>>>>>>running test 2146"
../source/schedule.exe 8  7  8   < ../inputs/input/lu280 > ../outputs/t2146
echo ">>>>>>>>running test 2147"
../source/schedule.exe 7  10  1   < ../inputs/input/lu281 > ../outputs/t2147
echo ">>>>>>>>running test 2148"
../source/schedule.exe 2  9  8   < ../inputs/input/lu282 > ../outputs/t2148
echo ">>>>>>>>running test 2149"
../source/schedule.exe 7  8  5   < ../inputs/input/lu283 > ../outputs/t2149
echo ">>>>>>>>running test 2150"
../source/schedule.exe 8  9  8   < ../inputs/input/lu284 > ../outputs/t2150
echo ">>>>>>>>running test 2151"
../source/schedule.exe 3  6  5   < ../inputs/input/lu285 > ../outputs/t2151
echo ">>>>>>>>running test 2152"
../source/schedule.exe 2  5  4   < ../inputs/input/lu286 > ../outputs/t2152
echo ">>>>>>>>running test 2153"
../source/schedule.exe 7  6  5   < ../inputs/input/lu287 > ../outputs/t2153
echo ">>>>>>>>running test 2154"
../source/schedule.exe 4  1  4   < ../inputs/input/lu288 > ../outputs/t2154
echo ">>>>>>>>running test 2155"
../source/schedule.exe 3  8  1   < ../inputs/input/lu289 > ../outputs/t2155
echo ">>>>>>>>running test 2156"
../source/schedule.exe 8  5  4   < ../inputs/input/lu290 > ../outputs/t2156
echo ">>>>>>>>running test 2157"
../source/schedule.exe 7  4  7   < ../inputs/input/lu291 > ../outputs/t2157
echo ">>>>>>>>running test 2158"
../source/schedule.exe 8  7  6   < ../inputs/input/lu292 > ../outputs/t2158
echo ">>>>>>>>running test 2159"
../source/schedule.exe 9  6  5   < ../inputs/input/lu293 > ../outputs/t2159
echo ">>>>>>>>running test 2160"
../source/schedule.exe 8  9  4   < ../inputs/input/lu294 > ../outputs/t2160
echo ">>>>>>>>running test 2161"
../source/schedule.exe 1  6  7   < ../inputs/input/lu295 > ../outputs/t2161
echo ">>>>>>>>running test 2162"
../source/schedule.exe 2  9  6   < ../inputs/input/lu296 > ../outputs/t2162
echo ">>>>>>>>running test 2163"
../source/schedule.exe 5  4  7   < ../inputs/input/lu297 > ../outputs/t2163
echo ">>>>>>>>running test 2164"
../source/schedule.exe 6  3  10   < ../inputs/input/lu298 > ../outputs/t2164
echo ">>>>>>>>running test 2165"
../source/schedule.exe 7  8  9   < ../inputs/input/lu299 > ../outputs/t2165
echo ">>>>>>>>running test 2166"
../source/schedule.exe 4  5  2   < ../inputs/input/lu300 > ../outputs/t2166
echo ">>>>>>>>running test 2167"
../source/schedule.exe 3  10  1   < ../inputs/input/lu301 > ../outputs/t2167
echo ">>>>>>>>running test 2168"
../source/schedule.exe 8  5  4   < ../inputs/input/lu302 > ../outputs/t2168
echo ">>>>>>>>running test 2169"
../source/schedule.exe 3  2  5   < ../inputs/input/lu303 > ../outputs/t2169
echo ">>>>>>>>running test 2170"
../source/schedule.exe 4  7  10   < ../inputs/input/lu304 > ../outputs/t2170
echo ">>>>>>>>running test 2171"
../source/schedule.exe 7  8  3   < ../inputs/input/lu305 > ../outputs/t2171
echo ">>>>>>>>running test 2172"
../source/schedule.exe 4  7  10   < ../inputs/input/lu306 > ../outputs/t2172
echo ">>>>>>>>running test 2173"
../source/schedule.exe 9  4  5   < ../inputs/input/lu307 > ../outputs/t2173
echo ">>>>>>>>running test 2174"
../source/schedule.exe 10  5  8   < ../inputs/input/lu308 > ../outputs/t2174
echo ">>>>>>>>running test 2175"
../source/schedule.exe 3  6  3   < ../inputs/input/lu309 > ../outputs/t2175
echo ">>>>>>>>running test 2176"
../source/schedule.exe 6  3  4   < ../inputs/input/lu310 > ../outputs/t2176
echo ">>>>>>>>running test 2177"
../source/schedule.exe 1  10  3   < ../inputs/input/lu311 > ../outputs/t2177
echo ">>>>>>>>running test 2178"
../source/schedule.exe 4  3  8   < ../inputs/input/lu312 > ../outputs/t2178
echo ">>>>>>>>running test 2179"
../source/schedule.exe 3  8  7   < ../inputs/input/lu313 > ../outputs/t2179
echo ">>>>>>>>running test 2180"
../source/schedule.exe 10  7  8   < ../inputs/input/lu314 > ../outputs/t2180
echo ">>>>>>>>running test 2181"
../source/schedule.exe 3  4  5   < ../inputs/input/lu315 > ../outputs/t2181
echo ">>>>>>>>running test 2182"
../source/schedule.exe 4  5  8   < ../inputs/input/lu316 > ../outputs/t2182
echo ">>>>>>>>running test 2183"
../source/schedule.exe 1  2  3   < ../inputs/input/lu317 > ../outputs/t2183
echo ">>>>>>>>running test 2184"
../source/schedule.exe 10  7  8   < ../inputs/input/lu318 > ../outputs/t2184
echo ">>>>>>>>running test 2185"
../source/schedule.exe 7  4  9   < ../inputs/input/lu319 > ../outputs/t2185
echo ">>>>>>>>running test 2186"
../source/schedule.exe 4  7  10   < ../inputs/input/lu320 > ../outputs/t2186
echo ">>>>>>>>running test 2187"
../source/schedule.exe 9  6  5   < ../inputs/input/lu321 > ../outputs/t2187
echo ">>>>>>>>running test 2188"
../source/schedule.exe 6  1  4   < ../inputs/input/lu322 > ../outputs/t2188
echo ">>>>>>>>running test 2189"
../source/schedule.exe 9  10  3   < ../inputs/input/lu323 > ../outputs/t2189
echo ">>>>>>>>running test 2190"
../source/schedule.exe 8  5  4   < ../inputs/input/lu324 > ../outputs/t2190
echo ">>>>>>>>running test 2191"
../source/schedule.exe 9  4  3   < ../inputs/input/lu325 > ../outputs/t2191
echo ">>>>>>>>running test 2192"
../source/schedule.exe 8  3  4   < ../inputs/input/lu326 > ../outputs/t2192
echo ">>>>>>>>running test 2193"
../source/schedule.exe 5  10  1   < ../inputs/input/lu327 > ../outputs/t2193
echo ">>>>>>>>running test 2194"
../source/schedule.exe 8  3  10   < ../inputs/input/lu328 > ../outputs/t2194
echo ">>>>>>>>running test 2195"
../source/schedule.exe 7  6  1   < ../inputs/input/lu329 > ../outputs/t2195
echo ">>>>>>>>running test 2196"
../source/schedule.exe 6  5  4   < ../inputs/input/lu330 > ../outputs/t2196
echo ">>>>>>>>running test 2197"
../source/schedule.exe 5  2  9   < ../inputs/input/lu331 > ../outputs/t2197
echo ">>>>>>>>running test 2198"
../source/schedule.exe 4  5  2   < ../inputs/input/lu332 > ../outputs/t2198
echo ">>>>>>>>running test 2199"
../source/schedule.exe 3  4  3   < ../inputs/input/lu333 > ../outputs/t2199
echo ">>>>>>>>running test 2200"
../source/schedule.exe 6  9  8   < ../inputs/input/lu334 > ../outputs/t2200
echo ">>>>>>>>running test 2201"
../source/schedule.exe 7  6  1   < ../inputs/input/lu335 > ../outputs/t2201
echo ">>>>>>>>running test 2202"
../source/schedule.exe 4  1  2   < ../inputs/input/lu336 > ../outputs/t2202
echo ">>>>>>>>running test 2203"
../source/schedule.exe 5  10  1   < ../inputs/input/lu337 > ../outputs/t2203
echo ">>>>>>>>running test 2204"
../source/schedule.exe 10  9  2   < ../inputs/input/lu338 > ../outputs/t2204
echo ">>>>>>>>running test 2205"
../source/schedule.exe 5  2  1   < ../inputs/input/lu339 > ../outputs/t2205
echo ">>>>>>>>running test 2206"
../source/schedule.exe 8  7  8   < ../inputs/input/lu340 > ../outputs/t2206
echo ">>>>>>>>running test 2207"
../source/schedule.exe 7  6  9   < ../inputs/input/lu341 > ../outputs/t2207
echo ">>>>>>>>running test 2208"
../source/schedule.exe 10  1  10   < ../inputs/input/lu342 > ../outputs/t2208
echo ">>>>>>>>running test 2209"
../source/schedule.exe 9  6  7   < ../inputs/input/lu343 > ../outputs/t2209
echo ">>>>>>>>running test 2210"
../source/schedule.exe 6  7  10   < ../inputs/input/lu344 > ../outputs/t2210
echo ">>>>>>>>running test 2211"
../source/schedule.exe 7  10  9   < ../inputs/input/lu345 > ../outputs/t2211
echo ">>>>>>>>running test 2212"
../source/schedule.exe 6  7  10   < ../inputs/input/lu346 > ../outputs/t2212
echo ">>>>>>>>running test 2213"
../source/schedule.exe 3  4  5   < ../inputs/input/lu347 > ../outputs/t2213
echo ">>>>>>>>running test 2214"
../source/schedule.exe 10  9  6   < ../inputs/input/lu348 > ../outputs/t2214
echo ">>>>>>>>running test 2215"
../source/schedule.exe 3  6  9   < ../inputs/input/lu349 > ../outputs/t2215
echo ">>>>>>>>running test 2216"
../source/schedule.exe 10  5  8   < ../inputs/input/lu350 > ../outputs/t2216
echo ">>>>>>>>running test 2217"
../source/schedule.exe 5  8  9   < ../inputs/input/lu351 > ../outputs/t2217
echo ">>>>>>>>running test 2218"
../source/schedule.exe 2  7  4   < ../inputs/input/lu352 > ../outputs/t2218
echo ">>>>>>>>running test 2219"
../source/schedule.exe 3  4  9   < ../inputs/input/lu353 > ../outputs/t2219
echo ">>>>>>>>running test 2220"
../source/schedule.exe 6  9  8   < ../inputs/input/lu354 > ../outputs/t2220
echo ">>>>>>>>running test 2221"
../source/schedule.exe 7  8  9   < ../inputs/input/lu355 > ../outputs/t2221
echo ">>>>>>>>running test 2222"
../source/schedule.exe 10  7  4   < ../inputs/input/lu356 > ../outputs/t2222
echo ">>>>>>>>running test 2223"
../source/schedule.exe 1  4  9   < ../inputs/input/lu357 > ../outputs/t2223
echo ">>>>>>>>running test 2224"
../source/schedule.exe 10  9  10   < ../inputs/input/lu358 > ../outputs/t2224
echo ">>>>>>>>running test 2225"
../source/schedule.exe 5  4  7   < ../inputs/input/lu359 > ../outputs/t2225
echo ">>>>>>>>running test 2226"
../source/schedule.exe 2  3  4   < ../inputs/input/lu360 > ../outputs/t2226
echo ">>>>>>>>running test 2227"
../source/schedule.exe 7  8  3   < ../inputs/input/lu361 > ../outputs/t2227
echo ">>>>>>>>running test 2228"
../source/schedule.exe 8  9  10   < ../inputs/input/lu362 > ../outputs/t2228
echo ">>>>>>>>running test 2229"
../source/schedule.exe 1  6  5   < ../inputs/input/lu363 > ../outputs/t2229
echo ">>>>>>>>running test 2230"
../source/schedule.exe 4  3  6   < ../inputs/input/lu364 > ../outputs/t2230
echo ">>>>>>>>running test 2231"
../source/schedule.exe 7  2  5   < ../inputs/input/lu365 > ../outputs/t2231
echo ">>>>>>>>running test 2232"
../source/schedule.exe 4  3  2   < ../inputs/input/lu366 > ../outputs/t2232
echo ">>>>>>>>running test 2233"
../source/schedule.exe 9  10  3   < ../inputs/input/lu367 > ../outputs/t2233
echo ">>>>>>>>running test 2234"
../source/schedule.exe 4  1  8   < ../inputs/input/lu368 > ../outputs/t2234
echo ">>>>>>>>running test 2235"
../source/schedule.exe 1  8  7   < ../inputs/input/lu369 > ../outputs/t2235
echo ">>>>>>>>running test 2236"
../source/schedule.exe 6  3  8   < ../inputs/input/lu370 > ../outputs/t2236
echo ">>>>>>>>running test 2237"
../source/schedule.exe 5  4  3   < ../inputs/input/lu371 > ../outputs/t2237
echo ">>>>>>>>running test 2238"
../source/schedule.exe 10  1  8   < ../inputs/input/lu372 > ../outputs/t2238
echo ">>>>>>>>running test 2239"
../source/schedule.exe 3  8  7   < ../inputs/input/lu373 > ../outputs/t2239
echo ">>>>>>>>running test 2240"
../source/schedule.exe 6  9  10   < ../inputs/input/lu374 > ../outputs/t2240
echo ">>>>>>>>running test 2241"
../source/schedule.exe 9  8  3   < ../inputs/input/lu375 > ../outputs/t2241
echo ">>>>>>>>running test 2242"
../source/schedule.exe 6  3  10   < ../inputs/input/lu376 > ../outputs/t2242
echo ">>>>>>>>running test 2243"
../source/schedule.exe 3  10  9   < ../inputs/input/lu377 > ../outputs/t2243
echo ">>>>>>>>running test 2244"
../source/schedule.exe 10  3  8   < ../inputs/input/lu378 > ../outputs/t2244
echo ">>>>>>>>running test 2245"
../source/schedule.exe 5  2  7   < ../inputs/input/lu379 > ../outputs/t2245
echo ">>>>>>>>running test 2246"
../source/schedule.exe 6  1  6   < ../inputs/input/lu380 > ../outputs/t2246
echo ">>>>>>>>running test 2247"
../source/schedule.exe 3  2  3   < ../inputs/input/lu381 > ../outputs/t2247
echo ">>>>>>>>running test 2248"
../source/schedule.exe 8  9  8   < ../inputs/input/lu382 > ../outputs/t2248
echo ">>>>>>>>running test 2249"
../source/schedule.exe 7  6  5   < ../inputs/input/lu383 > ../outputs/t2249
echo ">>>>>>>>running test 2250"
../source/schedule.exe 6  7  8   < ../inputs/input/lu384 > ../outputs/t2250
echo ">>>>>>>>running test 2251"
../source/schedule.exe 3  8  9   < ../inputs/input/lu385 > ../outputs/t2251
echo ">>>>>>>>running test 2252"
../source/schedule.exe 10  9  8   < ../inputs/input/lu386 > ../outputs/t2252
echo ">>>>>>>>running test 2253"
../source/schedule.exe 5  8  7   < ../inputs/input/lu387 > ../outputs/t2253
echo ">>>>>>>>running test 2254"
../source/schedule.exe 2  7  2   < ../inputs/input/lu388 > ../outputs/t2254
echo ">>>>>>>>running test 2255"
../source/schedule.exe 3  10  1   < ../inputs/input/lu389 > ../outputs/t2255
echo ">>>>>>>>running test 2256"
../source/schedule.exe 10  3  8   < ../inputs/input/lu390 > ../outputs/t2256
echo ">>>>>>>>running test 2257"
../source/schedule.exe 1  8  1   < ../inputs/input/lu391 > ../outputs/t2257
echo ">>>>>>>>running test 2258"
../source/schedule.exe 4  5  10   < ../inputs/input/lu392 > ../outputs/t2258
echo ">>>>>>>>running test 2259"
../source/schedule.exe 7  6  9   < ../inputs/input/lu393 > ../outputs/t2259
echo ">>>>>>>>running test 2260"
../source/schedule.exe 10  7  6   < ../inputs/input/lu394 > ../outputs/t2260
echo ">>>>>>>>running test 2261"
../source/schedule.exe 7  6  1   < ../inputs/input/lu395 > ../outputs/t2261
echo ">>>>>>>>running test 2262"
../source/schedule.exe 10  5  2   < ../inputs/input/lu396 > ../outputs/t2262
echo ">>>>>>>>running test 2263"
../source/schedule.exe 1  2  1   < ../inputs/input/lu397 > ../outputs/t2263
echo ">>>>>>>>running test 2264"
../source/schedule.exe 2  9  10   < ../inputs/input/lu398 > ../outputs/t2264
echo ">>>>>>>>running test 2265"
../source/schedule.exe 3  8  7   < ../inputs/input/lu399 > ../outputs/t2265
echo ">>>>>>>>running test 2266"
../source/schedule.exe 6  9  4   < ../inputs/input/lu400 > ../outputs/t2266
echo ">>>>>>>>running test 2267"
../source/schedule.exe 3  6  7   < ../inputs/input/lu401 > ../outputs/t2267
echo ">>>>>>>>running test 2268"
../source/schedule.exe 10  3  6   < ../inputs/input/lu402 > ../outputs/t2268
echo ">>>>>>>>running test 2269"
../source/schedule.exe 5  10  5   < ../inputs/input/lu403 > ../outputs/t2269
echo ">>>>>>>>running test 2270"
../source/schedule.exe 6  7  10   < ../inputs/input/lu404 > ../outputs/t2270
echo ">>>>>>>>running test 2271"
../source/schedule.exe 7  10  9   < ../inputs/input/lu405 > ../outputs/t2271
echo ">>>>>>>>running test 2272"
../source/schedule.exe 4  5  10   < ../inputs/input/lu406 > ../outputs/t2272
echo ">>>>>>>>running test 2273"
../source/schedule.exe 1  6  7   < ../inputs/input/lu407 > ../outputs/t2273
echo ">>>>>>>>running test 2274"
../source/schedule.exe 6  7  10   < ../inputs/input/lu408 > ../outputs/t2274
echo ">>>>>>>>running test 2275"
../source/schedule.exe 1  8  9   < ../inputs/input/lu409 > ../outputs/t2275
echo ">>>>>>>>running test 2276"
../source/schedule.exe 8  3  8   < ../inputs/input/lu410 > ../outputs/t2276
echo ">>>>>>>>running test 2277"
../source/schedule.exe 3  6  9   < ../inputs/input/lu411 > ../outputs/t2277
echo ">>>>>>>>running test 2278"
../source/schedule.exe 8  9  6   < ../inputs/input/lu412 > ../outputs/t2278
echo ">>>>>>>>running test 2279"
../source/schedule.exe 9  2  5   < ../inputs/input/lu413 > ../outputs/t2279
echo ">>>>>>>>running test 2280"
../source/schedule.exe 10  9  2   < ../inputs/input/lu414 > ../outputs/t2280
echo ">>>>>>>>running test 2281"
../source/schedule.exe 5  8  1   < ../inputs/input/lu415 > ../outputs/t2281
echo ">>>>>>>>running test 2282"
../source/schedule.exe 4  5  10   < ../inputs/input/lu416 > ../outputs/t2282
echo ">>>>>>>>running test 2283"
../source/schedule.exe 5  10  1   < ../inputs/input/lu417 > ../outputs/t2283
echo ">>>>>>>>running test 2284"
../source/schedule.exe 6  3  8   < ../inputs/input/lu418 > ../outputs/t2284
echo ">>>>>>>>running test 2285"
../source/schedule.exe 9  4  5   < ../inputs/input/lu419 > ../outputs/t2285
echo ">>>>>>>>running test 2286"
../source/schedule.exe 4  5  10   < ../inputs/input/lu420 > ../outputs/t2286
echo ">>>>>>>>running test 2287"
../source/schedule.exe 7  6  5   < ../inputs/input/lu421 > ../outputs/t2287
echo ">>>>>>>>running test 2288"
../source/schedule.exe 10  7  2   < ../inputs/input/lu422 > ../outputs/t2288
echo ">>>>>>>>running test 2289"
../source/schedule.exe 5  6  7   < ../inputs/input/lu423 > ../outputs/t2289
echo ">>>>>>>>running test 2290"
../source/schedule.exe 6  5  8   < ../inputs/input/lu424 > ../outputs/t2290
echo ">>>>>>>>running test 2291"
../source/schedule.exe 1  6  5   < ../inputs/input/lu425 > ../outputs/t2291
echo ">>>>>>>>running test 2292"
../source/schedule.exe 6  9  4   < ../inputs/input/lu426 > ../outputs/t2292
echo ">>>>>>>>running test 2293"
../source/schedule.exe 9  6  5   < ../inputs/input/lu427 > ../outputs/t2293
echo ">>>>>>>>running test 2294"
../source/schedule.exe 10  5  4   < ../inputs/input/lu428 > ../outputs/t2294
echo ">>>>>>>>running test 2295"
../source/schedule.exe 7  6  3   < ../inputs/input/lu429 > ../outputs/t2295
echo ">>>>>>>>running test 2296"
../source/schedule.exe 2  5  10   < ../inputs/input/lu430 > ../outputs/t2296
echo ">>>>>>>>running test 2297"
../source/schedule.exe 7  10  7   < ../inputs/input/lu431 > ../outputs/t2297
echo ">>>>>>>>running test 2298"
../source/schedule.exe 10  1  2   < ../inputs/input/lu432 > ../outputs/t2298
echo ">>>>>>>>running test 2299"
../source/schedule.exe 1  8  7   < ../inputs/input/lu433 > ../outputs/t2299
echo ">>>>>>>>running test 2300"
../source/schedule.exe 10  1  4   < ../inputs/input/lu434 > ../outputs/t2300
echo ">>>>>>>>running test 2301"
../source/schedule.exe 7  4  5   < ../inputs/input/lu435 > ../outputs/t2301
echo ">>>>>>>>running test 2302"
../source/schedule.exe 4  9  4   < ../inputs/input/lu436 > ../outputs/t2302
echo ">>>>>>>>running test 2303"
../source/schedule.exe 3  2  3   < ../inputs/input/lu437 > ../outputs/t2303
echo ">>>>>>>>running test 2304"
../source/schedule.exe 4  1  6   < ../inputs/input/lu438 > ../outputs/t2304
echo ">>>>>>>>running test 2305"
../source/schedule.exe 7  2  7   < ../inputs/input/lu439 > ../outputs/t2305
echo ">>>>>>>>running test 2306"
../source/schedule.exe 10  7  4   < ../inputs/input/lu440 > ../outputs/t2306
echo ">>>>>>>>running test 2307"
../source/schedule.exe 9  4  9   < ../inputs/input/lu441 > ../outputs/t2307
echo ">>>>>>>>running test 2308"
../source/schedule.exe 10  7  8   < ../inputs/input/lu442 > ../outputs/t2308
echo ">>>>>>>>running test 2309"
../source/schedule.exe 5  8  5   < ../inputs/input/lu443 > ../outputs/t2309
echo ">>>>>>>>running test 2310"
../source/schedule.exe 6  3  4   < ../inputs/input/lu444 > ../outputs/t2310
echo ">>>>>>>>running test 2311"
../source/schedule.exe 7  8  3   < ../inputs/input/lu445 > ../outputs/t2311
echo ">>>>>>>>running test 2312"
../source/schedule.exe 6  5  8   < ../inputs/input/lu446 > ../outputs/t2312
echo ">>>>>>>>running test 2313"
../source/schedule.exe 7  8  9   < ../inputs/input/lu447 > ../outputs/t2313
echo ">>>>>>>>running test 2314"
../source/schedule.exe 4  7  10   < ../inputs/input/lu448 > ../outputs/t2314
echo ">>>>>>>>running test 2315"
../source/schedule.exe 1  6  5   < ../inputs/input/lu449 > ../outputs/t2315
echo ">>>>>>>>running test 2316"
../source/schedule.exe 10  5  6   < ../inputs/input/lu450 > ../outputs/t2316
echo ">>>>>>>>running test 2317"
../source/schedule.exe 3  6  3   < ../inputs/input/lu451 > ../outputs/t2317
echo ">>>>>>>>running test 2318"
../source/schedule.exe 2  5  4   < ../inputs/input/lu452 > ../outputs/t2318
echo ">>>>>>>>running test 2319"
../source/schedule.exe 1  6  9   < ../inputs/input/lu453 > ../outputs/t2319
echo ">>>>>>>>running test 2320"
../source/schedule.exe 10  7  2   < ../inputs/input/lu454 > ../outputs/t2320
echo ">>>>>>>>running test 2321"
../source/schedule.exe 3  2  3   < ../inputs/input/lu455 > ../outputs/t2321
echo ">>>>>>>>running test 2322"
../source/schedule.exe 6  1  2   < ../inputs/input/lu456 > ../outputs/t2322
echo ">>>>>>>>running test 2323"
../source/schedule.exe 7  2  5   < ../inputs/input/lu457 > ../outputs/t2323
echo ">>>>>>>>running test 2324"
../source/schedule.exe 4  1  4   < ../inputs/input/lu458 > ../outputs/t2324
echo ">>>>>>>>running test 2325"
../source/schedule.exe 5  6  5   < ../inputs/input/lu459 > ../outputs/t2325
echo ">>>>>>>>running test 2326"
../source/schedule.exe 6  3  10   < ../inputs/input/lu460 > ../outputs/t2326
echo ">>>>>>>>running test 2327"
../source/schedule.exe 3  6  3   < ../inputs/input/lu461 > ../outputs/t2327
echo ">>>>>>>>running test 2328"
../source/schedule.exe 8  9  6   < ../inputs/input/lu462 > ../outputs/t2328
echo ">>>>>>>>running test 2329"
../source/schedule.exe 9  6  9   < ../inputs/input/lu463 > ../outputs/t2329
echo ">>>>>>>>running test 2330"
../source/schedule.exe 10  7  2   < ../inputs/input/lu464 > ../outputs/t2330
echo ">>>>>>>>running test 2331"
../source/schedule.exe 3  6  3   < ../inputs/input/lu465 > ../outputs/t2331
echo ">>>>>>>>running test 2332"
../source/schedule.exe 4  7  10   < ../inputs/input/lu466 > ../outputs/t2332
echo ">>>>>>>>running test 2333"
../source/schedule.exe 3  8  3   < ../inputs/input/lu467 > ../outputs/t2333
echo ">>>>>>>>running test 2334"
../source/schedule.exe 10  9  4   < ../inputs/input/lu468 > ../outputs/t2334
echo ">>>>>>>>running test 2335"
../source/schedule.exe 1  8  9   < ../inputs/input/lu469 > ../outputs/t2335
echo ">>>>>>>>running test 2336"
../source/schedule.exe 10  7  8   < ../inputs/input/lu470 > ../outputs/t2336
echo ">>>>>>>>running test 2337"
../source/schedule.exe 3  10  7   < ../inputs/input/lu471 > ../outputs/t2337
echo ">>>>>>>>running test 2338"
../source/schedule.exe 8  3  2   < ../inputs/input/lu472 > ../outputs/t2338
echo ">>>>>>>>running test 2339"
../source/schedule.exe 1  2  7   < ../inputs/input/lu473 > ../outputs/t2339
echo ">>>>>>>>running test 2340"
../source/schedule.exe 4  9  4   < ../inputs/input/lu474 > ../outputs/t2340
echo ">>>>>>>>running test 2341"
../source/schedule.exe 3  6  9   < ../inputs/input/lu475 > ../outputs/t2341
echo ">>>>>>>>running test 2342"
../source/schedule.exe 10  5  4   < ../inputs/input/lu476 > ../outputs/t2342
echo ">>>>>>>>running test 2343"
../source/schedule.exe 9  8  7   < ../inputs/input/lu477 > ../outputs/t2343
echo ">>>>>>>>running test 2344"
../source/schedule.exe 2  3  6   < ../inputs/input/lu478 > ../outputs/t2344
echo ">>>>>>>>running test 2345"
../source/schedule.exe 3  8  7   < ../inputs/input/lu479 > ../outputs/t2345
echo ">>>>>>>>running test 2346"
../source/schedule.exe 8  7  4   < ../inputs/input/lu480 > ../outputs/t2346
echo ">>>>>>>>running test 2347"
../source/schedule.exe 9  4  3   < ../inputs/input/lu481 > ../outputs/t2347
echo ">>>>>>>>running test 2348"
../source/schedule.exe 8  5  10   < ../inputs/input/lu482 > ../outputs/t2348
echo ">>>>>>>>running test 2349"
../source/schedule.exe 5  8  3   < ../inputs/input/lu483 > ../outputs/t2349
echo ">>>>>>>>running test 2350"
../source/schedule.exe 2  7  4   < ../inputs/input/lu484 > ../outputs/t2350
echo ">>>>>>>>running test 2351"
../source/schedule.exe 5  6  7   < ../inputs/input/lu485 > ../outputs/t2351
echo ">>>>>>>>running test 2352"
../source/schedule.exe 6  3  2   < ../inputs/input/lu486 > ../outputs/t2352
echo ">>>>>>>>running test 2353"
../source/schedule.exe 5  2  7   < ../inputs/input/lu487 > ../outputs/t2353
echo ">>>>>>>>running test 2354"
../source/schedule.exe 10  5  4   < ../inputs/input/lu488 > ../outputs/t2354
echo ">>>>>>>>running test 2355"
../source/schedule.exe 3  4  3   < ../inputs/input/lu489 > ../outputs/t2355
echo ">>>>>>>>running test 2356"
../source/schedule.exe 10  5  4   < ../inputs/input/lu490 > ../outputs/t2356
echo ">>>>>>>>running test 2357"
../source/schedule.exe 3  10  1   < ../inputs/input/lu491 > ../outputs/t2357
echo ">>>>>>>>running test 2358"
../source/schedule.exe 6  5  4   < ../inputs/input/lu492 > ../outputs/t2358
echo ">>>>>>>>running test 2359"
../source/schedule.exe 9  2  9   < ../inputs/input/lu493 > ../outputs/t2359
echo ">>>>>>>>running test 2360"
../source/schedule.exe 2  5  4   < ../inputs/input/lu494 > ../outputs/t2360
echo ">>>>>>>>running test 2361"
../source/schedule.exe 7  4  9   < ../inputs/input/lu495 > ../outputs/t2361
echo ">>>>>>>>running test 2362"
../source/schedule.exe 8  1  8   < ../inputs/input/lu496 > ../outputs/t2362
echo ">>>>>>>>running test 2363"
../source/schedule.exe 5  10  3   < ../inputs/input/lu497 > ../outputs/t2363
echo ">>>>>>>>running test 2364"
../source/schedule.exe 6  3  6   < ../inputs/input/lu498 > ../outputs/t2364
echo ">>>>>>>>running test 2365"
../source/schedule.exe 5  6  5   < ../inputs/input/lu499 > ../outputs/t2365
echo ">>>>>>>>running test 2366"
../source/schedule.exe 8  7  10   < ../inputs/input/lu500 > ../outputs/t2366
echo ">>>>>>>>running test 2367"
../source/schedule.exe 7 1 9  < ../inputs/input/bdt.58 > ../outputs/t2367
echo ">>>>>>>>running test 2368"
../source/schedule.exe 1 4 2  < ../inputs/input/bdt.35 > ../outputs/t2368
echo ">>>>>>>>running test 2369"
../source/schedule.exe 4 8 8  < ../inputs/input/bdt.18 > ../outputs/t2369
echo ">>>>>>>>running test 2370"
../source/schedule.exe 7 2 10  < ../inputs/input/bdt.24 > ../outputs/t2370
echo ">>>>>>>>running test 2371"
../source/schedule.exe 6 8 3  < ../inputs/input/bdt.17 > ../outputs/t2371
echo ">>>>>>>>running test 2372"
../source/schedule.exe 7 10 5  < ../inputs/input/bdt.84 > ../outputs/t2372
echo ">>>>>>>>running test 2373"
../source/schedule.exe 6 8 3  < ../inputs/input/bdt.56 > ../outputs/t2373
echo ">>>>>>>>running test 2374"
../source/schedule.exe 8 8 0  < ../inputs/input/bdt.80 > ../outputs/t2374
echo ">>>>>>>>running test 2375"
../source/schedule.exe 8 1 4  < ../inputs/input/bdt.35 > ../outputs/t2375
echo ">>>>>>>>running test 2376"
../source/schedule.exe 9 3 4  < ../inputs/input/bdt.20 > ../outputs/t2376
echo ">>>>>>>>running test 2377"
../source/schedule.exe 8 8 5  < ../inputs/input/bdt.14 > ../outputs/t2377
echo ">>>>>>>>running test 2378"
../source/schedule.exe 4 9 7  < ../inputs/input/bdt.91 > ../outputs/t2378
echo ">>>>>>>>running test 2379"
../source/schedule.exe 1 8 3  < ../inputs/input/bdt.9 > ../outputs/t2379
echo ">>>>>>>>running test 2380"
../source/schedule.exe 10 10 7  < ../inputs/input/bdt.2 > ../outputs/t2380
echo ">>>>>>>>running test 2381"
../source/schedule.exe 5 2 8  < ../inputs/input/bdt.41 > ../outputs/t2381
echo ">>>>>>>>running test 2382"
../source/schedule.exe 8 3 4  < ../inputs/input/bdt.84 > ../outputs/t2382
echo ">>>>>>>>running test 2383"
../source/schedule.exe 10 10 6  < ../inputs/input/bdt.20 > ../outputs/t2383
echo ">>>>>>>>running test 2384"
../source/schedule.exe 10 7 9  < ../inputs/input/bdt.22 > ../outputs/t2384
echo ">>>>>>>>running test 2385"
../source/schedule.exe 2 8 7  < ../inputs/input/bdt.100 > ../outputs/t2385
echo ">>>>>>>>running test 2386"
../source/schedule.exe 10 3 4  < ../inputs/input/bdt.6 > ../outputs/t2386
echo ">>>>>>>>running test 2387"
../source/schedule.exe 2 5 3  < ../inputs/input/bdt.46 > ../outputs/t2387
echo ">>>>>>>>running test 2388"
../source/schedule.exe 8 6 0  < ../inputs/input/bdt.16 > ../outputs/t2388
echo ">>>>>>>>running test 2389"
../source/schedule.exe 2 7 7  < ../inputs/input/bdt.77 > ../outputs/t2389
echo ">>>>>>>>running test 2390"
../source/schedule.exe 0 5 1  < ../inputs/input/bdt.1 > ../outputs/t2390
echo ">>>>>>>>running test 2391"
../source/schedule.exe 5 4 5  < ../inputs/input/bdt.20 > ../outputs/t2391
echo ">>>>>>>>running test 2392"
../source/schedule.exe 8 6 2  < ../inputs/input/bdt.35 > ../outputs/t2392
echo ">>>>>>>>running test 2393"
../source/schedule.exe 8 4 4  < ../inputs/input/bdt.63 > ../outputs/t2393
echo ">>>>>>>>running test 2394"
../source/schedule.exe 6 4 8  < ../inputs/input/bdt.82 > ../outputs/t2394
echo ">>>>>>>>running test 2395"
../source/schedule.exe 0 1 3  < ../inputs/input/bdt.80 > ../outputs/t2395
echo ">>>>>>>>running test 2396"
../source/schedule.exe 8 7 9  < ../inputs/input/bdt.47 > ../outputs/t2396
echo ">>>>>>>>running test 2397"
../source/schedule.exe 1 9 9  < ../inputs/input/bdt.27 > ../outputs/t2397
echo ">>>>>>>>running test 2398"
../source/schedule.exe 1 9 0  < ../inputs/input/bdt.39 > ../outputs/t2398
echo ">>>>>>>>running test 2399"
../source/schedule.exe 4 0 10  < ../inputs/input/bdt.83 > ../outputs/t2399
echo ">>>>>>>>running test 2400"
../source/schedule.exe 7 0 6  < ../inputs/input/bdt.38 > ../outputs/t2400
echo ">>>>>>>>running test 2401"
../source/schedule.exe 5 0 7  < ../inputs/input/bdt.30 > ../outputs/t2401
echo ">>>>>>>>running test 2402"
../source/schedule.exe 2 9 7  < ../inputs/input/bdt.74 > ../outputs/t2402
echo ">>>>>>>>running test 2403"
../source/schedule.exe 10 10 6  < ../inputs/input/bdt.42 > ../outputs/t2403
echo ">>>>>>>>running test 2404"
../source/schedule.exe 2 5 10  < ../inputs/input/bdt.25 > ../outputs/t2404
echo ">>>>>>>>running test 2405"
../source/schedule.exe 8 5 0  < ../inputs/input/bdt.31 > ../outputs/t2405
echo ">>>>>>>>running test 2406"
../source/schedule.exe 6 9 1  < ../inputs/input/bdt.37 > ../outputs/t2406
echo ">>>>>>>>running test 2407"
../source/schedule.exe 8 4 2  < ../inputs/input/bdt.29 > ../outputs/t2407
echo ">>>>>>>>running test 2408"
../source/schedule.exe 5 9 1  < ../inputs/input/bdt.91 > ../outputs/t2408
echo ">>>>>>>>running test 2409"
../source/schedule.exe 5 1 2  < ../inputs/input/bdt.95 > ../outputs/t2409
echo ">>>>>>>>running test 2410"
../source/schedule.exe 1 9 10  < ../inputs/input/bdt.79 > ../outputs/t2410
echo ">>>>>>>>running test 2411"
../source/schedule.exe 3 6 5  < ../inputs/input/bdt.83 > ../outputs/t2411
echo ">>>>>>>>running test 2412"
../source/schedule.exe 7 2 8  < ../inputs/input/bdt.86 > ../outputs/t2412
echo ">>>>>>>>running test 2413"
../source/schedule.exe 4 7 7  < ../inputs/input/bdt.83 > ../outputs/t2413
echo ">>>>>>>>running test 2414"
../source/schedule.exe 0 3 6  < ../inputs/input/bdt.36 > ../outputs/t2414
echo ">>>>>>>>running test 2415"
../source/schedule.exe 5 5 1  < ../inputs/input/bdt.49 > ../outputs/t2415
echo ">>>>>>>>running test 2416"
../source/schedule.exe 6 9 8  < ../inputs/input/bdt.64 > ../outputs/t2416
echo ">>>>>>>>running test 2417"
../source/schedule.exe 2 3 1  < ../inputs/input/nnt1 > ../outputs/t2417
echo ">>>>>>>>running test 2418"
../source/schedule.exe 2 3 1  < ../inputs/input/nnt2 > ../outputs/t2418
echo ">>>>>>>>running test 2419"
../source/schedule.exe 1 0 1  < ../inputs/input/nnt2 > ../outputs/t2419
echo ">>>>>>>>running test 2420"
../source/schedule.exe 1 0 2  < ../inputs/input/nnt3 > ../outputs/t2420
echo ">>>>>>>>running test 2421"
../source/schedule.exe 3 0 2  < ../inputs/input/nnt3 > ../outputs/t2421
echo ">>>>>>>>running test 2422"
../source/schedule.exe 3 2 2  < ../inputs/input/nnt4 > ../outputs/t2422
echo ">>>>>>>>running test 2423"
../source/schedule.exe 4 2 2  < ../inputs/input/nnt4 > ../outputs/t2423
echo ">>>>>>>>running test 2424"
../source/schedule.exe 4 0 2  < ../inputs/input/nnt5 > ../outputs/t2424
echo ">>>>>>>>running test 2425"
../source/schedule.exe 4 3 2  < ../inputs/input/nnt6 > ../outputs/t2425
echo ">>>>>>>>running test 2426"
../source/schedule.exe 4 3 2  < ../inputs/input/nnt7 > ../outputs/t2426
echo ">>>>>>>>running test 2427"
../source/schedule.exe 4 3 2  < ../inputs/input/nnt8 > ../outputs/t2427
echo ">>>>>>>>running test 2428"
../source/schedule.exe 2 3 2  < ../inputs/input/nnt8 > ../outputs/t2428
echo ">>>>>>>>running test 2429"
../source/schedule.exe 2 0 2  < ../inputs/input/nnt8 > ../outputs/t2429
echo ">>>>>>>>running test 2430"
../source/schedule.exe 2 0 2  < ../inputs/input/nnt9 > ../outputs/t2430
echo ">>>>>>>>running test 2431"
../source/schedule.exe 2 3 2  < ../inputs/input/nnt9 > ../outputs/t2431
echo ">>>>>>>>running test 2432"
../source/schedule.exe 2 3 1  < ../inputs/input/nnt9 > ../outputs/t2432
echo ">>>>>>>>running test 2433"
../source/schedule.exe 5 3 1  < ../inputs/input/nnt9 > ../outputs/t2433
echo ">>>>>>>>running test 2434"
../source/schedule.exe 5 3 1  < ../inputs/input/nnt10 > ../outputs/t2434
echo ">>>>>>>>running test 2435"
../source/schedule.exe 0 3 1  < ../inputs/input/nnt10 > ../outputs/t2435
echo ">>>>>>>>running test 2436"
../source/schedule.exe 0 1 1  < ../inputs/input/nnt10 > ../outputs/t2436
echo ">>>>>>>>running test 2437"
../source/schedule.exe 0 1 1  < ../inputs/input/nnt11 > ../outputs/t2437
echo ">>>>>>>>running test 2438"
../source/schedule.exe 3 4 1  < ../inputs/input/nnt11 > ../outputs/t2438
echo ">>>>>>>>running test 2439"
../source/schedule.exe 3 1 1  < ../inputs/input/nnt11 > ../outputs/t2439
echo ">>>>>>>>running test 2440"
../source/schedule.exe 3 1 1  < ../inputs/input/nnt12 > ../outputs/t2440
echo ">>>>>>>>running test 2441"
../source/schedule.exe 3 1 0  < ../inputs/input/nnt12 > ../outputs/t2441
echo ">>>>>>>>running test 2442"
../source/schedule.exe 5 0 0  < ../inputs/input/nnt12 > ../outputs/t2442
echo ">>>>>>>>running test 2443"
../source/schedule.exe 5 1 1  < ../inputs/input/nnt13 > ../outputs/t2443
echo ">>>>>>>>running test 2444"
../source/schedule.exe 1 1 1  < ../inputs/input/nnt13 > ../outputs/t2444
echo ">>>>>>>>running test 2445"
../source/schedule.exe 1 1 1  < ../inputs/input/nnt14 > ../outputs/t2445
echo ">>>>>>>>running test 2446"
../source/schedule.exe 3 5 2  < ../inputs/input/nnt14 > ../outputs/t2446
echo ">>>>>>>>running test 2447"
../source/schedule.exe 3 0 0  < ../inputs/input/nnt14 > ../outputs/t2447
echo ">>>>>>>>running test 2448"
../source/schedule.exe 1 0 7  < ../inputs/input/inp.hf.18 > ../outputs/t2448
echo ">>>>>>>>running test 2449"
../source/schedule.exe 3 2 4  < ../inputs/input/inp.hf.17 > ../outputs/t2449
echo ">>>>>>>>running test 2450"
../source/schedule.exe 0 1 0  < ../inputs/input/adt.55 > ../outputs/t2450
echo ">>>>>>>>running test 2451"
../source/schedule.exe 0 0 0  < ../inputs/input/adt.3 > ../outputs/t2451
echo ">>>>>>>>running test 2452"
../source/schedule.exe 1 1  < ../inputs/input/ad.2 > ../outputs/t2452
echo ">>>>>>>>running test 2453"
../source/schedule.exe 1 1  < ../inputs/input/ad.2 > ../outputs/t2453
echo ">>>>>>>>running test 2454"
../source/schedule.exe 1 1  < ../inputs/input/ad.2 > ../outputs/t2454
echo ">>>>>>>>running test 2455"
../source/schedule.exe 1 1  < ../inputs/input/ad.2 > ../outputs/t2455
echo ">>>>>>>>running test 2456"
../source/schedule.exe 1 1  < ../inputs/input/ad.2 > ../outputs/t2456
echo ">>>>>>>>running test 2457"
../source/schedule.exe 1 1  < ../inputs/input/ad.2 > ../outputs/t2457
echo ">>>>>>>>running test 2458"
../source/schedule.exe 1 1  < ../inputs/input/ad.2 > ../outputs/t2458
echo ">>>>>>>>running test 2459"
../source/schedule.exe 1 1  < ../inputs/input/ad.2 > ../outputs/t2459
echo ">>>>>>>>running test 2460"
../source/schedule.exe 0 0 0  < ../inputs/input/inp.hf.14 > ../outputs/t2460
echo ">>>>>>>>running test 2461"
../source/schedule.exe 0 1 5  < ../inputs/input/inp.hf.14 > ../outputs/t2461
echo ">>>>>>>>running test 2462"
../source/schedule.exe 0 5 1  < ../inputs/input/inp.hf.13 > ../outputs/t2462
echo ">>>>>>>>running test 2463"
../source/schedule.exe 1 2 3  < ../inputs/input/inp.hf.12 > ../outputs/t2463
echo ">>>>>>>>running test 2464"
../source/schedule.exe 0 1 0  < ../inputs/input/inp.hf.8 > ../outputs/t2464
echo ">>>>>>>>running test 2465"
../source/schedule.exe 2 1 0  < ../inputs/input/inp.hf.1 > ../outputs/t2465
echo ">>>>>>>>running test 2466"
../source/schedule.exe 1 1 0  < ../inputs/input/inp.hf.12 > ../outputs/t2466
echo ">>>>>>>>running test 2467"
../source/schedule.exe 0 2 5  < ../inputs/input/inp.hf.8 > ../outputs/t2467
echo ">>>>>>>>running test 2468"
../source/schedule.exe 0 1 2   < ../inputs/input/lu119 > ../outputs/t2468
echo ">>>>>>>>running test 2469"
../source/schedule.exe 1 0 3   < ../inputs/input/lu68 > ../outputs/t2469
echo ">>>>>>>>running test 2470"
../source/schedule.exe 3 3 1  < ../inputs/input/ft.2 > ../outputs/t2470
echo ">>>>>>>>running test 2471"
../source/schedule.exe 9 4 2  < ../inputs/input/ft.21 > ../outputs/t2471
echo ">>>>>>>>running test 2472"
../source/schedule.exe 3 9 7  < ../inputs/input/ft.1 > ../outputs/t2472
echo ">>>>>>>>running test 2473"
../source/schedule.exe 2 0 2  < ../inputs/input/ft.30 > ../outputs/t2473
echo ">>>>>>>>running test 2474"
../source/schedule.exe 6 8 3  < ../inputs/input/ft.29 > ../outputs/t2474
echo ">>>>>>>>running test 2475"
../source/schedule.exe 10 8 3  < ../inputs/input/ft.25 > ../outputs/t2475
echo ">>>>>>>>running test 2476"
../source/schedule.exe 2 7 9  < ../inputs/input/ft.6 > ../outputs/t2476
echo ">>>>>>>>running test 2477"
../source/schedule.exe 8 6 5  < ../inputs/input/ft.1 > ../outputs/t2477
echo ">>>>>>>>running test 2478"
../source/schedule.exe 2 5 6  < ../inputs/input/ft.30 > ../outputs/t2478
echo ">>>>>>>>running test 2479"
../source/schedule.exe 2 1 5  < ../inputs/input/ft.20 > ../outputs/t2479
echo ">>>>>>>>running test 2480"
../source/schedule.exe 10 0 7  < ../inputs/input/ft.25 > ../outputs/t2480
echo ">>>>>>>>running test 2481"
../source/schedule.exe 7 8 1  < ../inputs/input/ft.25 > ../outputs/t2481
echo ">>>>>>>>running test 2482"
../source/schedule.exe 10 7 9  < ../inputs/input/ft.3 > ../outputs/t2482
echo ">>>>>>>>running test 2483"
../source/schedule.exe 1 2 3  < ../inputs/input/ft.20 > ../outputs/t2483
echo ">>>>>>>>running test 2484"
../source/schedule.exe 3 7 3  < ../inputs/input/ft.18 > ../outputs/t2484
echo ">>>>>>>>running test 2485"
../source/schedule.exe 3 6 4  < ../inputs/input/ft.9 > ../outputs/t2485
echo ">>>>>>>>running test 2486"
../source/schedule.exe 7 10 9  < ../inputs/input/ft.6 > ../outputs/t2486
echo ">>>>>>>>running test 2487"
../source/schedule.exe 6 8 9  < ../inputs/input/ft.26 > ../outputs/t2487
echo ">>>>>>>>running test 2488"
../source/schedule.exe 3 1 5  < ../inputs/input/ft.8 > ../outputs/t2488
echo ">>>>>>>>running test 2489"
../source/schedule.exe 2 4 2  < ../inputs/input/ft.15 > ../outputs/t2489
echo ">>>>>>>>running test 2490"
../source/schedule.exe 6 6 0  < ../inputs/input/ft.19 > ../outputs/t2490
echo ">>>>>>>>running test 2491"
../source/schedule.exe 4 10 6  < ../inputs/input/ft.26 > ../outputs/t2491
echo ">>>>>>>>running test 2492"
../source/schedule.exe 6 0 1  < ../inputs/input/ft.4 > ../outputs/t2492
echo ">>>>>>>>running test 2493"
../source/schedule.exe 7 2 5  < ../inputs/input/ft.5 > ../outputs/t2493
echo ">>>>>>>>running test 2494"
../source/schedule.exe 9 8 0  < ../inputs/input/ft.1 > ../outputs/t2494
echo ">>>>>>>>running test 2495"
../source/schedule.exe 4 2 10  < ../inputs/input/ft.1 > ../outputs/t2495
echo ">>>>>>>>running test 2496"
../source/schedule.exe 4 1 4  < ../inputs/input/ft.14 > ../outputs/t2496
echo ">>>>>>>>running test 2497"
../source/schedule.exe 1 1 9  < ../inputs/input/ft.21 > ../outputs/t2497
echo ">>>>>>>>running test 2498"
../source/schedule.exe 2 7 3  < ../inputs/input/ft.11 > ../outputs/t2498
echo ">>>>>>>>running test 2499"
../source/schedule.exe 10 10 6  < ../inputs/input/ft.2 > ../outputs/t2499
echo ">>>>>>>>running test 2500"
../source/schedule.exe 8 9 2  < ../inputs/input/ft.8 > ../outputs/t2500
echo ">>>>>>>>running test 2501"
../source/schedule.exe 2 9 10  < ../inputs/input/ft.9 > ../outputs/t2501
echo ">>>>>>>>running test 2502"
../source/schedule.exe 6 9 1  < ../inputs/input/ft.11 > ../outputs/t2502
echo ">>>>>>>>running test 2503"
../source/schedule.exe 10 7 5  < ../inputs/input/ft.3 > ../outputs/t2503
echo ">>>>>>>>running test 2504"
../source/schedule.exe 7 1 4  < ../inputs/input/ft.19 > ../outputs/t2504
echo ">>>>>>>>running test 2505"
../source/schedule.exe 1 2 1  < ../inputs/input/ft.24 > ../outputs/t2505
echo ">>>>>>>>running test 2506"
../source/schedule.exe 3 1 6  < ../inputs/input/ft.17 > ../outputs/t2506
echo ">>>>>>>>running test 2507"
../source/schedule.exe 1 9 5  < ../inputs/input/ft.14 > ../outputs/t2507
echo ">>>>>>>>running test 2508"
../source/schedule.exe 9 5 8  < ../inputs/input/ft.8 > ../outputs/t2508
echo ">>>>>>>>running test 2509"
../source/schedule.exe 0 6 3  < ../inputs/input/ft.14 > ../outputs/t2509
echo ">>>>>>>>running test 2510"
../source/schedule.exe 8 6 2  < ../inputs/input/ft.27 > ../outputs/t2510
echo ">>>>>>>>running test 2511"
../source/schedule.exe 6 6 10  < ../inputs/input/ft.8 > ../outputs/t2511
echo ">>>>>>>>running test 2512"
../source/schedule.exe 8 2 9  < ../inputs/input/ft.19 > ../outputs/t2512
echo ">>>>>>>>running test 2513"
../source/schedule.exe 2 2 6  < ../inputs/input/ft.11 > ../outputs/t2513
echo ">>>>>>>>running test 2514"
../source/schedule.exe 4 9 4  < ../inputs/input/ft.15 > ../outputs/t2514
echo ">>>>>>>>running test 2515"
../source/schedule.exe 10 7 9  < ../inputs/input/ft.26 > ../outputs/t2515
echo ">>>>>>>>running test 2516"
../source/schedule.exe 4 7 6  < ../inputs/input/ft.24 > ../outputs/t2516
echo ">>>>>>>>running test 2517"
../source/schedule.exe 9 5 3  < ../inputs/input/ft.1 > ../outputs/t2517
echo ">>>>>>>>running test 2518"
../source/schedule.exe 3 5 9  < ../inputs/input/ft.25 > ../outputs/t2518
echo ">>>>>>>>running test 2519"
../source/schedule.exe 5 3 10  < ../inputs/input/ft.5 > ../outputs/t2519
echo ">>>>>>>>running test 2520"
../source/schedule.exe  < ../inputs/input/bdt.77 > ../outputs/t2520
echo ">>>>>>>>running test 2521"
../source/schedule.exe  < ../inputs/input/bdt.77 > ../outputs/t2521
echo ">>>>>>>>running test 2522"
../source/schedule.exe  < ../inputs/input/bdt.77 > ../outputs/t2522
echo ">>>>>>>>running test 2523"
../source/schedule.exe 1 2   < ../inputs/input/bdt.77 > ../outputs/t2523
echo ">>>>>>>>running test 2524"
../source/schedule.exe 2 3   < ../inputs/input/bdt.77 > ../outputs/t2524
echo ">>>>>>>>running test 2525"
../source/schedule.exe 2 3   < ../inputs/input/bdt.77 > ../outputs/t2525
echo ">>>>>>>>running test 2526"
../source/schedule.exe 0 0  < ../inputs/input/bdt.77 > ../outputs/t2526
echo ">>>>>>>>running test 2527"
../source/schedule.exe 0   0     < ../inputs/input/bdt.77 > ../outputs/t2527
echo ">>>>>>>>running test 2528"
../source/schedule.exe 0          0  < ../inputs/input/bdt.77 > ../outputs/t2528
echo ">>>>>>>>running test 2529"
../source/schedule.exe 1 1 1  < ../inputs/input/et.1 > ../outputs/t2529
echo ">>>>>>>>running test 2530"
../source/schedule.exe 1 2 3  < ../inputs/input/et.3 > ../outputs/t2530
echo ">>>>>>>>running test 2531"
../source/schedule.exe 1 2 3  < ../inputs/input/et.2 > ../outputs/t2531
echo ">>>>>>>>running test 2532"
../source/schedule.exe 2 1 3  < ../inputs/input/et.4 > ../outputs/t2532
echo ">>>>>>>>running test 2533"
../source/schedule.exe 3 4 1  < ../inputs/input/et.5 > ../outputs/t2533
echo ">>>>>>>>running test 2534"
../source/schedule.exe 1 2 1  < ../inputs/input/et.6 > ../outputs/t2534
echo ">>>>>>>>running test 2535"
../source/schedule.exe 2 1 2  < ../inputs/input/et.7 > ../outputs/t2535
echo ">>>>>>>>running test 2536"
../source/schedule.exe 2 3 1  < ../inputs/input/et.8 > ../outputs/t2536
echo ">>>>>>>>running test 2537"
../source/schedule.exe 2 1 1  < ../inputs/input/et.9 > ../outputs/t2537
echo ">>>>>>>>running test 2538"
../source/schedule.exe 2 5 1  < ../inputs/input/et.10 > ../outputs/t2538
echo ">>>>>>>>running test 2539"
../source/schedule.exe 0 0 0  < ../inputs/input/et.11 > ../outputs/t2539
echo ">>>>>>>>running test 2540"
../source/schedule.exe 0 1 4  < ../inputs/input/et.12 > ../outputs/t2540
echo ">>>>>>>>running test 2541"
../source/schedule.exe 1 2 3  < ../inputs/input/et.13 > ../outputs/t2541
echo ">>>>>>>>running test 2542"
../source/schedule.exe 4 1 2  < ../inputs/input/et.14 > ../outputs/t2542
echo ">>>>>>>>running test 2543"
../source/schedule.exe 1 2 3  < ../inputs/input/et.15 > ../outputs/t2543
echo ">>>>>>>>running test 2544"
../source/schedule.exe 3  1  < ../inputs/input/ft.2 > ../outputs/t2544
echo ">>>>>>>>running test 2545"
../source/schedule.exe 9  2  < ../inputs/input/ft.21 > ../outputs/t2545
echo ">>>>>>>>running test 2546"
../source/schedule.exe 3   < ../inputs/input/ft.1 > ../outputs/t2546
echo ">>>>>>>>running test 2547"
../source/schedule.exe 2  2  < ../inputs/input/ft.30 > ../outputs/t2547
echo ">>>>>>>>running test 2548"
../source/schedule.exe 6   < ../inputs/input/ft.29 > ../outputs/t2548
echo ">>>>>>>>running test 2549"
../source/schedule.exe 8 3  < ../inputs/input/ft.25 > ../outputs/t2549
echo ">>>>>>>>running test 2550"
../source/schedule.exe 2  9  < ../inputs/input/ft.6 > ../outputs/t2550
echo ">>>>>>>>running test 2551"
../source/schedule.exe 8 6   < ../inputs/input/ft.1 > ../outputs/t2551
echo ">>>>>>>>running test 2552"
../source/schedule.exe 2 5   < ../inputs/input/ft.30 > ../outputs/t2552
echo ">>>>>>>>running test 2553"
../source/schedule.exe 2  5  < ../inputs/input/ft.20 > ../outputs/t2553
echo ">>>>>>>>running test 2554"
../source/schedule.exe 2 5 0  < ../inputs/input/dt.1 > ../outputs/t2554
echo ">>>>>>>>running test 2555"
../source/schedule.exe 2 0 0  < ../inputs/input/dt.1 > ../outputs/t2555
echo ">>>>>>>>running test 2556"
../source/schedule.exe 2 0 0  < ../inputs/input/dt.2 > ../outputs/t2556
echo ">>>>>>>>running test 2557"
../source/schedule.exe 2 2 2   < ../inputs/input/dt.2 > ../outputs/t2557
echo ">>>>>>>>running test 2558"
../source/schedule.exe 0 2 1   < ../inputs/input/dt.3 > ../outputs/t2558
echo ">>>>>>>>running test 2559"
../source/schedule.exe 1 4 2   < ../inputs/input/dt.4 > ../outputs/t2559
echo ">>>>>>>>running test 2560"
../source/schedule.exe 0 4 2   < ../inputs/input/dt.5 > ../outputs/t2560
echo ">>>>>>>>running test 2561"
../source/schedule.exe 0 4 2   < ../inputs/input/dt.6 > ../outputs/t2561
echo ">>>>>>>>running test 2562"
../source/schedule.exe 1 4 2   < ../inputs/input/dt.7 > ../outputs/t2562
echo ">>>>>>>>running test 2563"
../source/schedule.exe 1 4 0   < ../inputs/input/dt.8 > ../outputs/t2563
echo ">>>>>>>>running test 2564"
../source/schedule.exe 1 4 0   < ../inputs/input/dt.9 > ../outputs/t2564
echo ">>>>>>>>running test 2565"
../source/schedule.exe 0 2 0  < ../inputs/input/dt.9 > ../outputs/t2565
echo ">>>>>>>>running test 2566"
../source/schedule.exe 1 2 1  < ../inputs/input/dt.10 > ../outputs/t2566
echo ">>>>>>>>running test 2567"
../source/schedule.exe 1 2 1  < ../inputs/input/dt.11 > ../outputs/t2567
echo ">>>>>>>>running test 2568"
../source/schedule.exe 1 2 1  < ../inputs/input/dt.12 > ../outputs/t2568
echo ">>>>>>>>running test 2569"
../source/schedule.exe 3 2 0  < ../inputs/input/dt.13 > ../outputs/t2569
echo ">>>>>>>>running test 2570"
../source/schedule.exe 3 2 0  < ../inputs/input/dt.14 > ../outputs/t2570
echo ">>>>>>>>running test 2571"
../source/schedule.exe 2 1 0   < ../inputs/input/dt.15 > ../outputs/t2571
echo ">>>>>>>>running test 2572"
../source/schedule.exe 2 1 1   < ../inputs/input/dt.16 > ../outputs/t2572
echo ">>>>>>>>running test 2573"
../source/schedule.exe 2 1 1   < ../inputs/input/dt.17 > ../outputs/t2573
echo ">>>>>>>>running test 2574"
../source/schedule.exe 2 1 1   < ../inputs/input/dt.18 > ../outputs/t2574
echo ">>>>>>>>running test 2575"
../source/schedule.exe 2 1 3   < ../inputs/input/dt.19 > ../outputs/t2575
echo ">>>>>>>>running test 2576"
../source/schedule.exe 2 1 3   < ../inputs/input/dt.20 > ../outputs/t2576
echo ">>>>>>>>running test 2577"
../source/schedule.exe 2 1 3   < ../inputs/input/dt.21 > ../outputs/t2577
echo ">>>>>>>>running test 2578"
../source/schedule.exe 2 1 3   < ../inputs/input/dt.22 > ../outputs/t2578
echo ">>>>>>>>running test 2579"
../source/schedule.exe 4 1 2   < ../inputs/input/dt.23 > ../outputs/t2579
echo ">>>>>>>>running test 2580"
../source/schedule.exe 4 1 2   < ../inputs/input/dt.24 > ../outputs/t2580
echo ">>>>>>>>running test 2581"
../source/schedule.exe 1 1 1  < ../inputs/input/ct.1 > ../outputs/t2581
echo ">>>>>>>>running test 2582"
../source/schedule.exe 0 2 1  < ../inputs/input/ct.2 > ../outputs/t2582
echo ">>>>>>>>running test 2583"
../source/schedule.exe 3 2 0  < ../inputs/input/ct.3 > ../outputs/t2583
echo ">>>>>>>>running test 2584"
../source/schedule.exe 3 0 0  < ../inputs/input/ct.3 > ../outputs/t2584
echo ">>>>>>>>running test 2585"
../source/schedule.exe 3 0 0  < ../inputs/input/ct.4 > ../outputs/t2585
echo ">>>>>>>>running test 2586"
../source/schedule.exe 1 1 1  < ../inputs/input/ct.4 > ../outputs/t2586
echo ">>>>>>>>running test 2587"
../source/schedule.exe 1 1 1  < ../inputs/input/ct.5 > ../outputs/t2587
echo ">>>>>>>>running test 2588"
../source/schedule.exe 3 0 3  < ../inputs/input/ct.5 > ../outputs/t2588
echo ">>>>>>>>running test 2589"
../source/schedule.exe 3 0 3  < ../inputs/input/ct.6 > ../outputs/t2589
echo ">>>>>>>>running test 2590"
../source/schedule.exe 3 1 3  < ../inputs/input/ct.7 > ../outputs/t2590
echo ">>>>>>>>running test 2591"
../source/schedule.exe 1 0 0  < ../inputs/input/ct.7 > ../outputs/t2591
echo ">>>>>>>>running test 2592"
../source/schedule.exe 1 9 9  < ../inputs/input/ct.8 > ../outputs/t2592
echo ">>>>>>>>running test 2593"
../source/schedule.exe 1 3 1  < ../inputs/input/ct.8 > ../outputs/t2593
echo ">>>>>>>>running test 2594"
../source/schedule.exe 1 3 1  < ../inputs/input/ct.9 > ../outputs/t2594
echo ">>>>>>>>running test 2595"
../source/schedule.exe 1 3 1  < ../inputs/input/ct.10 > ../outputs/t2595
echo ">>>>>>>>running test 2596"
../source/schedule.exe 1 3 1  < ../inputs/input/ct.11 > ../outputs/t2596
echo ">>>>>>>>running test 2597"
../source/schedule.exe 0 3 0  < ../inputs/input/ct.11 > ../outputs/t2597
echo ">>>>>>>>running test 2598"
../source/schedule.exe 1 3 0  < ../inputs/input/ct.12 > ../outputs/t2598
echo ">>>>>>>>running test 2599"
../source/schedule.exe 1 3 2  < ../inputs/input/ct.13 > ../outputs/t2599
echo ">>>>>>>>running test 2600"
../source/schedule.exe 3 4 5  < ../inputs/input/ct.14 > ../outputs/t2600
echo ">>>>>>>>running test 2601"
../source/schedule.exe 1 2 3  < ../inputs/input/ct.15 > ../outputs/t2601
echo ">>>>>>>>running test 2602"
../source/schedule.exe 4 2 3  < ../inputs/input/ct.16 > ../outputs/t2602
echo ">>>>>>>>running test 2603"
../source/schedule.exe 2 2 2  < ../inputs/input/ct.17 > ../outputs/t2603
echo ">>>>>>>>running test 2604"
../source/schedule.exe 4 5 6  < ../inputs/input/ct.18 > ../outputs/t2604
echo ">>>>>>>>running test 2605"
../source/schedule.exe 3 3 4  < ../inputs/input/ct.19 > ../outputs/t2605
echo ">>>>>>>>running test 2606"
../source/schedule.exe 3 2 4  < ../inputs/input/ct.20 > ../outputs/t2606
echo ">>>>>>>>running test 2607"
../source/schedule.exe 3 2 4  < ../inputs/input/ct.21 > ../outputs/t2607
echo ">>>>>>>>running test 2608"
../source/schedule.exe 0 1 2  < ../inputs/input/ct.22 > ../outputs/t2608
echo ">>>>>>>>running test 2609"
../source/schedule.exe 1 0 5  < ../inputs/input/ct.23 > ../outputs/t2609
echo ">>>>>>>>running test 2610"
../source/schedule.exe 3 4 2  < ../inputs/input/ct.24 > ../outputs/t2610
echo ">>>>>>>>running test 2611"
../source/schedule.exe 3 2 1  < ../inputs/input/ct.25 > ../outputs/t2611
echo ">>>>>>>>running test 2612"
../source/schedule.exe 7 1 3  < ../inputs/input/ct.26 > ../outputs/t2612
echo ">>>>>>>>running test 2613"
../source/schedule.exe 2 1 4  < ../inputs/input/ct.27 > ../outputs/t2613
echo ">>>>>>>>running test 2614"
../source/schedule.exe 3 1 5  < ../inputs/input/ct.28 > ../outputs/t2614
echo ">>>>>>>>running test 2615"
../source/schedule.exe 0 0 0  < ../inputs/input/ct.29 > ../outputs/t2615
echo ">>>>>>>>running test 2616"
../source/schedule.exe 1 2 0  < ../inputs/input/ct.30 > ../outputs/t2616
echo ">>>>>>>>running test 2617"
../source/schedule.exe 2 3 1  < ../inputs/input/ct.31 > ../outputs/t2617
echo ">>>>>>>>running test 2618"
../source/schedule.exe 1 4 2  < ../inputs/input/ct.32 > ../outputs/t2618
echo ">>>>>>>>running test 2619"
../source/schedule.exe 3 5 0  < ../inputs/input/ct.33 > ../outputs/t2619
echo ">>>>>>>>running test 2620"
../source/schedule.exe 0 3 4  < ../inputs/input/ct.34 > ../outputs/t2620
echo ">>>>>>>>running test 2621"
../source/schedule.exe 1 2 3  < ../inputs/input/ct.35 > ../outputs/t2621
echo ">>>>>>>>running test 2622"
../source/schedule.exe 6 7 3  < ../inputs/input/ct.36 > ../outputs/t2622
echo ">>>>>>>>running test 2623"
../source/schedule.exe 1 2 0  < ../inputs/input/ct.37 > ../outputs/t2623
echo ">>>>>>>>running test 2624"
../source/schedule.exe 3 4 5  < ../inputs/input/ct.38 > ../outputs/t2624
echo ">>>>>>>>running test 2625"
../source/schedule.exe 2 3 1  < ../inputs/input/ct.39 > ../outputs/t2625
echo ">>>>>>>>running test 2626"
../source/schedule.exe 1 4 5  < ../inputs/input/ct.40 > ../outputs/t2626
echo ">>>>>>>>running test 2627"
../source/schedule.exe 1 5 6  < ../inputs/input/ct.41 > ../outputs/t2627
echo ">>>>>>>>running test 2628"
../source/schedule.exe 1 2 4  < ../inputs/input/ct.42 > ../outputs/t2628
echo ">>>>>>>>running test 2629"
../source/schedule.exe 0 8 4  < ../inputs/input/ct.43 > ../outputs/t2629
echo ">>>>>>>>running test 2630"
../source/schedule.exe 0 3 4  < ../inputs/input/ct.44 > ../outputs/t2630
echo ">>>>>>>>running test 2631"
../source/schedule.exe 0 3 2  < ../inputs/input/ct.45 > ../outputs/t2631
echo ">>>>>>>>running test 2632"
../source/schedule.exe 8 2 4  < ../inputs/input/ct.46 > ../outputs/t2632
echo ">>>>>>>>running test 2633"
../source/schedule.exe 2 2 1  < ../inputs/input/ct.47 > ../outputs/t2633
echo ">>>>>>>>running test 2634"
../source/schedule.exe 1 2 4  < ../inputs/input/ct.48 > ../outputs/t2634
echo ">>>>>>>>running test 2635"
../source/schedule.exe 0 9 0  < ../inputs/input/ct.49 > ../outputs/t2635
echo ">>>>>>>>running test 2636"
../source/schedule.exe 1 3 2  < ../inputs/input/ct.50 > ../outputs/t2636
echo ">>>>>>>>running test 2637"
../source/schedule.exe 0 9 2  < ../inputs/input/ct.51 > ../outputs/t2637
echo ">>>>>>>>running test 2638"
../source/schedule.exe 2 1 2  < ../inputs/input/ct.52 > ../outputs/t2638
echo ">>>>>>>>running test 2639"
../source/schedule.exe 2 4 2  < ../inputs/input/ct.53 > ../outputs/t2639
echo ">>>>>>>>running test 2640"
../source/schedule.exe 2 4 2  < ../inputs/input/ct.54 > ../outputs/t2640
echo ">>>>>>>>running test 2641"
../source/schedule.exe 2 2 2  < ../inputs/input/ct.55 > ../outputs/t2641
echo ">>>>>>>>running test 2642"
../source/schedule.exe 2 4 2  < ../inputs/input/ct.56 > ../outputs/t2642
echo ">>>>>>>>running test 2643"
../source/schedule.exe 2 4 2  < ../inputs/input/ct.57 > ../outputs/t2643
echo ">>>>>>>>running test 2644"
../source/schedule.exe 2 1 2  < ../inputs/input/ct.58 > ../outputs/t2644
echo ">>>>>>>>running test 2645"
../source/schedule.exe 2 4 2  < ../inputs/input/ct.59 > ../outputs/t2645
echo ">>>>>>>>running test 2646"
../source/schedule.exe 2 4 2  < ../inputs/input/ct.60 > ../outputs/t2646
echo ">>>>>>>>running test 2647"
../source/schedule.exe 2 2 2  < ../inputs/input/ct.61 > ../outputs/t2647
echo ">>>>>>>>running test 2648"
../source/schedule.exe 2 0 2  < ../inputs/input/ct.62 > ../outputs/t2648
echo ">>>>>>>>running test 2649"
../source/schedule.exe 2 4 2  < ../inputs/input/ct.63 > ../outputs/t2649
echo ">>>>>>>>running test 2650"
../source/schedule.exe 2 4 2  < ../inputs/input/ct.65 > ../outputs/t2650
